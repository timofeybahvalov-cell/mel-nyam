# Источники футажей и звуков «Мел-Ням»

Видео (YouTube, зелёный фон / «футажи для монтажа»), скачаны yt-dlp, затем кеинг `tools/key_clips.py`:

| реакция в игре | YouTube ID | фрагмент |
|---|---|---|
| idle (смотрит в камеру) | XaCqQrXMjEs | 0.30–2.70 c |
| smile (улыбается) | XaCqQrXMjEs | 5.00–6.80 c |
| omg («Оу май гад») | J728pqNq-T0 | 3.30–4.80 c |
| am («Ам-ам-ам») | a_4FPR8pi1w | 0.00–3.60 c |
| sad (грустит) | idT3wNIGPxo | 4.70–7.20 c |
| bored («Бррр», скучает) | 8RHiHJXlwW8 | 0.00–1.85 c |
| laugh (смеётся) | wBXB2bVjHUg | 0.00–1.90 c |
| angry (злится, краснеет) | lUEDgjLZkDc | 4.95–6.45 c |
| rage (вскакивает и кричит) | lUEDgjLZkDc | 0.95–3.15 c |
| faster («Быстрее! Быстрее!») | vsh-FiuvtSw | 3.40–4.30 c |
| best («Кто лучший?», смеётся) | MXGkApFQjxQ | 1.15–2.35 c |

Звуковые мемы: myinstants.com (`snd_src/*.mp3`), нарезка по таймкодам из распознавания речи
(faster-whisper, см. `transcripts_whisper.txt`), нецензурные фрагменты вырезаны.

Реплики версии 0.2 (`snd_src/`, таймкоды — в `tools/make_assets.py`, таблица `VOICE`):

| реплика в игре | файл | откуда |
|---|---|---|
| «Ребята, всем привет! С вами блогер Меллстрой!» | `bloger-melstroi.mp3` | myinstants.com |
| «Я уже красный! Культурно не получится…» | `yt-ya-uzhe-krasnyi.mp3` | YouTube s72tdWU8ukA |
| «Дай его!» | `dai-ego-khammam.mp3` | myinstants.com |
| «…давай!», «Эх ты…» | `yt-davai-eh-ty.mp3` | YouTube 7zBDB0r9fbo |
| «Начинаем наше лудо-приключение! Да-да, нет-нет, да будет свет» | `yt-ludo-priklyuchenie.mp3` | YouTube u3ULgC9bAHc |
| «Быстрее! Быстрее!» | `yt-bystree-bystree.mp3` | YouTube vsh-FiuvtSw |
| «Кто лучший? Ахаха!» | `yt-kto-luchshii.mp3` | YouTube MXGkApFQjxQ |
| крик | `yt-krichit.mp3` | YouTube lUEDgjLZkDc |

Ругательства в этих репликах заменены писком 1 кГц (`('bleep', секунды)` в таблице `VOICE`).
Каждая нарезанная реплика проверена распознаванием речи.

Не нашлось: ролик «Я уже красный» на зелёном фоне (на YouTube он закрыт возрастным ограничением, а открытая версия снята
в комнате, без зелёного фона). Поэтому голос взят из оригинала, а на экране в этот момент — другой злой футаж, покрашенный в красный.

Остальное:

- Фоны десяти локаций, чекушка, стол и груша (`art_src/`) сгенерированы нейросетью специально для игры.
- Звёзды, пузырь, кнопки, свечение, все звуковые эффекты и музыка созданы кодом в `tools/make_assets.py`.
- Шрифт `fonts/Nunito.ttf` — Nunito, лицензия SIL Open Font License.
- `src/stb_image.h` — stb_image v2.32, public domain / MIT.
