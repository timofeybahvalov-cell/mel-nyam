# Источники футажей и звуков «Мел-Ням»

Видео (YouTube, зелёный фон / «футажи для монтажа»), скачаны yt-dlp, затем кеинг `tools/key_clips.py`:

| реакция в игре | YouTube ID | фрагмент |
|---|---|---|
| idle (смотрит в камеру) | XaCqQrXMjEs | 0.30–2.70 c |
| smile (улыбается) | XaCqQrXMjEs | 5.00–6.80 c |
| omg («Оу май гад») | J728pqNq-T0 | 3.30–4.80 c |
| am («Ам-ам-ам») | a_4FPR8pi1w | 0.00–3.60 c |
| sad (грустит) | idT3wNIGPxo | 4.70–7.20 c |
| bored («Бррр», скучает) | 8RHiHJXlwW8 | 0.00–1.85 c |
| laugh (смеётся) | wBXB2bVjHUg | 0.00–1.90 c |

Звуковые мемы: myinstants.com (`snd_src/*.mp3`), нарезка по таймкодам из распознавания речи
(faster-whisper, см. `transcripts_whisper.txt`), нецензурные фрагменты вырезаны.

Остальное:

- Фоны трёх локаций, чекушка, стол и груша (`art_src/`) сгенерированы нейросетью специально для игры.
- Звёзды, пузырь, кнопки, свечение, все звуковые эффекты и музыка созданы кодом в `tools/make_assets.py`.
- Шрифт `fonts/Nunito.ttf` — Nunito, лицензия SIL Open Font License.
- `src/stb_image.h` — stb_image v2.32, public domain / MIT.
