#include "sim.h"
#include <math.h>
#include <string.h>

#define GRAV 1050.0f
#define BUOY 430.0f
#define DAMP_AIR 0.9997f
#define DAMP_BUB 0.970f
#define NODE_DAMP 0.985f
#define STAR_R 43.0f
#define BUBBLE_R 46.0f
#define SPIKE_R 21.0f
#define BLOW_RANGE 400.0f
#define BLOW_V 540.0f

static float dist2(float ax, float ay, float bx, float by) { float dx = bx - ax, dy = by - ay; return sqrtf(dx * dx + dy * dy); }

static void rope_relax(Sim *s, Rope *r, int iters) {
    int n = r->n; const Pin *p = &s->pin[r->pin];
    for (int it = 0; it < iters; it++) {
        r->p[0].x = p->x; r->p[0].y = p->y;
        if (!r->cut || s->state == ST_PLAY) { r->p[n - 1].x = s->c.x; r->p[n - 1].y = s->c.y; }
        for (int i = 0; i < n - 1; i++) {
            if (r->cut && i == r->cut_at) continue;
            Pt *a = &r->p[i], *b = &r->p[i + 1];
            float dx = b->x - a->x, dy = b->y - a->y, d = sqrtf(dx * dx + dy * dy);
            if (d <= r->seg || d < 1e-5f) continue;
            float wa = (i == 0) ? 0.0f : 1.0f, wb = (i + 1 == n - 1 && (!r->cut || s->state == ST_PLAY)) ? 0.0f : 1.0f;
            float tot = wa + wb; if (tot <= 0) continue;
            float k = (d - r->seg) / d / tot;
            a->x += dx * k * wa; a->y += dy * k * wa; b->x -= dx * k * wb; b->y -= dy * k * wb;
        }
    }
}
static void rope_integrate(Sim *s, Rope *r) {
    int n = r->n;
    for (int i = 1; i < n; i++) {
        if (i == n - 1 && (!r->cut || s->state == ST_PLAY)) break;
        Pt *q = &r->p[i];
        float vx = (q->x - q->px) * NODE_DAMP, vy = (q->y - q->py) * NODE_DAMP;
        q->px = q->x; q->py = q->y; q->x += vx; q->y += vy + GRAV * SIM_DT * SIM_DT;
    }
}
static int rope_make(Sim *s, int pin, float len) {
    int ri = -1;
    for (int i = 0; i < MAX_ROPES; i++) if (!s->rope[i].active) { ri = i; break; }
    if (ri < 0) return -1;
    Rope *r = &s->rope[ri]; memset(r, 0, sizeof(*r));
    Pin *p = &s->pin[pin]; float d = dist2(p->x, p->y, s->c.x, s->c.y);
    if (len < d) len = d;
    if (len < 24) len = 24;
    int n = (int)(len / 14.0f) + 2; if (n < 3) n = 3; if (n > ROPE_NODES) n = ROPE_NODES;
    r->active = 1; r->pin = pin; r->n = n; r->len = len; r->seg = len / (float)(n - 1); r->fade = 1;
    float sag = len > d ? sqrtf(len * len - d * d) * 0.45f : 0.0f;
    for (int i = 0; i < n; i++) {
        float t = (float)i / (float)(n - 1);
        r->p[i].x = p->x + (s->c.x - p->x) * t; r->p[i].y = p->y + (s->c.y - p->y) * t + sinf(PI * t) * sag;
        r->p[i].px = r->p[i].x; r->p[i].py = r->p[i].y;
    }
    p->used = 1; p->rope = ri;
    return ri;
}

void sim_load(Sim *s, const LObj *o) {
    memset(s, 0, sizeof(*s));
    s->mx = -9999; s->my = -9999;
    const LObj *q;
    for (q = o; q->type != O_END; q++) if (q->type == O_CANDY) { s->c.x = s->c.px = q->x; s->c.y = s->c.py = q->y; }
    for (q = o; q->type != O_END; q++) {
        switch (q->type) {
        case O_PIN: case O_AUTOPIN:
            if (s->npins < MAX_PINS) {
                Pin *p = &s->pin[s->npins]; p->x = q->x; p->y = q->y; p->rope = -1;
                p->autopin = (q->type == O_AUTOPIN); p->r = q->a;
                if (!p->autopin) rope_make(s, s->npins, q->a);
                s->npins++;
            } break;
        case O_STAR: if (s->nstars < MAX_STARS) { s->star[s->nstars].x = q->x; s->star[s->nstars].y = q->y; s->nstars++; } break;
        case O_BUBBLE: if (s->nbubbles < MAX_BUBBLES) { s->bubble[s->nbubbles].x = q->x; s->bubble[s->nbubbles].y = q->y; s->nbubbles++; } break;
        case O_BLOWER: if (s->nblowers < MAX_BLOWERS) {
                Blower *b = &s->blower[s->nblowers++]; b->x = q->x; b->y = q->y; b->ang = q->a * (PI / 180.0f);
                b->dx = cosf(b->ang); b->dy = sinf(b->ang);
            } break;
        case O_SPIKES: if (s->nspikes < MAX_SPIKES) { Spikes *k = &s->spikes[s->nspikes++]; k->x0 = q->x; k->y0 = q->y; k->x1 = q->a; k->y1 = q->b; } break;
        case O_MEL: s->mx = q->x; s->my = q->y; s->has_mel = 1; break;
        default: break;
        }
    }
    /* settle the ropes (bottle must not move during settling: only the taut ones hold it) */
    for (int it = 0; it < 4; it++)
        for (int i = 0; i < MAX_ROPES; i++) if (s->rope[i].active) {
            Rope *r = &s->rope[i]; const Pin *p = &s->pin[r->pin];
            float dx = s->c.x - p->x, dy = s->c.y - p->y, d = sqrtf(dx * dx + dy * dy);
            if (d > r->len) { float k = r->len / d; s->c.x = p->x + dx * k; s->c.y = p->y + dy * k; }
        }
    s->c.px = s->c.x; s->c.py = s->c.y;
    for (int k = 0; k < 90; k++)
        for (int i = 0; i < MAX_ROPES; i++) if (s->rope[i].active) { rope_integrate(s, &s->rope[i]); rope_relax(s, &s->rope[i], 8); }
    for (int i = 0; i < MAX_ROPES; i++) if (s->rope[i].active) for (int j = 0; j < s->rope[i].n; j++) { s->rope[i].p[j].px = s->rope[i].p[j].x; s->rope[i].p[j].py = s->rope[i].p[j].y; }
    s->mouth_dist = dist2(s->c.x, s->c.y, s->mx, s->my);
}

static float seg_point_dist(float x0, float y0, float x1, float y1, float px, float py) {
    float dx = x1 - x0, dy = y1 - y0, l2 = dx * dx + dy * dy, t = l2 > 1e-6f ? ((px - x0) * dx + (py - y0) * dy) / l2 : 0.0f;
    t = clampf(t, 0, 1);
    return dist2(x0 + dx * t, y0 + dy * t, px, py);
}
static float wrap_pi(float a) { while (a > PI) a -= TAU; while (a < -PI) a += TAU; return a; }

void sim_step(Sim *s) {
    Pt *c = &s->c;
    s->time += SIM_DT;
    if (s->state == ST_PLAY) {
        float damp = s->in_bubble ? DAMP_BUB : DAMP_AIR;
        float vx = (c->x - c->px) * damp, vy = (c->y - c->py) * damp;
        c->px = c->x; c->py = c->y;
        c->x += vx; c->y += vy + (s->in_bubble ? -BUOY : GRAV) * SIM_DT * SIM_DT;
        if (s->in_bubble) s->bubble_t += SIM_DT;
        for (int it = 0; it < 5; it++)
            for (int i = 0; i < MAX_ROPES; i++) {
                Rope *r = &s->rope[i]; if (!r->active || r->cut) continue;
                const Pin *p = &s->pin[r->pin];
                float dx = c->x - p->x, dy = c->y - p->y, d = sqrtf(dx * dx + dy * dy);
                if (d > r->len) { float k = r->len / d; c->x = p->x + dx * k; c->y = p->y + dy * k; }
            }
        for (int i = 0; i < s->npins; i++) {
            Pin *p = &s->pin[i];
            if (p->autopin && !p->used && dist2(c->x, c->y, p->x, p->y) < p->r) {
                if (rope_make(s, i, 0) >= 0) { s->events |= EV_ATTACH; s->ev_x = p->x; s->ev_y = p->y; p->pulse = 1; }
            }
        }
        if (!s->in_bubble)
            for (int i = 0; i < s->nbubbles; i++) {
                Bubble *b = &s->bubble[i];
                if (!b->used && dist2(c->x, c->y, b->x, b->y) < BUBBLE_R) {
                    b->used = 1; s->in_bubble = 1; s->bubble_t = 0; s->events |= EV_BUBBLE_IN;
                    /* entering a bubble kills most of the momentum */
                    c->px = c->x - (c->x - c->px) * 0.35f; c->py = c->y - (c->y - c->py) * 0.35f;
                    break;
                }
            }
        for (int i = 0; i < s->nstars; i++) {
            Star *t = &s->star[i];
            if (!t->got && dist2(c->x, c->y, t->x, t->y) < STAR_R) { t->got = 1; t->t = 0; s->stars++; s->events |= EV_STAR; s->ev_star = i; }
        }
        for (int i = 0; i < s->nspikes; i++) {
            const Spikes *k = &s->spikes[i];
            if (seg_point_dist(k->x0, k->y0, k->x1, k->y1, c->x, c->y) < SPIKE_R) { s->state = ST_BROKEN; s->state_t = 0; s->events |= EV_BREAK; s->in_bubble = 0; break; }
        }
        s->mouth_dist = dist2(c->x, c->y, s->mx, s->my);
        if (s->state == ST_PLAY && s->has_mel && s->mouth_dist < MOUTH_R) { s->state = ST_EATEN; s->state_t = 0; s->events |= EV_EAT; s->in_bubble = 0; }
        if (s->state == ST_PLAY && (c->x < -70 || c->x > DESIGN_W + 70 || c->y > DESIGN_H + 80 || c->y < -90)) { s->state = ST_LOST; s->state_t = 0; s->events |= EV_LOST; }
        /* visual rotation of the bottle: the neck points along the taut ropes */
        float tx = 0, ty = 0; int nt = 0;
        for (int i = 0; i < MAX_ROPES; i++) {
            const Rope *r = &s->rope[i]; if (!r->active || r->cut) continue;
            const Pin *p = &s->pin[r->pin];
            float dx = p->x - c->x, dy = p->y - c->y, d = sqrtf(dx * dx + dy * dy);
            if (d > r->len * 0.94f && d > 1) { tx += dx / d; ty += dy / d; nt++; }
        }
        if (nt) { float diff = wrap_pi(atan2f(tx, -ty) - s->rot); s->rotv += diff * 140.0f * SIM_DT; s->rotv *= 0.94f; }
        else if (s->in_bubble) { float diff = wrap_pi(sinf(s->time * 2.2f) * 0.18f - s->rot); s->rotv += diff * 30.0f * SIM_DT; s->rotv *= 0.95f; }
        else { float want = clampf((c->x - c->px) / SIM_DT * 0.012f, -7.0f, 7.0f); s->rotv += (want - s->rotv) * 0.01f; }
        s->rot = wrap_pi(s->rot + s->rotv * SIM_DT);
    } else {
        s->state_t += SIM_DT;
    }
    for (int i = 0; i < MAX_ROPES; i++) {
        Rope *r = &s->rope[i]; if (!r->active) continue;
        rope_integrate(s, r); rope_relax(s, r, 8);
        if (r->cut) { r->fade -= SIM_DT / 0.5f; if (r->fade <= 0) r->active = 0; }
    }
    for (int i = 0; i < s->nblowers; i++) { Blower *b = &s->blower[i]; if (b->squeeze > 0) { b->squeeze -= SIM_DT * 3.5f; if (b->squeeze < 0) b->squeeze = 0; } }
    for (int i = 0; i < s->npins; i++) { Pin *p = &s->pin[i]; if (p->pulse > 0) { p->pulse -= SIM_DT * 2.5f; if (p->pulse < 0) p->pulse = 0; } }
    for (int i = 0; i < s->nstars; i++) s->star[i].t += SIM_DT;
}

static void rope_cut_at(Sim *s, Rope *r, int link, float x, float y) {
    r->cut = 1; r->cut_at = link; r->fade = 1;
    s->events |= EV_CUT; s->cut_x = x; s->cut_y = y;
    /* give the loose ends a little kick */
    Pt *a = &r->p[link], *b = &r->p[link + 1];
    if (link > 0) { a->px = a->x + 0.6f; a->py = a->y + 0.3f; }
    if (link + 1 < r->n - 1) { b->px = b->x - 0.6f; b->py = b->y + 0.3f; }
}
static int seg_seg(float ax, float ay, float bx, float by, float cx, float cy, float dx, float dy, float *ix, float *iy) {
    float rx = bx - ax, ry = by - ay, sx = dx - cx, sy = dy - cy, den = rx * sy - ry * sx;
    if (fabsf(den) < 1e-6f) return 0;
    float t = ((cx - ax) * sy - (cy - ay) * sx) / den, u = ((cx - ax) * ry - (cy - ay) * rx) / den;
    if (t < 0 || t > 1 || u < 0 || u > 1) return 0;
    *ix = ax + rx * t; *iy = ay + ry * t; return 1;
}
int sim_cut(Sim *s, float x0, float y0, float x1, float y1) {
    int cnt = 0;
    if (s->state != ST_PLAY) return 0;
    for (int i = 0; i < MAX_ROPES; i++) {
        Rope *r = &s->rope[i]; if (!r->active || r->cut) continue;
        for (int j = 0; j < r->n - 1; j++) {
            float ix, iy; const Pt *a = &r->p[j], *b = &r->p[j + 1];
            if (seg_seg(x0, y0, x1, y1, a->x, a->y, b->x, b->y, &ix, &iy)) { rope_cut_at(s, r, j, ix, iy); cnt++; break; }
        }
    }
    return cnt;
}
int sim_cut_pin(Sim *s, int pin) {
    if (s->state != ST_PLAY || pin < 0 || pin >= s->npins) return 0;
    for (int i = 0; i < MAX_ROPES; i++) {
        Rope *r = &s->rope[i];
        if (r->active && !r->cut && r->pin == pin) { int j = r->n / 2; if (j > r->n - 2) j = r->n - 2; rope_cut_at(s, r, j, (r->p[j].x + r->p[j + 1].x) * 0.5f, (r->p[j].y + r->p[j + 1].y) * 0.5f); return 1; }
    }
    return 0;
}
int sim_pop(Sim *s) {
    if (s->state != ST_PLAY || !s->in_bubble) return 0;
    s->in_bubble = 0; s->events |= EV_BUBBLE_POP; s->ev_x = s->c.x; s->ev_y = s->c.y;
    return 1;
}
int sim_blow(Sim *s, int i) {
    if (i < 0 || i >= s->nblowers) return 0;
    Blower *b = &s->blower[i];
    if (b->squeeze > 0.55f) return 0;                    /* still squeezed */
    b->squeeze = 1; s->events |= EV_BLOW; s->ev_blower = i;
    if (s->state != ST_PLAY) return 1;
    float rx = s->c.x - b->x, ry = s->c.y - b->y, along = rx * b->dx + ry * b->dy, lat = fabsf(rx * -b->dy + ry * b->dx);
    if (along > -20 && along < BLOW_RANGE && lat < 62.0f + along * 0.16f) {
        float k = BLOW_V * clampf(1.15f * (1.0f - along / BLOW_RANGE), 0, 1);   /* fades to zero at the range limit */
        s->c.px -= b->dx * k * SIM_DT; s->c.py -= b->dy * k * SIM_DT;
    }
    return 1;
}
int sim_tap(Sim *s, float x, float y) {
    if (s->state != ST_PLAY) return 0;
    if (s->in_bubble && dist2(x, y, s->c.x, s->c.y) < BUBBLE_VIS_R + 12) return sim_pop(s);
    for (int i = 0; i < s->nblowers; i++) if (dist2(x, y, s->blower[i].x, s->blower[i].y) < 50) return sim_blow(s, i);
    return 0;
}
int sim_do(Sim *s, const Step *st) {
    switch (st->act) {
    case ACT_CUT: return sim_cut_pin(s, st->arg);
    case ACT_POP: return sim_pop(s);
    case ACT_BLOW: return sim_blow(s, st->arg);
    }
    return 0;
}
int sim_ropes_left(const Sim *s) { int n = 0; for (int i = 0; i < MAX_ROPES; i++) if (s->rope[i].active && !s->rope[i].cut) n++; return n; }
