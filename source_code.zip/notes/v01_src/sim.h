/* Game simulation (physics + rules) of «Мел-Ням». No rendering here:
   the same code drives the game, the level generator and the solver. */
#ifndef MN_SIM_H
#define MN_SIM_H
#include "engine.h"

enum { O_END = 0, O_CANDY, O_PIN, O_AUTOPIN, O_STAR, O_BUBBLE, O_BLOWER, O_SPIKES, O_MEL };
/* O_CANDY   x,y
   O_PIN     x,y  a = rope length (0: exactly the distance to the bottle)
   O_AUTOPIN x,y  a = catch radius
   O_STAR    x,y
   O_BUBBLE  x,y
   O_BLOWER  x,y  a = direction in degrees (0 = blows right, 90 = down, 180 = left, 270 = up)
   O_SPIKES  x,y  a,b = second end point
   O_MEL     x,y  (mouth position)                                              */
typedef struct { int type; float x, y, a, b; } LObj;

enum { ACT_END = 0, ACT_CUT, ACT_POP, ACT_BLOW };
typedef struct { float t; int act, arg; } Step;

typedef struct {
    const char *name, *hint;
    int box;
    const LObj *objs;
    const Step *demo;          /* a known 3-star solution */
} LevelDef;

#define SIM_DT (1.0f / 120.0f)
#define MAX_ROPES 8
#define ROPE_NODES 52
#define MAX_PINS 8
#define MAX_STARS 3
#define MAX_BUBBLES 4
#define MAX_BLOWERS 4
#define MAX_SPIKES 6

#define CANDY_R 24.0f
#define BUBBLE_VIS_R 46.0f
#define MOUTH_R 46.0f
#define MOUTH_NEAR 175.0f

typedef struct { float x, y, px, py; } Pt;
typedef struct { int active, cut, pin, n, cut_at; float seg, len, fade; Pt p[ROPE_NODES]; } Rope;
typedef struct { float x, y, r; int autopin, used, rope; float pulse; } Pin;
typedef struct { float x, y; int got; float t; } Star;
typedef struct { float x, y; int used; } Bubble;
typedef struct { float x, y, dx, dy, ang, squeeze; } Blower;
typedef struct { float x0, y0, x1, y1; } Spikes;

enum { EV_CUT = 1, EV_STAR = 2, EV_BUBBLE_IN = 4, EV_BUBBLE_POP = 8, EV_BLOW = 16, EV_ATTACH = 32,
       EV_EAT = 64, EV_LOST = 128, EV_BREAK = 256 };
enum { ST_PLAY = 0, ST_EATEN, ST_LOST, ST_BROKEN };

typedef struct {
    Pt c; float rot, rotv; int in_bubble; float bubble_t;
    Rope rope[MAX_ROPES];
    Pin pin[MAX_PINS]; int npins;
    Star star[MAX_STARS]; int nstars;
    Bubble bubble[MAX_BUBBLES]; int nbubbles;
    Blower blower[MAX_BLOWERS]; int nblowers;
    Spikes spikes[MAX_SPIKES]; int nspikes;
    float mx, my; int has_mel;
    int state; float time, state_t; int stars;
    u32 events; float ev_x, ev_y; int ev_star, ev_blower; float cut_x, cut_y;
    float mouth_dist;
} Sim;

void sim_load(Sim *s, const LObj *objs);
void sim_step(Sim *s);                                           /* advance SIM_DT */
int  sim_cut(Sim *s, float x0, float y0, float x1, float y1);    /* swipe segment; returns ropes cut */
int  sim_cut_pin(Sim *s, int pin);                               /* cut the rope of pin #  */
int  sim_tap(Sim *s, float x, float y);                          /* pop bubble / squeeze blower */
int  sim_pop(Sim *s);
int  sim_blow(Sim *s, int blower);
int  sim_do(Sim *s, const Step *st);                             /* run one scripted action */
int  sim_ropes_left(const Sim *s);

#endif
