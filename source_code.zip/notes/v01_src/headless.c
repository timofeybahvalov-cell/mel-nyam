/* Headless test harness: runs the real game (engine + sim + game.c) without a window,
   feeds scripted input and dumps frames (PPM) / audio (WAV).
   build: gcc -O2 -Isrc tools/headless.c src/game.c src/engine.c src/sim.c -lm -o /tmp/headless
   usage: headless <pack.bin> <outdir> <script file | demotest | perf>
   script: size W H | dbg CMD ARG | wait S | down/move/up X Y | click X Y | swipe X0 Y0 X1 Y1 | key N |
           shot NAME | audio | state | rec N | recstop
   rec N   writes every N-th frame as raw BGRA (W*H*4 bytes) into the command in $REC_CMD (popen), e.g.
           REC_CMD="ffmpeg -y -f rawvideo -pix_fmt bgra -s 1280x720 -r 60 -i - out.mp4", or into <outdir>/rec.bgra  */
#include "engine.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static u8 g_save[256]; static int g_save_n;
void plat_audio_lock(void) {}
void plat_audio_unlock(void) {}
void plat_save(const void *d, int n) { if (n > 256) n = 256; memcpy(g_save, d, n); g_save_n = n; }
int plat_load(void *d, int max) { int n = g_save_n < max ? g_save_n : max; memcpy(d, g_save, n); return n; }
void plat_quit(void) { printf("[plat_quit]\n"); }
void plat_fullscreen(void) { printf("[plat_fullscreen]\n"); }
int plat_caps(void) { return 3; }
void plat_log(const char *s) { printf("[log] %s\n", s); }

static u32 *fb; static int W = 1280, H = 720; static const char *outdir = "/tmp";
static FILE *wav; static int wav_frames; static double audio_acc;
static FILE *rec; static int rec_every = 1, rec_i, rec_pipe;
/* capture camera: `cam W H MODE [RATE]` records a W x H window of the frame instead of the whole frame.
   MODE 0 fixed (centre set by `camfix X Y`, design units), 1 follow the bottle and hold, 2 follow, then return to the centre.
   In modes 1 and 2 the window also shifts so that Mel's face and his speech bubble are not cut off (see cam_step).
   `log PATH` writes one line per recorded frame (F), per action (E), plus A (audio start), R (record start) and M (Mel's face). */
static int cam_w, cam_h, cam_mode, cam_ready; static float cam_cx = 640, cam_cy = 360, cam_tx = 640, cam_ty = 360, cam_rate = 4.5f;
static FILE *caplog; static long step_n; static int rec_n, ev_seen;
static void cam_step(float dt) {
    float rate = cam_rate;
    if (cam_mode >= 1) {
        int st = app_debug(4, 0), ph = (st >> 8) & 15, sc = (st >> 12) & 15; float bxo = app_debug(12, 0) / 8.0f, byo = app_debug(13, 0) / 8.0f;
        if (sc == 3 && ph == 0) { cam_tx = bxo; cam_ty = byo; }
        else if (cam_mode == 2 && sc == 3) { cam_tx = 640; cam_ty = 360; }
        if (sc == 3) {      /* keep Mel's face and his whole speech bubble inside the window: always once the level is over, during play only while the bottle stays inside too */
            float hw0 = cam_w * 1280.0f / W * 0.5f, fx = app_debug(14, 0) / 8.0f, l = fx - 80, r = fx + 80; int say = app_debug(22, 0);
            if (say) { float bx = fx + app_debug(23, 0) / 8.0f, bw = app_debug(24, 0) / 8.0f + 8; if (bx - bw * 0.5f < l) l = bx - bw * 0.5f; if (bx + bw * 0.5f > r) r = bx + bw * 0.5f; }
            l -= 18; r += 18;
            if (ph != 0 || say) {
                float t = cam_tx;
                if (r - l > 2 * hw0) t = (l + r) * 0.5f; else { if (t < r - hw0) t = r - hw0; if (t > l + hw0) t = l + hw0; }
                if (ph != 0 || fabsf(t - bxo) < hw0 - 70) {
                    cam_tx = t;
                    if (cam_ready && r - l <= 2 * hw0 && (cam_cx < r - hw0 - 1 || cam_cx > l + hw0 + 1) && rate < 13.0f) rate = 13.0f;     /* a quick move while the bubble is still cut off */
                }
            }
        }
    }
    float tx = cam_tx, ty = cam_ty, hw = cam_w * 1280.0f / W * 0.5f, hh = cam_h * 720.0f / H * 0.5f;
    if (tx < hw) tx = hw; if (tx > 1280 - hw) tx = 1280 - hw; if (ty < hh) ty = hh; if (ty > 720 - hh) ty = 720 - hh;
    if (!cam_ready) { cam_cx = tx; cam_cy = ty; cam_ready = 1; }
    float k = 1.0f - expf(-dt * rate), ky = 1.0f - expf(-dt * cam_rate); cam_cx += (tx - cam_cx) * k; cam_cy += (ty - cam_cy) * ky;
}
static double now_s(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec + ts.tv_nsec * 1e-9; }
static void shot(const char *name) {
    char path[512]; snprintf(path, sizeof(path), "%s/%s.ppm", outdir, name);
    FILE *f = fopen(path, "wb"); if (!f) return;
    fprintf(f, "P6\n%d %d\n255\n", W, H);
    u8 *row = malloc(W * 3);
    for (int y = 0; y < H; y++) { for (int x = 0; x < W; x++) { u32 p = fb[y * W + x]; row[x * 3] = (p >> 16) & 255; row[x * 3 + 1] = (p >> 8) & 255; row[x * 3 + 2] = p & 255; } fwrite(row, 1, W * 3, f); }
    free(row); fclose(f);
}
static void frame(float dt) {
    app_frame(dt); step_n++;
    if (cam_w) cam_step(dt);
    if (caplog) { int n = app_debug(16, 0); if (n != ev_seen) { ev_seen = n; fprintf(caplog, "E %d %ld %d %.2f %.2f\n", rec_n, step_n, app_debug(17, 0), app_debug(18, 0) / 8.0f, app_debug(19, 0) / 8.0f); } }
    if (rec && (rec_i++ % rec_every) == 0) {
        int x0 = 0, y0 = 0, w = W, h = H;
        if (cam_w) {
            w = cam_w; h = cam_h; x0 = (int)(cam_cx * W / 1280.0f - w * 0.5f + 0.5f); y0 = (int)(cam_cy * H / 720.0f - h * 0.5f + 0.5f);
            if (x0 < 0) x0 = 0; if (x0 > W - w) x0 = W - w; if (y0 < 0) y0 = 0; if (y0 > H - h) y0 = H - h;
        }
        if (w == W && h == H) fwrite(fb, 4, (size_t)W * H, rec); else for (int y = 0; y < h; y++) fwrite(fb + (size_t)(y0 + y) * W + x0, 4, (size_t)w, rec);
        if (caplog) { int st = app_debug(4, 0); fprintf(caplog, "F %d %ld %.2f %.2f %d %d %d %d %d\n", rec_n, step_n, app_debug(12, 0) / 8.0f, app_debug(13, 0) / 8.0f, (st >> 8) & 15, (st >> 4) & 15, st & 15, x0, y0); }
        rec_n++;
    }
    if (wav) { audio_acc += dt * 44100.0; int n = (int)audio_acc; audio_acc -= n; static i16 buf[8192 * 2]; while (n > 0) { int k = n > 8192 ? 8192 : n; audio_mix(buf, k); fwrite(buf, 4, k, wav); wav_frames += k; n -= k; } }
}
static void wait_s(float s) { int n = (int)(s * 60.0f + 0.5f); for (int i = 0; i < n; i++) frame(1.0f / 60.0f); }
static void resize(int w, int h) { W = w; H = h; free(fb); fb = calloc((size_t)w * h, 4); app_resize(fb, w, h); }
static void wav_begin(void) { char p[512]; snprintf(p, sizeof(p), "%s/audio.wav", outdir); wav = fopen(p, "wb"); u8 hdr[44] = { 0 }; fwrite(hdr, 1, 44, wav); }
static void wav_end(void) {
    if (!wav) return; u32 n = wav_frames * 4; u8 h[44]; memcpy(h, "RIFF", 4); u32 v = 36 + n; memcpy(h + 4, &v, 4); memcpy(h + 8, "WAVEfmt ", 8);
    v = 16; memcpy(h + 16, &v, 4); u16 s = 1; memcpy(h + 20, &s, 2); s = 2; memcpy(h + 22, &s, 2); v = 44100; memcpy(h + 24, &v, 4); v = 44100 * 4; memcpy(h + 28, &v, 4);
    s = 4; memcpy(h + 32, &s, 2); s = 16; memcpy(h + 34, &s, 2); memcpy(h + 36, "data", 4); memcpy(h + 40, &n, 4);
    fseek(wav, 0, SEEK_SET); fwrite(h, 1, 44, wav); fclose(wav); wav = NULL;
}

int main(int argc, char **argv) {
    if (argc < 4) { printf("usage: headless pack outdir script|demotest|perf\n"); return 1; }
    FILE *f = fopen(argv[1], "rb"); if (!f) { printf("no pack\n"); return 1; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); u8 *pack = malloc(n); if (fread(pack, 1, n, f) != (size_t)n) return 1; fclose(f);
    outdir = argv[2];
    double t0 = now_s();
    app_init(pack, (int)n, 44100);
    printf("init %.0f ms\n", (now_s() - t0) * 1000);
    resize(1280, 720);
    if (!strcmp(argv[3], "demotest")) {
        int bad = 0;
        for (int lv = 0; lv < 18; lv++) {
            app_debug(2, lv); int res = -1, stars = 0; float t = 0;
            for (int i = 0; i < 60 * 20; i++) {
                frame(1.0f / 60.0f); t += 1.0f / 60.0f; int st = app_debug(4, 0);
                if ((st & 15) != 0) { res = st & 15; stars = (st >> 4) & 15; break; }
            }
            printf("level %2d: %s stars=%d t=%.2f\n", lv + 1, res == 1 ? "EATEN" : (res == 2 ? "LOST" : (res == 3 ? "BROKEN" : "TIMEOUT")), stars, t);
            if (res != 1 || stars != 3) bad++;
        }
        printf("demotest: %d bad\n", bad); return bad;
    }
    if (!strcmp(argv[3], "perf")) {
        int sizes[3][2] = { { 1280, 720 }, { 1920, 1080 }, { 2560, 1440 } };
        for (int k = 0; k < 3; k++) {
            resize(sizes[k][0], sizes[k][1]); app_debug(2, 17); wait_s(0.5f);
            double a = now_s(); for (int i = 0; i < 240; i++) frame(1.0f / 60.0f); double b = now_s();
            printf("%dx%d: %.2f ms/frame (level 18 demo)\n", W, H, (b - a) * 1000 / 240);
            app_debug(5, 0); wait_s(0.5f); a = now_s(); for (int i = 0; i < 120; i++) frame(1.0f / 60.0f); b = now_s();
            printf("%dx%d: %.2f ms/frame (menu)\n", W, H, (b - a) * 1000 / 120);
        }
        return 0;
    }
    FILE *sf = fopen(argv[3], "r"); if (!sf) { printf("no script\n"); return 1; }
    char line[512], a[64], name[256]; float x0, y0, x1, y1, d; int i0, i1;
    while (fgets(line, sizeof(line), sf)) {
        if (line[0] == '#' || sscanf(line, "%63s", a) != 1) continue;
        if (!strcmp(a, "size") && sscanf(line, "%*s %d %d", &i0, &i1) == 2) resize(i0, i1);
        else if (!strcmp(a, "dbg") && sscanf(line, "%*s %d %d", &i0, &i1) == 2) app_debug(i0, i1);
        else if (!strcmp(a, "wait") && sscanf(line, "%*s %f", &d) == 1) wait_s(d);
        else if (!strcmp(a, "down") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) app_pointer(1, x0, y0);
        else if (!strcmp(a, "move") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) app_pointer(0, x0, y0);
        else if (!strcmp(a, "up") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) app_pointer(2, x0, y0);
        else if (!strcmp(a, "click") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) { app_pointer(0, x0, y0); frame(1 / 60.f); app_pointer(1, x0, y0); frame(1 / 60.f); frame(1 / 60.f); app_pointer(2, x0, y0); frame(1 / 60.f); }
        else if (!strcmp(a, "swipe") && sscanf(line, "%*s %f %f %f %f", &x0, &y0, &x1, &y1) == 4) {
            app_pointer(0, x0, y0); app_pointer(1, x0, y0); frame(1 / 60.f);
            for (int i = 1; i <= 6; i++) { app_pointer(0, x0 + (x1 - x0) * i / 6.f, y0 + (y1 - y0) * i / 6.f); frame(1 / 60.f); }
            app_pointer(2, x1, y1); frame(1 / 60.f);
        }
        else if (!strcmp(a, "key") && sscanf(line, "%*s %d", &i0) == 1) { app_key(i0, 1); app_key(i0, 0); }
        else if (!strcmp(a, "shot") && sscanf(line, "%*s %255s", name) == 1) shot(name);
        else if (!strcmp(a, "audio")) { wav_begin(); if (caplog) fprintf(caplog, "A %ld\n", step_n); }
        else if (!strcmp(a, "log") && sscanf(line, "%*s %255s", name) == 1) { if (caplog) fclose(caplog); caplog = fopen(name, "w"); }
        else if (!strcmp(a, "cam")) { cam_w = cam_h = cam_mode = 0; cam_rate = 4.5f; sscanf(line, "%*s %d %d %d %f", &cam_w, &cam_h, &cam_mode, &cam_rate); if (cam_w > W) cam_w = W; if (cam_h > H) cam_h = H; cam_ready = 0; }
        else if (!strcmp(a, "camfix") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) { cam_tx = x0; cam_ty = y0; }
        else if (!strcmp(a, "rec")) {
            rec_every = 1; sscanf(line, "%*s %d", &rec_every); if (rec_every < 1) rec_every = 1; rec_i = 0; rec_n = 0;
            if (caplog) fprintf(caplog, "R %ld\nM %.2f %.2f\n", step_n, app_debug(14, 0) / 8.0f, app_debug(15, 0) / 8.0f);
            const char *cmd = getenv("REC_CMD");
            if (cmd && cmd[0]) { rec = popen(cmd, "w"); rec_pipe = 1; } else { char p[512]; snprintf(p, sizeof(p), "%s/rec.bgra", outdir); rec = fopen(p, "wb"); rec_pipe = 0; }
        }
        else if (!strcmp(a, "recstop")) { if (rec) { if (rec_pipe) pclose(rec); else fclose(rec); rec = NULL; } }
        else if (!strcmp(a, "state")) { int st = app_debug(4, 0); printf("state: sim=%d stars=%d phase=%d scr=%d demo=%d total=%d\n", st & 15, (st >> 4) & 15, (st >> 8) & 15, (st >> 12) & 15, (st >> 16) & 1, app_debug(9, 0)); }
        else printf("?? %s", line);
    }
    wav_end();
    if (rec) { if (rec_pipe) pclose(rec); else fclose(rec); }
    if (caplog) fclose(caplog);
    return 0;
}
