/* «Мел-Ням» for Android. build_apk.sh puts this script into the <head> of the page that goes into the APK,
   so it runs inside the app's WebView before the game starts. The page itself is the same MelNyam.html as on the site.

   1. Saves. The WebView writes localStorage to disk with a delay of a few seconds, so a result could be lost when the
      app is swiped away right after a level. Every «melnyam.*» entry (progress, nick, own replays, own levels) is
      therefore copied at once into the app's own storage through the MelNyamApp bridge (MainActivity.Bridge), and is
      put back from there when the game starts. That storage is also what Android backs up.
   2. MelNyamBack() is called for the system Back button: 'stay' = the game handled it, 'exit' = leave the app. */
(function () {
  'use strict';
  var A = window.MelNyamApp, PRE = 'melnyam.';
  function own(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  if (A) {
    try {
      var ls = window.localStorage, kept = JSON.parse(A.dump() || '{}'), k, i, extra = [];
      for (k in kept) if (own(kept, k) && k.indexOf(PRE) === 0 && ls.getItem(k) !== kept[k]) ls.setItem(k, kept[k]);
      for (i = 0; i < ls.length; i++) { k = ls.key(i); if (k && k.indexOf(PRE) === 0 && !own(kept, k)) extra.push(k); }
      for (i = 0; i < extra.length; i++) A.put(extra[i], ls.getItem(extra[i]));
      var SP = window.Storage.prototype, set = SP.setItem, del = SP.removeItem;
      SP.setItem = function (key, val) {
        try { if (this === ls && String(key).indexOf(PRE) === 0) A.put(String(key), String(val)); } catch (e) {}
        return set.apply(this, arguments);
      };
      SP.removeItem = function (key) {
        try { if (this === ls && String(key).indexOf(PRE) === 0) A.del(String(key)); } catch (e) {}
        return del.apply(this, arguments);
      };
    } catch (e) { try { console.log('MelNyam: saves bridge is off: ' + e); } catch (e2) {} }
  }
  window.MelNyamBack = function () {
    try {
      var M = window.MelNyam;
      if (!M || !M.stats().started) return 'exit';
      if (((M.debug(4, 0) >> 12) & 15) === 0 && !M.debug(98, 0)) return 'exit';     /* main menu, no window open */
      M.key(1);                                                                     /* the same as Esc: pause, close, one screen back */
      return 'stay';
    } catch (e) { return 'exit'; }
  };
})();
