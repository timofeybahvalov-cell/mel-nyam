#!/usr/bin/env python3
"""Launcher icons of the Android version, drawn from the same bottle picture as the icon of the .exe and of the site.

    python3 android/make_icons.py        (needs PIL, numpy, opencv; the result is kept in android/res/mipmap-*)

Android 8+ uses the adaptive icon: ic_launcher_bg (gradient) + ic_launcher_fg (bottle); the launcher cuts its own shape
out of the middle 72 of 108 units, so the bottle stays inside the 66-unit safe circle.
Android 7 uses the ready-made picture ic_launcher.png.
"""
import os, sys
import numpy as np
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, 'tools'))
import make_assets as MA

TOP, BOT = np.array([120, 70, 235], np.float32), np.array([40, 28, 120], np.float32)     # the gradient of gen/icon.png
DENS = (('mdpi', 1.0), ('hdpi', 1.5), ('xhdpi', 2.0), ('xxhdpi', 3.0), ('xxxhdpi', 4.0))

def bottle(height):
    """the bottle sticker, `height` pixels tall before it is tilted"""
    b = MA.key_generated(os.path.join(ROOT, 'art_src', 'bottle_src.png'), 'magenta')
    b = MA.resize_rgba(b, int(round(b.shape[1] * height / b.shape[0])), height)
    b = MA.sticker(b, max(2, round(height * 3 / 132)))                       # the same outline as in the game: 3 px on a 132 px bottle
    return Image.fromarray(b, 'RGBA').rotate(-16, resample=Image.BICUBIC, expand=True)

def gradient(size, y0, y1):
    """vertical gradient TOP..BOT between the rows y0..y1, flat outside"""
    t = np.clip((np.arange(size, dtype=np.float32) - y0) / max(1.0, y1 - y0), 0, 1)[:, None, None]
    g = np.zeros((size, size, 4), np.float32); g[..., :3] = TOP * (1 - t) + BOT * t; g[..., 3] = 255
    return Image.fromarray(g.astype(np.uint8), 'RGBA')

def save(im, name, dens, px):
    d = os.path.join(HERE, 'res', 'mipmap-' + dens); os.makedirs(d, exist_ok=True)
    im.resize((px, px), Image.LANCZOS).save(os.path.join(d, name), optimize=True)

# ---- legacy icon: the picture of gen/icon.png, drawn large
S = 768
legacy = gradient(S, 0, S - 1)
bt = bottle(int(S * 0.80)); legacy.alpha_composite(bt, ((S - bt.width) // 2, (S - bt.height) // 2))
mask = Image.new('L', (S * 2, S * 2), 0)
ImageDraw.Draw(mask).rounded_rectangle([S * 2 * 0.031, S * 2 * 0.031, S * 2 * 0.969, S * 2 * 0.969], radius=S * 2 * 0.19, fill=255)
legacy.putalpha(mask.resize((S, S), Image.LANCZOS))

# ---- adaptive icon, 108 units = A pixels
A = 864
bg = gradient(A, A * 18 / 108, A * 90 / 108)                                # the whole gradient inside the visible 72 units
fg = Image.new('RGBA', (A, A), (0, 0, 0, 0))
bt = bottle(int(A * 0.555)); fg.alpha_composite(bt, ((A - bt.width) // 2, (A - bt.height) // 2))
bb = fg.getbbox(); r = max(np.hypot(x - A / 2, y - A / 2) for x in (bb[0], bb[2]) for y in (bb[1], bb[3]))
print('bottle box %s, farthest corner %.1f of 108 units from the centre (safe circle: 33)' % (bb, r * 108 / A))

for dens, k in DENS:
    save(legacy, 'ic_launcher.png', dens, int(48 * k))
    save(bg, 'ic_launcher_bg.png', dens, int(108 * k))
    save(fg, 'ic_launcher_fg.png', dens, int(108 * k))

# ---- preview: how launchers will show it
P = 288
def shaped(kind):
    full = Image.alpha_composite(bg, fg).crop((A * 18 // 108, A * 18 // 108, A * 90 // 108, A * 90 // 108)).resize((P, P), Image.LANCZOS)
    m = Image.new('L', (P * 4, P * 4), 0); d = ImageDraw.Draw(m)
    if kind == 'circle': d.ellipse([0, 0, P * 4 - 1, P * 4 - 1], fill=255)
    elif kind == 'squircle': d.rounded_rectangle([0, 0, P * 4 - 1, P * 4 - 1], radius=P * 4 * 0.30, fill=255)
    else: d.rounded_rectangle([0, 0, P * 4 - 1, P * 4 - 1], radius=P * 4 * 0.12, fill=255)
    full.putalpha(m.resize((P, P), Image.LANCZOS)); return full
sheet = Image.new('RGB', (P * 4 + 100, P + 40), (32, 34, 40))
for i, im in enumerate([shaped('circle'), shaped('squircle'), shaped('square'), legacy.resize((P, P), Image.LANCZOS)]):
    sheet.paste(im, (20 + i * (P + 20), 20), im)
out = os.environ.get('MN_ICON_PREVIEW')
if out: sheet.save(out, quality=92)
print('icons written to', os.path.join(HERE, 'res'))
