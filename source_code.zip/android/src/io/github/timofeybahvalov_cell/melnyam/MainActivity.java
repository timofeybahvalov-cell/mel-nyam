package io.github.timofeybahvalov_cell.melnyam;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * «Мел-Ням» for Android.
 *
 * The whole game is assets/MelNyam.html: the same page as on the site (WebAssembly build of the C sources) plus
 * web/boot.js in its head. This activity shows it in one full-screen WebView. The page is served from inside the APK
 * under an https address (the way androidx WebViewAssetLoader does it), so the game behaves exactly as on the site:
 * it works without the internet, and the records table is reached over the network like from any browser.
 */
public final class MainActivity extends Activity {
    private static final String TAG = "MelNyam";
    private static final String HOST = "appassets.androidplatform.net";    /* reserved for pages that live inside an app */
    private static final String PAGE = "/assets/MelNyam.html";
    private static final String START = "https://" + HOST + PAGE;
    private static final String SAVE_PREFIX = "melnyam.";
    private static final int BG = 0xFF05040C;
    private static final int FILL = ViewGroup.LayoutParams.MATCH_PARENT;

    private FrameLayout root;
    private WebView web;
    private SharedPreferences saves;
    private boolean resumed;
    private int restarts;
    private long restartsSince;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) Api28.useCutoutArea(getWindow());
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        saves = getSharedPreferences("saves", MODE_PRIVATE);
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {     /* test builds only (MN_APK_DEBUG=1): the page can be inspected from a computer */
            try { WebView.setWebContentsDebuggingEnabled(true); } catch (Throwable t) { /* no WebView */ }
        }
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root, new ViewGroup.LayoutParams(FILL, FILL));
        hideSystemBars();
        startGame();
    }

    /* ---------------------------------------------------------------- the game page */
    private void startGame() {
        root.removeAllViews();
        WebView v;
        try {
            v = new WebView(this);
        } catch (Throwable t) {                                          /* no WebView on the device, or it is being updated right now */
            Log.e(TAG, "no WebView", t);
            showFailure();
            return;
        }
        v.setBackgroundColor(BG);
        v.setOverScrollMode(View.OVER_SCROLL_NEVER);
        v.setVerticalScrollBarEnabled(false);
        v.setHorizontalScrollBarEnabled(false);
        v.setHapticFeedbackEnabled(false);
        v.setOnLongClickListener(new View.OnLongClickListener() {         /* no text-selection menu over the game */
            @Override public boolean onLongClick(View x) { return true; }
        });

        WebSettings s = v.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                                    /* localStorage: progress, replays, own levels */
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);                                      /* obey the page's <meta name="viewport"> */
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);                                              /* the system font size must not scale the page */
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setGeolocationEnabled(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);

        v.addJavascriptInterface(new Bridge(), "MelNyamApp");
        v.setWebViewClient(new Client());
        v.setWebChromeClient(new Chrome());
        root.addView(v, new FrameLayout.LayoutParams(FILL, FILL));
        web = v;
        v.requestFocus();
        v.loadUrl(START);
    }

    private void showFailure() {
        TextView t = new TextView(this);
        t.setText("Не получилось открыть игру.\n\nОбнови приложения «Android System WebView» и Chrome в Google Play, потом запусти игру ещё раз.");
        t.setTextColor(0xFFE9E4FF);
        t.setTextSize(18);
        t.setGravity(Gravity.CENTER);
        int p = (int) (32 * getResources().getDisplayMetrics().density);
        t.setPadding(p, p, p, p);
        root.removeAllViews();
        root.addView(t, new FrameLayout.LayoutParams(FILL, FILL));
    }

    private void dropWebView(WebView v) {
        try { root.removeView(v); } catch (Throwable t) { /* already removed */ }
        try { v.destroy(); } catch (Throwable t) { /* already destroyed */ }
    }

    /** Anything that is not the game page is opened outside of the app. */
    private boolean leaveApp(Uri u) {
        if (u != null && HOST.equalsIgnoreCase(u.getHost())) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Throwable t) { /* nothing can open it */ }
        return true;
    }

    private final class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (u == null || !HOST.equalsIgnoreCase(u.getHost())) return null;       /* online.json and the records table: the real network */
            if (PAGE.equals(u.getPath())) {
                try {
                    InputStream in = getAssets().open("MelNyam.html");
                    Map<String, String> h = new HashMap<String, String>();
                    h.put("Cache-Control", "no-store");
                    return new WebResourceResponse("text/html", "utf-8", 200, "OK", h, in);
                } catch (Throwable t) {
                    Log.e(TAG, "asset", t);
                }
            }
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return leaveApp(r.getUrl()); }

        @Override
        @SuppressWarnings("deprecation")
        public boolean shouldOverrideUrlLoading(WebView v, String url) { return leaveApp(url == null ? null : Uri.parse(url)); }

        /** Android 8+: the system may kill the page's process to free memory while the game is in the background. Start the page again instead of crashing. */
        @Override
        public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
            Log.w(TAG, "the page process is gone");
            dropWebView(v);
            if (v == web) {
                web = null;
                long now = SystemClock.elapsedRealtime();
                if (now - restartsSince > 60000) { restartsSince = now; restarts = 0; }
                if (++restarts > 3) showFailure();                       /* it keeps dying: do not loop */
                else if (resumed) startGame();                           /* otherwise onResume() starts it */
            }
            return true;
        }
    }

    private static final class Chrome extends WebChromeClient {
        @Override
        public boolean onConsoleMessage(ConsoleMessage m) {
            Log.i(TAG, m.message() + " (line " + m.lineNumber() + ")");
            return true;
        }
    }

    /** Called by web/boot.js: the game's saves are kept in the app's own storage as well. */
    private final class Bridge {
        @JavascriptInterface
        public String dump() {
            try {
                JSONObject o = new JSONObject();
                for (Map.Entry<String, ?> e : saves.getAll().entrySet()) {
                    if (e.getValue() instanceof String) o.put(e.getKey(), (String) e.getValue());
                }
                return o.toString();
            } catch (Throwable t) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void put(String key, String value) {
            if (key != null && value != null && key.startsWith(SAVE_PREFIX)) saves.edit().putString(key, value).apply();
        }

        @JavascriptInterface
        public void del(String key) {
            if (key != null) saves.edit().remove(key).apply();
        }
    }

    /* ---------------------------------------------------------------- system things */
    @Override
    public void onBackPressed() {
        final WebView v = web;
        if (v == null) { moveTaskToBack(true); return; }
        v.evaluateJavascript("typeof MelNyamBack==='function'?MelNyamBack():'exit'", new ValueCallback<String>() {
            @Override public void onReceiveValue(String answer) {
                if (answer == null || !answer.contains("stay")) moveTaskToBack(true);      /* main menu: leave, the game stays in memory */
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (web == null) { restarts = 0; startGame(); } else web.onResume();
        hideSystemBars();
    }

    @Override
    protected void onPause() {
        resumed = false;
        if (web != null) web.onPause();                                  /* the page becomes hidden: it stops drawing and mutes itself */
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (web != null) { WebView v = web; web = null; dropWebView(v); }
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused) hideSystemBars();
    }

    /** Full screen without the status and navigation bars; a swipe from the edge shows them for a moment.
     *  These flags are the old way of doing it, but they work the same on every Android from 7 to 15. */
    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    /** Phones with a camera cutout: the window takes the whole screen, so the 16:9 picture stays in the middle of it.
     *  Kept in its own class: the field does not exist before Android 9. */
    private static final class Api28 {
        static void useCutoutArea(Window w) {
            try {
                WindowManager.LayoutParams lp = w.getAttributes();
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(lp);
            } catch (Throwable t) { /* keep the default */ }
        }
    }

}
