package io.github.timofeybahvalov_cell.melnyam;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * «Мел-Ням» for Android.
 *
 * The whole game is assets/MelNyam.html: the same page as on the site (WebAssembly build of the C sources) plus
 * web/boot.js in its head. This activity shows it in one full-screen WebView. The page is served from inside the APK
 * under an https address (the way androidx WebViewAssetLoader does it), so the game behaves exactly as on the site:
 * it works without the internet, and the records table is reached over the network like from any browser.
 *
 * Since 0.4 the app can also update itself (see "the update" below): the game asks for it, the new APK is downloaded
 * from the game's site, checked, and handed to the system installer, which asks the player to confirm.
 */
public final class MainActivity extends Activity {
    private static final String TAG = "MelNyam";
    private static final String HOST = "appassets.androidplatform.net";    /* reserved for pages that live inside an app */
    private static final String PAGE = "/assets/MelNyam.html";
    private static final String START = "https://" + HOST + PAGE;
    private static final String SAVE_PREFIX = "melnyam.";
    private static final int BG = 0xFF05040C;
    private static final int FILL = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final String ACTION_INSTALL = "io.github.timofeybahvalov_cell.melnyam.INSTALL_RESULT";
    /* the update, as the game sees it (src/engine.h, PC_UPDATE_STATE): 0 nothing, 1..99 downloading, 200 handed to the installer, below 0 failed */
    private static final int UPD_NET = -1, UPD_BAD = -2, UPD_WRITE = -3, UPD_REFUSED = -4, UPD_INSTALLING = 200;
    private static final AtomicInteger updState = new AtomicInteger(0);

    private FrameLayout root;
    private WebView web;
    private SharedPreferences saves;
    private boolean resumed;
    private boolean debuggable;
    private int restarts;
    private long restartsSince;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) Api28.useCutoutArea(getWindow());
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        saves = getSharedPreferences("saves", MODE_PRIVATE);
        debuggable = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        if (debuggable) {                                                 /* test builds only (MN_APK_DEBUG=1): the page can be inspected from a computer */
            try { WebView.setWebContentsDebuggingEnabled(true); } catch (Throwable t) { /* no WebView */ }
        }
        if (updState.get() == 0) deleteDownload();                        /* what an update left behind */
        installAnswer(getIntent());
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root, new ViewGroup.LayoutParams(FILL, FILL));
        hideSystemBars();
        startGame();
    }

    /* ---------------------------------------------------------------- the game page */
    private void startGame() {
        root.removeAllViews();
        WebView v;
        try {
            v = new WebView(this);
        } catch (Throwable t) {                                          /* no WebView on the device, or it is being updated right now */
            Log.e(TAG, "no WebView", t);
            showFailure();
            return;
        }
        v.setBackgroundColor(BG);
        v.setOverScrollMode(View.OVER_SCROLL_NEVER);
        v.setVerticalScrollBarEnabled(false);
        v.setHorizontalScrollBarEnabled(false);
        v.setHapticFeedbackEnabled(false);
        v.setOnLongClickListener(new View.OnLongClickListener() {         /* no text-selection menu over the game */
            @Override public boolean onLongClick(View x) { return true; }
        });

        WebSettings s = v.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                                    /* localStorage: progress, replays, own levels */
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);                                      /* obey the page's <meta name="viewport"> */
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);                                              /* the system font size must not scale the page */
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setGeolocationEnabled(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        if (debuggable) s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);      /* test builds: a stand-in table on this computer, without https */

        v.addJavascriptInterface(new Bridge(), "MelNyamApp");
        v.setWebViewClient(new Client());
        v.setWebChromeClient(new Chrome());
        root.addView(v, new FrameLayout.LayoutParams(FILL, FILL));
        web = v;
        v.requestFocus();
        v.loadUrl(START);
    }

    private void showFailure() {
        TextView t = new TextView(this);
        t.setText("Не получилось открыть игру.\n\nОбнови приложения «Android System WebView» и Chrome в Google Play, потом запусти игру ещё раз.");
        t.setTextColor(0xFFE9E4FF);
        t.setTextSize(18);
        t.setGravity(Gravity.CENTER);
        int p = (int) (32 * getResources().getDisplayMetrics().density);
        t.setPadding(p, p, p, p);
        root.removeAllViews();
        root.addView(t, new FrameLayout.LayoutParams(FILL, FILL));
    }

    private void dropWebView(WebView v) {
        try { root.removeView(v); } catch (Throwable t) { /* already removed */ }
        try { v.destroy(); } catch (Throwable t) { /* already destroyed */ }
    }

    /** Anything that is not the game page is opened outside of the app. */
    private boolean leaveApp(Uri u) {
        if (u != null && HOST.equalsIgnoreCase(u.getHost())) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Throwable t) { /* nothing can open it */ }
        return true;
    }

    private final class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (u == null || !HOST.equalsIgnoreCase(u.getHost())) return null;       /* online.json and the records table: the real network */
            if (PAGE.equals(u.getPath())) {
                try {
                    InputStream in = getAssets().open("MelNyam.html");
                    Map<String, String> h = new HashMap<String, String>();
                    h.put("Cache-Control", "no-store");
                    return new WebResourceResponse("text/html", "utf-8", 200, "OK", h, in);
                } catch (Throwable t) {
                    Log.e(TAG, "asset", t);
                }
            }
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return leaveApp(r.getUrl()); }

        @Override
        @SuppressWarnings("deprecation")
        public boolean shouldOverrideUrlLoading(WebView v, String url) { return leaveApp(url == null ? null : Uri.parse(url)); }

        /** Android 8+: the system may kill the page's process to free memory while the game is in the background. Start the page again instead of crashing. */
        @Override
        public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
            Log.w(TAG, "the page process is gone");
            dropWebView(v);
            if (v == web) {
                web = null;
                long now = SystemClock.elapsedRealtime();
                if (now - restartsSince > 60000) { restartsSince = now; restarts = 0; }
                if (++restarts > 3) showFailure();                       /* it keeps dying: do not loop */
                else if (resumed) startGame();                           /* otherwise onResume() starts it */
            }
            return true;
        }
    }

    private final class Chrome extends WebChromeClient {
        @Override
        public boolean onConsoleMessage(ConsoleMessage m) {
            Log.i(TAG, m.message() + " (line " + m.lineNumber() + ")");
            return true;
        }

        /** V0.6: the page asks for the microphone (the little Mel repeats what he hears). Only the game's own page may have it, and only sound. */
        @Override
        public void onPermissionRequest(final PermissionRequest req) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        boolean audio = false;
                        String[] want = req.getResources();
                        if (want != null) for (String r : want) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) audio = true;
                        Uri o = req.getOrigin();
                        if (!audio || o == null || !HOST.equalsIgnoreCase(o.getHost())) { req.deny(); return; }
                        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { req.grant(new String[] { PermissionRequest.RESOURCE_AUDIO_CAPTURE }); return; }
                        if (pendingMic != null) { try { pendingMic.deny(); } catch (Throwable t) { /* answered already */ } }
                        pendingMic = req;
                        requestPermissions(new String[] { Manifest.permission.RECORD_AUDIO }, REQ_MIC);      /* the system's own question: «Разрешить записывать аудио?» */
                    } catch (Throwable t) {
                        Log.w(TAG, "microphone", t);
                        try { req.deny(); } catch (Throwable t2) { /* answered already */ }
                    }
                }
            });
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest req) { if (req == pendingMic) pendingMic = null; }
    }

    private static final int REQ_MIC = 61;
    private PermissionRequest pendingMic;                /* the page waits while the system asks the player */

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        if (code != REQ_MIC) return;
        PermissionRequest req = pendingMic; pendingMic = null;
        if (req == null) return;
        try {
            if (results != null && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) req.grant(new String[] { PermissionRequest.RESOURCE_AUDIO_CAPTURE });
            else req.deny();
        } catch (Throwable t) { Log.w(TAG, "microphone", t); }
    }

    /** Called by web/boot.js: the game's saves are kept in the app's own storage as well. */
    private final class Bridge {
        @JavascriptInterface
        public String dump() {
            try {
                JSONObject o = new JSONObject();
                for (Map.Entry<String, ?> e : saves.getAll().entrySet()) {
                    if (e.getValue() instanceof String) o.put(e.getKey(), (String) e.getValue());
                }
                return o.toString();
            } catch (Throwable t) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void put(String key, String value) {
            if (key != null && value != null && key.startsWith(SAVE_PREFIX)) saves.edit().putString(key, value).apply();
        }

        @JavascriptInterface
        public void del(String key) {
            if (key != null) saves.edit().remove(key).apply();
        }

        /** A web page (the support page, the game's site) is opened in the phone's browser. */
        @JavascriptInterface
        public void open(final String url) {
            if (!webAddress(url)) return;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Throwable t) { /* no browser */ }
                }
            });
        }

        /** The game found a newer version on its site: download that APK, check it, give it to the system installer. */
        @JavascriptInterface
        public boolean update(final String url, final int size, final String sha256) {
            if (!webAddress(url) || size <= 0 || sha256 == null || sha256.length() != 64) return false;
            int st = updState.get();
            if (st > 0 || !updState.compareAndSet(st, 1)) return false;                   /* already at it */
            new Thread(new Runnable() {
                @Override public void run() { downloadAndInstall(url, size, sha256); }
            }, "update").start();
            return true;
        }

        @JavascriptInterface
        public int updateState() { return updState.get(); }

        @JavascriptInterface
        public void updateReset() { int st = updState.get(); if (st < 0) updState.compareAndSet(st, 0); }
    }

    private boolean webAddress(String url) {
        return url != null && (url.startsWith("https://") || (debuggable && url.startsWith("http://127.0.0.1")));
    }

    /* ---------------------------------------------------------------- the update */
    private File downloadFile() { return new File(new File(getCacheDir(), "update"), "MelNyam.apk"); }

    private void deleteDownload() {
        try { File f = downloadFile(); f.delete(); f.getParentFile().delete(); } catch (Throwable t) { /* nothing to delete */ }
    }

    /** Runs on its own thread. The file is used only if its size and SHA-256 are the ones the game's site promised and
     *  it is this very app in a newer version. (That it is signed with the same key is checked by Android itself.) */
    private void downloadAndInstall(String url, int size, String sha256) {
        File f = downloadFile();
        int res = UPD_NET;
        HttpURLConnection c = null;
        try {
            f.getParentFile().mkdirs();
            f.delete();
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(20000);
            c.setReadTimeout(20000);
            c.setUseCaches(false);
            c.setInstanceFollowRedirects(true);
            if (c.getResponseCode() == 200) {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] buf = new byte[1 << 16];
                int total = 0, n;
                boolean tooBig = false, writeFailed = false;
                InputStream in = c.getInputStream();
                OutputStream out = null;
                try {
                    try { out = new FileOutputStream(f); } catch (Throwable t) { writeFailed = true; }
                    while (!writeFailed && (n = in.read(buf)) > 0) {
                        total += n;
                        if (total > size) { tooBig = true; break; }
                        md.update(buf, 0, n);
                        try { out.write(buf, 0, n); } catch (Throwable t) { writeFailed = true; }
                        int pct = (int) ((long) total * 100 / size);
                        updState.set(pct < 1 ? 1 : (pct > 99 ? 99 : pct));
                    }
                    if (out != null && !writeFailed) { try { out.flush(); } catch (Throwable t) { writeFailed = true; } }
                } finally {
                    try { if (out != null) out.close(); } catch (Throwable t) { writeFailed = true; }
                    try { in.close(); } catch (Throwable t) { /* closed */ }
                }
                if (writeFailed) res = UPD_WRITE;
                else if (!tooBig && total < size) res = UPD_NET;                          /* the connection broke */
                else if (tooBig || !hex(md.digest()).equalsIgnoreCase(sha256) || !newerVersionOfThisApp(f)) res = UPD_BAD;
                else res = 100;
            }
        } catch (Throwable t) {
            Log.w(TAG, "update: download", t);
        } finally {
            if (c != null) c.disconnect();
        }
        if (res == 100) res = install(f, size);
        deleteDownload();
        updState.set(res);
    }

    private static String hex(byte[] d) {
        StringBuilder b = new StringBuilder(d.length * 2);
        for (byte x : d) b.append(Character.forDigit((x >> 4) & 15, 16)).append(Character.forDigit(x & 15, 16));
        return b.toString();
    }

    @SuppressWarnings("deprecation")
    private boolean newerVersionOfThisApp(File f) {
        try {
            PackageInfo neu = getPackageManager().getPackageArchiveInfo(f.getPath(), 0);
            PackageInfo own = getPackageManager().getPackageInfo(getPackageName(), 0);
            return neu != null && getPackageName().equals(neu.packageName) && neu.versionCode > own.versionCode;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Gives the checked file to the system installer. Android then shows its own «Update this app?» window
     *  (through installAnswer below); the first time it also asks to allow this app to install updates. */
    private int install(File f, int size) {
        PackageInstaller.Session s = null;
        try {
            PackageInstaller pi = getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams p = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            p.setAppPackageName(getPackageName());
            p.setSize(size);
            int id = pi.createSession(p);
            s = pi.openSession(id);
            InputStream in = new FileInputStream(f);
            OutputStream out = s.openWrite("MelNyam.apk", 0, size);
            try {
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                s.fsync(out);
            } finally {
                try { out.close(); } catch (Throwable t) { /* closed */ }
                try { in.close(); } catch (Throwable t) { /* closed */ }
            }
            Intent back = new Intent(this, MainActivity.class).setAction(ACTION_INSTALL);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);      /* the system adds its answer to it */
            s.commit(PendingIntent.getActivity(this, id, back, flags).getIntentSender());
            return UPD_INSTALLING;
        } catch (SecurityException e) {
            Log.w(TAG, "update: install", e);
            return UPD_REFUSED;
        } catch (Throwable t) {
            Log.w(TAG, "update: install", t);
            if (s != null) { try { s.abandon(); } catch (Throwable t2) { /* gone */ } }
            return UPD_WRITE;
        } finally {
            if (s != null) { try { s.close(); } catch (Throwable t) { /* closed */ } }
        }
    }

    /** The installer's answers arrive as intents for this activity. */
    @SuppressWarnings("deprecation")
    private void installAnswer(Intent i) {
        if (i == null || !ACTION_INSTALL.equals(i.getAction())) return;
        int st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
        Log.i(TAG, "update: installer says " + st + " " + i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE));
        if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {             /* the system wants to ask the player: show its window */
            try {
                Intent ask = (Intent) i.getParcelableExtra(Intent.EXTRA_INTENT);
                startActivity(ask);
            } catch (Throwable t) {
                Log.w(TAG, "update: confirm", t);
                updState.set(UPD_REFUSED);
            }
        } else if (st == PackageInstaller.STATUS_SUCCESS) {
            updState.set(0);                                               /* (normally the app is already replaced and closed by now) */
        } else if (st == PackageInstaller.STATUS_FAILURE_ABORTED || st == PackageInstaller.STATUS_FAILURE_BLOCKED) {
            updState.set(UPD_REFUSED);                                     /* the player said no, or the phone forbids it */
        } else if (st == PackageInstaller.STATUS_FAILURE_STORAGE) {
            updState.set(UPD_WRITE);
        } else {
            updState.set(UPD_BAD);                                         /* not a valid update of this app (other signing key, broken file...) */
        }
        setIntent(new Intent(this, MainActivity.class));                   /* do not handle the same answer again */
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        installAnswer(i);
    }

    /* ---------------------------------------------------------------- system things */
    @Override
    public void onBackPressed() {
        final WebView v = web;
        if (v == null) { moveTaskToBack(true); return; }
        v.evaluateJavascript("typeof MelNyamBack==='function'?MelNyamBack():'exit'", new ValueCallback<String>() {
            @Override public void onReceiveValue(String answer) {
                if (answer == null || !answer.contains("stay")) moveTaskToBack(true);      /* main menu: leave, the game stays in memory */
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (web == null) { restarts = 0; startGame(); } else web.onResume();
        hideSystemBars();
    }

    @Override
    protected void onPause() {
        resumed = false;
        if (web != null) web.onPause();                                  /* the page becomes hidden: it stops drawing and mutes itself */
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (web != null) { WebView v = web; web = null; dropWebView(v); }
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused) hideSystemBars();
    }

    /** Full screen without the status and navigation bars; a swipe from the edge shows them for a moment.
     *  These flags are the old way of doing it, but they work the same on every Android from 7 to 15. */
    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    /** Phones with a camera cutout: the window takes the whole screen, so the 16:9 picture stays in the middle of it.
     *  Kept in its own class: the field does not exist before Android 9. */
    private static final class Api28 {
        static void useCutoutArea(Window w) {
            try {
                WindowManager.LayoutParams lp = w.getAttributes();
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(lp);
            } catch (Throwable t) { /* keep the default */ }
        }
    }

}
