#!/bin/bash
# «Мел-Ням» — Android version: MelNyam.html (already built by ../build.sh) wrapped into MelNyam.apk.
#
#   bash android/build_apk.sh
#
# No Gradle: aapt2 + javac + d8 + zipalign + apksigner from the Android SDK.
#   ANDROID_SDK   folder with build-tools/<any>/ and platforms/android-34/android.jar   (default: ~/.cache/sdk)
#   MN_KEY_DIR    folder with the signing key: melnyam.jks + password.txt               (default: ../../android_key)
#                 Every update must be signed with the SAME key, or phones refuse to install it over the old version.
#                 The key is made here on the first run. Keep that folder and never publish it.
#   MN_APK_DEBUG=1  test build: debuggable (the page can be inspected over adb; plain http to this computer is allowed, for the
#                   stand-in table), written to MelNyam-debug.apk in MN_APK_OUT (default: the scratch folder's parent). Never publish that one.
#   MN_HTML, MN_VER, MN_VER_NAME   tests of the update: another page and another version number (e.g. a "0.4.1" to update to)
# Needs: JDK 11+ (javac, keytool), python3, zip. With JDK 21 take build-tools 35 or newer: the d8 of build-tools 34 cannot read its class files.
set -e
cd "$(dirname "$0")"

# The version comes from ../src/version.h, the same place the game itself reads it from.
VERSION_NAME="${MN_VER_NAME:-$(sed -n 's/^#define APP_VER_NAME "\(.*\)".*/\1/p' ../src/version.h)}"      # shown under the icon («Мел-Ням 0.4») and in the system's app info
VERSION_CODE="${MN_VER:-$(sed -n 's/^#define APP_VER \([0-9]*\).*/\1/p' ../src/version.h)}"             # must grow with every published APK: 0.3 -> 300, 0.4 -> 400, a fix of it -> 401
[ -n "$VERSION_NAME" ] && [ "$VERSION_CODE" -gt 0 ] || { echo "no version in ../src/version.h"; exit 1; }
HTML="${MN_HTML:-../MelNyam.html}"
MIN_SDK=24                # Android 7.0
TARGET_SDK=34

SDK="${ANDROID_SDK:-$HOME/.cache/sdk}"
BT="$(ls -d "$SDK"/build-tools/*/ 2>/dev/null | sort | tail -1)"
JAR="$SDK/platforms/android-$TARGET_SDK/android.jar"
[ -x "${BT}aapt2" ] && [ -f "$JAR" ] || { echo "Android SDK not found in $SDK (need build-tools and platforms/android-$TARGET_SDK)"; exit 1; }
[ -f "$HTML" ] || { echo "$HTML is missing: run ../build.sh first"; exit 1; }
KEYS="${MN_KEY_DIR:-$(cd ../.. && pwd)/android_key}"
KEYTOOL="$(command -v keytool || echo "$(dirname "$(readlink -f "$(command -v javac)")")/keytool")"       # not always on the PATH
B="${MN_APK_TMP:-$HOME/.cache/apk_build}"
OUT="${MN_APK_FILE:-../MelNyam.apk}"; DEBUG=""
if [ "$MN_APK_DEBUG" = "1" ]; then DEBUG="--debug-mode"; OUT="${MN_APK_FILE:-${MN_APK_OUT:-$(dirname "$B")}/MelNyam-debug.apk}"; fi
rm -rf "$B"; mkdir -p "$B/assets" "$B/res/values" "$B/classes" "$B/dex"
if [ -n "$DEBUG" ]; then sed 's/android:usesCleartextTraffic="false"/android:usesCleartextTraffic="true"/' AndroidManifest.xml > "$B/AndroidManifest.xml"; else cp AndroidManifest.xml "$B/AndroidManifest.xml"; fi

# ---- signing key (once)
if [ ! -f "$KEYS/melnyam.jks" ]; then
  mkdir -p "$KEYS"
  python3 -c "import secrets; print(secrets.token_urlsafe(24))" > "$KEYS/password.txt"
  "$KEYTOOL" -genkeypair -keystore "$KEYS/melnyam.jks" -storetype PKCS12 -alias melnyam -keyalg RSA -keysize 2048 -validity 10950 \
          -storepass:file "$KEYS/password.txt" -dname "CN=Mel-Nyam, O=timofeybahvalov-cell" >/dev/null
  echo "new signing key: $KEYS/melnyam.jks"
fi

# ---- the page: MelNyam.html + web/boot.js in its head
python3 - "$B/assets/MelNyam.html" "$HTML" <<'PY'
import sys
html = open(sys.argv[2], encoding='utf-8').read(); boot = open('web/boot.js', encoding='utf-8').read()
mark = '<title>Мел-Ням</title>'
assert html.count(mark) == 1 and '</script' not in boot.lower()
with open(sys.argv[1], 'w', encoding='utf-8', newline='\n') as f: f.write(html.replace(mark, mark + '\n<script>\n' + boot + '</script>'))
PY

# ---- resources and manifest
printf '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">Мел-Ням %s</string>\n</resources>\n' "$VERSION_NAME" > "$B/res/values/strings.xml"
"${BT}aapt2" compile --dir res -o "$B/res1.zip"
"${BT}aapt2" compile --dir "$B/res" -o "$B/res2.zip"
"${BT}aapt2" link -o "$B/unsigned.apk" -I "$JAR" --manifest "$B/AndroidManifest.xml" -A "$B/assets" \
    --min-sdk-version $MIN_SDK --target-sdk-version $TARGET_SDK --version-code $VERSION_CODE --version-name "$VERSION_NAME" $DEBUG \
    "$B/res1.zip" "$B/res2.zip"

# ---- code
javac -nowarn -source 8 -target 8 -Xlint:-options -encoding UTF-8 -classpath "$JAR" -d "$B/classes" $(find src -name '*.java')
"${BT}d8" --release --min-api $MIN_SDK --lib "$JAR" --output "$B/dex" $(find "$B/classes" -name '*.class')
(cd "$B/dex" && zip -q -9 ../unsigned.apk classes.dex)

# ---- align, sign, check
"${BT}zipalign" -f -p 4 "$B/unsigned.apk" "$B/aligned.apk"
"${BT}apksigner" sign --ks "$KEYS/melnyam.jks" --ks-key-alias melnyam --ks-pass "file:$KEYS/password.txt" --out "$OUT" "$B/aligned.apk"
rm -f "$OUT.idsig"
"${BT}apksigner" verify --min-sdk-version $MIN_SDK "$OUT"
"${BT}zipalign" -c 4 "$OUT"
rm -rf "$B"
ls -l "$OUT" | awk '{printf "%s: %.2f MB\n", $9, $5/1048576}'
