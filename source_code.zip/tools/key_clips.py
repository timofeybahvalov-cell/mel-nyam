#!/usr/bin/env python3
"""
Chroma-key pipeline for the green-screen meme footage ("футажи").
raw mp4 (in /tmp/raw)  ->  keyed, despilled, sticker-outlined RGBA frames
Frames are saved as JPEG pairs [premultiplied colour | alpha] (side by side)
into melnyam/clips/<name>/NNN.jpg  + meta.json
"""
import cv2, numpy as np, json, os, sys, shutil

RAW = '/tmp/raw'
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'clips')
OUT_SCALE = 1.6           # output pixels per design unit
FACE_UNITS = 70.0         # normalised face-box width in design units
OUTLINE_U = 2.6           # sticker outline (design units)
PAD = 8                   # transparent padding (px) around frames

# name: src, t0, t1, fps, face_w(src px), ref_x (src px, becomes anchor x), crop (x0,y0,x1,y1) in src px, zoom
CLIPS = {
    'idle':  dict(src='XaCqQrXMjEs', t0=0.30, t1=2.70, fps=12, face=213, cx=603, cy=262, crop=(287, 0, 994, 496), zoom=1.0),
    'smile': dict(src='XaCqQrXMjEs', t0=5.00, t1=6.80, fps=12, face=213, cx=603, cy=256, crop=(287, 0, 994, 496), zoom=1.0),
    'omg':   dict(src='J728pqNq-T0', t0=3.30, t1=4.80, fps=12, face=137, cx=640, cy=292, crop=(330, 80, 960, 720), zoom=0.78),
    'am':    dict(src='a_4FPR8pi1w', t0=0.00, t1=3.60, fps=10, face=178, cx=520, cy=166, crop=(20, 0, 1060, 480), zoom=0.8),
    'sad':   dict(src='idT3wNIGPxo', t0=4.70, t1=7.20, fps=12, face=251, cx=655, cy=285, crop=(227, 0, 1054, 432), zoom=1.0),
    'bored': dict(src='8RHiHJXlwW8', t0=0.00, t1=1.85, fps=11, face=135, cx=610, cy=352, crop=(268, 100, 1012, 720), zoom=0.70),
    'laugh': dict(src='wBXB2bVjHUg', t0=0.00, t1=1.90, fps=11, face=290, cx=661, cy=398, crop=(200, 60, 1120, 718), zoom=0.88),
}

def smoothstep(lo, hi, x):
    t = np.clip((x - lo) / (hi - lo), 0, 1)
    return t * t * (3 - 2 * t)

def key_frame(bgr, lo=28.0, hi=92.0):
    """returns (rgb float 0..255 despilled, alpha float 0..1)"""
    f = bgr.astype(np.float32)
    b, g, r = f[..., 0], f[..., 1], f[..., 2]
    ex = g - np.maximum(r, b)                      # green excess
    a = 1.0 - smoothstep(lo, hi, ex)
    # kill dark-green shadow areas of the screen: strongly green hue even if dark
    hue_green = (g > 120) & (g > r * 1.6) & (g > b * 1.6)
    a = np.where(hue_green, np.minimum(a, 0.0), a)
    a8 = (a * 255).astype(np.uint8)
    a8 = cv2.medianBlur(a8, 3)
    a8 = cv2.erode(a8, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
    # keep big connected components only
    n, lab, stats, _ = cv2.connectedComponentsWithStats((a8 > 100).astype(np.uint8), 8)
    if n > 1:
        areas = stats[1:, cv2.CC_STAT_AREA]; big = areas.max()
        keep = np.zeros(n, np.uint8); keep[1:] = (areas > big * 0.02).astype(np.uint8)
        mask = keep[lab]
        mask = cv2.dilate(mask, np.ones((5, 5), np.uint8))
        a8 = a8 * mask
    a = cv2.GaussianBlur(a8, (0, 0), 0.9).astype(np.float32) / 255.0
    # despill
    g2 = np.minimum(g, np.maximum(r, b) + 4)
    rgb = np.stack([r, g2, b], axis=-1)
    return rgb, a

def process(name, cfg, preview=False):
    cap = cv2.VideoCapture(f"{RAW}/{cfg['src']}.mp4")
    sfps = cap.get(cv2.CAP_PROP_FPS)
    s = FACE_UNITS / cfg['face'] * cfg.get('zoom', 1.0)       # design units per src px
    k = s * OUT_SCALE                                          # out px per src px
    x0, y0, x1, y1 = cfg['crop']
    nfr = int(round((cfg['t1'] - cfg['t0']) * cfg['fps']))
    frames = []
    for i in range(nfr):
        t = cfg['t0'] + i / cfg['fps']
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(round(t * sfps)))
        ok, f = cap.read()
        if not ok: break
        f = f[y0:y1, x0:x1]
        rgb, a = key_frame(f, cfg.get('lo', 28.0), cfg.get('hi', 92.0))
        ow, oh = int(round((x1 - x0) * k)), int(round((y1 - y0) * k))
        pm = rgb * a[..., None]                                 # premultiply before resampling
        pm = cv2.resize(pm, (ow, oh), interpolation=cv2.INTER_AREA)
        al = cv2.resize(a, (ow, oh), interpolation=cv2.INTER_AREA)
        frames.append((pm, al))
    cap.release()
    # union bbox
    un = np.max(np.stack([al for _, al in frames]), axis=0) > 0.15
    ys, xs = np.where(un)
    bx0, bx1, by0, by1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    # bottom: the last row where the union is wide (flat cut edge of the footage)
    rowcount = un.sum(axis=1)
    wide = np.where(rowcount > rowcount.max() * 0.35)[0]
    by1 = min(by1, wide.max() + 1)
    by1 -= cfg.get('trim_bottom', 2)
    ro = OUTLINE_U * OUT_SCALE
    R = int(np.ceil(ro)) + 2
    kern = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * int(round(ro)) + 1, 2 * int(round(ro)) + 1))
    out = []
    for pm, al in frames:
        pm = pm[by0:by1, bx0:bx1]; al = al[by0:by1, bx0:bx1]
        h, w = al.shape
        # pad: transparent on left/right/top, replicate at bottom (so the outline does not wrap the bottom cut)
        alp = np.zeros((h + PAD + R, w + 2 * PAD), np.float32); alp[PAD:PAD + h, PAD:PAD + w] = al
        alp[PAD + h:, PAD:PAD + w] = al[-1:, :]
        pmp = np.zeros((h + PAD + R, w + 2 * PAD, 3), np.float32); pmp[PAD:PAD + h, PAD:PAD + w] = pm
        pmp[PAD + h:, PAD:PAD + w] = pm[-1:, :]
        dil = cv2.dilate(alp, kern)
        dil = cv2.GaussianBlur(dil, (0, 0), 0.8)
        dil = np.clip((dil - 0.25) / 0.5, 0, 1)                 # crisp-ish AA edge
        A = np.maximum(dil, alp)
        C = pmp + (A - alp)[..., None] * 255.0                  # subject over white sticker edge
        # soft dark rim just outside the white edge for readability
        A = A[:PAD + h]; C = C[:PAD + h]
        out.append((np.clip(C, 0, 255), np.clip(A, 0, 1)))
    H, W = out[0][1].shape
    ax = (cfg['cx'] - x0) * k - bx0 + PAD       # anchor = reference face centre
    ay = (cfg['cy'] - y0) * k - by0 + PAD
    avail = (H - ay) / OUT_SCALE                # design units of body available below the face centre
    meta = dict(name=name, n=len(out), fps=cfg['fps'], w=W, h=H, scale=OUT_SCALE, ax=float(ax), ay=float(ay), avail=float(avail))
    if preview: return out, meta
    d = os.path.join(OUT, name)
    if os.path.isdir(d): shutil.rmtree(d)
    os.makedirs(d)
    total = 0
    for i, (C, A) in enumerate(out):
        side = np.zeros((H, W * 2, 3), np.uint8)
        side[:, :W] = C[..., ::-1].astype(np.uint8)             # RGB->BGR for imwrite
        side[:, W:] = (A * 255).astype(np.uint8)[..., None]
        p = os.path.join(d, f'{i:03d}.jpg')
        cv2.imwrite(p, side, [cv2.IMWRITE_JPEG_QUALITY, cfg.get('q', 80), cv2.IMWRITE_JPEG_OPTIMIZE, 1])
        total += os.path.getsize(p)
    json.dump(meta, open(os.path.join(d, 'meta.json'), 'w'))
    print(f"{name}: {len(out)} frames {W}x{H}  anchor=({ax:.0f},{ay:.0f}) avail={avail:.0f}u  {total/1024:.0f} KB")
    return out, meta

def preview_sheet(names, path):
    from PIL import Image
    rows = []
    for nm in names:
        out, meta = process(nm, CLIPS[nm], preview=True)
        idx = np.linspace(0, len(out) - 1, 6).astype(int)
        W, H = meta['w'], meta['h']
        row = np.zeros((H + 30, 6 * (W + 10), 3), np.float32)
        row[..., 0] = 40; row[..., 1] = 30; row[..., 2] = 90
        yy, xx = np.mgrid[0:H + 30, 0:6 * (W + 10)]
        chk = (((xx // 16) + (yy // 16)) % 2) * 25
        row += chk[..., None]
        for j, i in enumerate(idx):
            C, A = out[i]
            x = j * (W + 10) + 5
            reg = row[10:10 + H, x:x + W]
            reg[:] = C + reg * (1 - A[..., None])
            ax = int(meta['ax']); ay = int(meta['ay']); row[10 + ay - 12:10 + ay + 12, x + ax:x + ax + 1] = (255, 255, 0); row[10 + ay:10 + ay + 1, x + ax - 12:x + ax + 12] = (255, 255, 0)
        rows.append(row)
        print(nm, meta)
    Wm = max(r.shape[1] for r in rows)
    sheet = np.zeros((sum(r.shape[0] for r in rows), Wm, 3), np.uint8); y = 0
    for r in rows:
        sheet[y:y + r.shape[0], :r.shape[1]] = np.clip(r, 0, 255).astype(np.uint8); y += r.shape[0]
    Image.fromarray(sheet).save(path, quality=88)
    print('saved', path, sheet.shape)

if __name__ == '__main__':
    if len(sys.argv) > 2 and sys.argv[1] == 'preview':
        preview_sheet(sys.argv[3:] or list(CLIPS), sys.argv[2])
    else:
        names = sys.argv[1:] or list(CLIPS)
        for nm in names: process(nm, CLIPS[nm])
