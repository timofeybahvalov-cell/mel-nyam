#!/usr/bin/env python3
"""debug renderer: draws the generated levels + solution paths (from /tmp/levels.json)"""
import json, sys, math
from PIL import Image, ImageDraw
L = json.load(open('/tmp/levels.json'))
S = 0.5
def P(x, y): return (x * S, y * S)
per = 6
for si in range(0, len(L), per):
    chunk = L[si:si + per]
    sheet = Image.new('RGB', (int(1280 * S) * 3 + 20, (int(720 * S) + 10) * 2), (10, 10, 10))
    for i, lv in enumerate(chunk):
        im = Image.new('RGB', (int(1280 * S), int(720 * S)), (38, 30, 70)); d = ImageDraw.Draw(im)
        d.rectangle([0, 0, 230 * S, 80 * S], outline=(80, 80, 120)); d.rectangle([1050 * S, 0, 1280 * S, 90 * S], outline=(80, 80, 120))
        candy = None
        for o in lv['objs']:
            if o[0] == 1: candy = o
        for o in lv['objs']:
            t, x, y, a, b = o
            if t == 2:
                d.line([P(x, y), P(candy[1], candy[2])], fill=(200, 150, 90), width=2); d.ellipse([x*S-5, y*S-5, x*S+5, y*S+5], fill=(120, 170, 255))
            elif t == 3:
                d.ellipse([(x-a)*S, (y-a)*S, (x+a)*S, (y+a)*S], outline=(90, 130, 200)); d.ellipse([x*S-5, y*S-5, x*S+5, y*S+5], fill=(60, 110, 255))
            elif t == 4: d.regular_polygon((x*S, y*S, 11), 5, fill=(255, 210, 40))
            elif t == 5: d.ellipse([(x-46)*S, (y-46)*S, (x+46)*S, (y+46)*S], outline=(150, 230, 255), width=2)
            elif t == 6:
                r = math.radians(a); d.line([P(x, y), P(x + math.cos(r)*70, y + math.sin(r)*70)], fill=(80, 200, 255), width=5); d.ellipse([x*S-8, y*S-8, x*S+8, y*S+8], fill=(40, 120, 255))
            elif t == 7: d.line([P(x, y), P(a, b)], fill=(255, 60, 60), width=5)
            elif t == 8:
                d.ellipse([(x-46)*S, (y-46)*S, (x+46)*S, (y+46)*S], outline=(80, 255, 120), width=2)
                d.rectangle([(x-110)*S, (y+40)*S, (x+110)*S, (y+135)*S], outline=(80, 255, 120))      # desk
                d.ellipse([(x-36)*S, (y-17-45)*S, (x+36)*S, (y-17+45)*S], outline=(255, 200, 170))      # head
        pts = [P(p[0], p[1]) for p in lv['path']]
        if len(pts) > 1: d.line(pts, fill=(255, 255, 255), width=1)
        for k in range(0, len(lv['path']), 20):
            p = lv['path'][k]; d.ellipse([p[0]*S-2, p[1]*S-2, p[0]*S+2, p[1]*S+2], fill=(255, 120, 255))
        d.ellipse([candy[1]*S-7, candy[2]*S-7, candy[1]*S+7, candy[2]*S+7], fill=(255, 80, 80))
        d.text((6, 345), f"{lv['name']} ok={lv['ok']}", fill=(255, 255, 0))
        sheet.paste(im, ((i % 3) * (int(1280 * S) + 10), (i // 3) * (int(720 * S) + 10)))
    sheet.save(f'/tmp/sheets/levels_{si // per}.png'); print('saved', si // per)
