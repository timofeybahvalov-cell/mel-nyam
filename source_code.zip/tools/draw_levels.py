#!/usr/bin/env python3
"""debug renderer: draws the generated levels + solution paths (from /tmp/levels.json)
usage: draw_levels.py [first_box [last_box]]   -> /tmp/sheets/box_N.jpg (6 levels per sheet)"""
import json, sys, math, os
from PIL import Image, ImageDraw
L = json.load(open('/tmp/levels.json'))
S = 0.5
os.makedirs('/tmp/sheets', exist_ok=True)
def P(x, y): return (x * S, y * S)
b0 = int(sys.argv[1]) if len(sys.argv) > 1 else 1
b1 = int(sys.argv[2]) if len(sys.argv) > 2 else b0 if len(sys.argv) > 1 else 99
PC = [(90, 200, 255), (255, 150, 60), (200, 120, 255)]
for si in range(0, len(L), 6):
    box = si // 6 + 1
    if box < b0 or box > b1: continue
    chunk = L[si:si + 6]
    sheet = Image.new('RGB', (int(1280 * S) * 3 + 20, (int(720 * S) + 10) * 2), (10, 10, 10))
    for i, lv in enumerate(chunk):
        im = Image.new('RGB', (int(1280 * S), int(720 * S)), (38, 30, 70)); d = ImageDraw.Draw(im)
        d.rectangle([0, 0, 230 * S, 100 * S], outline=(80, 80, 120)); d.rectangle([1100 * S, 0, 1280 * S, 90 * S], outline=(80, 80, 120)); d.rectangle([540 * S, 0, 740 * S, 60 * S], outline=(80, 80, 120))
        candy = None; pin_i = 0
        for o in lv['objs']:
            if o[0] == 1: candy = o
        for o in lv['objs']:
            t, x, y, a, b, c, dd, e = o
            if t == 2:
                d.line([P(x, y), P(candy[1], candy[2])], fill=(200, 150, 90) if not b else (255, 110, 110), width=2); d.ellipse([x*S-5, y*S-5, x*S+5, y*S+5], fill=(120, 170, 255)); d.text((x*S+6, y*S-6), str(pin_i) + (' T%g' % b if b else ''), fill=(200, 200, 255)); pin_i += 1
            elif t == 3:
                d.ellipse([(x-a)*S, (y-a)*S, (x+a)*S, (y+a)*S], outline=(90, 130, 200) if not b else (255, 110, 110)); d.ellipse([x*S-5, y*S-5, x*S+5, y*S+5], fill=(60, 110, 255)); d.text((x*S+6, y*S-6), str(pin_i) + (' T%g' % b if b else ''), fill=(200, 200, 255)); pin_i += 1
            elif t == 13:
                d.line([P(x, y), P(a, b)], fill=(150, 150, 170), width=4); px, py = x + (a - x) * c, y + (b - y) * c
                d.line([P(px, py), P(candy[1], candy[2])], fill=(200, 150, 90), width=2); d.rectangle([px*S-6, py*S-6, px*S+6, py*S+6], fill=(120, 255, 170)); d.text((px*S+8, py*S-6), str(pin_i), fill=(200, 255, 200)); pin_i += 1
            elif t == 4: d.regular_polygon((x*S, y*S, 11), 5, fill=(255, 210, 40))
            elif t == 5: d.ellipse([(x-46)*S, (y-46)*S, (x+46)*S, (y+46)*S], outline=(150, 230, 255), width=2)
            elif t == 6:
                r = math.radians(a); d.line([P(x, y), P(x + math.cos(r)*70, y + math.sin(r)*70)], fill=(80, 200, 255), width=5); d.ellipse([x*S-8, y*S-8, x*S+8, y*S+8], fill=(40, 120, 255))
            elif t == 7: d.line([P(x, y), P(a, b)], fill=(255, 60, 60), width=5)
            elif t == 8:
                d.ellipse([(x-46)*S, (y-46)*S, (x+46)*S, (y+46)*S], outline=(80, 255, 120), width=2)
                f = -1 if a else 1
                d.rectangle([(x-110)*S, min(y+40*f, y+135*f)*S, (x+110)*S, max(y+40*f, y+135*f)*S], outline=(80, 255, 120))      # desk
                d.ellipse([(x-36)*S, (y-17*f-45)*S, (x+36)*S, (y-17*f+45)*S], outline=(255, 200, 170))      # head
            elif t == 9:
                r = math.radians(a); hl = b or 60; cx, sy = math.cos(r) * hl, math.sin(r) * hl
                d.line([P(x - cx, y - sy), P(x + cx, y + sy)], fill=(90, 255, 140), width=6); d.line([P(x, y), P(x + math.sin(r) * 22, y - math.cos(r) * 22)], fill=(90, 255, 140), width=1)
            elif t == 10:
                col = PC[int(b) % 3]; d.ellipse([(x-30)*S, (y-30)*S, (x+30)*S, (y+30)*S], outline=col, width=3)
                if a >= 0: r = math.radians(a); d.line([P(x, y), P(x + math.cos(r)*55, y + math.sin(r)*55)], fill=col, width=2)
            elif t == 11: d.rectangle([(x-24)*S, (y-24)*S, (x+24)*S, (y+24)*S], outline=(255, 255, 120), width=2); d.text((x*S-4, y*S-6), 'G', fill=(255, 255, 120))
            elif t == 12:
                d.line([P(x, y), P(a, b)], fill=(255, 60, 220), width=2); d.text(((x+a)/2*S+4, (y+b)/2*S+2), '%g/%g+%g' % (c, dd, e), fill=(255, 150, 240))
        pts = [P(p[0], p[1]) for p in lv['path']]
        if len(pts) > 1: d.line(pts, fill=(255, 255, 255), width=1)
        for k in range(0, len(lv['path']), 20):
            p = lv['path'][k]; d.ellipse([p[0]*S-2, p[1]*S-2, p[0]*S+2, p[1]*S+2], fill=(255, 120, 255)); 
            if k % 40 == 0: d.text((p[0]*S+3, p[1]*S+2), '%.1f' % (k * 3 / 120.0), fill=(170, 170, 170))
        d.ellipse([candy[1]*S-7, candy[2]*S-7, candy[1]*S+7, candy[2]*S+7], fill=(255, 80, 80))
        d.text((6, 345), f"{lv['name']} ok={lv['ok']}", fill=(255, 255, 0))
        sheet.paste(im, ((i % 3) * (int(1280 * S) + 10), (i // 3) * (int(720 * S) + 10)))
    sheet.save(f'/tmp/sheets/box_{box}.jpg', quality=85); print('saved box', box)
