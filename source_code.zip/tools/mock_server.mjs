// A local stand-in for the Google Sheet + Apps Script web app, for tests:
//     node tools/mock_server.mjs [PORT] [STATE.json]
// It runs the real server/Code.gs against an in-memory "spreadsheet" and answers like Google does
// (every answer is a 302 redirect to another URL that returns the text, with CORS open to everybody).
// It also serves the web build:  http://127.0.0.1:PORT/MelNyam.html?api=http://127.0.0.1:PORT/exec
import fs from 'fs';
import http from 'http';
import path from 'path';
import vm from 'vm';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const PORT = parseInt(process.argv[2] || '8787', 10), STATE = process.argv[3] || '';
let book = {};                                    // sheet name -> array of rows (row 0 = header)
if (STATE && fs.existsSync(STATE)) book = JSON.parse(fs.readFileSync(STATE, 'utf8'));
const persist = () => { if (STATE) fs.writeFileSync(STATE, JSON.stringify(book)); };
function range(rows, r, c, nr, nc) {
  const cell = (i, j) => { while (rows.length < r + i) rows.push([]); const row = rows[r - 1 + i]; while (row.length < c + j) row.push(''); return row; };
  return {
    getValues() { const out = []; for (let i = 0; i < nr; i++) { const o = []; for (let j = 0; j < nc; j++) { const row = rows[r - 1 + i] || []; o.push(row[c - 1 + j] === undefined ? '' : row[c - 1 + j]); } out.push(o); } return out; },
    getValue() { return this.getValues()[0][0]; },
    setValues(v) { for (let i = 0; i < nr; i++) for (let j = 0; j < nc; j++) cell(i, j + 1)[c - 1 + j] = v[i][j]; persist(); },
    setValue(v) { cell(0, 1)[c - 1] = v; persist(); },      // (like Google: a text column keeps "007" as text; here everything is kept as it was given)
    setNumberFormat() { return this; },
  };
}
function sheet(name) {
  const rows = book[name];
  return {
    appendRow(v) { rows.push(v.slice()); persist(); },
    deleteRow(r) { rows.splice(r - 1, 1); persist(); },
    setFrozenRows() {},
    getLastRow() { return rows.length; },
    getRange(a, b, c, d) { if (typeof a === 'string') return range(rows, 1, 1, 1, 1); return range(rows, a, b, c || 1, d || 1); },
  };
}
const cache = new Map();
const props = new Map();                          // script properties: the admin key lives here, never in the sheet
const sbytes = (buf) => Array.from(buf, (b) => (b > 127 ? b - 256 : b));      // Apps Script hands bytes out as signed numbers
if (process.env.MOCK_ADMIN_PW) props.set('ADMIN_KEY', crypto.createHash('sha256').update('mel-nyam/admin/v1:' + process.env.MOCK_ADMIN_PW, 'utf8').digest('hex'));
const sandbox = {
  SpreadsheetApp: { getActiveSpreadsheet: () => ({ getSheetByName: (n) => (book[n] ? sheet(n) : null), insertSheet: (n) => { book[n] = []; return sheet(n); } }) },
  ContentService: { MimeType: { TEXT: 'text/plain' }, createTextOutput: (s) => ({ text: String(s), setMimeType() { return this; } }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  CacheService: { getScriptCache: () => ({ get: (k) => { const e = cache.get(k); return e && e.until > Date.now() ? e.v : null; }, put: (k, v, sec) => cache.set(k, { v: String(v), until: Date.now() + sec * 1000 }), remove: (k) => cache.delete(k),
    getAll: (keys) => { const o = {}; for (const k of keys) { const e = cache.get(k); if (e && e.until > Date.now()) o[k] = e.v; } return o; } }) },
  PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => (props.has(k) ? props.get(k) : null), setProperty: (k, v) => { props.set(k, String(v)); } }) },
  Utilities: {
    DigestAlgorithm: { SHA_256: 'sha256' }, Charset: { UTF_8: 'utf8' },
    computeDigest: (alg, s, cs) => sbytes(crypto.createHash(alg).update(String(s), cs || 'utf8').digest()),
    computeHmacSha256Signature: (msg, key, cs) => sbytes(crypto.createHmac('sha256', Buffer.from(String(key), cs || 'utf8')).update(String(msg), cs || 'utf8').digest()),
    getUuid: () => crypto.randomUUID(), sleep: () => {},
  },
  Logger: { log: (s) => console.log('[Logger] ' + s) },
  console,
};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(ROOT, 'server/Code.gs'), 'utf8'), sandbox, { filename: 'Code.gs' });
const pending = new Map(); let seq = 0;
const cors = { 'Access-Control-Allow-Origin': '*' };
const files = { '/MelNyam.html': 'MelNyam.html', '/online.json': null };
// MOCK_SITE = a folder that plays the game's site: its online.json is merged into the answer (support page, newest version),
// and its other files (MelNyam.exe, MelNyam.apk ...) are served from the root, for the update tests.
const SITE = process.env.MOCK_SITE || '';
http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname === '/exec') {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      let out;
      if (req.method === 'POST') out = sandbox.doPost({ postData: { contents: Buffer.concat(chunks).toString('utf8') } });
      else out = sandbox.doGet({ parameter: Object.fromEntries(u.searchParams) });
      const t = String(++seq) + Math.random().toString(36).slice(2);
      pending.set(t, out.text);
      if (process.env.MOCK_LOG) console.log(req.method, req.url.slice(0, 90), '->', out.text.slice(0, 90).replace(/\n/g, ' / '));
      res.writeHead(302, { Location: 'http://' + req.headers.host + '/echo?t=' + t, ...cors }); res.end();
    });
  } else if (u.pathname === '/echo') {
    const t = u.searchParams.get('t'), text = pending.get(t); pending.delete(t);
    if (text === undefined) { res.writeHead(404, cors); res.end('gone'); return; }
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', ...cors }); res.end(text);
  } else if (u.pathname === '/online.json') {
    let extra = {};
    try { if (SITE) extra = JSON.parse(fs.readFileSync(path.join(SITE, 'online.json'), 'utf8')); } catch (e) { extra = {}; }
    res.writeHead(200, { 'Content-Type': 'application/json', ...cors }); res.end(JSON.stringify({ ...extra, api: 'http://' + req.headers.host + '/exec' }));
  } else if (u.pathname === '/_melAdminPassword') {       // tests: what the owner does in the Apps Script editor
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', ...cors }); res.end(sandbox.melAdminPassword());
  } else if (SITE && /^\/[A-Za-z0-9_.-]+$/.test(u.pathname) && fs.existsSync(path.join(SITE, u.pathname.slice(1)))) {
    const fp = path.join(SITE, u.pathname.slice(1)), slow = parseInt(process.env.MOCK_SLOW || '0', 10);
    const type = { '.html': 'text/html; charset=utf-8', '.json': 'application/json', '.apk': 'application/vnd.android.package-archive' }[path.extname(fp)] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': type, 'Content-Length': fs.statSync(fp).size, ...cors });
    if (!slow) fs.createReadStream(fp).pipe(res);
    else { const data = fs.readFileSync(fp); let off = 0; const t = setInterval(() => { if (off >= data.length) { clearInterval(t); res.end(); return; } res.write(data.subarray(off, off + slow)); off += slow; }, 20); }
  } else if (files[u.pathname]) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); fs.createReadStream(path.join(ROOT, files[u.pathname])).pipe(res);
  } else { res.writeHead(404, cors); res.end('not found'); }
}).listen(PORT, '127.0.0.1', () => console.log('mock table on http://127.0.0.1:' + PORT + '/exec'));
