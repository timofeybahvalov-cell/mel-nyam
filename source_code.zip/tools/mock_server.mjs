// A local stand-in for the Google Sheet + Apps Script web app, for tests:
//     node tools/mock_server.mjs [PORT] [STATE.json]
// It runs the real server/Code.gs against an in-memory "spreadsheet" and answers like Google does
// (every answer is a 302 redirect to another URL that returns the text, with CORS open to everybody).
// It also serves the web build:  http://127.0.0.1:PORT/MelNyam.html?api=http://127.0.0.1:PORT/exec
import fs from 'fs';
import http from 'http';
import path from 'path';
import vm from 'vm';
import { fileURLToPath } from 'url';
const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const PORT = parseInt(process.argv[2] || '8787', 10), STATE = process.argv[3] || '';
let book = {};                                    // sheet name -> array of rows (row 0 = header)
if (STATE && fs.existsSync(STATE)) book = JSON.parse(fs.readFileSync(STATE, 'utf8'));
const persist = () => { if (STATE) fs.writeFileSync(STATE, JSON.stringify(book)); };
function range(rows, r, c, nr, nc) {
  const cell = (i, j) => { while (rows.length < r + i) rows.push([]); const row = rows[r - 1 + i]; while (row.length < c + j) row.push(''); return row; };
  return {
    getValues() { const out = []; for (let i = 0; i < nr; i++) { const o = []; for (let j = 0; j < nc; j++) { const row = rows[r - 1 + i] || []; o.push(row[c - 1 + j] === undefined ? '' : row[c - 1 + j]); } out.push(o); } return out; },
    getValue() { return this.getValues()[0][0]; },
    setValues(v) { for (let i = 0; i < nr; i++) for (let j = 0; j < nc; j++) cell(i, j + 1)[c - 1 + j] = v[i][j]; persist(); },
    setValue(v) { cell(0, 1)[c - 1] = v; persist(); },
    setNumberFormat() { return this; },
  };
}
function sheet(name) {
  const rows = book[name];
  return {
    appendRow(v) { rows.push(v.slice()); persist(); },
    setFrozenRows() {},
    getLastRow() { return rows.length; },
    getRange(a, b, c, d) { if (typeof a === 'string') return range(rows, 1, 1, 1, 1); return range(rows, a, b, c || 1, d || 1); },
  };
}
const cache = new Map();
const sandbox = {
  SpreadsheetApp: { getActiveSpreadsheet: () => ({ getSheetByName: (n) => (book[n] ? sheet(n) : null), insertSheet: (n) => { book[n] = []; return sheet(n); } }) },
  ContentService: { MimeType: { TEXT: 'text/plain' }, createTextOutput: (s) => ({ text: String(s), setMimeType() { return this; } }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  CacheService: { getScriptCache: () => ({ get: (k) => { const e = cache.get(k); return e && e.until > Date.now() ? e.v : null; }, put: (k, v, sec) => cache.set(k, { v, until: Date.now() + sec * 1000 }), remove: (k) => cache.delete(k) }) },
  console,
};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(ROOT, 'server/Code.gs'), 'utf8'), sandbox, { filename: 'Code.gs' });
const pending = new Map(); let seq = 0;
const cors = { 'Access-Control-Allow-Origin': '*' };
const files = { '/MelNyam.html': 'MelNyam.html', '/online.json': null };
http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname === '/exec') {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      let out;
      if (req.method === 'POST') out = sandbox.doPost({ postData: { contents: Buffer.concat(chunks).toString('utf8') } });
      else out = sandbox.doGet({ parameter: Object.fromEntries(u.searchParams) });
      const t = String(++seq) + Math.random().toString(36).slice(2);
      pending.set(t, out.text);
      if (process.env.MOCK_LOG) console.log(req.method, req.url.slice(0, 90), '->', out.text.slice(0, 90).replace(/\n/g, ' / '));
      res.writeHead(302, { Location: 'http://' + req.headers.host + '/echo?t=' + t, ...cors }); res.end();
    });
  } else if (u.pathname === '/echo') {
    const t = u.searchParams.get('t'), text = pending.get(t); pending.delete(t);
    if (text === undefined) { res.writeHead(404, cors); res.end('gone'); return; }
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', ...cors }); res.end(text);
  } else if (u.pathname === '/online.json') {
    res.writeHead(200, { 'Content-Type': 'application/json', ...cors }); res.end(JSON.stringify({ api: 'http://' + req.headers.host + '/exec' }));
  } else if (files[u.pathname]) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); fs.createReadStream(path.join(ROOT, files[u.pathname])).pipe(res);
  } else { res.writeHead(404, cors); res.end('not found'); }
}).listen(PORT, '127.0.0.1', () => console.log('mock table on http://127.0.0.1:' + PORT + '/exec'));
