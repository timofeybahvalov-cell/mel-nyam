#!/usr/bin/env python3
"""Skins of the bottle (V0.5): art_src/skin_*.png (generated pictures on a magenta background) -> sprites `skin0` .. `skin10`.

    python3 tools/make_skins.py            put the sprites into the existing gen/pack.bin (everything else in the pack stays byte for byte)
    python3 tools/make_skins.py crop       first run after new pictures were generated: cut the sources down to the object (saves space)

tools/make_assets.py calls build(add) too, so a full rebuild of the pack has the skins as well.
Needs: python3, PIL, numpy."""
import io, os, struct, sys
import numpy as np
from PIL import Image, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ART = os.path.join(ROOT, 'art_src'); GEN = os.path.join(ROOT, 'gen')
PK_PNG = 1
S = 3.0            # sprite pixels per design unit (the level's own bottle has 2.0; the shop shows the skins large)
HEIGHT = 66        # design units, the same as the bottle
# index 0 is the bottle the game always had; the order here is the order in the shop (src/g_meta.inc: skin_tab)
SKINS = ['bottle_src', 'skin_water', 'skin_juice', 'skin_mors', 'skin_kvass', 'skin_lemonade', 'skin_energy', 'skin_beer', 'skin_wine', 'skin_vodka', 'skin_gold']

def smoothstep(lo, hi, x):
    t = np.clip((x - lo) / (hi - lo), 0, 1); return t * t * (3 - 2 * t)

def outside_mask(bg):
    """bg: True where the pixel looks like the background. Returns the part of it that is connected to the border (flood fill)."""
    h, w = bg.shape; out = np.zeros_like(bg); out[0, :] = bg[0, :]; out[-1, :] = bg[-1, :]; out[:, 0] = bg[:, 0]; out[:, -1] = bg[:, -1]
    while True:
        g = out.copy()
        g[1:, :] |= out[:-1, :]; g[:-1, :] |= out[1:, :]; g[:, 1:] |= out[:, :-1]; g[:, :-1] |= out[:, 1:]
        g &= bg
        # (plain dilation would need thousands of passes: sweep along the rows and the columns instead)
        for _ in range(2):
            for y in range(1, h): g[y] |= g[y - 1] & bg[y]
            for y in range(h - 2, -1, -1): g[y] |= g[y + 1] & bg[y]
            for x in range(1, w): g[:, x] |= g[:, x - 1] & bg[:, x]
            for x in range(w - 2, -1, -1): g[:, x] |= g[:, x + 1] & bg[:, x]
        if (g == out).all(): return out
        out = g

def key(path):
    """magenta background -> alpha. Only the background that touches the border is removed: purple grapes inside the outline stay."""
    f = np.asarray(Image.open(path).convert('RGB')).astype(np.float32)
    r, g, b = f[..., 0], f[..., 1], f[..., 2]
    m = np.minimum(r, b) - g
    a = 1.0 - smoothstep(45, 150, m)
    out = outside_mask(a < 0.6)
    near = np.asarray(Image.fromarray((out * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(5))) > 0      # the soft edge next to the outside keeps its soft alpha
    a = np.where(out, 0.0, np.where(near, a, 1.0))
    # colour under the soft edge: take it from the opaque neighbours, so no magenta fringe is left
    opaque = (a > 0.97).astype(np.float32)
    wsum = np.asarray(Image.fromarray((opaque * 255).astype(np.uint8)).filter(ImageFilter.BoxBlur(4))).astype(np.float32) / 255.0
    col = np.empty_like(f)
    for c in range(3):
        cs = np.asarray(Image.fromarray(np.clip(f[..., c] * opaque, 0, 255).astype(np.uint8)).filter(ImageFilter.BoxBlur(4))).astype(np.float32)
        col[..., c] = np.where(opaque > 0, f[..., c], cs / np.maximum(wsum, 1e-3))
    a = np.asarray(Image.fromarray((a * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.7))).astype(np.float32) / 255.0
    rgba = np.dstack([np.clip(col, 0, 255), a * 255]).astype(np.uint8)
    ys, xs = np.where(a > 0.05)
    return rgba[ys.min():ys.max() + 1, xs.min():xs.max() + 1]

def resize_rgba(rgba, w, h):
    return np.asarray(Image.fromarray(rgba).convert('RGBa').resize((w, h), Image.LANCZOS).convert('RGBA'))

def sticker(rgba, px, color=(255, 255, 255)):
    """a white sticker outline of px pixels around the sprite"""
    pad = int(px) + 3; h, w = rgba.shape[:2]
    big = np.zeros((h + 2 * pad, w + 2 * pad, 4), np.uint8); big[pad:pad + h, pad:pad + w] = rgba
    a = big[..., 3].astype(np.float32) / 255.0
    solid = Image.fromarray(((a > 0.5) * 255).astype(np.uint8))
    for _ in range(int(px)): solid = solid.filter(ImageFilter.MaxFilter(3))
    dil = np.asarray(solid.filter(ImageFilter.GaussianBlur(1.6))).astype(np.float32) / 255.0; dil = np.clip((dil - 0.35) / 0.3, 0, 1)
    A = np.maximum(dil, a)
    C = big[..., :3].astype(np.float32) * a[..., None] + np.array(color, np.float32) * (A - a)[..., None]
    out = np.zeros_like(big); out[..., :3] = np.clip(C / np.maximum(A[..., None], 1e-4), 0, 255); out[..., 3] = A * 255
    return out

def png_bytes(rgba):
    b = io.BytesIO(); Image.fromarray(rgba).save(b, 'PNG', optimize=True); return b.getvalue()

def sprites():
    out = []
    for i, name in enumerate(SKINS):
        k = key(os.path.join(ART, name + '.png'))
        hh = int(HEIGHT * S); ww = int(round(k.shape[1] * hh / k.shape[0]))
        out.append(sticker(resize_rgba(k, ww, hh), 4))
    return out

def build(add):
    """add(name, type, data, a, b, c, d): the function of tools/make_assets.py"""
    sp = sprites()
    for i, s in enumerate(sp): add('skin%d' % i, PK_PNG, png_bytes(s), int(S * 1000), -1, -1, 0)
    return sp

def crop_sources():
    for name in SKINS[1:]:
        p = os.path.join(ART, name + '.png'); im = Image.open(p).convert('RGB'); f = np.asarray(im).astype(np.float32)
        a = (np.minimum(f[..., 0], f[..., 2]) - f[..., 1]) < 100; out = outside_mask(~a); ys, xs = np.where(~out)
        m = 28; box = (max(0, xs.min() - m), max(0, ys.min() - m), min(im.size[0], xs.max() + 1 + m), min(im.size[1], ys.max() + 1 + m))
        if box[2] - box[0] < im.size[0] - 8:
            im.crop(box).save(p, optimize=True); print('%-16s %dx%d -> %dx%d, %d KB' % (name, im.size[0], im.size[1], box[2] - box[0], box[3] - box[1], os.path.getsize(p) // 1024))

def patch_pack(path):
    d = open(path, 'rb').read(); assert d[:4] == b'MNPK'
    ver, n, _ = struct.unpack('<III', d[4:16]); ent = []
    for i in range(n):
        name, typ, off, size, a, b, c, dd = struct.unpack('<32sIIIiiii', d[16 + 60 * i:16 + 60 * (i + 1)])
        nm = name.rstrip(b'\0').decode()
        if not nm.startswith('skin'): ent.append((nm, typ, d[off:off + size], a, b, c, dd))
    kept = len(ent)
    sp = build(lambda name, typ, data, a=0, b=0, c=0, dd=0: ent.append((name, typ, data, a, b, c, dd)))
    hdr = 16 + 60 * len(ent); off = hdr; blobs = []; table = b''
    for name, typ, data, a, b, c, dd in ent:
        pad = (-off) % 4; off += pad; blobs.append(b'\0' * pad + data)
        table += struct.pack('<32sIIIiiii', name.encode(), typ, off, len(data), a, b, c, dd); off += len(data)
    with open(path, 'wb') as f:
        f.write(b'MNPK' + struct.pack('<III', ver, len(ent), 0)); f.write(table)
        for bl in blobs: f.write(bl)
        f.write(b'\0' * ((-off) % 16))
    print('pack: %d entries kept, %d skins, %.2f MB -> %.2f MB' % (kept, len(ent) - kept, len(d) / 1e6, os.path.getsize(path) / 1e6))
    W = sum(s.shape[1] for s in sp) + 16 * (len(sp) + 1); H = max(s.shape[0] for s in sp) + 32
    sheet = Image.new('RGBA', (W, H), (58, 42, 140, 255)); x = 16
    for s in sp: sheet.alpha_composite(Image.fromarray(s), (x, 16)); x += s.shape[1] + 16
    sheet.convert('RGB').save(os.path.join(GEN, 'skins_preview.png'))

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'crop': crop_sources()
    patch_pack(os.path.join(GEN, 'pack.bin'))
