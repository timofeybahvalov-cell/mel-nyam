/* Checks the recordings of real players (tools/tas_runs/seeds, downloaded by tools/tas_seeds.py) against the game as it is now.
   build:  gcc -O2 -ffp-contract=off -Isrc tools/tas_seedcheck.c src/tas.c src/sim.c -lm -o /tmp/tas_seedcheck
   usage:  tas_seedcheck [SEEDS_DIR [RUNS_DIR]]        (defaults: tools/tas_runs/seeds, tools/tas_runs)

   1. Every recording is replayed on the simulation: it has to win with all the stars at exactly the step the table has
      for it. If one does not, the physics is no longer the one the records were made on (and SIM_VERSION must change).
   2. The stored TAS run of every level (RUNS_DIR/lvNN.txt) is compared with the best recording of the table:
      a level where a player is faster needs a new search (tools/tas_find.c picks the seeds up by itself).
   The exit code is 0 only if every recording replays and no player is faster than the stored TAS. */
#include "tas.h"
#include "levels.h"
#include <stdio.h>
#include <string.h>

extern int sim_skip_visual;
static int hexwords(const char *s, u32 *a, int max) {
    int n = 0;
    while (n < max) {
        u32 v = 0; int k;
        for (k = 0; k < 8; k++) { char c = s[k]; int d = (c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10 : -1; if (d < 0) break; v = v << 4 | (u32)d; }
        if (k < 8) break;
        a[n++] = v; s += 8;
    }
    return n;
}
static int replay(const LObj *objs, const u32 *a, int n) {      /* like tas_check(), but without the 40 s limit of the search: records may be longer */
    static Sim T; int i = 0, mx = sim_max_stars(objs); sim_skip_visual = 0;
    sim_load(&T, objs);
    while (T.state == ST_PLAY && T.tick < 60000) {
        while (i < n && (int)(a[i] >> 15) <= T.tick) { sim_act(&T, (int)((a[i] >> 12) & 7u), (int)(a[i] & 4095u)); i++; }
        sim_step(&T);
    }
    return (T.state == ST_EATEN && T.stars >= mx) ? T.tick : 0;
}

int main(int argc, char **argv) {
    const char *seeds = argc > 1 ? argv[1] : "tools/tas_runs/seeds", *runs = argc > 2 ? argv[2] : "tools/tas_runs";
    static u32 a[1600]; static char line[16000]; char path[600]; int total = 0, ok = 0, slower = 0, equal = 0, levels = 0, norun = 0;
    for (int lv = 0; lv < LEVEL_COUNT; lv++) {
        int best = 0, tas = 0;
        snprintf(path, sizeof(path), "%s/seed%02d.txt", seeds, lv);
        FILE *f = fopen(path, "r");
        if (f) {
            while (fgets(line, sizeof(line), f)) {
                int tk, st, pos = 0;
                if (sscanf(line, "%d_%d_%n", &tk, &st, &pos) < 2 || !pos) continue;
                int n = hexwords(line + pos, a, 1600), r = replay(g_levels[lv].objs, a, n);
                total++;
                if (r == tk) ok++; else printf("level %d (%s): the table has %d steps, the replay gives %d\n", lv, g_levels[lv].name, tk, r);
                if (!best || tk < best) best = tk;
            }
            fclose(f);
        }
        levels += best > 0;
        snprintf(path, sizeof(path), "%s/lv%02d.txt", runs, lv);
        f = fopen(path, "r");
        if (f) { int nn, pr, pos = 0; if (fgets(line, sizeof(line), f) && sscanf(line, "%d %d %d %n", &tas, &nn, &pr, &pos) >= 3 && pos) { int n = hexwords(line + pos, a, 1600); if (tas_check(g_levels[lv].objs, a, n) != tas) tas = 0; } else tas = 0; fclose(f); }
        if (!tas) { norun++; printf("level %d (%s): no stored TAS run that fits\n", lv, g_levels[lv].name); }
        else if (best && tas > best) { slower++; printf("level %d (%s): TAS %d is SLOWER than the best of the table, %d\n", lv, g_levels[lv].name, tas, best); }
        else if (best && tas == best) { equal++; printf("level %d (%s): TAS %d = the best of the table\n", lv, g_levels[lv].name, tas); }
    }
    printf("seedcheck: %d recordings of players on %d levels, %d replay exactly; TAS slower than a player on %d levels, equal on %d, missing on %d\n", total, levels, ok, slower, equal, norun);
    return (total == ok && !slower && !norun) ? 0 : 1;
}
