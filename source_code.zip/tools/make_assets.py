#!/usr/bin/env python3
"""
Asset pipeline of «Мел-Ням»:  art + keyed clips + fonts + sounds  ->  build_tmp/pack.bin
(the pack is embedded into the .exe and into the .html)
"""
import os, sys, json, math, struct, subprocess, glob, ctypes, hashlib
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
ART = os.path.join(ROOT, 'art_src'); CLIPS = os.path.join(ROOT, 'clips'); SND = os.path.join(ROOT, 'snd_src')
OUTDIR = os.path.join(ROOT, 'gen'); os.makedirs(OUTDIR, exist_ok=True)
FONT = os.path.join(ROOT, 'fonts', 'Nunito.ttf')
PREV = '/tmp/sheets'; os.makedirs(PREV, exist_ok=True)
SR = 22050

PK_PNG, PK_JPG, PK_JPGA, PK_FONT, PK_ADPCM, PK_ANIM, PK_RAW = 1, 2, 3, 4, 5, 6, 7
entries = []   # (name, type, bytes, a, b, c, d)
def add(name, typ, data, a=0, b=0, c=0, d=0):
    assert len(name) < 32, name
    entries.append((name, typ, bytes(data), int(a), int(b), int(c), int(d)))

def smoothstep(lo, hi, x):
    t = np.clip((x - lo) / (hi - lo), 0, 1); return t * t * (3 - 2 * t)

def png_bytes(rgba):
    import io
    im = Image.fromarray(rgba, 'RGBA'); bio = io.BytesIO(); im.save(bio, 'PNG', optimize=True); return bio.getvalue()
def jpg_bytes(rgb, q=84):
    ok, buf = cv2.imencode('.jpg', rgb[..., ::-1], [cv2.IMWRITE_JPEG_QUALITY, q, cv2.IMWRITE_JPEG_OPTIMIZE, 1]); return buf.tobytes()
def jpga_bytes(rgba, q=86):
    a = rgba[..., 3:4].astype(np.float32) / 255.0
    pm = (rgba[..., :3].astype(np.float32) * a).astype(np.uint8)
    h, w = rgba.shape[:2]; side = np.zeros((h, w * 2, 3), np.uint8); side[:, :w] = pm; side[:, w:] = rgba[..., 3:4]
    return jpg_bytes(side, q)
def add_img(name, rgba, scale, ax=-1, ay=-1, flags=0):
    add(name, PK_PNG, png_bytes(rgba), scale * 1000, ax, ay, flags)

def resize_rgba(rgba, w, h):
    f = rgba.astype(np.float32); a = f[..., 3:4] / 255.0; pm = f[..., :3] * a
    pm = cv2.resize(pm, (w, h), interpolation=cv2.INTER_AREA); al = cv2.resize(f[..., 3], (w, h), interpolation=cv2.INTER_AREA)
    out = np.zeros((h, w, 4), np.float32); out[..., :3] = pm / np.maximum(al[..., None] / 255.0, 1e-4); out[..., 3] = al
    return np.clip(out, 0, 255).astype(np.uint8)

# ----------------------------------------------------------------------------- generated art -> sprites
def key_generated(path, mode):
    f = np.asarray(Image.open(path).convert('RGB')).astype(np.float32)
    r, g, b = f[..., 0], f[..., 1], f[..., 2]
    m = (np.minimum(r, b) - g) if mode == 'magenta' else (g - np.maximum(r, b))
    a = 1.0 - smoothstep(45, 150, m)
    a8 = (a * 255).astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats((a8 > 128).astype(np.uint8), 8)
    if n > 1:
        areas = stats[1:, cv2.CC_STAT_AREA]; keep = np.zeros(n, np.uint8); keep[1:] = (areas > areas.max() * 0.004)
        a = a * cv2.dilate(keep[lab], np.ones((5, 5), np.uint8))
    opaque = (a > 0.97).astype(np.float32)
    wsum = cv2.blur(opaque, (9, 9)); csum = cv2.blur(f * opaque[..., None], (9, 9))
    fill = csum / np.maximum(wsum[..., None], 1e-4)
    col = np.where(opaque[..., None] > 0, f, fill)
    a = cv2.GaussianBlur(a, (0, 0), 0.7)
    rgba = np.dstack([np.clip(col, 0, 255), a * 255]).astype(np.uint8)
    ys, xs = np.where(a > 0.05)
    return rgba[ys.min():ys.max() + 1, xs.min():xs.max() + 1]

def sticker(rgba, px, color=(255, 255, 255)):
    """add a white sticker outline of px pixels around a sprite"""
    pad = int(px) + 3
    h, w = rgba.shape[:2]; big = np.zeros((h + 2 * pad, w + 2 * pad, 4), np.uint8); big[pad:pad + h, pad:pad + w] = rgba
    a = big[..., 3].astype(np.float32) / 255.0
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * int(px) + 1, 2 * int(px) + 1))
    dil = cv2.GaussianBlur(cv2.dilate(a, k), (0, 0), 0.8); dil = np.clip((dil - 0.25) / 0.5, 0, 1)
    A = np.maximum(dil, a)
    C = big[..., :3].astype(np.float32) * a[..., None] + np.array(color, np.float32) * (A - a)[..., None]
    out = np.zeros_like(big); out[..., :3] = np.clip(C / np.maximum(A[..., None], 1e-4), 0, 255); out[..., 3] = A * 255
    return out

def build_sprites():
    S = 2.0
    # bottle («чекушка»)
    b = key_generated(os.path.join(ART, 'bottle_src.png'), 'magenta')
    hh = int(66 * S); ww = int(round(b.shape[1] * hh / b.shape[0]))
    b = resize_rgba(b, ww, hh); b = sticker(b, 3)
    add_img('bottle', b, S); Image.fromarray(b).save(os.path.join(OUTDIR, 'bottle.png'))
    # desk
    d = key_generated(os.path.join(ART, 'desk_src.png'), 'green')
    al = d[..., 3] > 128; roww = al.sum(axis=1); top = int(np.argmax(roww > roww.max() * 0.8))
    xs = np.where(al[top + 4])[0]; slab_w = xs.max() - xs.min() + 1; cx = (xs.max() + xs.min()) / 2
    k = (224 * S) / slab_w
    d2 = resize_rgba(d, int(round(d.shape[1] * k)), int(round(d.shape[0] * k)))
    add_img('desk', d2, S, int(round(cx * k)), int(round(top * k)) + 2)
    kb = (224 * 4.0) / slab_w
    d4 = resize_rgba(d, int(round(d.shape[1] * kb)), int(round(d.shape[0] * kb)))
    add('desk_big', PK_JPGA, jpga_bytes(d4, 88), 4000, int(round(cx * kb)), int(round(top * kb)) + 4, 0)
    Image.fromarray(d2).save(os.path.join(OUTDIR, 'desk.png'))
    print('desk', d2.shape, 'anchor', int(cx * k), int(top * k))
    # blower
    bl = key_generated(os.path.join(ART, 'blower_src.png'), 'magenta')
    k = (100 * S) / bl.shape[1]
    bl2 = resize_rgba(bl, int(round(bl.shape[1] * k)), int(round(bl.shape[0] * k))); bl2 = sticker(bl2, 2)
    al = bl2[..., 3] > 128; colh = al.sum(axis=0); bulb = np.where(colh > colh.max() * 0.7)[0]
    add_img('blower', bl2, S, int((bulb.min() + bulb.max()) / 2), bl2.shape[0] // 2)
    Image.fromarray(bl2).save(os.path.join(OUTDIR, 'blower.png'))
    return b

# ----------------------------------------------------------------------------- procedural sprites
def star_mask(size, r_out, r_in, round_px, rot=-90):
    SS = 4; N = size * SS
    im = Image.new('L', (N, N), 0); d = ImageDraw.Draw(im); pts = []
    for i in range(10):
        ang = math.radians(rot + i * 36); r = (r_out if i % 2 == 0 else r_in) * N
        pts.append((N / 2 + math.cos(ang) * r, N / 2 + math.sin(ang) * r))
    d.polygon(pts, fill=255)
    im = im.filter(ImageFilter.GaussianBlur(round_px * SS))
    m = np.asarray(im).astype(np.float32) / 255.0
    m = np.clip((m - 0.5) * (round_px * SS * 0.9) + 0.5, 0, 1)
    return cv2.resize(m, (size, size), interpolation=cv2.INTER_AREA)

def build_star():
    S = 2.0; size = int(60 * S)
    outer = star_mask(size, 0.47, 0.235, 2.6); inner = star_mask(size, 0.385, 0.185, 2.2); core = star_mask(size, 0.24, 0.115, 1.6)
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float32) / size
    grad = np.stack([np.full_like(yy, 255), 236 - 96 * yy, 60 - 50 * yy], -1)             # yellow -> orange
    col = np.zeros((size, size, 3), np.float32) + np.array([122, 62, 0], np.float32)       # outline brown
    col = col * (1 - inner[..., None]) + grad * inner[..., None]
    light = np.stack([np.full_like(yy, 255), np.full_like(yy, 250), 170 + 0 * yy], -1)
    col = col * (1 - core[..., None] * 0.75) + light * core[..., None] * 0.75
    gl = np.clip(1 - np.hypot(xx - 0.36, yy - 0.30) / 0.13, 0, 1) * inner                    # glint
    col = col + gl[..., None] * 90
    rgba = np.dstack([np.clip(col, 0, 255), outer * 255]).astype(np.uint8)
    rgba = sticker(rgba, 0) if False else rgba
    add_img('star', rgba, S); Image.fromarray(rgba).save(os.path.join(OUTDIR, 'star.png'))
    ring = np.clip(outer - inner, 0, 1)
    e = np.zeros((size, size, 4), np.float32)
    e[..., :3] = np.array([26, 22, 70], np.float32) * (1 - ring[..., None]) + np.array([150, 140, 220], np.float32) * ring[..., None]
    e[..., 3] = (inner * 150 + ring * 235)
    add_img('star_empty', np.clip(e, 0, 255).astype(np.uint8), S)
    # glow (additive)
    g = int(150 * 1.0); yy, xx = np.mgrid[0:g, 0:g].astype(np.float32); r = np.hypot(xx - g / 2 + 0.5, yy - g / 2 + 0.5) / (g / 2)
    v = np.clip(1 - r, 0, 1) ** 2.2
    glow = np.dstack([255 * v, 225 * v, 120 * v, 255 * v]).astype(np.uint8)       # premult-ish: stored straight with alpha=v
    glow[..., :3] = np.clip(np.dstack([255 * np.ones_like(v), 225 * np.ones_like(v), 120 * np.ones_like(v)]), 0, 255)
    add_img('glow', glow, 1.0)
    # white soft glow
    wg = np.dstack([np.full_like(v, 255), np.full_like(v, 255), np.full_like(v, 255), 255 * v]).astype(np.uint8)
    add_img('wglow', wg, 1.0)
    # sparkle (4-point)
    n = 96; yy, xx = np.mgrid[0:n, 0:n].astype(np.float32); x = (xx - n / 2 + 0.5) / (n / 2); y = (yy - n / 2 + 0.5) / (n / 2)
    v = np.maximum(np.exp(-np.abs(x) * 5.0) * np.exp(-(y * 14) ** 2), np.exp(-np.abs(y) * 5.0) * np.exp(-(x * 14) ** 2))
    v = np.clip(v + np.exp(-(x * x + y * y) * 22) * 0.9, 0, 1) * np.clip(1.15 - np.hypot(x, y), 0, 1)
    sp = np.dstack([np.full_like(v, 255), np.full_like(v, 255), np.full_like(v, 255), 255 * v]).astype(np.uint8)
    add_img('spark', sp, 2.0)
    # soft dot
    n = 32; yy, xx = np.mgrid[0:n, 0:n].astype(np.float32); r = np.hypot(xx - n / 2 + 0.5, yy - n / 2 + 0.5) / (n / 2)
    v = np.clip((1 - r) * 3.0, 0, 1)
    add_img('dot', np.dstack([np.full_like(v, 255), np.full_like(v, 255), np.full_like(v, 255), 255 * v]).astype(np.uint8), 2.0)

def build_pin_bubble():
    S = 2.0
    # pin
    n = int(34 * S); SS = 4; N = n * SS
    yy, xx = np.mgrid[0:N, 0:N].astype(np.float32); r = np.hypot(xx - N / 2 + 0.5, yy - N / 2 + 0.5) / (N / 2)
    def disc(rad): return np.clip((rad - r) * (N / 2) / 1.5 + 0.5, 0, 1)
    col = np.zeros((N, N, 3), np.float32); a = disc(0.98)
    col[:] = (22, 30, 72)
    ring = disc(0.86); t = np.clip((yy / N), 0, 1)[..., None]
    metal = np.array([214, 226, 246], np.float32) * (1 - t) + np.array([108, 126, 170], np.float32) * t
    col = col * (1 - ring[..., None]) + metal * ring[..., None]
    inner = disc(0.56); blue = np.array([86, 160, 255], np.float32) * (1 - t) + np.array([34, 84, 200], np.float32) * t
    col = col * (1 - inner[..., None]) + np.array([22, 30, 72], np.float32) * inner[..., None]
    inner2 = disc(0.46); col = col * (1 - inner2[..., None]) + blue * inner2[..., None]
    gl = np.clip(1 - np.hypot(xx - N * 0.40, yy - N * 0.36) / (N * 0.10), 0, 1)
    col += gl[..., None] * 150
    rgba = np.dstack([np.clip(col, 0, 255), a * 255]).astype(np.uint8)
    rgba = np.asarray(Image.fromarray(rgba, 'RGBA').convert('RGBa').resize((n, n), Image.LANCZOS).convert('RGBA'))
    add_img('pin', rgba, S); Image.fromarray(rgba).save(os.path.join(OUTDIR, 'pin.png'))
    # bubble
    n = int(108 * S); yy, xx = np.mgrid[0:n, 0:n].astype(np.float32); x = (xx - n / 2 + 0.5) / (n / 2); y = (yy - n / 2 + 0.5) / (n / 2); r = np.hypot(x, y)
    edge = np.clip((0.96 - r) * (n / 2) / 1.5 + 0.5, 0, 1)
    body = 0.10 + 0.50 * np.clip(r, 0, 1) ** 5 + 0.18 * np.clip(r, 0, 1) ** 1.5
    rim = np.exp(-((r - 0.90) / 0.045) ** 2) * 0.55
    alpha = np.clip(body + rim, 0, 1) * edge
    col = np.zeros((n, n, 3), np.float32); col[:] = (190, 236, 255)
    col += rim[..., None] * 60
    hl = np.exp(-(((x + 0.42) * 0.9 + (y + 0.42) * 0.9) ** 2) / 0.012 - (((x + 0.42) - (y + 0.42)) ** 2) / 0.22) * edge   # elongated glint top-left
    hl2 = np.exp(-((x - 0.45) ** 2 + (y - 0.50) ** 2) / 0.012) * 0.55 * edge
    alpha = np.clip(alpha + hl * 0.85 + hl2 * 0.6, 0, 1)
    col = col + (hl + hl2)[..., None] * 120
    rgba = np.dstack([np.clip(col, 0, 255), alpha * 255]).astype(np.uint8)
    add_img('bubble', rgba, S); Image.fromarray(rgba).save(os.path.join(OUTDIR, 'bubble.png'))

# ----------------------------------------------------------------------------- backgrounds, covers, logo
def build_backgrounds(bottle):
    # one background per location of the chapter: file, darkening (the playfield must stay readable)
    names = [('bg_room.jpg', 0.80), ('bg_city.jpg', 0.80), ('bg_villa.jpg', 0.74), ('bg_gym.jpg', 0.92), ('bg_garage.jpg', 0.86),
             ('bg_plane.jpg', 0.70), ('bg_club.jpg', 0.74), ('bg_yacht.jpg', 0.80), ('bg_island.jpg', 0.70), ('bg_arena.jpg', 0.82)]
    for i, (nm, dark) in enumerate(names):
        im = Image.open(os.path.join(ART, nm)).convert('RGB')
        f = np.asarray(im).astype(np.float32)
        h, w = f.shape[:2]; yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        r = np.hypot((xx - w / 2) / (w / 2), (yy - h / 2) / (h / 2) * 0.9)
        vig = 1.0 - 0.38 * np.clip(r - 0.35, 0, 1.2) ** 1.6
        g = f * dark * vig[..., None]
        add('bg%d' % i, PK_JPG, jpg_bytes(np.clip(g, 0, 255).astype(np.uint8), 86), 1000, -1, -1, 1)
        # box cover: 300x190 units @1.5
        cw, ch = 450, 285
        k = max(cw / w, ch / h) * 1.25
        small = cv2.resize(f, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA)
        x0 = (small.shape[1] - cw) // 2; y0 = (small.shape[0] - ch) // 2
        crop = small[y0:y0 + ch, x0:x0 + cw]
        m = Image.new('L', (cw * 4, ch * 4), 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, cw * 4 - 1, ch * 4 - 1], radius=30 * 4, fill=255)
        m = np.asarray(m.resize((cw, ch), Image.LANCZOS))
        rgba = np.dstack([np.clip(crop, 0, 255), m]).astype(np.uint8)
        add('cover%d' % i, PK_JPGA, jpga_bytes(rgba, 88), 1500, -1, -1, 0)
    # ---- logo
    SSC = 1.6; SS = 2
    font = ImageFont.truetype(FONT, int(150 * SSC * SS)); font.set_variation_by_axes([1000])
    def letter(ch, c0, c1, rot):
        sw = int(13 * SSC * SS)
        x0, y0, x1, y1 = font.getbbox(ch, anchor='ls', stroke_width=sw)
        pad = int(20 * SSC * SS); W, H = x1 - x0 + 2 * pad, y1 - y0 + 2 * pad
        ox, oy = pad - x0, pad - y0
        t = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(t)
        d.text((ox, oy + int(9 * SSC * SS)), ch, font=font, anchor='ls', fill=(12, 14, 46, 255), stroke_width=sw, stroke_fill=(12, 14, 46, 255))
        d.text((ox, oy), ch, font=font, anchor='ls', fill=(28, 34, 92, 255), stroke_width=sw, stroke_fill=(28, 34, 92, 255))
        d.text((ox, oy), ch, font=font, anchor='ls', fill=(255, 255, 255, 255), stroke_width=int(5 * SSC * SS), stroke_fill=(255, 255, 255, 255))
        mask = Image.new('L', (W, H), 0); ImageDraw.Draw(mask).text((ox, oy), ch, font=font, anchor='ls', fill=255)
        ma = np.asarray(mask).astype(np.float32) / 255.0
        yy = np.linspace(0, 1, H, dtype=np.float32)[:, None] * np.ones((1, W), np.float32)
        ys = np.where(ma.max(axis=1) > 0.5)[0]; tt = np.clip((yy * H - ys.min()) / max(1, ys.max() - ys.min()), 0, 1)
        col = np.array(c0, np.float32)[None, None] * (1 - tt[..., None]) + np.array(c1, np.float32)[None, None] * tt[..., None]
        gloss = (tt < 0.46).astype(np.float32) * 0.22
        col = col + gloss[..., None] * 255
        arr = np.asarray(t).astype(np.float32)
        arr[..., :3] = arr[..., :3] * (1 - ma[..., None]) + np.clip(col, 0, 255) * ma[..., None]
        t = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), 'RGBA').rotate(rot, resample=Image.BICUBIC, expand=True)
        return t, font.getlength(ch)
    word1 = [('М', -5), ('Е', 3), ('Л', -3)]; word2 = [('Н', 4), ('Я', -4), ('М', 5)]
    W, H = int(1000 * SSC * SS), int(260 * SSC * SS)
    canvas = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    x = int(40 * SSC * SS); base = int(190 * SSC * SS)
    def put(tile, cx, cy):
        canvas.alpha_composite(tile, (int(cx - tile.width / 2), int(cy - tile.height / 2)))
    for k, (ch, rot) in enumerate(word1):
        t, adv = letter(ch, (255, 255, 255), (150, 214, 255), rot)
        put(t, x + adv / 2, base - int(58 * SSC * SS) + (k % 2) * int(8 * SSC * SS)); x += adv + int(6 * SSC * SS)
    # the bottle instead of the hyphen
    bh = int(150 * SSC * SS); bt = Image.fromarray(bottle, 'RGBA'); bt = bt.resize((int(bt.width * bh / bt.height), bh), Image.LANCZOS).rotate(-18, resample=Image.BICUBIC, expand=True)
    x += int(4 * SSC * SS); put(bt, x + bt.width / 2 - int(10 * SSC * SS), base - int(62 * SSC * SS)); x += bt.width - int(14 * SSC * SS)
    for k, (ch, rot) in enumerate(word2):
        t, adv = letter(ch, (214, 255, 110), (62, 190, 60), rot)
        put(t, x + adv / 2, base - int(58 * SSC * SS) + ((k + 1) % 2) * int(8 * SSC * SS)); x += adv + int(6 * SSC * SS)
    arr = np.asarray(canvas); ys, xs = np.where(arr[..., 3] > 8)
    canvas = canvas.crop((xs.min() - 4, ys.min() - 4, xs.max() + 5, ys.max() + 5))
    canvas = canvas.convert('RGBa').resize((canvas.width // SS, canvas.height // SS), Image.LANCZOS).convert('RGBA')
    canvas.save(os.path.join(OUTDIR, 'logo.png'))
    add_img('logo', np.asarray(canvas), SSC)
    print('logo', canvas.size)

# ----------------------------------------------------------------------------- fonts
CHARS = [chr(c) for c in range(32, 127)] + [chr(c) for c in range(0x410, 0x450)] + list('Ёё«»—–…№×•·')
def build_font(name, weight, em, stroke, shadow, fill=(255, 255, 255, 255), strokec=(24, 28, 78, 255), shadowc=(8, 10, 40, 200), spacing=0.0):
    SS = 2
    font = ImageFont.truetype(FONT, em * SS); font.set_variation_by_axes([weight])
    sw = int(round(stroke * SS)); tiles = []
    for ch in CHARS:
        adv = font.getlength(ch) / SS + spacing
        if ch == ' ': tiles.append((ord(ch), None, 0, 0, adv)); continue
        x0, y0, x1, y1 = font.getbbox(ch, anchor='ls', stroke_width=sw)
        pad = 3 * SS; sh = int(round(shadow * SS))
        W, H = x1 - x0 + 2 * pad, y1 - y0 + 2 * pad + sh
        W += W % 2; H += H % 2
        t = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(t); ox, oy = pad - x0, pad - y0
        if sh: d.text((ox, oy + sh), ch, font=font, anchor='ls', fill=shadowc, stroke_width=sw, stroke_fill=shadowc)
        if sw: d.text((ox, oy), ch, font=font, anchor='ls', fill=fill, stroke_width=sw, stroke_fill=strokec)
        else: d.text((ox, oy), ch, font=font, anchor='ls', fill=fill)
        t = t.convert('RGBa').resize((W // SS, H // SS), Image.LANCZOS).convert('RGBA')
        tiles.append((ord(ch), t, (x0 - pad) / SS, (y0 - pad) / SS, adv))
    AW = 1024; x = y = 2; rowh = 0; pos = {}
    for cp, t, xo, yo, adv in sorted([q for q in tiles if q[1] is not None], key=lambda q: -q[1].height):
        if x + t.width + 2 > AW: x = 2; y += rowh + 2; rowh = 0
        pos[cp] = (x, y); x += t.width + 2; rowh = max(rowh, t.height)
    AH = y + rowh + 1; AH += (-AH) % 4
    atlas = Image.new('RGBA', (AW, AH), (0, 0, 0, 0)); blob = b''
    for cp, t, xo, yo, adv in sorted(tiles, key=lambda q: q[0]):
        if t is None: blob += struct.pack('<IHHHHhhhH', cp, 0, 0, 0, 0, 0, 0, int(round(adv * 16)), 0); continue
        px, py = pos[cp]; atlas.paste(t, (px, py))
        blob += struct.pack('<IHHHHhhhH', cp, px, py, t.width, t.height, int(round(xo)), int(round(yo)), int(round(adv * 16)), 0)
    cap = -font.getbbox('Н', anchor='ls')[1] / SS
    add(name, PK_FONT, blob, len(tiles), em, int(em * 1.22), int(round(cap)))
    add(name + '_img', PK_PNG, png_bytes(np.asarray(atlas)), 1000, 0, 0, 0)
    atlas.save(os.path.join(PREV, 'font_%s.png' % name))
    print('font', name, atlas.size, 'cap', cap)

# ----------------------------------------------------------------------------- clips
def build_clips():
    for d in sorted(glob.glob(os.path.join(CLIPS, '*'))):
        mp = os.path.join(d, 'meta.json')
        if not os.path.exists(mp): continue
        m = json.load(open(mp)); frames = [open(os.path.join(d, '%03d.jpg' % i), 'rb').read() for i in range(m['n'])]
        hdr = struct.pack('<8i', int(m['scale'] * 1000), int(round(m['ax'])), int(round(m['ay'])), int(round(m['avail'])), 0, 0, 0, 0)
        off = 32 + 4 * (m['n'] + 1); offs = []
        for f in frames: offs.append(off); off += len(f)
        offs.append(off)
        blob = hdr + struct.pack('<%dI' % len(offs), *offs) + b''.join(frames)
        add('clip_' + m['name'], PK_ANIM, blob, m['n'], int(m['fps'] * 100), m['w'], m['h'])

# ----------------------------------------------------------------------------- audio
_adpcm = None
def adpcm_encode(x):
    global _adpcm
    if _adpcm is None:
        so = '/tmp/libadpcm.so'
        subprocess.check_call(['gcc', '-O2', '-shared', '-fPIC', '-o', so, os.path.join(ROOT, 'tools', 'adpcm.c')])
        _adpcm = ctypes.CDLL(so)
    pcm = np.clip(x * 32767.0, -32768, 32767).astype(np.int16); n = len(pcm)
    out = np.zeros((n + 1) // 2 + 4, np.uint8)
    _adpcm.adpcm_encode(pcm.ctypes.data_as(ctypes.c_void_p), ctypes.c_int(n), out.ctypes.data_as(ctypes.c_void_p))
    return out.tobytes(), n
def add_sound(name, x, rate=SR):
    x = np.asarray(x, np.float32)
    data, n = adpcm_encode(x); add(name, PK_ADPCM, data, rate, n)

def load_audio(path):
    raw = subprocess.check_output(['ffmpeg', '-v', 'error', '-i', path, '-ac', '1', '-ar', str(SR), '-f', 's16le', '-'])
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768.0
def fade(x, a=0.006, r=0.02):
    x = x.copy(); na = int(a * SR); nr = int(r * SR)
    if na and len(x) > na: x[:na] *= np.linspace(0, 1, na)
    if nr and len(x) > nr: x[-nr:] *= np.linspace(1, 0, nr)
    return x
def trim(x, thr=0.035):
    env = np.abs(x); win = int(0.01 * SR); e = np.convolve(env, np.ones(win) / win, 'same'); idx = np.where(e > thr * e.max())[0]
    return x[max(0, idx[0] - int(0.01 * SR)):min(len(x), idx[-1] + int(0.03 * SR))] if len(idx) else x
def norm(x, peak=0.9, rms=None):
    x = x - np.mean(x); p = np.max(np.abs(x)) + 1e-9; g = peak / p
    if rms: g = min(g * 3.0, rms / (np.sqrt(np.mean(x * x)) + 1e-9)); x = np.tanh(x * g * 1.1) / 1.1 * 1.0; return np.clip(x, -0.98, 0.98)
    return x * g

VOICE = [  # name, file, [(t0, t1), ...]   (timings from speech recognition; profanity is cut out)
    ('v_am',     'am-am-am-am-mellstroy.mp3', [(0.00, 3.05)]),
    ('v_am1',    'am-am-am-am-mellstroy.mp3', [(0.00, 1.20)]),
    ('v_hello',  'hello-im-mellstroy.mp3', [(0.00, 2.30)]),
    ('v_bravo',  'mellstroy-bravo.mp3', [(4.25, 6.65)]),
    ('v_omg',    'omg-mellstroy.mp3', [(0.00, 0.44), (2.60, 3.53)]),
    ('v_obidno', 'mellstroy-obidno-mellstroi-vavfya.mp3', [(4.95, 5.90)]),
    ('v_posidim','posidim-melstroi.mp3', [(4.46, 6.64)]),
    ('v_laugh',  'mellstroy-laugh.mp3', [(0.00, 2.30)]),
    ('v_uuu',    'mellstroy-raduet.mp3', [(0.00, 2.40)]),
    ('v_stop',   'mellstroy-stop-stop-stop-stop.mp3', [(0.00, 1.12)]),
    ('v_scream', 'mellstroy-krichit.mp3', [(0.00, 1.90)]),
    # V0.2. A piece is (t0, t1) of the voice's own file, (file, t0, t1) of another one, ('gap', seconds) or ('bleep', seconds): profanity is bleeped.
    ('v_hi',     'bloger-melstroi.mp3', [(0.55, 3.68)]),
    ('v_red',    'yt-ya-uzhe-krasnyi.mp3', [(3.00, 6.42), ('bleep', 0.45)]),
    ('v_give',   'dai-ego-khammam.mp3', [(2.06, 2.73)]),
    ('v_davai',  'yt-davai-eh-ty.mp3', [('bleep', 0.30), ('gap', 0.04), (1.39, 1.82)]),
    ('v_ludo',   'yt-ludo-priklyuchenie.mp3', [(1.98, 7.48)]),
    ('v_faster', 'yt-bystree-bystree.mp3', [(1.50, 2.04), ('gap', 0.28), (3.60, 4.20)]),
    ('v_best',   'yt-kto-luchshii.mp3', [(0.40, 1.78), (2.40, 3.42)]),
    ('v_rage',   'yt-krichit.mp3', [(1.18, 2.02), ('gap', 0.10), ('yt-davai-eh-ty.mp3', 2.86, 3.28), ('gap', 0.05), ('bleep', 0.40)]),
]
def bleep(d):
    t = np.arange(int(d * SR), dtype=np.float32) / SR
    return fade((0.42 * np.sin(2 * np.pi * 1000.0 * t)).astype(np.float32), 0.008, 0.012)
def build_voices():
    import wave
    os.makedirs('/tmp/voice_cuts', exist_ok=True)
    for name, fn, cuts in VOICE:
        x = load_audio(os.path.join(SND, fn)); parts = []
        mixed = any(len(c) == 3 for c in cuts)                  # pieces of different recordings: bring them to one level first
        for c in cuts:
            if c[0] == 'gap': parts.append(np.zeros(int(c[1] * SR), np.float32)); continue
            if c[0] == 'bleep': parts.append(bleep(c[1])); continue
            src = x if len(c) == 2 else load_audio(os.path.join(SND, c[0])); t0, t1 = c[-2], c[-1]
            pc = fade(trim(src[int(t0 * SR):int(t1 * SR)]), 0.006, 0.03)
            if mixed or any(q[0] == 'bleep' for q in cuts): pc = pc * (0.9 / (np.max(np.abs(pc)) + 1e-9))
            parts.append(pc.astype(np.float32))
        seg = np.concatenate(parts)
        seg = fade(norm(seg, 0.92, rms=0.20), 0.008, 0.05)
        add_sound(name, seg)
        w = wave.open('/tmp/voice_cuts/%s.wav' % name, 'wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((np.clip(seg, -1, 1) * 32767).astype(np.int16).tobytes()); w.close()
        print('voice %-10s %.2fs  rms %.3f' % (name, len(seg) / SR, np.sqrt(np.mean(seg * seg))))

def tt(d): return np.arange(int(d * SR), dtype=np.float32) / SR
def sweep(f0, f1, d, curve=1.0):
    t = tt(d); u = (t / d) ** curve; f = f0 + (f1 - f0) * u; return np.sin(2 * np.pi * np.cumsum(f) / SR)
def noise(d, seed=1): return np.random.RandomState(seed).uniform(-1, 1, int(d * SR)).astype(np.float32)
def lp(x, fc):
    a = math.exp(-2 * math.pi * fc / SR); y = np.empty_like(x); s = 0.0
    for i in range(len(x)): s = s * a + x[i] * (1 - a); y[i] = s
    return y
def hp(x, fc): return x - lp(x, fc)
def bell(f, d, dec=6.0, inh=2.76):
    t = tt(d); return (np.sin(2 * np.pi * f * t) + 0.45 * np.sin(2 * np.pi * f * inh * t) * np.exp(-t * dec * 1.5) + 0.2 * np.sin(2 * np.pi * f * 5.4 * t) * np.exp(-t * dec * 3)) * np.exp(-t * dec)
def marimba(f, d, dec=7.0):
    t = tt(d); return (np.sin(2 * np.pi * f * t) + 0.35 * np.sin(2 * np.pi * f * 4 * t) * np.exp(-t * 22) + 0.12 * np.sin(2 * np.pi * f * 9.2 * t) * np.exp(-t * 40)) * np.exp(-t * dec) * np.minimum(1, t / 0.003)
def mixat(buf, x, t, g=1.0):
    i = int(t * SR); n = min(len(x), len(buf) - i)
    if n > 0: buf[i:i + n] += x[:n] * g

def build_sfx():
    # rope cut: snip
    x = np.zeros(int(0.16 * SR), np.float32)
    mixat(x, hp(noise(0.03, 3), 2500) * np.exp(-tt(0.03) * 120), 0, 0.9)
    mixat(x, sweep(2200, 500, 0.11, 0.6) * np.exp(-tt(0.11) * 30), 0.004, 0.55)
    mixat(x, sweep(240, 110, 0.12) * np.exp(-tt(0.12) * 22), 0.0, 0.5)          # low "twang"
    add_sound('s_cut', fade(norm(x, 0.85)))
    # auto-rope attach
    x = np.zeros(int(0.3 * SR), np.float32); mixat(x, marimba(660, 0.14, 16), 0, 0.7); mixat(x, marimba(990, 0.2, 12), 0.07, 0.7)
    add_sound('s_attach', fade(norm(x, 0.7)))
    # stars
    for i, f in enumerate([1046.5, 1318.5, 1568.0]):
        x = np.zeros(int(0.9 * SR), np.float32)
        mixat(x, bell(f, 0.85, 5.0), 0, 0.7); mixat(x, bell(f * 2, 0.5, 9.0), 0.05, 0.3); mixat(x, bell(f * 1.5, 0.6, 8.0), 0.10, 0.25)
        mixat(x, hp(noise(0.25, 7 + i), 6000) * np.exp(-tt(0.25) * 14), 0.0, 0.10)
        add_sound('s_star%d' % (i + 1), fade(norm(x, 0.8), 0.002, 0.1))
    # bubble in / pop
    x = sweep(260, 760, 0.16, 0.7) * np.exp(-tt(0.16) * 9) * np.minimum(1, tt(0.16) / 0.01)
    x2 = np.zeros(int(0.3 * SR), np.float32); mixat(x2, x, 0, 0.8); mixat(x2, sweep(500, 1100, 0.1) * np.exp(-tt(0.1) * 18), 0.13, 0.4)
    add_sound('s_bubble', fade(norm(x2, 0.7)))
    x = np.zeros(int(0.18 * SR), np.float32); mixat(x, noise(0.02, 9) * np.exp(-tt(0.02) * 160), 0, 1.0); mixat(x, sweep(1300, 240, 0.07, 0.5) * np.exp(-tt(0.07) * 40), 0.0, 0.8)
    mixat(x, hp(noise(0.12, 11), 5000) * np.exp(-tt(0.12) * 30), 0.01, 0.25)
    add_sound('s_pop', fade(norm(x, 0.85), 0.001, 0.02))
    # blower puff
    n = noise(0.34, 13); e = np.minimum(1, tt(0.34) / 0.02) * np.exp(-tt(0.34) * 10)
    x = lp(hp(n, 500), 3800) * e + 0.35 * sweep(300, 120, 0.34) * e
    add_sound('s_blow', fade(norm(x, 0.8)))
    # ui click / tick
    x = np.zeros(int(0.09 * SR), np.float32); mixat(x, marimba(880, 0.08, 40), 0, 0.8); mixat(x, marimba(1320, 0.05, 50), 0.02, 0.5)
    add_sound('s_click', fade(norm(x, 0.6), 0.001, 0.01))
    x = marimba(1760, 0.04, 70); add_sound('s_tick', fade(norm(x, 0.35), 0.001, 0.01))
    # whoosh
    n = noise(0.42, 17); t = tt(0.42); e = np.sin(np.pi * t / 0.42) ** 2
    y = np.empty_like(n); s = 0.0
    for i in range(len(n)):
        fc = 500 + 3500 * (i / len(n)); a = math.exp(-2 * math.pi * fc / SR); s = s * a + n[i] * (1 - a); y[i] = s
    add_sound('s_whoosh', fade(norm(hp(y, 250) * e, 0.6)))
    # win jingle
    x = np.zeros(int(1.5 * SR), np.float32)
    for k, (f, tm) in enumerate([(523.25, 0.0), (659.25, 0.10), (783.99, 0.20), (1046.5, 0.32)]):
        mixat(x, marimba(f, 0.6, 6), tm, 0.7); mixat(x, bell(f * 2, 0.5, 8), tm, 0.2)
    for f in (523.25, 659.25, 783.99, 1046.5): mixat(x, bell(f, 0.95, 3.5), 0.46, 0.33)
    add_sound('s_win', fade(norm(x, 0.8), 0.002, 0.15))
    # fail "wah-wah"
    x = np.zeros(int(0.9 * SR), np.float32)
    for k, (f, tm, d) in enumerate([(311.1, 0.0, 0.3), (293.7, 0.27, 0.3), (261.6, 0.54, 0.34)]):
        t = tt(d); saw = sum(np.sin(2 * np.pi * f * h * t) / h for h in range(1, 9)); wob = 1 + 0.25 * np.sin(2 * np.pi * 7 * t)
        mixat(x, lp((saw * wob * np.minimum(1, t / 0.02) * np.exp(-t * 3.0)).astype(np.float32), 1400), tm, 0.5)
    add_sound('s_fail', fade(norm(x, 0.7), 0.004, 0.08))
    # glass break
    x = np.zeros(int(0.6 * SR), np.float32); mixat(x, hp(noise(0.3, 21), 3000) * np.exp(-tt(0.3) * 16), 0, 0.8); mixat(x, noise(0.03, 22) * np.exp(-tt(0.03) * 90), 0, 0.9)
    rs = np.random.RandomState(5)
    for k in range(14): mixat(x, bell(rs.uniform(2200, 6800), 0.25, rs.uniform(14, 30), 1.0 + rs.uniform(0.3, 0.9)), rs.uniform(0.0, 0.22), 0.16)
    add_sound('s_break', fade(norm(x, 0.85), 0.001, 0.05))
    # gulp
    x = np.zeros(int(0.42 * SR), np.float32)
    for tm in (0.0, 0.16): mixat(x, sweep(210, 120, 0.11, 0.6) * np.sin(np.pi * tt(0.11) / 0.11) ** 1.5, tm, 0.9); mixat(x, sweep(520, 300, 0.05) * np.exp(-tt(0.05) * 40), tm + 0.085, 0.25)
    add_sound('s_gulp', fade(norm(x, 0.8)))
    # level start pop
    x = sweep(420, 980, 0.12, 0.6) * np.exp(-tt(0.12) * 16); add_sound('s_start', fade(norm(x, 0.5)))
    # ---- V0.2
    # bouncer: a rubbery "boing"
    d = 0.30; t = tt(d); f = 170 + 330 * np.exp(-t * 9) * (1 + 0.35 * np.sin(2 * np.pi * 21 * t) * np.exp(-t * 5))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 9) * np.minimum(1, t / 0.004)
    x = x + 0.5 * sweep(120, 60, d) * np.exp(-t * 26)
    add_sound('s_bounce', fade(norm(x.astype(np.float32), 0.8)))
    # portal: two detuned rising tones with a shimmer
    d = 0.42; t = tt(d); e = np.sin(np.pi * t / d) ** 1.3
    x = (sweep(260, 1500, d, 1.6) + 0.7 * sweep(390, 2240, d, 1.6)) * e * (1 + 0.5 * np.sin(2 * np.pi * 30 * t)) * 0.5
    x = x + 0.25 * hp(noise(d, 41), 4000) * e
    add_sound('s_portal', fade(norm(x.astype(np.float32), 0.7)))
    # gravity flip: a low "wub" that dips and comes back
    d = 0.48; t = tt(d); f = 70 + 170 * np.abs(1 - 2 * t / d) ** 1.5
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = (np.sin(ph) + 0.4 * np.sin(2 * ph) + 0.2 * np.sin(3.01 * ph)) * np.sin(np.pi * t / d) ** 0.7
    add_sound('s_grav', fade(norm(lp(x.astype(np.float32), 1800), 0.8)))
    # laser burn: an electric buzz with crackle
    d = 0.36; t = tt(d); saw = sum(np.sin(2 * np.pi * 96 * h * t) / h for h in range(1, 24))
    x = lp(hp((saw * (0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 53 * t)))).astype(np.float32), 500), 5200) * np.exp(-t * 7)
    x = x + 0.5 * hp(noise(d, 43), 3000) * np.exp(-t * 12) * (np.random.RandomState(8).uniform(0, 1, len(t)) > 0.72)
    add_sound('s_zap', fade(norm(x.astype(np.float32), 0.75), 0.002, 0.04))
    # thief: a quick swipe and a cheeky two-note laugh
    x = np.zeros(int(0.5 * SR), np.float32)
    n = noise(0.16, 45); e = np.sin(np.pi * tt(0.16) / 0.16) ** 2; mixat(x, lp(hp(n, 900), 5200) * e, 0.0, 0.5)
    for k, (f, tm) in enumerate([(784.0, 0.13), (622.3, 0.25)]):
        tk = tt(0.16); sq = np.sign(np.sin(2 * np.pi * f * tk)) * 0.5 + np.sin(2 * np.pi * f * tk) * 0.5
        mixat(x, lp((sq * np.minimum(1, tk / 0.004) * np.exp(-tk * 13)).astype(np.float32), 3200), tm, 0.5)
    add_sound('s_steal', fade(norm(x, 0.7)))
    # thief pops up: a short squeak
    d = 0.13; t = tt(d); f = 1500 + 900 * np.sin(np.pi * t / d)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t / d) ** 0.8
    add_sound('s_squeak', fade(norm(x.astype(np.float32), 0.5), 0.003, 0.01))
    # glass crunch: shards settling after the smash (many tiny cracks and tinkles)
    x = np.zeros(int(0.75 * SR), np.float32); rs = np.random.RandomState(12)
    for k in range(46):
        tm = rs.uniform(0, 1) ** 1.6 * 0.55; dd = rs.uniform(0.006, 0.022)
        g = hp(rs.uniform(-1, 1, int(dd * SR)).astype(np.float32), rs.uniform(2500, 6000)) * np.exp(-tt(dd)[:int(dd * SR)] * rs.uniform(150, 420))
        mixat(x, g, tm, rs.uniform(0.35, 1.0) * (1 - tm))
    for k in range(18): mixat(x, bell(rs.uniform(3000, 8200), 0.16, rs.uniform(22, 44), 1.0 + rs.uniform(0.2, 0.8)), rs.uniform(0.02, 0.5), 0.10)
    mixat(x, lp(noise(0.05, 47), 900) * np.exp(-tt(0.05) * 60), 0.0, 0.5)                 # the dull hit itself
    add_sound('s_glass', fade(norm(x, 0.85), 0.001, 0.06))
    # splash: the drink spills
    d = 0.55; t = tt(d); n = noise(d, 49); y = np.empty_like(n); st = 0.0
    for i in range(len(n)):
        fc = 3600 * math.exp(-i / len(n) * 3.2) + 350; a = math.exp(-2 * math.pi * fc / SR); st = st * a + n[i] * (1 - a); y[i] = st
    x = hp(y, 180) * np.minimum(1, t / 0.008) * np.exp(-t * 6.5) * 1.6
    rs = np.random.RandomState(15)
    for k in range(7):
        f0 = rs.uniform(500, 1300); dd = rs.uniform(0.03, 0.06); mixat(x, sweep(f0, f0 * 1.9, dd, 0.7) * np.sin(np.pi * tt(dd) / dd) ** 2, rs.uniform(0.08, 0.42), 0.22)
    add_sound('s_splash', fade(norm(x.astype(np.float32), 0.75), 0.002, 0.08))

def build_music():
    bpm = 116.0; beat = 60.0 / bpm; bars = 16; total = bars * 4 * beat
    N = int(total * SR); buf = np.zeros(N + SR * 3, np.float32)
    A4 = 440.0
    def nf(name):
        names = {'C': -9, 'D': -7, 'E': -5, 'F': -4, 'G': -2, 'A': 0, 'B': 2}
        n = names[name[0]]; i = 1
        if name[i] == '#': n += 1; i += 1
        elif name[i] == 'b': n -= 1; i += 1
        return A4 * 2 ** ((n + (int(name[i:]) - 4) * 12) / 12.0)
    chords = ['C', 'C', 'F', 'F', 'G', 'G', 'C', 'C', 'Am', 'Am', 'F', 'F', 'G', 'G', 'C', 'G7']
    cn = {'C': ('C3', 'G2', ['E4', 'G4', 'C5']), 'F': ('F2', 'C3', ['F4', 'A4', 'C5']), 'G': ('G2', 'D3', ['D4', 'G4', 'B4']),
          'Am': ('A2', 'E3', ['E4', 'A4', 'C5']), 'G7': ('G2', 'D3', ['F4', 'G4', 'B4'])}
    mel = ["E5 . G5 . E5 . C5 .", "D5 E5 D5 C5 G4 . . .", "F5 . A5 . F5 . C5 .", "D5 F5 E5 D5 C5 . . .",
           "G5 . B5 . G5 . D5 .", "F5 G5 F5 D5 B4 . . .", "C5 E5 G5 C6 . G5 E5 .", "C5 . . . . . G4 .",
           "A4 C5 E5 A5 . E5 C5 .", "A5 . G5 . E5 . C5 .", "F5 . A5 . C6 . A5 .", "F5 E5 D5 C5 A4 . . .",
           "G4 B4 D5 G5 . D5 B4 .", "G5 . F5 . D5 . B4 .", "C5 E5 G5 E5 C6 . G5 .", "B4 D5 F5 G5 . . . ."]
    swing = 0.10
    def stab(freqs, d=0.16):
        t = tt(d); x = np.zeros_like(t)
        for f in freqs:
            for h in range(1, 7): x += np.sin(2 * np.pi * f * h * t) / h * (0.8 if h % 2 else 0.45)
        return x * np.minimum(1, t / 0.004) * np.exp(-t * 16) / len(freqs)
    def bass(f, d=0.42):
        t = tt(d); return (np.sin(2 * np.pi * f * t) + 0.35 * np.sin(2 * np.pi * 2 * f * t) + 0.12 * np.sin(2 * np.pi * 3 * f * t)) * np.minimum(1, t / 0.006) * np.exp(-t * 5.5)
    kick = sweep(150, 46, 0.2, 0.5) * np.exp(-tt(0.2) * 16)
    hat = hp(noise(0.05, 31), 6500) * np.exp(-tt(0.05) * 70)
    snare = hp(noise(0.12, 33), 1800) * np.exp(-tt(0.12) * 28); mixat(snare, sweep(240, 170, 0.08) * np.exp(-tt(0.08) * 30), 0, 0.5)
    for b in range(bars):
        t0 = b * 4 * beat; root, fifth, tri = cn[chords[b]]
        mixat(buf, bass(nf(root)), t0, 0.50); mixat(buf, bass(nf(fifth)), t0 + 2 * beat, 0.44)
        if b % 4 == 3: mixat(buf, bass(nf(root) * 1.122), t0 + 3.5 * beat + swing * beat * 0.5, 0.3)
        for k in (1, 3): mixat(buf, stab([nf(n) for n in tri]), t0 + k * beat, 0.26)
        mixat(buf, stab([nf(n) for n in tri], 0.1), t0 + 2.5 * beat + swing * beat * 0.5, 0.13)
        for k in (0, 2): mixat(buf, kick, t0 + k * beat, 0.5)
        for k in (1, 3): mixat(buf, snare, t0 + k * beat, 0.20)
        for k in range(8): mixat(buf, hat, t0 + k * 0.5 * beat + (swing * beat * 0.5 if k % 2 else 0), 0.10 if k % 2 == 0 else 0.065)
        notes = mel[b].split()
        for k, nm in enumerate(notes):
            if nm == '.': continue
            tn = t0 + k * 0.5 * beat + (swing * beat * 0.5 if k % 2 else 0)
            f = nf(nm); mixat(buf, marimba(f, 0.5, 6.5), tn, 0.36); mixat(buf, marimba(f * 2, 0.3, 10), tn, 0.07)
            if b >= 8: mixat(buf, bell(f * 2, 0.4, 9.0), tn, 0.045)           # sparkle doubling in the second half
    loop = buf[:N].copy(); tail = buf[N:]; loop[:len(tail)] += tail[:N]             # wrap the tail -> seamless loop
    loop = lp(loop, 7000)
    loop = np.tanh(loop / (np.max(np.abs(loop)) + 1e-9) * 1.25) / 1.25
    add_sound('music', norm(loop, 0.78))
    import wave
    w = wave.open('/tmp/music_preview.wav', 'wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((norm(loop, 0.78) * 32767).astype(np.int16).tobytes()); w.close()
    print('music %.1fs' % (N / SR))

# ----------------------------------------------------------------------------- icon + pack
def build_icon(bottle):
    S = 256; im = Image.new('RGBA', (S * 2, S * 2), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([8, 8, S * 2 - 9, S * 2 - 9], radius=96, fill=(40, 30, 110, 255))
    g = np.asarray(im).astype(np.float32); yy = np.linspace(0, 1, S * 2)[:, None, None]
    g[..., :3] = np.array([120, 70, 235], np.float32) * (1 - yy) + np.array([40, 28, 120], np.float32) * yy
    im = Image.fromarray(g.astype(np.uint8), 'RGBA')
    bt = Image.fromarray(bottle, 'RGBA'); h = int(S * 2 * 0.86); bt = bt.resize((int(bt.width * h / bt.height), h), Image.LANCZOS).rotate(-16, resample=Image.BICUBIC, expand=True)
    im.alpha_composite(bt, ((S * 2 - bt.width) // 2, (S * 2 - bt.height) // 2))
    im = im.resize((S, S), Image.LANCZOS)
    im.save(os.path.join(OUTDIR, 'icon.ico'), sizes=[(256, 256), (64, 64), (48, 48), (32, 32), (16, 16)])
    im.save(os.path.join(OUTDIR, 'icon.png'))

def write_pack(path):
    n = len(entries); hdr = 16 + 60 * n; off = hdr; blobs = []; table = b''
    for name, typ, data, a, b, c, d in entries:
        pad = (-off) % 4; off += pad; blobs.append(b'\0' * pad + data)
        table += struct.pack('<32sIIIiiii', name.encode(), typ, off, len(data), a, b, c, d); off += len(data)
    with open(path, 'wb') as f:
        f.write(b'MNPK' + struct.pack('<III', 1, n, 0)); f.write(table)
        for bl in blobs: f.write(bl)
        f.write(b'\0' * ((-off) % 16))
    print('pack: %d entries, %.2f MB -> %s' % (n, os.path.getsize(path) / 1e6, path))
    by = {}
    for name, typ, data, *_ in entries: by[typ] = by.get(typ, 0) + len(data)
    print('  by type:', {k: '%.0fK' % (v / 1024) for k, v in by.items()})

if __name__ == '__main__':
    bottle = build_sprites(); build_star(); build_pin_bubble(); build_backgrounds(bottle)
    build_font('ui', 1000, 80, 4.8, 4.0, spacing=2.0)
    build_font('txt', 800, 52, 0, 0)
    build_clips(); build_voices(); build_sfx(); build_music(); build_icon(bottle)
    write_pack(os.path.join(OUTDIR, 'pack.bin'))
