#!/usr/bin/env python3
"""Glue the web build into ONE self-contained file: MelNyam.html.

   web/shell.html      page, canvas, input, WebAudio, storage
   gen/game.wasm       the game compiled to WebAssembly
   gen/game_js.mjs     the same module translated to plain JS by binaryen's wasm2js (optional fallback
                       for pages where WebAssembly is forbidden by a Content-Security-Policy)
   gen/pack.bin        assets
"""
import base64, io, os, sys
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(p, mode='rb'):
    with open(os.path.join(ROOT, p), mode, **({} if 'b' in mode else {'encoding': 'utf-8'})) as f: return f.read()
def b64(data, width=8000):
    s = base64.b64encode(data).decode('ascii')
    return '\n'.join(s[i:i + width] for i in range(0, len(s), width))

shell = rd('web/shell.html', 'r')
icon = Image.open(os.path.join(ROOT, 'gen/icon.png')).convert('RGBA').resize((64, 64), Image.LANCZOS)
buf = io.BytesIO(); icon.save(buf, 'PNG', optimize=True)

fallback = '/* no JS fallback in this build */'
fb_path = os.path.join(ROOT, 'gen/game_js.mjs')
if os.path.exists(fb_path):
    src = rd('gen/game_js.mjs', 'r')
    cut = src.index('var retasmFunc = asmFunc(')                  # drop the ES-module tail (instantiation + exports)
    lines = [l.strip() for l in src[:cut].split('\n') if not l.startswith('import * as ')]
    body = '\n'.join(l for l in lines if l)
    assert '</script' not in body.lower() and '<!--' not in body
    fallback = 'window.__melnyam_js = function (imports) {\n' + body + '\nreturn asmFunc(imports);\n};'

parts = {'__ICON_B64__': base64.b64encode(buf.getvalue()).decode('ascii'),
         '__PACK_B64__': b64(rd('gen/pack.bin')), '__WASM_B64__': b64(rd('gen/game.wasm')), '/*__FALLBACK_JS__*/': fallback}
out = shell
for k, v in parts.items():
    assert out.count(k) == 1, k
    out = out.replace(k, v)
dst = os.path.join(ROOT, sys.argv[1] if len(sys.argv) > 1 else 'MelNyam.html')
with open(dst, 'w', encoding='utf-8', newline='\n') as f: f.write(out)
print('%s: %.2f MB (pack %.2f MB, wasm %d KB, js fallback %d KB)' % (os.path.basename(dst), len(out.encode('utf-8')) / 1048576,
      len(parts['__PACK_B64__']) / 1048576, len(parts['__WASM_B64__']) // 1024, len(fallback) // 1024))
