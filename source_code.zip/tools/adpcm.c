/* IMA ADPCM (4 bit, low nibble first) encoder used by make_assets.py; the decoder lives in src/engine.c */
static const int idxtab[16] = { -1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8 };
static const int steptab[89] = { 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230,
    253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871,
    5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767 };
void adpcm_encode(const short *in, int n, unsigned char *out) {
    int pred = 0, idx = 0;
    for (int i = 0; i < n; i++) {
        int step = steptab[idx], diff = in[i] - pred, nib = 0, vp = step >> 3;
        if (diff < 0) { nib = 8; diff = -diff; }
        if (diff >= step) { nib |= 4; diff -= step; vp += step; }
        if (diff >= (step >> 1)) { nib |= 2; diff -= step >> 1; vp += step >> 1; }
        if (diff >= (step >> 2)) { nib |= 1; vp += step >> 2; }
        if (nib & 8) pred -= vp; else pred += vp;
        if (pred > 32767) pred = 32767; if (pred < -32768) pred = -32768;
        idx += idxtab[nib]; if (idx < 0) idx = 0; if (idx > 88) idx = 88;
        if (i & 1) out[i >> 1] |= (unsigned char)(nib << 4); else out[i >> 1] = (unsigned char)nib;
    }
}
