// Runs the web build without a browser:  node tools/node_test.mjs simhash [js]
//   simhash  prints one physics hash per level (must be identical to `headless simhash` and `MelNyam.exe --simhash`)
//   demotest plays the stored solution of every level through the whole game loop
// "js" as the last argument tests the plain-JS fallback (wasm2js) instead of WebAssembly.
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const mode = process.argv[2] || 'simhash', useJS = process.argv[3] === 'js';
let ex, mem;
const blobs = {};
const env = {
  js_save() {}, js_load() { return 0; }, js_fullscreen() {}, js_caps() { return 0; }, js_log() {},
  js_store(kp, kn, p, n) { blobs[Buffer.from(mem.buffer, kp, kn).toString()] = Buffer.from(new Uint8Array(mem.buffer, p, n)); },
  js_fetch(kp, kn, p, max) { const b = blobs[Buffer.from(mem.buffer, kp, kn).toString()]; if (!b) return 0; const n = Math.min(b.length, max); new Uint8Array(mem.buffer, p, n).set(b.subarray(0, n)); return n; },
  js_http() {}, js_random() { return 12345; },
};
const nosys = () => 52;
const wasi = new Proxy({ proc_exit() { throw new Error('exit'); } }, { get: (t, k) => (k in t ? t[k] : nosys) });
const imports = { env, wasi_snapshot_preview1: wasi };
if (useJS) {
  const src = fs.readFileSync(path.join(ROOT, 'gen/game_js.mjs'), 'utf8');
  const cut = src.indexOf('var retasmFunc = asmFunc(');
  const body = src.slice(0, cut).split('\n').filter(l => !l.startsWith('import * as ')).join('\n');
  ex = new Function('imports', body + '\nreturn asmFunc(imports);')(imports);
} else {
  ex = (await WebAssembly.instantiate(fs.readFileSync(path.join(ROOT, 'gen/game.wasm')), imports)).instance.exports;
}
mem = ex.memory;
if (ex._initialize) ex._initialize();
const pack = fs.readFileSync(path.join(ROOT, 'gen/pack.bin'));
const p = ex.web_alloc(pack.length);
new Uint8Array(mem.buffer, p, pack.length).set(pack);
ex.web_init(p, pack.length, 44100);
ex.web_resize(640, 360);
const count = ex.web_debug(28, 0);
if (mode === 'simhash') {
  console.log('sim ' + ex.web_debug(31, 0));
  for (let lv = 0; lv < count; lv++) console.log(lv + ' ' + ex.web_debug(30, lv));
} else if (mode === 'demotest') {
  let bad = 0;
  for (let lv = 0; lv < count; lv++) {
    ex.web_debug(2, lv); let res = 0, stars = 0; const need = ex.web_debug(25, lv);
    for (let i = 0; i < 60 * 40; i++) { ex.web_frame(1 / 60); const st = ex.web_debug(4, 0); if (st & 15) { res = st & 15; stars = (st >> 4) & 15; break; } }
    if (res !== 1 || stars !== need) { bad++; console.log('level ' + (lv + 1) + ': result=' + res + ' stars=' + stars + '/' + need); }
  }
  console.log('demotest (' + (useJS ? 'js' : 'wasm') + '): ' + count + ' levels, ' + bad + ' bad');
  process.exit(bad ? 1 : 0);
}
