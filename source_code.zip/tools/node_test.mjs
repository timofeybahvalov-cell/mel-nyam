// Runs the web build without a browser:  node tools/node_test.mjs simhash [js]
//   simhash  prints one physics hash per level (must be identical to `headless simhash` and `MelNyam.exe --simhash`)
//   demotest plays the stored solution of every level through the whole game loop
//   tastest  plays every stored TAS run through the whole game loop: all the stars, at exactly the stored step
//   tas [js] [levels...]  the TAS search inside the game with real frame times, as in a browser (default levels: 4 13 21)
//   tasslow [js] [level]  the same search on a device that is far too slow: after 30 s the game must stop and show what it has
// "js" as the last argument tests the plain-JS fallback (wasm2js) instead of WebAssembly.
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const mode = process.argv[2] || 'simhash', useJS = process.argv[3] === 'js';
const rest = process.argv.slice(useJS ? 4 : 3);
let ex, mem;
const blobs = {};
const env = {
  js_save() {}, js_load() { return 0; }, js_fullscreen() {}, js_caps() { return 0; }, js_log() {},
  js_store(kp, kn, p, n) { blobs[Buffer.from(mem.buffer, kp, kn).toString()] = Buffer.from(new Uint8Array(mem.buffer, p, n)); },
  js_fetch(kp, kn, p, max) { const b = blobs[Buffer.from(mem.buffer, kp, kn).toString()]; if (!b) return 0; const n = Math.min(b.length, max); new Uint8Array(mem.buffer, p, n).set(b.subarray(0, n)); return n; },
  js_http() {}, js_random() { return 12345; }, js_snd() {}, js_ctl() { return 0; },
};
const nosys = () => 52;
const wasi = new Proxy({ proc_exit() { throw new Error('exit'); } }, { get: (t, k) => (k in t ? t[k] : nosys) });
const imports = { env, wasi_snapshot_preview1: wasi };
if (useJS) {
  const src = fs.readFileSync(path.join(ROOT, 'gen/game_js.mjs'), 'utf8');
  const cut = src.indexOf('var retasmFunc = asmFunc(');
  const body = src.slice(0, cut).split('\n').filter(l => !l.startsWith('import * as ')).join('\n');
  ex = new Function('imports', body + '\nreturn asmFunc(imports);')(imports);
} else {
  ex = (await WebAssembly.instantiate(fs.readFileSync(path.join(ROOT, 'gen/game.wasm')), imports)).instance.exports;
}
mem = ex.memory;
if (ex._initialize) ex._initialize();
const pack = fs.readFileSync(path.join(ROOT, 'gen/pack.bin'));
const p = ex.web_alloc(pack.length);
new Uint8Array(mem.buffer, p, pack.length).set(pack);
ex.web_init(p, pack.length, 44100);
ex.web_resize(640, 360);
const count = ex.web_debug(28, 0);
if (mode === 'simhash') {
  console.log('sim ' + ex.web_debug(31, 0));
  for (let lv = 0; lv < count; lv++) console.log(lv + ' ' + ex.web_debug(30, lv));
} else if (mode === 'demotest') {
  let bad = 0;
  for (let lv = 0; lv < count; lv++) {
    ex.web_debug(2, lv); let res = 0, stars = 0; const need = ex.web_debug(25, lv);
    for (let i = 0; i < 60 * 40; i++) { ex.web_frame(1 / 60); const st = ex.web_debug(4, 0); if (st & 15) { res = st & 15; stars = (st >> 4) & 15; break; } }
    if (res !== 1 || stars !== need) { bad++; console.log('level ' + (lv + 1) + ': result=' + res + ' stars=' + stars + '/' + need); }
  }
  console.log('demotest (' + (useJS ? 'js' : 'wasm') + '): ' + count + ' levels, ' + bad + ' bad');
  process.exit(bad ? 1 : 0);
} else if (mode === 'tas') {
  // every level: the stored solution is played as a counted run (that is "the player's record"), then the search starts from it
  const list = rest.length ? rest.map(Number) : [4, 13, 21];
  console.log('TAS runs that pass the check: ' + ex.web_debug(122, 0) + ' of ' + count + ', proved ' + ex.web_debug(136, 0) + '; memory before the search ' + (mem.buffer.byteLength / 1048576).toFixed(0) + ' MB');
  for (const lv of list) {
    ex.web_debug(34, lv);
    for (let i = 0; i < 60 * 60; i++) { ex.web_frame(1 / 60); if (ex.web_debug(4, 0) & 15) break; }
    for (let i = 0; i < 30; i++) ex.web_frame(1 / 60);
    if (!ex.web_debug(139, lv)) { console.log('level ' + lv + ': the search did not start'); continue; }
    const own = ex.web_debug(133, 0), t0 = performance.now(); let dt = 1 / 60, worst = 0, frames = 0, st = 0;
    for (;;) {
      const f0 = performance.now(); ex.web_frame(dt); const el = performance.now() - f0;
      if (el > worst) worst = el; frames++;
      dt = Math.ceil((el + 3) / 16.667) * 16.667 / 1000;          /* a 60 Hz screen: the frame lasts a whole number of refreshes */
      st = ex.web_debug(124, 0); if (((st >> 1) & 7) !== 1 || frames > 200000) break;
    }
    const sec = (performance.now() - t0) / 1000;
    console.log('level ' + lv + ' (' + (useJS ? 'js' : 'wasm') + '): own ' + own + ' -> search ' + ex.web_debug(125, 0) + ' (stored ' + ex.web_debug(121, lv) + ')  ' + sec.toFixed(1) + ' s, ' + frames + ' frames, slowest frame ' +
      worst.toFixed(0) + ' ms, tried ' + ex.web_debug(131, 0) + 'k, state ' + ((st >> 1) & 7) + ', memory ' + (mem.buffer.byteLength / 1048576).toFixed(0) + ' MB');
    ex.web_debug(134, 0); ex.web_debug(135, 0);
  }
} else if (mode === 'tastest') {
  let bad = 0, proved = 0;
  for (let lv = 0; lv < count; lv++) {
    ex.web_debug(130, 0);
    const want = ex.web_debug(121, lv), need = ex.web_debug(25, lv); let res = 0, stars = 0, ticks = 0;
    if (ex.web_debug(120, lv)) for (let i = 0; i < 60 * 60; i++) {
      ex.web_frame(1 / 60); const st = ex.web_debug(4, 0);
      if (((st >> 12) & 15) === 3 && (st & 15) !== 0) { res = st & 15; stars = (st >> 4) & 15; ticks = ex.web_debug(27, 0); break; }
    }
    if (!(want > 0 && res === 1 && stars === need && ticks === want)) { bad++; console.log('level ' + (lv + 1) + ': BAD result=' + res + ' stars=' + stars + '/' + need + ' steps=' + ticks + ' want=' + want); }
    proved += ex.web_debug(129, lv);
  }
  console.log('tastest (' + (useJS ? 'js' : 'wasm') + '): ' + count + ' levels, ' + bad + ' bad, ' + proved + ' proved');
  process.exit(bad ? 1 : 0);
} else if (mode === 'tasslow') {
  // every frame takes 0.1 s of game time, so the search gets its smallest portions: the 30 s limit has to end it
  const lv = rest.length ? Number(rest[0]) : 21;
  ex.web_debug(34, lv);
  for (let i = 0; i < 60 * 60; i++) { ex.web_frame(1 / 60); if (ex.web_debug(4, 0) & 15) break; }
  for (let i = 0; i < 30; i++) ex.web_frame(1 / 60);
  const started = ex.web_debug(139, lv), own = ex.web_debug(133, 0); let frames = 0, st = 0;
  for (;;) { ex.web_frame(0.1); frames++; st = ex.web_debug(124, 0); if (((st >> 1) & 7) !== 1 || frames > 5000) break; }
  console.log('tasslow (' + (useJS ? 'js' : 'wasm') + '), level ' + lv + ': started ' + started + ', own ' + own + ' -> ' + ex.web_debug(125, 0) + ' after ' + (frames / 10).toFixed(1) + ' s of game time, state ' + ((st >> 1) & 7) +
    ', progress shown ' + ((st >> 4) / 10).toFixed(0) + '%, tried ' + ex.web_debug(131, 0) + 'k, stopped by the time limit: ' + ((ex.web_debug(132, 0) >> 30) & 1));
  process.exit(((st >> 1) & 7) === 2 && frames < 320 && ((ex.web_debug(132, 0) >> 30) & 1) ? 0 : 1);
}
