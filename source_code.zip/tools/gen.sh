#!/bin/bash
# rebuild + run the level generator:  gen.sh [level#] [pstep]
cd "$(dirname "$0")"
gcc -O2 -Wall -I../src lvlgen.c ../src/sim.c -lm -o /tmp/lvlgen || exit 1
/tmp/lvlgen ../src/levels.h /tmp/levels.json "$@"
