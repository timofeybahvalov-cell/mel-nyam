#!/bin/bash
# rebuild + run the level generator:  gen.sh [first [last [pstep]]]   (verbose for levels first..last)
cd "$(dirname "$0")"
gcc -O2 -Wall -Wno-misleading-indentation -ffp-contract=off -I../src lvlgen.c ../src/sim.c -lm -o /tmp/lvlgen || exit 1
/tmp/lvlgen ../src/levels.h /tmp/levels.json "$@"
