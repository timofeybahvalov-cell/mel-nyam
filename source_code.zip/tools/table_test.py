#!/usr/bin/env python3
"""Protocol test of the records table (server/Code.gs).

    python3 tools/table_test.py http://127.0.0.1:8787/exec          # the local stand-in (tools/mock_server.mjs)
    python3 tools/table_test.py https://script.google.com/macros/s/XXXX/exec  quick   # the real one: a short smoke test

It talks to the table exactly like the game does and checks the answers."""
import sys, random, urllib.request, urllib.parse

API = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8787/exec'
QUICK = len(sys.argv) > 2
SALT = b'mel-nyam/v2/4eKywka'

def fnv(h, b):
    for c in b:
        h = ((h ^ c) * 16777619) & 0xFFFFFFFF
    return h

def sig(*parts):
    parts = list(parts) + [''] * (5 - len(parts))
    h = fnv(2166136261, SALT)
    for p in parts:
        h = fnv(h, b'|'); h = fnv(h, p.encode('utf-8'))
    return '%08x' % h

def get(**q):
    with urllib.request.urlopen(API + '?' + urllib.parse.urlencode(q), timeout=40) as r:
        return r.read().decode('utf-8')

def post(*fields):
    req = urllib.request.Request(API, data='\t'.join(fields).encode('utf-8'), headers={'Content-Type': 'text/plain;charset=utf-8'})
    with urllib.request.urlopen(req, timeout=40) as r:
        return r.read().decode('utf-8')

def replay(ticks, stars, n=1):
    acts = ''.join('%08x' % ((min(ticks, 10 + 7 * i) << 15) | (1 << 12) | 0x10) for i in range(n))
    return '%d_%d_%s' % (ticks, stars, acts)

def sub(level, uid, nick, stars, ticks, rep=None, bad_sig=False):
    rep = rep or replay(ticks, stars)
    s = sig(level, str(uid), nick, rep)
    return post('sub', level, str(uid), nick, str(stars), str(ticks), rep, 'deadbeef' if bad_sig else s)

fails = 0
def check(name, cond, info=''):
    global fails
    print(('ok   ' if cond else 'FAIL ') + name + ('' if cond else '   ' + str(info)[:300]))
    if not cond: fails += 1

level = 'b%02d-%04x' % (random.randrange(20, 50), random.randrange(65536))
check('ping', get(a='ping').startswith('ok\tmel-nyam'))
check('empty table', get(a='top', l=level) == 'ok\t0', get(a='top', l=level))
r = sub(level, 5001, 'Первый', 3, 500); check('first record is rank 1', r == 'ok\t1', r)
r = sub(level, 5002, 'Second', 3, 400); check('faster record takes rank 1', r == 'ok\t1', r)
r = sub(level, 5003, 'Третий', 2, 100); check('fewer stars rank lower', r == 'ok\t3', r)
r = sub(level, 5001, 'Первый', 3, 450); check('improved own record', r == 'ok\t2', r)
r = sub(level, 5001, 'Первый', 3, 900); check('worse run keeps the old record', r == 'ok\t2', r)
t = get(a='top', l=level).split('\n')
check('table has 3 rows', t[0] == 'ok\t3' and len(t) == 4, t)
rows = [x.split('\t') for x in t[1:]]
check('order and values', [(x[1], x[2], x[3]) for x in rows] == [('Second', '3', '400'), ('Первый', '3', '450'), ('Третий', '2', '100')], rows)
check('public ids match the game formula', rows[1][4] == sig('p', '5001', level), rows[1])
r = get(a='rep', l=level, p=rows[0][4]); check('replay download', r == 'ok\tSecond\t' + replay(400, 3), r)
check('unknown replay', get(a='rep', l=level, p='00000000').startswith('err'))
check('bad signature refused', sub(level, 5004, 'Хакер', 3, 1, bad_sig=True) == 'err\tsig')
check('replay must match the values', post('sub', level, '5004', 'Хакер', '3', '50', replay(60, 3), sig(level, '5004', 'Хакер', replay(60, 3))) == 'err\treplay')
check('too many stars refused', sub(level, 5004, 'Хакер', 9, 50).startswith('err'))
check('bad level key refused', sub('zz', 5004, 'Хакер', 3, 50).startswith('err'))
r = sub(level, 5005, 'бл' + 'ядь', 1, 77); t = get(a='top', l=level)
check('rude nick is replaced', r.startswith('ok') and '\tИгрок\t1\t77\t' in t, t)
r = sub(level, 5001, 'Новый_ник', 3, 999); t = get(a='top', l=level)
check('nick change is shown', 'Новый_ник\t3\t450' in t, t)

if not QUICK:
    lv2 = 'b%02d-%04x' % (random.randrange(20, 50), random.randrange(65536))
    for i in range(104):
        sub(lv2, 7000 + i, 'Игрок%d' % i, 3 if i % 3 else 2, 300 + (i * 37) % 211)
    t = get(a='top', l=lv2).split('\n'); rows = [x.split('\t') for x in t[1:]]
    keys = [(-int(x[2]), int(x[3])) for x in rows]
    check('top is cut to 100 rows', t[0] == 'ok\t100' and len(rows) == 100, t[0])
    check('top is sorted (stars, then time)', keys == sorted(keys))
    check('a run outside the top 100 is not stored', sub(lv2, 9999, 'Слабый', 0, 5000) == 'ok\t0')
    r = sub(lv2, 9998, 'Быстрый', 3, 5); check('a new best enters at rank 1', r == 'ok\t1', r)
    t = get(a='top', l=lv2).split('\n'); check('still 100 rows, the new best is first', t[0] == 'ok\t100' and t[1].split('\t')[1] == 'Быстрый', t[:2])

# ---- levels made by players ----
data = '1;2;1,6400,2500;2,6400,900;4,6400,3500;4,6400,4200;4,6400,4900;8,6400,5900'
rep = replay(240, 3)
def pub(uid, nick, name, data, rep):
    return post('pub', str(uid), nick, name, data, rep, sig('pub', str(uid), name, data, rep))
name = 'Тест %d' % random.randrange(1000, 9999)
r = pub(5001, 'Автор', name, data, rep); check('publish a level', r.startswith('ok\t'), r)
lid = int(r.split('\t')[1]) if r.startswith('ok\t') else 0
t = get(a='list', s='new', o=0).split('\n')
check('the level is first in the list of new levels', len(t) > 1 and t[1].split('\t')[:4] == [str(lid), name, 'Автор', '3'], t[:2])
r = get(a='lvl', id=lid); check('level download', r == '\t'.join(['ok', str(lid), name, 'Автор', data, rep]), r)
t = get(a='top', l='u%d' % lid); check('the author holds the first record of his level', t.startswith('ok\t1\n1\tАвтор\t3\t240\t'), t)
r = sub('u%d' % lid, 5002, 'Гость', 3, 200); check('a record on a player level', r == 'ok\t1', r)
check('records on unknown player levels are refused', sub('u999999', 5002, 'Гость', 3, 200).startswith('err'))
check('level without Mel refused', pub(5001, 'Автор', 'Плохой', '1;2;1,6400,2500;2,6400,900;4,6400,3500', rep) == 'err\tdata')
check('garbage level refused', pub(5001, 'Автор', 'Плохой', '1;2;abc', rep) == 'err\tdata')
check('rude level name refused', pub(5001, 'Автор', 'ху' + 'й вам', data, rep) == 'err\tname')
check('bad signature refused', post('pub', '5001', 'Автор', 'Ещё', data, rep, '12345678') == 'err\tsig')
check('unknown level', get(a='lvl', id=99999999).startswith('err'))
print('\n%s' % ('ALL OK' if not fails else '%d FAILED' % fails))
sys.exit(1 if fails else 0)
