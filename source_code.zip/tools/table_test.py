#!/usr/bin/env python3
"""Protocol test of the records table (server/Code.gs).

    python3 tools/table_test.py http://127.0.0.1:8787/exec          # the local stand-in (tools/mock_server.mjs)
    python3 tools/table_test.py https://script.google.com/macros/s/XXXX/exec  quick   # the real one: a short smoke test
    MN_ADMIN_PW=... python3 tools/table_test.py http://127.0.0.1:8787/exec             # with the admin password: the admin commands too
                                                                                         # (the stand-in: MOCK_ADMIN_PW=... node tools/mock_server.mjs)

It talks to the table exactly like the game does and checks the answers."""
import sys, os, time, random, hashlib, hmac, urllib.request, urllib.parse

API = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8787/exec'
QUICK = len(sys.argv) > 2
SALT = b'mel-nyam/v2/4eKywka'

def fnv(h, b):
    for c in b:
        h = ((h ^ c) * 16777619) & 0xFFFFFFFF
    return h

def sig(*parts):
    parts = list(parts) + [''] * (5 - len(parts))
    h = fnv(2166136261, SALT)
    for p in parts:
        h = fnv(h, b'|'); h = fnv(h, p.encode('utf-8'))
    return '%08x' % h

def get(**q):
    with urllib.request.urlopen(API + '?' + urllib.parse.urlencode(q), timeout=40) as r:
        return r.read().decode('utf-8')

def post(*fields):
    req = urllib.request.Request(API, data='\t'.join(fields).encode('utf-8'), headers={'Content-Type': 'text/plain;charset=utf-8'})
    with urllib.request.urlopen(req, timeout=40) as r:
        return r.read().decode('utf-8')

def replay(ticks, stars, n=1):
    acts = ''.join('%08x' % ((min(ticks, 10 + 7 * i) << 15) | (1 << 12) | 0x10) for i in range(n))
    return '%d_%d_%s' % (ticks, stars, acts)

def sub(level, uid, nick, stars, ticks, rep=None, bad_sig=False):
    rep = rep or replay(ticks, stars)
    s = sig(level, str(uid), nick, rep)
    return post('sub', level, str(uid), nick, str(stars), str(ticks), rep, 'deadbeef' if bad_sig else s)

fails = 0
def check(name, cond, info=''):
    global fails
    print(('ok   ' if cond else 'FAIL ') + name + ('' if cond else '   ' + str(info)[:300]))
    if not cond: fails += 1

level = 'b%02d-%04x' % (random.randrange(20, 50), random.randrange(65536))
check('ping', get(a='ping').startswith('ok\tmel-nyam'))
check('empty table', get(a='top', l=level) == 'ok\t0', get(a='top', l=level))
r = sub(level, 5001, 'Первый', 3, 500); check('first record is rank 1', r == 'ok\t1', r)
r = sub(level, 5002, 'Second', 3, 400); check('faster record takes rank 1', r == 'ok\t1', r)
r = sub(level, 5003, 'Третий', 2, 100); check('fewer stars rank lower', r == 'ok\t3', r)
r = sub(level, 5001, 'Первый', 3, 450); check('improved own record', r == 'ok\t2', r)
r = sub(level, 5001, 'Первый', 3, 900); check('worse run keeps the old record', r == 'ok\t2', r)
t = get(a='top', l=level).split('\n')
check('table has 3 rows', t[0] == 'ok\t3' and len(t) == 4, t)
rows = [x.split('\t') for x in t[1:]]
check('order and values', [(x[1], x[2], x[3]) for x in rows] == [('Second', '3', '400'), ('Первый', '3', '450'), ('Третий', '2', '100')], rows)
check('public ids match the game formula', rows[1][4] == sig('p', '5001', level), rows[1])
r = get(a='rep', l=level, p=rows[0][4]); check('replay download', r == 'ok\tSecond\t' + replay(400, 3), r)
check('unknown replay', get(a='rep', l=level, p='00000000').startswith('err'))
check('bad signature refused', sub(level, 5004, 'Хакер', 3, 1, bad_sig=True) == 'err\tsig')
check('replay must match the values', post('sub', level, '5004', 'Хакер', '3', '50', replay(60, 3), sig(level, '5004', 'Хакер', replay(60, 3))) == 'err\treplay')
check('too many stars refused', sub(level, 5004, 'Хакер', 9, 50).startswith('err'))
check('bad level key refused', sub('zz', 5004, 'Хакер', 3, 50).startswith('err'))
r = sub(level, 5005, 'бл' + 'ядь', 1, 77); t = get(a='top', l=level)
check('rude nick is replaced', r.startswith('ok') and '\tИгрок\t1\t77\t' in t, t)
r = sub(level, 5001, 'Новый_ник', 3, 999); t = get(a='top', l=level)
check('nick change is shown', 'Новый_ник\t3\t450' in t, t)

if not QUICK:
    lv2 = 'b%02d-%04x' % (random.randrange(20, 50), random.randrange(65536))
    for i in range(104):
        sub(lv2, 7000 + i, 'Игрок%d' % i, 3 if i % 3 else 2, 300 + (i * 37) % 211)
    t = get(a='top', l=lv2).split('\n'); rows = [x.split('\t') for x in t[1:]]
    keys = [(-int(x[2]), int(x[3])) for x in rows]
    check('top is cut to 100 rows', t[0] == 'ok\t100' and len(rows) == 100, t[0])
    check('top is sorted (stars, then time)', keys == sorted(keys))
    check('a run outside the top 100 is not stored', sub(lv2, 9999, 'Слабый', 0, 5000) == 'ok\t0')
    r = sub(lv2, 9998, 'Быстрый', 3, 5); check('a new best enters at rank 1', r == 'ok\t1', r)
    t = get(a='top', l=lv2).split('\n'); check('still 100 rows, the new best is first', t[0] == 'ok\t100' and t[1].split('\t')[1] == 'Быстрый', t[:2])

# ---- levels made by players ----
data = '1;2;1,6400,2500;2,6400,900;4,6400,3500;4,6400,4200;4,6400,4900;8,6400,5900'
rep = replay(240, 3)
def pub(uid, nick, name, data, rep):
    return post('pub', str(uid), nick, name, data, rep, sig('pub', str(uid), name, data, rep))
name = 'Тест %d' % random.randrange(1000, 9999)
r = pub(5001, 'Автор', name, data, rep); check('publish a level', r.startswith('ok\t'), r)
lid = int(r.split('\t')[1]) if r.startswith('ok\t') else 0
t = get(a='list', s='new', o=0).split('\n')
check('the level is first in the list of new levels', len(t) > 1 and t[1].split('\t')[:4] == [str(lid), name, 'Автор', '3'], t[:2])
r = get(a='lvl', id=lid); check('level download', r == '\t'.join(['ok', str(lid), name, 'Автор', data, rep]), r)
t = get(a='top', l='u%d' % lid); check('the author holds the first record of his level', t.startswith('ok\t1\n1\tАвтор\t3\t240\t'), t)
r = sub('u%d' % lid, 5002, 'Гость', 3, 200); check('a record on a player level', r == 'ok\t1', r)
check('records on unknown player levels are refused', sub('u999999', 5002, 'Гость', 3, 200).startswith('err'))
check('level without Mel refused', pub(5001, 'Автор', 'Плохой', '1;2;1,6400,2500;2,6400,900;4,6400,3500', rep) == 'err\tdata')
check('garbage level refused', pub(5001, 'Автор', 'Плохой', '1;2;abc', rep) == 'err\tdata')
check('rude level name refused', pub(5001, 'Автор', 'ху' + 'й вам', data, rep) == 'err\tname')
check('bad signature refused', post('pub', '5001', 'Автор', 'Ещё', data, rep, '12345678') == 'err\tsig')
check('unknown level', get(a='lvl', id=99999999).startswith('err'))

# ---- V0.4: accounts (a nick with a password), who is online, the admin commands ----
if not QUICK:
    proto = get(a='ping').split('\t')
    check('the table says it knows accounts', proto[:3] == ['ok', 'mel-nyam', '4'], proto)
    def ph(pw): return hashlib.sha256(('mel-nyam/pw/v1:' + pw).encode('utf-8')).hexdigest()
    def reg(uid, nick, pw): return post('reg', str(uid), nick, ph(pw), '400', sig('reg', str(uid), nick, ph(pw)))
    def login(nick, pw): return post('login', nick, ph(pw), '400', sig('login', nick, ph(pw)))
    def sub2(level, uid, tok, stars, ticks):
        rp = replay(ticks, stars); return post('sub2', level, str(uid), tok, str(stars), str(ticks), rp, sig('sub2', level, str(uid), rp))
    n1 = 'Акк%d' % random.randrange(100000, 999999); n2 = 'Other%d' % random.randrange(1000, 9999)
    u1 = random.randrange(10 ** 8, 2 * 10 ** 9); u2 = u1 + 1; u3 = u1 + 2
    la = 'b%02d-%04x' % (random.randrange(20, 50), random.randrange(65536)); lb = 'b%02d-%04x' % (random.randrange(20, 50), random.randrange(65536))
    r = reg(u1, n1, 'Пароль_1a'); f = r.split('\t'); check('create an account', f[0] == 'ok' and f[1] == str(u1) and f[2] == n1 and len(f[3]) == 32, r)
    tok1 = f[3] if len(f) > 3 else ''
    check('the same device cannot create a second account', reg(u1, n2, 'Пароль_1a') == 'err\texists')
    check('a taken nick is refused (any letter case)', reg(u2, n1.upper(), 'Qwerty_12') == 'err\ttaken')
    check('a rude nick is refused', reg(u2, 'ху' + 'йло', 'Qwerty_12') == 'err\tbadnick')
    check('the nick «Игрок» is reserved', reg(u2, 'игрок', 'Qwerty_12') == 'err\tbadnick')
    check('a bad signature is refused', post('reg', str(u2), n2, ph('x'), '400', '00000000') == 'err\tsig')
    r = reg(u2, n2, 'Qwerty_12'); check('a second account', r.startswith('ok\t'), r); tok2 = r.split('\t')[3]
    check('a wrong password is refused', login(n1, 'не тот') == 'err\tauth')
    check('an unknown nick gets the same answer', login('Нет_такого', 'Пароль_1a') == 'err\tauth')
    r = login(n1.lower(), 'Пароль_1a'); f = r.split('\t'); check('sign in on another device: the same number, a new key', f[:3] == ['ok', str(u1), n1] and len(f[3]) == 32 and f[3] != tok1, r)
    tok1b = f[3] if len(f) > 3 else ''
    check('a record needs the key of the account', sub2(la, u1, 'ffffffffffffffffffffffffffffffff', 3, 500) == 'err\tauth')
    check('a record with the key', sub2(la, u1, tok1, 3, 500) == 'ok\t1')
    check('the second device of the account works too', sub2(lb, u1, tok1b, 2, 700) == 'ok\t1')
    check('an old game cannot write in the name of an account', sub(la, u1, n1, 3, 100) == 'err\tauth')
    r = sub(la, u3, n1, 3, 450); t = get(a='top', l=la).split('\n')
    check('a player without an account cannot show the nick of an account', r.startswith('ok') and t[1].split('\t')[1] == 'Игрок' and t[2].split('\t')[1] == n1, t)
    r = get(a='mine', u=u1, t=tok1b); check('the progress of the account', sorted(r.split('\n')[1:]) == sorted([la + '\t3\t500', lb + '\t2\t700']) and r.startswith('ok\t2'), r)
    check('the progress needs the key', get(a='mine', u=u1, t='0' * 32) == 'err\tauth')
    n1b = n1 + '_x'
    check('a nick cannot be changed to a taken one', post('ren', str(u1), tok1, n2, sig('ren', str(u1), n2)) == 'err\ttaken')
    r = post('ren', str(u1), tok1, n1b, sig('ren', str(u1), n1b)); check('change the nick', r == 'ok\t' + n1b, r)
    t = get(a='top', l=la); check('the table shows the new nick at once', ('\t' + n1b + '\t3\t500') in t, t)
    check('the old nick is free again', login(n1, 'Пароль_1a') == 'err\tauth')
    r = post('pw', str(u1), tok1, ph('не тот'), ph('Новый_2b'), sig('pw', str(u1), ph('не тот'), ph('Новый_2b'))); check('the password change needs the old password', r == 'err\tauth', r)
    r = post('pw', str(u1), tok1, ph('Пароль_1a'), ph('Новый_2b'), sig('pw', str(u1), ph('Пароль_1a'), ph('Новый_2b'))); f = r.split('\t'); check('change the password', f[0] == 'ok' and len(f[1]) == 32, r)
    tok1 = f[1] if len(f) > 1 else tok1
    check('the other device is signed out by it', sub2(la, u1, tok1b, 3, 400) == 'err\tauth')
    check('the old password does not work', login(n1b, 'Пароль_1a') == 'err\tauth')
    r = login(n1b, 'Новый_2b'); check('the new password works', r.startswith('ok\t' + str(u1)), r); tok1b = r.split('\t')[3]
    check('sign out', post('out', str(u1), tok1b, sig('out', str(u1))) == 'ok' and sub2(la, u1, tok1b, 3, 400) == 'err\tauth')
    pubname = 'Акк %d' % random.randrange(1000, 9999)
    r = post('pub2', str(u1), tok1, pubname, data, rep, sig('pub2', str(u1), pubname, data, rep)); check('publish a level from the account', r.startswith('ok\t'), r)
    lid2 = int(r.split('\t')[1]) if r.startswith('ok\t') else 0
    t = get(a='list', s='new', o=0).split('\n'); check('its author is the nick of the account', t[1].split('\t')[:3] == [str(lid2), pubname, n1b], t[:2])
    check('an old game cannot publish in the name of an account', pub(u1, n1b, 'Чужой', data, rep) == 'err\tauth')
    r = get(a='hb', u=u1, t=tok1, w='l17', v=400, p=1); check('"I am here" from an account', r.startswith('ok\t'), r)
    r = get(a='hb', u=u3, w='m', v=400, p=2); check('"I am here" without an account', r.startswith('ok\t'), r)
    check('"I am here" with a wrong key', get(a='hb', u=u1, t='1' * 32, w='m', v=400, p=1) == 'err\tauth')
    for k in range(7): last = login(n2, 'мимо%d' % k)
    check('six wrong passwords in a row: a pause', last == 'err\twait' and login(n2, 'Qwerty_12') == 'err\twait', last)

    PW = os.environ.get('MN_ADMIN_PW', '')
    if PW:
        key = hashlib.sha256(('mel-nyam/admin/v1:' + PW).encode('utf-8')).hexdigest()
        def adm(cmd, a1='', a2='', k=None, ts=None, nonce=None):
            ts = str(int(time.time()) if ts is None else ts); nonce = nonce or '%032x' % random.getrandbits(128)
            mac = hmac.new((k or key).encode('ascii'), '|'.join(['adm', ts, nonce, cmd, a1, a2]).encode('utf-8'), hashlib.sha256).hexdigest()
            return post('adm', ts, nonce, cmd, a1, a2, mac)
        check('admin: a wrong password is refused', adm('hello', k='0' * 64) == 'err\tdenied')
        r = adm('hello'); f = r.split('\t'); check('admin: hello, with the count of wrong attempts', f[0] == 'ok' and f[1] == '4' and int(f[2]) >= 1, r)
        nn = '%032x' % random.getrandbits(128)
        check('admin: a command cannot be sent twice', adm('hello', nonce=nn).startswith('ok') and adm('hello', nonce=nn) == 'err\treplay')
        check('admin: an old command is refused', adm('hello', ts=int(time.time()) - 3600).startswith('err\ttime'))
        r = adm('online').split('\n'); on = {x.split('\t')[0]: x.split('\t') for x in r[1:]}
        check('admin: who is online, and where', on.get(str(u1), [])[1:5] == [n1b, 'l17', '400', '1'] and on.get(str(u3), [])[1:5] == ['', 'm', '400', '2'], r)
        r = adm('users').split('\n'); us = {x.split('\t')[0]: x.split('\t') for x in r[1:]}
        check('admin: the list of players', us.get(str(u1), [])[1:4] == [n1b, '1', '0'] and us[str(u1)][9] == '3' and us[str(u1)][10] == '1' and us.get(str(u3), [])[1:4] == ['Игрок', '0', '0'], [us.get(str(u1)), us.get(str(u3))])
        check('admin: block a player', adm('ban', str(u1), 'тест') == 'ok')
        t = get(a='top', l=la); check('a blocked player is not in the table', n1b not in t and t.startswith('ok\t1'), t)
        check('a blocked player cannot send records', sub2(la, u1, tok1, 3, 300) == 'err\tban')
        check('a blocked player gets the news with "I am here"', get(a='hb', u=u1, t=tok1, w='m', v=400, p=1) == 'err\tban')
        check('a blocked player cannot sign in', login(n1b, 'Новый_2b') == 'err\tban')
        t = get(a='list', s='new', o=0); check('the levels of a blocked player are hidden', pubname not in t, t[:200])
        check('admin: unblock', adm('unban', str(u1)) == 'ok' and sub2(la, u1, tok1, 3, 300) == 'ok\t1')
        check('admin: block a player who has no account', adm('ban', str(u3)) == 'ok' and sub(la, u3, 'Кто-то', 3, 10) == 'err\tban' and adm('unban', str(u3)) == 'ok')
        check('admin: a new password for a player', adm('resetpw', str(u1), ph('Сброс_3c')) == 'ok' and sub2(la, u1, tok1, 3, 200) == 'err\tauth' and login(n1b, 'Сброс_3c').startswith('ok\t'))
        check('admin: rename a player', adm('nick', str(u1), n1) == 'ok' and login(n1, 'Сброс_3c').startswith('ok\t'))
        check('admin: hide a level', adm('hide', str(lid2), '1') == 'ok' and pubname not in get(a='list', s='new', o=0) and adm('hide', str(lid2), '0') == 'ok' and pubname in get(a='list', s='new', o=0))
        r = adm('levels').split('\n'); check('admin: the list of levels', any(x.split('\t')[:4] == [str(lid2), str(u1), n1, pubname] for x in r[1:]), r[:3])
        r = adm('del', str(u1)); check('admin: delete a player with everything he has', r == 'ok\t4\t1', r)
        t = get(a='top', l=la); check('his records are gone', n1 not in t.replace('Игрок', ''), t)
        check('his levels are gone', pubname not in get(a='list', s='new', o=0))
        check('his nick is free: he can make a new account', reg(u1, n1, 'Снова_4d').startswith('ok\t'))
    else: print('skip the admin commands (no MN_ADMIN_PW)')
print('\n%s' % ('ALL OK' if not fails else '%d FAILED' % fails))
sys.exit(1 if fails else 0)
