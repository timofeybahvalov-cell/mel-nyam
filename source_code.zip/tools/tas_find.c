/* Offline TAS search for the built-in levels (the same search the game runs for player levels, with a much bigger budget).
   build:  gcc -O2 -ffp-contract=off -DTAS_TOOLS -Isrc tools/tas_find.c src/tas.c src/sim.c -lm -o /tmp/tas_find
   usage:  tas_find OUTDIR FIRST LAST [key=value ...]
           units=N      budget in millions of simulation ticks (default 400)
           frontier=N   states per tick of the wave (default 40000)
           closed=N     log2 of the cell table (default 22)      nodes=N  log2 of the action tree (default 22)
           res0=N res1=N  first / last cell size of the wave (0 coarse .. 10 fine; default 1 .. 8)
           exact=1      also try the exhaustive pass            v=1  talk
           suffix=MASK  waves from later starts of the best run: bit f = from f/8 of it (default 254 = all seven)
           fmem=N       at most N megabytes for one tick of the wave (two such buffers are kept)
           ins=N        polishing tries a new action at every N-th tick (default 1)
           lbcheck=1    check the pruning estimate on every winning run that is seen ("over=0" in the summary line means: never too high)
           game=1       the settings the game itself uses for the levels of players (game=2: with the units given before it)
           seeds=DIR    where the seedNN.txt files are (default OUTDIR)
           selftest=N   N random runs per level: the packed state of the wave must behave exactly like the full one
           keys=1       print the online keys of the levels (for tools/tas_seeds.py) and stop
   Starting points: the stored solution of the level, every line of seedNN.txt (recordings "ticks_stars_hex...",
   for example the best runs of the online table) and the previous result OUTDIR/lvNN.txt.
   Result: OUTDIR/lvNN.txt = "ticks n proved hex..." (kept only if it is faster than the file that is already there).
   tools/tas_pack.py turns these files into src/tas_data.h. */
#include "tas.h"
#include "levels.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static int hexwords(const char *s, u32 *a, int max) {
    int n = 0;
    while (n < max) {
        u32 v = 0; int k;
        for (k = 0; k < 8; k++) { char c = s[k]; int d = (c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10 : -1; if (d < 0) break; v = v << 4 | (u32)d; }
        if (k < 8) break;
        a[n++] = v; s += 8;
    }
    return n;
}
static int demo_plan(const LevelDef *d, u32 *a) {              /* the stored solution, played exactly like the game plays it */
    static Sim S; int n = 0, done[64]; memset(done, 0, sizeof(done));
    sim_load(&S, d->objs);
    while (S.state == ST_PLAY && S.tick < 4800) {
        for (int k = 0; k < 40 && d->demo[k].act != ACT_END; k++) if (!done[k] && S.time >= d->demo[k].t) { done[k] = 1; if (sim_do(&S, &d->demo[k])) a[n++] = ((u32)S.tick << 15) | ((u32)d->demo[k].act << 12) | ((u32)d->demo[k].arg & 4095u); }
        sim_step(&S);
    }
    return n;
}
static double now_s(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec + ts.tv_nsec * 1e-9; }

int main(int argc, char **argv) {
    if (argc < 4) { fprintf(stderr, "usage: tas_find OUTDIR FIRST LAST [units=400 frontier=40000 closed=22 nodes=22 res0=1 res1=8 exact=0 suffix=254 fmem=0 ins=1 lbcheck=0 game=0 seeds=DIR v=0 | selftest=N | keys=1]\n"); return 2; }
    const char *out = argv[1], *seeds = argv[1]; int first = atoi(argv[2]), last = atoi(argv[3]);
    TasCfg cfg; memset(&cfg, 0, sizeof(cfg));
    cfg.units = 400000000LL; cfg.frontier = 40000; cfg.closed_log2 = 22; cfg.nodes_log2 = 22; cfg.res_first = 1; cfg.res_last = 8; cfg.ins_step = 1; cfg.suffix = 0xFE;
    for (int i = 4; i < argc; i++) {
        char *e = strchr(argv[i], '='); if (!e) continue; long long v = atoll(e + 1); *e = 0;
        if (!strcmp(argv[i], "seeds")) { seeds = e + 1; continue; }
        if (!strcmp(argv[i], "units")) cfg.units = v * 1000000LL; else if (!strcmp(argv[i], "frontier")) cfg.frontier = (int)v; else if (!strcmp(argv[i], "closed")) cfg.closed_log2 = (int)v;
        else if (!strcmp(argv[i], "nodes")) cfg.nodes_log2 = (int)v; else if (!strcmp(argv[i], "res0")) cfg.res_first = (int)v; else if (!strcmp(argv[i], "res1")) cfg.res_last = (int)v;
        else if (!strcmp(argv[i], "exact")) cfg.exact = (int)v; else if (!strcmp(argv[i], "v")) cfg.verbose |= (int)v & 1; else if (!strcmp(argv[i], "ins")) cfg.ins_step = (int)v;
        else if (!strcmp(argv[i], "suffix")) cfg.suffix = (int)v;
        else if (!strcmp(argv[i], "lbcheck")) cfg.verbose |= v ? 2 : 0;     /* check the pruning estimate on every winning run that is seen */
        else if (!strcmp(argv[i], "fmem")) cfg.fmem = (int)v << 20;
        else if (!strcmp(argv[i], "keys")) {             /* the online keys of the levels (the same formula as level_key() in the game) and their star counts */
            for (int lv = 0; lv < LEVEL_COUNT; lv++) {
                u32 h = 2166136261u ^ (u32)SIM_VERSION;
                for (const LObj *o = g_levels[lv].objs; o->type != O_END; o++) { int w[8] = { o->type, (int)(o->x * 10), (int)(o->y * 10), (int)(o->a * 10), (int)(o->b * 10), (int)(o->c * 100), (int)(o->d * 100), (int)(o->e * 100) };
                    const u8 *q = (const u8 *)w; for (int k = 0; k < (int)sizeof(w); k++) h = (h ^ q[k]) * 16777619u; }
                printf("%d b%02d-%04x %d\n", lv, lv, (unsigned)(h & 0xFFFFu), sim_max_stars(g_levels[lv].objs));
            }
            return 0;
        }
        else if (!strcmp(argv[i], "selftest")) { int bad = 0; for (int lv = 0; lv < LEVEL_COUNT; lv++) { int b = tas_selftest(g_levels[lv].objs, (int)v); if (b) printf("level %d: %d differences\n", lv, b); bad += b; } printf("selftest: %d differences in %d levels x %d runs\n", bad, LEVEL_COUNT, (int)v); return bad != 0; }
        else if (!strcmp(argv[i], "game")) { long long u = cfg.units; tas_cfg_game(&cfg); if (v > 1) cfg.units = u; }
    }
    if (cfg.res_last > TAS_RES_N - 1) cfg.res_last = TAS_RES_N - 1;
    for (int lv = first; lv <= last && lv < LEVEL_COUNT; lv++) {
        const LevelDef *d = &g_levels[lv]; static u32 a[1600]; char path[600], line[16000], stats[400]; int demo_t, old_t = 0, old_proved = 0, nseeds = 0;
        double t0 = now_s();
        Tas *t = tas_new(d->objs, &cfg); if (!t) { fprintf(stderr, "out of memory\n"); return 1; }
        int n = demo_plan(d, a); demo_t = tas_check(d->objs, a, n); tas_seed(t, a, n); nseeds++;
        snprintf(path, sizeof(path), "%s/lv%02d.txt", out, lv);
        FILE *f = fopen(path, "r");
        if (f) { int tk, nn, pr; char *hex = line; if (fgets(line, sizeof(line), f) && sscanf(line, "%d %d %d %n", &tk, &nn, &pr, &n) >= 3) { hex = line + n; n = hexwords(hex, a, TAS_MAXA); if (tas_check(d->objs, a, n) == tk) { old_t = tk; old_proved = pr; tas_seed(t, a, n); nseeds++; } } fclose(f); }
        snprintf(path, sizeof(path), "%s/seed%02d.txt", seeds, lv);
        f = fopen(path, "r");
        if (f) { while (fgets(line, sizeof(line), f)) { int tk, st, pos = 0; if (sscanf(line, "%d_%d_%n", &tk, &st, &pos) >= 2 && pos) { n = hexwords(line + pos, a, TAS_MAXA); if (tas_check(d->objs, a, n) == tk) { tas_seed(t, a, n); nseeds++; } } } fclose(f); }
        while (tas_work(t, 20000000)) { }
        const TasPlan *b = tas_best(t); tas_stats(t, stats, (int)sizeof(stats));
        int real = b ? tas_check(d->objs, b->a, b->n) : 0, proved = tas_proved(t) || (old_proved && b && b->ticks == old_t);
        printf("lv %2d %-22s demo %4d -> tas %4d  (%5.2f s -> %5.2f s)  acts %2d  seeds %d%s%s  %.0f s  %s\n", lv, d->name, demo_t, b ? b->ticks : 0, demo_t / 120.0, b ? b->ticks / 120.0 : 0.0, b ? b->n : 0, nseeds,
               proved ? "  PROVED" : "", (b && real != b->ticks) ? "  !!! REAL SIM DISAGREES" : "", now_s() - t0, stats);
        fflush(stdout);
        if (b && real == b->ticks && (!old_t || b->ticks < old_t || (b->ticks == old_t && (proved > old_proved || b->n < n)))) {
            snprintf(path, sizeof(path), "%s/lv%02d.txt", out, lv);
            f = fopen(path, "w");
            if (f) { fprintf(f, "%d %d %d ", b->ticks, b->n, proved); for (int i = 0; i < b->n; i++) fprintf(f, "%08x", (unsigned)b->a[i]); fprintf(f, "\n"); fclose(f); }
        }
        tas_free(t);
    }
    return 0;
}
