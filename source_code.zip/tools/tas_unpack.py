#!/usr/bin/env python3
"""The reverse of tools/tas_pack.py: writes tools/tas_runs/lvNN.txt from src/tas_data.h.

    python3 tools/tas_unpack.py            (restores the files the offline search continues from)

src/tas_data.h is the copy of the runs that the game is built from, so it is the one that must never be lost.
The lvNN.txt files are only the form tools/tas_find.c reads and improves. If they are missing or older than the
header (a fresh checkout, a lost working folder), this tool brings them back; then tas_find can go on from the best
runs that are known. A file that is already faster than the header is left alone (run tas_pack.py for that one)."""
import os, re, sys

here = os.path.dirname(os.path.abspath(__file__))
dst = os.path.join(here, 'tas_runs')
s = open(os.path.join(here, '..', 'src', 'tas_data.h'), encoding='utf-8').read()
runs = [tuple(map(int, r)) for r in re.findall(r'\{(\d+), (\d+), (\d+), (\d+)\}', re.search(r'tas_runs\[TAS_DATA_LEVELS\] = \{(.*?)\};', s, re.S).group(1))]
words = [int(w, 16) for w in re.findall(r'0x([0-9a-f]{8})u', re.search(r'tas_words\[\d+\] = \{(.*?)\};', s, re.S).group(1))]
assert runs and sum(r[1] for r in runs) == len(words), (len(runs), len(words))
os.makedirs(dst, exist_ok=True)
written = kept = same = 0
for lv, (ticks, n, off, proved) in enumerate(runs):
    if not ticks: continue
    line = '%d %d %d %s\n' % (ticks, n, proved, ''.join('%08x' % w for w in words[off:off + n]))
    p = os.path.join(dst, 'lv%02d.txt' % lv)
    old = open(p).read() if os.path.exists(p) else ''
    if old == line: same += 1; continue
    f = old.split()
    if len(f) >= 3 and int(f[0]) < ticks: kept += 1; print('lv%02d.txt is faster than the header (%s < %d): left alone' % (lv, f[0], ticks)); continue
    open(p, 'w').write(line); written += 1
    print('lv%02d.txt: %s -> %d ticks%s' % (lv, (f[0] + (' proved' if len(f) >= 3 and f[2] == '1' else '')) if f else 'missing', ticks, ' proved' if proved else ''))
print('tas_unpack: %d levels, %d written, %d already the same, %d left alone' % (len(runs), written, same, kept))
