/* Plays the ten location tunes of src/music.c into WAV files and prints what they measure (no game needed):
     gcc -O2 -Isrc tools/music_test.c src/music.c -lm -o /tmp/music_test && /tmp/music_test OUTDIR */
#include "engine.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
static void wav(const char *path, const i16 *pcm, int n, int rate) {
    FILE *f = fopen(path, "wb"); if (!f) return; u32 d = (u32)n * 2, v;
    fwrite("RIFF", 1, 4, f); v = 36 + d; fwrite(&v, 4, 1, f); fwrite("WAVEfmt ", 1, 8, f); v = 16; fwrite(&v, 4, 1, f);
    u16 s = 1; fwrite(&s, 2, 1, f); fwrite(&s, 2, 1, f); v = (u32)rate; fwrite(&v, 4, 1, f); v = (u32)rate * 2; fwrite(&v, 4, 1, f); s = 2; fwrite(&s, 2, 1, f); s = 16; fwrite(&s, 2, 1, f);
    fwrite("data", 1, 4, f); fwrite(&d, 4, 1, f); fwrite(pcm, 2, (size_t)n, f); fclose(f);
}
int main(int argc, char **argv) {
    const char *dir = argc > 1 ? argv[1] : "/tmp"; Sound s; s.pcm = (i16 *)calloc((size_t)music_max() + 4, 2); s.n = music_max(); s.rate = MUSIC_RATE;
    for (int t = 0; t < MUSIC_TRACKS; t++) {
        struct timespec a, b; clock_gettime(CLOCK_MONOTONIC, &a);
        int steps = 0; music_begin(t, &s); while (music_step()) steps++;
        clock_gettime(CLOCK_MONOTONIC, &b);
        double ms = (b.tv_sec - a.tv_sec) * 1e3 + (b.tv_nsec - a.tv_nsec) / 1e6, sq = 0, dsum = 0; int peak = 0;
        for (int i = 0; i < s.n; i++) { int v = abs(s.pcm[i]); if (v > peak) peak = v; sq += (double)s.pcm[i] * s.pcm[i]; if (i) dsum += abs(s.pcm[i] - s.pcm[i - 1]); }
        char p[300]; snprintf(p, sizeof(p), "%s/track%d.wav", dir, t); wav(p, s.pcm, s.n, s.rate);
        printf("track %d: %.1f s, %d steps, %.0f ms (%.2f ms a step), peak %.2f, rms %.3f, seam jump %d (usual step %.0f)\n", t, (double)s.n / s.rate, steps, ms, ms / (steps ? steps : 1),
               peak / 32768.0, sqrt(sq / s.n) / 32768.0, abs(s.pcm[0] - s.pcm[s.n - 1]), dsum / s.n);
    }
    return 0;
}
