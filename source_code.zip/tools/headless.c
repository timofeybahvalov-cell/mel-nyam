/* Headless test harness: runs the real game (engine + sim + game.c) without a window,
   feeds scripted input and dumps frames (PPM) / audio (WAV).
   build: gcc -O2 -Isrc tools/headless.c src/game.c src/engine.c src/sim.c -lm -o /tmp/headless
   usage: headless <pack.bin> <outdir> <script file | demotest | perf>
   script: size W H | dbg CMD ARG | wait S | down/move/up X Y | click X Y | swipe X0 Y0 X1 Y1 | key N |
           shot NAME | audio | state | rec N | recstop
   rec N   writes every N-th frame as raw BGRA (W*H*4 bytes) into the command in $REC_CMD (popen), e.g.
           REC_CMD="ffmpeg -y -f rawvideo -pix_fmt bgra -s 1280x720 -r 60 -i - out.mp4", or into <outdir>/rec.bgra  */
#include "engine.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static u8 g_save[256]; static int g_save_n;
void plat_audio_lock(void) {}
void plat_audio_unlock(void) {}
void plat_save(const void *d, int n) { if (n > 256) n = 256; memcpy(g_save, d, n); g_save_n = n; }
int plat_load(void *d, int max) { int n = g_save_n < max ? g_save_n : max; memcpy(d, g_save, n); return n; }
void plat_quit(void) { printf("[plat_quit]\n"); }
void plat_fullscreen(void) { printf("[plat_fullscreen]\n"); }
int plat_caps(void) { return 3; }
void plat_log(const char *s) { printf("[log] %s\n", s); }

static u32 *fb; static int W = 1280, H = 720; static const char *outdir = "/tmp";
static FILE *wav; static int wav_frames; static double audio_acc;
static FILE *rec; static int rec_every = 1, rec_i, rec_pipe;
static double now_s(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec + ts.tv_nsec * 1e-9; }
static void shot(const char *name) {
    char path[512]; snprintf(path, sizeof(path), "%s/%s.ppm", outdir, name);
    FILE *f = fopen(path, "wb"); if (!f) return;
    fprintf(f, "P6\n%d %d\n255\n", W, H);
    u8 *row = malloc(W * 3);
    for (int y = 0; y < H; y++) { for (int x = 0; x < W; x++) { u32 p = fb[y * W + x]; row[x * 3] = (p >> 16) & 255; row[x * 3 + 1] = (p >> 8) & 255; row[x * 3 + 2] = p & 255; } fwrite(row, 1, W * 3, f); }
    free(row); fclose(f);
}
static void frame(float dt) {
    app_frame(dt);
    if (rec && (rec_i++ % rec_every) == 0) fwrite(fb, 4, (size_t)W * H, rec);
    if (wav) { audio_acc += dt * 44100.0; int n = (int)audio_acc; audio_acc -= n; static i16 buf[8192 * 2]; while (n > 0) { int k = n > 8192 ? 8192 : n; audio_mix(buf, k); fwrite(buf, 4, k, wav); wav_frames += k; n -= k; } }
}
static void wait_s(float s) { int n = (int)(s * 60.0f + 0.5f); for (int i = 0; i < n; i++) frame(1.0f / 60.0f); }
static void resize(int w, int h) { W = w; H = h; free(fb); fb = calloc((size_t)w * h, 4); app_resize(fb, w, h); }
static void wav_begin(void) { char p[512]; snprintf(p, sizeof(p), "%s/audio.wav", outdir); wav = fopen(p, "wb"); u8 hdr[44] = { 0 }; fwrite(hdr, 1, 44, wav); }
static void wav_end(void) {
    if (!wav) return; u32 n = wav_frames * 4; u8 h[44]; memcpy(h, "RIFF", 4); u32 v = 36 + n; memcpy(h + 4, &v, 4); memcpy(h + 8, "WAVEfmt ", 8);
    v = 16; memcpy(h + 16, &v, 4); u16 s = 1; memcpy(h + 20, &s, 2); s = 2; memcpy(h + 22, &s, 2); v = 44100; memcpy(h + 24, &v, 4); v = 44100 * 4; memcpy(h + 28, &v, 4);
    s = 4; memcpy(h + 32, &s, 2); s = 16; memcpy(h + 34, &s, 2); memcpy(h + 36, "data", 4); memcpy(h + 40, &n, 4);
    fseek(wav, 0, SEEK_SET); fwrite(h, 1, 44, wav); fclose(wav); wav = NULL;
}

int main(int argc, char **argv) {
    if (argc < 4) { printf("usage: headless pack outdir script|demotest|perf\n"); return 1; }
    FILE *f = fopen(argv[1], "rb"); if (!f) { printf("no pack\n"); return 1; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); u8 *pack = malloc(n); if (fread(pack, 1, n, f) != (size_t)n) return 1; fclose(f);
    outdir = argv[2];
    double t0 = now_s();
    app_init(pack, (int)n, 44100);
    printf("init %.0f ms\n", (now_s() - t0) * 1000);
    resize(1280, 720);
    if (!strcmp(argv[3], "demotest")) {
        int bad = 0;
        for (int lv = 0; lv < 18; lv++) {
            app_debug(2, lv); int res = -1, stars = 0; float t = 0;
            for (int i = 0; i < 60 * 20; i++) {
                frame(1.0f / 60.0f); t += 1.0f / 60.0f; int st = app_debug(4, 0);
                if ((st & 15) != 0) { res = st & 15; stars = (st >> 4) & 15; break; }
            }
            printf("level %2d: %s stars=%d t=%.2f\n", lv + 1, res == 1 ? "EATEN" : (res == 2 ? "LOST" : (res == 3 ? "BROKEN" : "TIMEOUT")), stars, t);
            if (res != 1 || stars != 3) bad++;
        }
        printf("demotest: %d bad\n", bad); return bad;
    }
    if (!strcmp(argv[3], "perf")) {
        int sizes[3][2] = { { 1280, 720 }, { 1920, 1080 }, { 2560, 1440 } };
        for (int k = 0; k < 3; k++) {
            resize(sizes[k][0], sizes[k][1]); app_debug(2, 17); wait_s(0.5f);
            double a = now_s(); for (int i = 0; i < 240; i++) frame(1.0f / 60.0f); double b = now_s();
            printf("%dx%d: %.2f ms/frame (level 18 demo)\n", W, H, (b - a) * 1000 / 240);
            app_debug(5, 0); wait_s(0.5f); a = now_s(); for (int i = 0; i < 120; i++) frame(1.0f / 60.0f); b = now_s();
            printf("%dx%d: %.2f ms/frame (menu)\n", W, H, (b - a) * 1000 / 120);
        }
        return 0;
    }
    FILE *sf = fopen(argv[3], "r"); if (!sf) { printf("no script\n"); return 1; }
    char line[512], a[64], name[256]; float x0, y0, x1, y1, d; int i0, i1;
    while (fgets(line, sizeof(line), sf)) {
        if (line[0] == '#' || sscanf(line, "%63s", a) != 1) continue;
        if (!strcmp(a, "size") && sscanf(line, "%*s %d %d", &i0, &i1) == 2) resize(i0, i1);
        else if (!strcmp(a, "dbg") && sscanf(line, "%*s %d %d", &i0, &i1) == 2) app_debug(i0, i1);
        else if (!strcmp(a, "wait") && sscanf(line, "%*s %f", &d) == 1) wait_s(d);
        else if (!strcmp(a, "down") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) app_pointer(1, x0, y0);
        else if (!strcmp(a, "move") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) app_pointer(0, x0, y0);
        else if (!strcmp(a, "up") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) app_pointer(2, x0, y0);
        else if (!strcmp(a, "click") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) { app_pointer(0, x0, y0); frame(1 / 60.f); app_pointer(1, x0, y0); frame(1 / 60.f); frame(1 / 60.f); app_pointer(2, x0, y0); frame(1 / 60.f); }
        else if (!strcmp(a, "swipe") && sscanf(line, "%*s %f %f %f %f", &x0, &y0, &x1, &y1) == 4) {
            app_pointer(0, x0, y0); app_pointer(1, x0, y0); frame(1 / 60.f);
            for (int i = 1; i <= 6; i++) { app_pointer(0, x0 + (x1 - x0) * i / 6.f, y0 + (y1 - y0) * i / 6.f); frame(1 / 60.f); }
            app_pointer(2, x1, y1); frame(1 / 60.f);
        }
        else if (!strcmp(a, "key") && sscanf(line, "%*s %d", &i0) == 1) { app_key(i0, 1); app_key(i0, 0); }
        else if (!strcmp(a, "shot") && sscanf(line, "%*s %255s", name) == 1) shot(name);
        else if (!strcmp(a, "audio")) wav_begin();
        else if (!strcmp(a, "rec")) {
            rec_every = 1; sscanf(line, "%*s %d", &rec_every); if (rec_every < 1) rec_every = 1; rec_i = 0;
            const char *cmd = getenv("REC_CMD");
            if (cmd && cmd[0]) { rec = popen(cmd, "w"); rec_pipe = 1; } else { char p[512]; snprintf(p, sizeof(p), "%s/rec.bgra", outdir); rec = fopen(p, "wb"); rec_pipe = 0; }
        }
        else if (!strcmp(a, "recstop")) { if (rec) { if (rec_pipe) pclose(rec); else fclose(rec); rec = NULL; } }
        else if (!strcmp(a, "state")) { int st = app_debug(4, 0); printf("state: sim=%d stars=%d phase=%d scr=%d demo=%d total=%d\n", st & 15, (st >> 4) & 15, (st >> 8) & 15, (st >> 12) & 15, (st >> 16) & 1, app_debug(9, 0)); }
        else printf("?? %s", line);
    }
    wav_end();
    if (rec) { if (rec_pipe) pclose(rec); else fclose(rec); }
    return 0;
}
