/* Headless test harness: runs the real game (engine + sim + game.c) without a window,
   feeds scripted input and dumps frames (PPM) / audio (WAV).
   build: gcc -O2 -Isrc tools/headless.c src/game.c src/engine.c src/sim.c src/tas.c src/music.c -lm -o /tmp/headless
   usage: headless <pack.bin> <outdir> <script file | demotest | tastest | simhash | perf>
   script: size W H | dbg CMD ARG | wait S | down/move/up X Y | click X Y | swipe X0 Y0 X1 Y1 | key N |
           api URL | cfg URL | nick NAME | reg NICK|PASSWORD | login NICK|PASSWORD | level TEXT | text TYPED TEXT | dbgp CMD ARG |
           shot NAME | audio | state | rec N | recstop
   rec N   writes every N-th frame as raw BGRA (W*H*4 bytes) into the command in $REC_CMD (popen), e.g.
           REC_CMD="ffmpeg -y -f rawvideo -pix_fmt bgra -s 1280x720 -r 60 -i - out.mp4", or into <outdir>/rec.bgra  */
#include "engine.h"
#include <stdio.h>
#include <unistd.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* storage: in memory, or in files when MN_STORE names a directory (save.dat + one file per named blob) */
static u8 g_save[8192]; static int g_save_n;
static struct { char key[20]; u8 *d; int n; } g_blob[128]; static int g_nblob;
static const char *store_dir(void) { const char *d = getenv("MN_STORE"); return d && d[0] ? d : NULL; }
static int file_read(const char *name, void *d, int max) { char p[600]; snprintf(p, sizeof(p), "%s/%s", store_dir(), name); FILE *f = fopen(p, "rb"); if (!f) return 0; int n = (int)fread(d, 1, (size_t)max, f); fclose(f); return n; }
static void file_write(const char *name, const void *d, int n) { char p[600]; snprintf(p, sizeof(p), "%s/%s", store_dir(), name); if (n <= 0) { remove(p); return; } FILE *f = fopen(p, "wb"); if (!f) return; fwrite(d, 1, (size_t)n, f); fclose(f); }
void plat_audio_lock(void) {}
void plat_audio_unlock(void) {}
void plat_save(const void *d, int n) { if (n > (int)sizeof(g_save)) n = (int)sizeof(g_save); memcpy(g_save, d, (size_t)n); g_save_n = n; if (store_dir()) file_write("save.dat", d, n); }
int plat_load(void *d, int max) { if (store_dir()) return file_read("save.dat", d, max); int n = g_save_n < max ? g_save_n : max; memcpy(d, g_save, (size_t)n); return n; }
void plat_store(const char *key, const void *d, int n) {
    if (store_dir()) { char nm[40]; snprintf(nm, sizeof(nm), "%s.dat", key); file_write(nm, d, n); return; }
    int i; for (i = 0; i < g_nblob; i++) if (!strcmp(g_blob[i].key, key)) break;
    if (i == g_nblob) { if (g_nblob == 128 || n <= 0) return; snprintf(g_blob[i].key, sizeof(g_blob[i].key), "%s", key); g_blob[i].d = NULL; g_nblob++; }
    free(g_blob[i].d); g_blob[i].d = NULL; g_blob[i].n = 0;
    if (n > 0) { g_blob[i].d = malloc((size_t)n); memcpy(g_blob[i].d, d, (size_t)n); g_blob[i].n = n; }
}
int plat_fetch(const char *key, void *d, int max) {
    if (store_dir()) { char nm[40]; snprintf(nm, sizeof(nm), "%s.dat", key); return file_read(nm, d, max); }
    for (int i = 0; i < g_nblob; i++) if (!strcmp(g_blob[i].key, key)) { int n = g_blob[i].n < max ? g_blob[i].n : max; if (n > 0) memcpy(d, g_blob[i].d, (size_t)n); return n; }
    return 0;
}
/* network: curl, answered a few frames later (the game must cope with the delay) */
static struct { int id, status, n, wait; char *d; } g_http[16]; static int g_nhttp; static int g_http_log;
void plat_http(int id, const char *url, const char *body, int body_len) {
    char cmd[1024], tmp[64] = "/tmp/mn_http_body_XXXXXX"; int st = 0; size_t n = 0, cap = 1 << 16; char *buf = malloc(cap);
    if (g_nhttp == 16) { free(buf); return; }
    if (body) { int fd = mkstemp(tmp); FILE *f = fdopen(fd, "wb"); fwrite(body, 1, (size_t)body_len, f); fclose(f);
        snprintf(cmd, sizeof(cmd), "curl -s -L -m 10 -w '\n%%{http_code}' -H 'Content-Type: text/plain' --data-binary @%s '%s' 2>/dev/null", tmp, url); }
    else snprintf(cmd, sizeof(cmd), "curl -s -L -m 10 -w '\n%%{http_code}' '%s' 2>/dev/null", url);
    FILE *pf = popen(cmd, "r");
    if (pf) { size_t k; while ((k = fread(buf + n, 1, cap - n - 1, pf)) > 0) { n += k; if (n + 1 >= cap) { cap *= 2; buf = realloc(buf, cap); } } pclose(pf); }
    if (body) remove(tmp);
    buf[n] = 0; char *nl = n ? strrchr(buf, '\n') : NULL; if (nl) { st = atoi(nl + 1); *nl = 0; n = (size_t)(nl - buf); }
    if (g_http_log) printf("[http %d] %s%s -> %d, %d bytes\n", id, body ? "POST " : "GET ", url, st, (int)n);
    g_http[g_nhttp].id = id; g_http[g_nhttp].status = st; g_http[g_nhttp].d = buf; g_http[g_nhttp].n = (int)n; g_http[g_nhttp].wait = 3; g_nhttp++;
}
static void http_pump(void) {
    for (int i = 0; i < g_nhttp; i++) if (--g_http[i].wait <= 0) {
        int id = g_http[i].id, st = g_http[i].status, n = g_http[i].n; char *d = g_http[i].d;
        g_http[i] = g_http[--g_nhttp]; i--;
        app_http(id, st, d, n); free(d);
    }
}
void plat_quit(void) { printf("[plat_quit]\n"); }
void plat_fullscreen(void) { printf("[plat_fullscreen]\n"); }
int plat_caps(void) { return getenv("MN_NET") ? 7 : 3; }      /* the network layer (curl) is used only when MN_NET is set */
u32 plat_random(void) {                              /* the first number is the player id the test asked for (MN_UID); the next ones differ from it and from run to run */
    static u32 n; const char *e = getenv("MN_UID"); u32 base = e ? (u32)strtoul(e, NULL, 10) : 123456789u;
    return n++ ? ((base ^ 0x5bd1e995u) + n * 7919u + (u32)getpid() * 31u) & 0x7FFFFFFFu : base;
}
void plat_log(const char *s) { printf("[log] %s\n", s); }
void plat_snd(int op, int idx, int id, float a, float b, float c) { (void)op; (void)idx; (void)id; (void)a; (void)b; (void)c; }
/* the small services: MN_PF = which build to pretend to be (PF_...); an update "downloads" by itself, 4 % per question,
   and fails at 60 % with the error MN_UPD_FAIL when that is set */
static int g_upd;
/* the pretended microphone (V0.6): env MN_MIC=0: there is none. The script says what "is said" into it:
   `mic FREQ MS [AMP]` a tone (after 150 ms of silence, with 200 ms of silence behind), `micfile PATH` raw mono 16-bit 16 kHz. */
static int g_mic_on, g_mic_freq = 440, g_mic_ms = 600, g_mic_amp = 12000; static char g_mic_file[300];
static void mic_deliver(void) {
    static i16 buf[16000 * 6]; int n = 0, rate = 16000;
    if (g_mic_file[0]) { FILE *f = fopen(g_mic_file, "rb"); if (f) { n = (int)fread(buf, 2, 16000 * 6, f); fclose(f); } }
    else {
        int lead = rate * 150 / 1000, body = rate * g_mic_ms / 1000, tail = rate / 5; if (lead + body + tail > 16000 * 6) body = 16000 * 6 - lead - tail;
        for (int i = 0; i < lead + body + tail; i++) {
            int k = i - lead; double env = k < 0 || k >= body ? 0 : (k < 160 ? k / 160.0 : (k > body - 160 ? (body - k) / 160.0 : 1.0));
            buf[n++] = (i16)(env * g_mic_amp * sin(6.283185307179586 * g_mic_freq * k / rate) + ((i * 7919) % 41 - 20));      /* (a little noise in the "room") */
        }
    }
    app_mic(buf, n, rate);
}
static long long g_clock;                            /* the pretended date and time (seconds since 1970); it runs on with the frames of the game */
static double g_clock_frac;
int plat_ctl(int what, const char *s, int a, int b) {
    (void)b;
    switch (what) {
    case PC_PLATFORM: { const char *e = getenv("MN_PF"); return e ? atoi(e) : PF_OTHER; }
    case PC_OPEN_URL: printf("[open] %s\n", s ? s : ""); return 1;
    case PC_UPDATE: { char t[300]; snprintf(t, sizeof(t), "%s", s ? s : ""); for (char *q = t; *q; q++) if (*q == '\n') *q = ' '; printf("[update] %s size %d\n", t, a); g_upd = 1; return 1; }
    case PC_UPDATE_STATE: {
        const char *f = getenv("MN_UPD_FAIL");
        if (g_upd > 0 && g_upd < 200) { g_upd += 4; if (f && g_upd >= 60) g_upd = atoi(f); else if (g_upd > 100) g_upd = 200; }
        return g_upd;
    }
    case PC_UPDATE_RESET: g_upd = 0; return 0;
    case PC_TIME: return (int)g_clock;                   /* tests set it: env MN_TIME, script commands "time N" and "timeadd N" */
    case PC_COPY: printf("[copy] %s\n", s ? s : ""); return 1;
    case PC_MIC: {
        const char *e = getenv("MN_MIC"); int none = e && !strcmp(e, "0");
        if (a == MIC_STATE) return none ? 2 : (g_mic_on ? 3 : 1);
        if (a == MIC_START) { if (none) return 0; g_mic_on = 1; printf("[mic] start\n"); return 1; }
        if (a == MIC_STOP) { if (g_mic_on) { g_mic_on = 0; printf("[mic] stop\n"); mic_deliver(); } return 1; }
        if (a == MIC_CANCEL || a == MIC_CLOSE) { g_mic_on = 0; return 1; }
        if (a == MIC_LEVEL) return g_mic_on ? 55 : 0;
        return 0;
    }
    }
    return 0;
}

static u32 *fb; static int W = 1280, H = 720; static const char *outdir = "/tmp";
static FILE *wav; static int wav_frames; static double audio_acc;
static FILE *rec; static int rec_every = 1, rec_i, rec_pipe;
/* capture camera: `cam W H MODE [RATE]` records a W x H window of the frame instead of the whole frame.
   MODE 0 fixed (centre set by `camfix X Y`, design units), 1 follow the bottle and hold, 2 follow, then return to the centre.
   In modes 1 and 2 the window also shifts so that Mel's face and his speech bubble are not cut off (see cam_step).
   `log PATH` writes one line per recorded frame (F), per action (E), plus A (audio start), R (record start) and M (Mel's face). */
static int cam_w, cam_h, cam_mode, cam_ready; static float cam_cx = 640, cam_cy = 360, cam_tx = 640, cam_ty = 360, cam_rate = 4.5f;
static FILE *caplog; static long step_n; static int rec_n, ev_seen;
static void cam_step(float dt) {
    float rate = cam_rate;
    if (cam_mode >= 1) {
        int st = app_debug(4, 0), ph = (st >> 8) & 15, sc = (st >> 12) & 15; float bxo = app_debug(12, 0) / 8.0f, byo = app_debug(13, 0) / 8.0f;
        if (sc == 3 && ph == 0) { cam_tx = bxo; cam_ty = byo; }
        else if (cam_mode == 2 && sc == 3) { cam_tx = 640; cam_ty = 360; }
        if (sc == 3) {      /* keep Mel's face and his whole speech bubble inside the window: always once the level is over, during play only while the bottle stays inside too */
            float hw0 = cam_w * 1280.0f / W * 0.5f, fx = app_debug(14, 0) / 8.0f, l = fx - 80, r = fx + 80; int say = app_debug(22, 0);
            if (say) { float bx = fx + app_debug(23, 0) / 8.0f, bw = app_debug(24, 0) / 8.0f + 8; if (bx - bw * 0.5f < l) l = bx - bw * 0.5f; if (bx + bw * 0.5f > r) r = bx + bw * 0.5f; }
            l -= 18; r += 18;
            if (ph != 0 || say) {
                float t = cam_tx;
                if (r - l > 2 * hw0) t = (l + r) * 0.5f; else { if (t < r - hw0) t = r - hw0; if (t > l + hw0) t = l + hw0; }
                if (ph != 0 || fabsf(t - bxo) < hw0 - 70) {
                    cam_tx = t;
                    if (cam_ready && r - l <= 2 * hw0 && (cam_cx < r - hw0 - 1 || cam_cx > l + hw0 + 1) && rate < 13.0f) rate = 13.0f;     /* a quick move while the bubble is still cut off */
                }
            }
        }
    }
    float tx = cam_tx, ty = cam_ty, hw = cam_w * 1280.0f / W * 0.5f, hh = cam_h * 720.0f / H * 0.5f;
    if (tx < hw) tx = hw; if (tx > 1280 - hw) tx = 1280 - hw; if (ty < hh) ty = hh; if (ty > 720 - hh) ty = 720 - hh;
    if (!cam_ready) { cam_cx = tx; cam_cy = ty; cam_ready = 1; }
    float k = 1.0f - expf(-dt * rate), ky = 1.0f - expf(-dt * cam_rate); cam_cx += (tx - cam_cx) * k; cam_cy += (ty - cam_cy) * ky;
}
static double now_s(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec + ts.tv_nsec * 1e-9; }
static void shot(const char *name) {
    char path[512]; snprintf(path, sizeof(path), "%s/%s.ppm", outdir, name);
    FILE *f = fopen(path, "wb"); if (!f) return;
    fprintf(f, "P6\n%d %d\n255\n", W, H);
    u8 *row = malloc(W * 3);
    for (int y = 0; y < H; y++) { for (int x = 0; x < W; x++) { u32 p = fb[y * W + x]; row[x * 3] = (p >> 16) & 255; row[x * 3 + 1] = (p >> 8) & 255; row[x * 3 + 2] = p & 255; } fwrite(row, 1, W * 3, f); }
    free(row); fclose(f);
}
static void frame(float dt) {
    http_pump();
    g_clock_frac += dt; while (g_clock_frac >= 1.0) { g_clock_frac -= 1.0; if (g_clock) g_clock++; }      /* the pretended clock runs with the game */
    app_frame(dt); step_n++;
    if (cam_w) cam_step(dt);
    if (caplog) { int n = app_debug(16, 0); if (n != ev_seen) { ev_seen = n; fprintf(caplog, "E %d %ld %d %.2f %.2f\n", rec_n, step_n, app_debug(17, 0), app_debug(18, 0) / 8.0f, app_debug(19, 0) / 8.0f); } }
    if (rec && (rec_i++ % rec_every) == 0) {
        int x0 = 0, y0 = 0, w = W, h = H;
        if (cam_w) {
            w = cam_w; h = cam_h; x0 = (int)(cam_cx * W / 1280.0f - w * 0.5f + 0.5f); y0 = (int)(cam_cy * H / 720.0f - h * 0.5f + 0.5f);
            if (x0 < 0) x0 = 0; if (x0 > W - w) x0 = W - w; if (y0 < 0) y0 = 0; if (y0 > H - h) y0 = H - h;
        }
        if (w == W && h == H) fwrite(fb, 4, (size_t)W * H, rec); else for (int y = 0; y < h; y++) fwrite(fb + (size_t)(y0 + y) * W + x0, 4, (size_t)w, rec);
        if (caplog) { int st = app_debug(4, 0); fprintf(caplog, "F %d %ld %.2f %.2f %d %d %d %d %d\n", rec_n, step_n, app_debug(12, 0) / 8.0f, app_debug(13, 0) / 8.0f, (st >> 8) & 15, (st >> 4) & 15, st & 15, x0, y0); }
        rec_n++;
    }
    if (wav) { audio_acc += dt * 44100.0; int n = (int)audio_acc; audio_acc -= n; static i16 buf[8192 * 2]; while (n > 0) { int k = n > 8192 ? 8192 : n; audio_mix(buf, k); fwrite(buf, 4, k, wav); wav_frames += k; n -= k; } }
}
static void wait_s(float s) { int n = (int)(s * 60.0f + 0.5f); for (int i = 0; i < n; i++) frame(1.0f / 60.0f); }
static void resize(int w, int h) { W = w; H = h; free(fb); fb = calloc((size_t)w * h, 4); app_resize(fb, w, h); }
static void wav_begin(void) { char p[512]; snprintf(p, sizeof(p), "%s/audio.wav", outdir); wav = fopen(p, "wb"); u8 hdr[44] = { 0 }; fwrite(hdr, 1, 44, wav); }
static void wav_end(void) {
    if (!wav) return; u32 n = wav_frames * 4; u8 h[44]; memcpy(h, "RIFF", 4); u32 v = 36 + n; memcpy(h + 4, &v, 4); memcpy(h + 8, "WAVEfmt ", 8);
    v = 16; memcpy(h + 16, &v, 4); u16 s = 1; memcpy(h + 20, &s, 2); s = 2; memcpy(h + 22, &s, 2); v = 44100; memcpy(h + 24, &v, 4); v = 44100 * 4; memcpy(h + 28, &v, 4);
    s = 4; memcpy(h + 32, &s, 2); s = 16; memcpy(h + 34, &s, 2); memcpy(h + 36, "data", 4); memcpy(h + 40, &n, 4);
    fseek(wav, 0, SEEK_SET); fwrite(h, 1, 44, wav); fclose(wav); wav = NULL;
}

int main(int argc, char **argv) {
    if (argc < 4) { printf("usage: headless pack outdir script|demotest|perf\n"); return 1; }
    FILE *f = fopen(argv[1], "rb"); if (!f) { printf("no pack\n"); return 1; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); u8 *pack = malloc(n); if (fread(pack, 1, n, f) != (size_t)n) return 1; fclose(f);
    outdir = argv[2];
    { const char *e = getenv("MN_TIME"); if (e) g_clock = atoll(e); }
    double t0 = now_s();
    app_init(pack, (int)n, 44100);
    printf("init %.0f ms\n", (now_s() - t0) * 1000);
    resize(1280, 720);
    if (!strcmp(argv[3], "demotest")) {
        int bad = 0, count = app_debug(28, 0);
        for (int lv = 0; lv < count; lv++) {
            app_debug(2, lv); int res = -1, stars = 0, need = app_debug(25, lv); float t = 0;
            for (int i = 0; i < 60 * 40; i++) {
                frame(1.0f / 60.0f); t += 1.0f / 60.0f; int st = app_debug(4, 0);
                if ((st & 15) != 0) { res = st & 15; stars = (st >> 4) & 15; break; }
            }
            printf("level %2d: %s stars=%d/%d t=%.2f\n", lv + 1, res == 1 ? "EATEN" : (res == 2 ? "LOST" : (res == 3 ? "BROKEN" : (res == 4 ? "STOLEN" : "TIMEOUT"))), stars, need, t);
            if (res != 1 || stars != need) bad++;
        }
        printf("demotest: %d levels, %d bad\n", count, bad); return bad;
    }
    if (!strcmp(argv[3], "tastest")) {       /* every stored TAS run, played through the whole game loop: all the stars, at exactly the stored step */
        int bad = 0, count = app_debug(28, 0), proved = 0; long total = 0;
        for (int lv = 0; lv < count; lv++) {
            app_debug(130, 0);
            int want = app_debug(121, lv), res = -1, stars = 0, need = app_debug(25, lv), ticks = 0;
            if (app_debug(120, lv)) for (int i = 0; i < 60 * 60; i++) {
                frame(1.0f / 60.0f); int st = app_debug(4, 0);
                if (((st >> 12) & 15) == 3 && (st & 15) != 0) { res = st & 15; stars = (st >> 4) & 15; ticks = app_debug(27, 0); break; }
            }
            int ok = want > 0 && res == 1 && stars == need && ticks == want;
            printf("level %2d: tas %4d steps (%5.2f s)%s  %s\n", lv + 1, want, want / 120.0, app_debug(129, lv) ? "  proved" : "", ok ? "ok" : "BAD");
            if (!ok) { bad++; printf("          result=%d stars=%d/%d steps=%d\n", res, stars, need, ticks); }
            total += want; proved += app_debug(129, lv);
        }
        printf("tastest: %d levels, %d bad, %d proved, all runs together %.2f s\n", count, bad, proved, total / 120.0); return bad;
    }
    if (!strcmp(argv[3], "simhash")) {       /* one line per level; must be identical in the exe and in the browser build */
        int count = app_debug(28, 0); printf("sim %d\n", app_debug(31, 0));
        for (int lv = 0; lv < count; lv++) printf("%d %d\n", lv, app_debug(30, lv));
        return 0;
    }
    if (!strcmp(argv[3], "perf")) {
        int sizes[3][2] = { { 1280, 720 }, { 1920, 1080 }, { 2560, 1440 } };
        for (int k = 0; k < 3; k++) {
            resize(sizes[k][0], sizes[k][1]); app_debug(2, 59); wait_s(0.5f);
            double a = now_s(); for (int i = 0; i < 240; i++) frame(1.0f / 60.0f); double b = now_s();
            printf("%dx%d: %.2f ms/frame (level 60 demo)\n", W, H, (b - a) * 1000 / 240);
            app_debug(5, 0); wait_s(0.5f); a = now_s(); for (int i = 0; i < 120; i++) frame(1.0f / 60.0f); b = now_s();
            printf("%dx%d: %.2f ms/frame (menu)\n", W, H, (b - a) * 1000 / 120);
        }
        return 0;
    }
    FILE *sf = fopen(argv[3], "r"); if (!sf) { printf("no script\n"); return 1; }
    char line[512], a[64], name[256]; float x0, y0, x1, y1, d; int i0, i1;
    while (fgets(line, sizeof(line), sf)) {
        if (line[0] == '#' || sscanf(line, "%63s", a) != 1) continue;
        if (!strcmp(a, "size") && sscanf(line, "%*s %d %d", &i0, &i1) == 2) resize(i0, i1);
        else if (!strcmp(a, "dbg") && sscanf(line, "%*s %d %d", &i0, &i1) == 2) app_debug(i0, i1);
        else if (!strcmp(a, "wait") && sscanf(line, "%*s %f", &d) == 1) wait_s(d);
        else if (!strcmp(a, "down") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) app_pointer(1, x0, y0);
        else if (!strcmp(a, "move") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) app_pointer(0, x0, y0);
        else if (!strcmp(a, "up") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) app_pointer(2, x0, y0);
        else if (!strcmp(a, "click") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) { app_pointer(0, x0, y0); frame(1 / 60.f); app_pointer(1, x0, y0); frame(1 / 60.f); frame(1 / 60.f); app_pointer(2, x0, y0); frame(1 / 60.f); }
        else if (!strcmp(a, "swipe") && sscanf(line, "%*s %f %f %f %f", &x0, &y0, &x1, &y1) == 4) {
            app_pointer(0, x0, y0); app_pointer(1, x0, y0); frame(1 / 60.f);
            for (int i = 1; i <= 6; i++) { app_pointer(0, x0 + (x1 - x0) * i / 6.f, y0 + (y1 - y0) * i / 6.f); frame(1 / 60.f); }
            app_pointer(2, x1, y1); frame(1 / 60.f);
        }
        else if (!strcmp(a, "key") && sscanf(line, "%*s %d", &i0) == 1) { app_key(i0, 1); app_key(i0, 0); }
        else if (!strcmp(a, "char") && sscanf(line, "%*s %d", &i0) == 1) app_char((u32)i0);
        else if (!strcmp(a, "text")) {          /* type the rest of the line (UTF-8) */
            const unsigned char *q = (const unsigned char *)strstr(line, "text") + 4; while (*q == ' ') q++;
            while (*q && *q != '\n' && *q != '\r') { u32 cp = *q++; if (cp >= 0xF0) { cp = (cp & 7) << 18 | (q[0] & 63) << 12 | (q[1] & 63) << 6 | (q[2] & 63); q += 3; } else if (cp >= 0xE0) { cp = (cp & 15) << 12 | (q[0] & 63) << 6 | (q[1] & 63); q += 2; } else if (cp >= 0xC0) { cp = (cp & 31) << 6 | (q[0] & 63); q += 1; } app_char(cp); frame(1 / 60.f); }
        }
        else if (!strcmp(a, "httplog")) g_http_log = 1;
        else if (!strcmp(a, "admpw")) { char *q = strstr(line, "admpw") + 5; while (*q == ' ') q++; char *e = q + strlen(q); while (e > q && (e[-1] == '\n' || e[-1] == '\r')) *--e = 0; app_text(8, q); }      /* the admin password (a build with -DMN_ADMIN) */
        else if (!strcmp(a, "chatsend")) { char *q = strstr(line, "chatsend") + 8; while (*q == ' ') q++; char *e = q + strlen(q); while (e > q && (e[-1] == '\n' || e[-1] == '\r')) *--e = 0; app_text(7, q); }      /* a message to the support chat */
        else if (!strcmp(a, "mic")) { int f0 = 440, ms = 600, amp = 12000; sscanf(line, "%*s %d %d %d", &f0, &ms, &amp); g_mic_freq = f0; g_mic_ms = ms; g_mic_amp = amp; g_mic_file[0] = 0; }
        else if (!strcmp(a, "micfile")) { sscanf(line, "%*s %299s", g_mic_file); }
        else if (!strcmp(a, "time")) { long long t = 0; if (sscanf(line, "%*s %lld", &t) == 1) { g_clock = t; g_clock_frac = 0; } }
        else if (!strcmp(a, "timeadd")) { long long t = 0; if (sscanf(line, "%*s %lld", &t) == 1) g_clock += t; }
        else if (!strcmp(a, "api") || !strcmp(a, "nick") || !strcmp(a, "level")) {          /* the rest of the line goes to app_text: table address / nick / level text for the editor */
            char *q = strstr(line, a) + strlen(a); while (*q == ' ') q++; q[strcspn(q, "\r\n")] = 0;
            app_text(a[0] == 'a' ? 1 : (a[0] == 'n' ? 2 : 3), q);
        }
        else if (!strcmp(a, "cfg") || !strcmp(a, "reg") || !strcmp(a, "login")) {           /* another online.json  |  "reg NICK|PASSWORD": create an account  |  "login NICK|PASSWORD" */
            char *q = strstr(line, a) + strlen(a); while (*q == ' ') q++; q[strcspn(q, "\r\n")] = 0;
            if (a[0] != 'c') { char *bar = strchr(q, '|'); if (bar) *bar = '\n'; }
            app_text(a[0] == 'c' ? 4 : (a[0] == 'r' ? 5 : 6), q);
        }
        else if (!strcmp(a, "print")) fputs(line + 6, stdout);
        else if (!strcmp(a, "drag") && sscanf(line, "%*s %f %f %f %f %f", &x0, &y0, &x1, &y1, &d) == 5) {       /* a slow drag lasting D seconds */
            int n = (int)(d * 60.0f + 0.5f); if (n < 2) n = 2;
            app_pointer(0, x0, y0); app_pointer(1, x0, y0); frame(1 / 60.f);
            for (int i = 1; i <= n; i++) { app_pointer(0, x0 + (x1 - x0) * i / (float)n, y0 + (y1 - y0) * i / (float)n); frame(1 / 60.f); }
            app_pointer(2, x1, y1); frame(1 / 60.f);
        }
        else if (!strcmp(a, "dbgp") && sscanf(line, "%*s %d %d", &i0, &i1) == 2) printf("dbg %d %d = %d\n", i0, i1, app_debug(i0, i1));
        else if (!strcmp(a, "shot") && sscanf(line, "%*s %255s", name) == 1) shot(name);
        else if (!strcmp(a, "audio")) { wav_begin(); if (caplog) fprintf(caplog, "A %ld\n", step_n); }
        else if (!strcmp(a, "log") && sscanf(line, "%*s %255s", name) == 1) { if (caplog) fclose(caplog); caplog = fopen(name, "w"); }
        else if (!strcmp(a, "cam")) { cam_w = cam_h = cam_mode = 0; cam_rate = 4.5f; sscanf(line, "%*s %d %d %d %f", &cam_w, &cam_h, &cam_mode, &cam_rate); if (cam_w > W) cam_w = W; if (cam_h > H) cam_h = H; cam_ready = 0; }
        else if (!strcmp(a, "camfix") && sscanf(line, "%*s %f %f", &x0, &y0) == 2) { cam_tx = x0; cam_ty = y0; }
        else if (!strcmp(a, "rec")) {
            rec_every = 1; sscanf(line, "%*s %d", &rec_every); if (rec_every < 1) rec_every = 1; rec_i = 0; rec_n = 0;
            if (caplog) fprintf(caplog, "R %ld\nM %.2f %.2f\n", step_n, app_debug(14, 0) / 8.0f, app_debug(15, 0) / 8.0f);
            const char *cmd = getenv("REC_CMD");
            if (cmd && cmd[0]) { rec = popen(cmd, "w"); rec_pipe = 1; } else { char p[512]; snprintf(p, sizeof(p), "%s/rec.bgra", outdir); rec = fopen(p, "wb"); rec_pipe = 0; }
        }
        else if (!strcmp(a, "recstop")) { if (rec) { if (rec_pipe) pclose(rec); else fclose(rec); rec = NULL; } }
        else if (!strcmp(a, "state")) { int st = app_debug(4, 0); printf("state: sim=%d stars=%d phase=%d scr=%d demo=%d total=%d\n", st & 15, (st >> 4) & 15, (st >> 8) & 15, (st >> 12) & 15, (st >> 16) & 1, app_debug(9, 0)); }
        else printf("?? %s", line);
    }
    wav_end();
    if (rec) { if (rec_pipe) pclose(rec); else fclose(rec); }
    if (caplog) fclose(caplog);
    return 0;
}
