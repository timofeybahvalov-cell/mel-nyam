/* Level generator / verifier for «Мел-Ням».
   Each level is described by its layout + a scripted solution.  Stars and Mel can be
   placed automatically on the trajectory of that solution (star_t / mel_t), which
   guarantees that every level is solvable with all its stars.  The tool then verifies the
   final level with the real game simulation, measures timing tolerance and writes
   src/levels.h (+ a JSON dump for the debug renderer).
   build: gcc -O2 -I../src lvlgen.c ../src/sim.c -lm -o /tmp/lvlgen
   usage: lvlgen levels.h levels.json [first [last [pstep]]]   (verbose output for levels first..last, 1-based) */
#include "sim.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct {
    const char *name, *hint; int box;
    LObj objs[48];
    Step script[48];
    float star_t[10];          /* >0: put star i on the solution path at that time */
    float mel_t;               /* >0: put Mel's mouth on the solution path at that time */
    float mel_dx, mel_dy;
    float dbg_t0, dbg_t1;      /* print the path in this time window */
    int mel_flip;              /* Mel placed by mel_t sits upside down */
    struct { float t; LObj o; } autos[12];   /* objects placed on the solution path: at time t the object is put at (path + o.x, path + o.y);
                                                 they are placed one after another, each on the path that the earlier ones produce */
} LevelSrc;
#define AT(t, obj) { t, obj }

#define CANDY(x,y)        { O_CANDY, x, y }
#define PIN(x,y)          { O_PIN, x, y }
#define PINL(x,y,len)     { O_PIN, x, y, len }
#define PINT(x,y,len,v,d) { O_PIN, x, y, len, v, d }          /* with a thief: speed px/s, start delay s */
#define AUTOPIN(x,y,r)    { O_AUTOPIN, x, y, r }
#define AUTOPINT(x,y,r,v) { O_AUTOPIN, x, y, r, v }
#define STAR(x,y)         { O_STAR, x, y }
#define BUBBLE(x,y)       { O_BUBBLE, x, y }
#define BLOWER(x,y,deg)   { O_BLOWER, x, y, deg }
#define SPIKES(x,y,x2,y2) { O_SPIKES, x, y, x2, y2 }
#define MEL(x,y)          { O_MEL, x, y }
#define MELF(x,y)         { O_MEL, x, y, 1 }             /* upside down, on the ceiling */
#define BOUNCER(x,y,deg)  { O_BOUNCER, x, y, deg, 0 }
#define BOUNCERL(x,y,deg,hl) { O_BOUNCER, x, y, deg, hl }
#define PORTAL(x,y,deg,pair) { O_PORTAL, x, y, deg, pair }
#define GRAVBTN(x,y)      { O_GRAV, x, y }
#define LASER(x,y,x2,y2,on,off,ph) { O_LASER, x, y, x2, y2, on, off, ph }
#define RAIL(x,y,x2,y2,u,len) { O_RAIL, x, y, x2, y2, u, len }
#define RAILT(x,y,x2,y2,u,len,v) { O_RAIL, x, y, x2, y2, u, len, v }   /* with a thief */
#define RAILAT(x,y,x2,y2,u,r,v) { O_RAIL, x, y, x2, y2, u, -(r), v }   /* sticky rail pin whose rope gets a thief */
#define RAILA(x,y,x2,y2,u,r) { O_RAIL, x, y, x2, y2, u, -(r) }           /* sticky pin on a rail: grabs the bottle inside radius r */
#define CUT(t,pin)        { t, ACT_CUT, pin }
#define POP(t)            { t, ACT_POP, 0 }
#define BLOW(t,i)         { t, ACT_BLOW, i }
#define GRAVITY(t,i)      { t, ACT_GRAV, i }
#define SLIDE(t,pin,u)    { t, ACT_SLIDE, (pin) | ((int)((u) * 255.0f + 0.5f) << 4) }

#include "level_src.h"

#define NLEV ((int)(sizeof(g_src) / sizeof(g_src[0])))
#define MAXSTEPS (120 * 40)

static float g_px[MAXSTEPS], g_py[MAXSTEPS];
typedef struct { int state, stars; float t_end; int steps, noeff; } Result;

static u32 rng = 12345;
static float frand(void) { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return (rng >> 8) / 16777216.0f; }

static Result run(const LObj *objs, const Step *script, float tmax, const float *jitter, int record, int verbose) {
    static Sim s; sim_load(&s, objs);
    int nact = 0; while (script[nact].act != ACT_END) nact++;
    int done[64] = { 0 };
    Result r = { 0, 0, 0, 0, 0 };
    int steps = (int)(tmax * 120.0f); if (steps > MAXSTEPS) steps = MAXSTEPS;
    for (int i = 0; i < steps; i++) {
        for (int a = 0; a < nact; a++) {
            float t = script[a].t + (jitter ? jitter[a] : 0.0f);
            if (!done[a] && s.time >= t) { done[a] = 1; int ok = sim_do(&s, &script[a]); if (!ok) r.noeff++; if (verbose && !ok) printf("    ! action %d (act %d arg %d at %.2f) had no effect\n", a, script[a].act, script[a].arg, t); }
        }
        s.events = 0;
        sim_step(&s);
        if (record) { g_px[i] = s.c.x; g_py[i] = s.c.y; }
        if (verbose) {
            if (s.events & EV_ATTACH) printf("    %.2fs attach rope\n", s.time);
            if (s.events & EV_BUBBLE_IN) printf("    %.2fs into bubble\n", s.time);
            if (s.events & EV_BUBBLE_POP) printf("    %.2fs bubble pops at (%.0f,%.0f)\n", s.time, s.c.x, s.c.y);
            if (s.events & EV_STAR) printf("    %.2fs star %d\n", s.time, s.ev_star);
            if (s.events & EV_BOUNCE) printf("    %.2fs bounce %d at (%.0f,%.0f)\n", s.time, s.ev_bouncer, s.c.x, s.c.y);
            if (s.events & EV_PORTAL) printf("    %.2fs portal %d -> %d\n", s.time, s.ev_portal, s.ev_portal2);
            if (s.events & EV_GRAV) printf("    %.2fs gravity %s\n", s.time, s.gdir > 0 ? "down" : "UP");
            if (s.events & EV_THIEF_FALL) printf("    %.2fs thief falls\n", s.time);
            if (s.events & EV_STOLEN) printf("    %.2fs STOLEN at (%.0f,%.0f)\n", s.time, s.c.x, s.c.y);
            if (s.events & EV_BREAK) printf("    %.2fs BROKEN (%s) at (%.0f,%.0f)\n", s.time, (s.events & EV_BURN) ? "laser" : "spikes", s.c.x, s.c.y);
            if (s.events & EV_LOST) printf("    %.2fs LOST at (%.0f,%.0f)\n", s.time, s.c.x, s.c.y);
            if (s.events & EV_EAT) printf("    %.2fs EATEN\n", s.time);
        }
        r.steps = i + 1;
        if (s.state != ST_PLAY) break;
    }
    r.state = s.state; r.stars = s.stars; r.t_end = s.time;
    return r;
}
static const char *stname(int st) { return st == ST_EATEN ? "EATEN" : (st == ST_LOST ? "LOST" : (st == ST_BROKEN ? "BROKEN" : (st == ST_STOLEN ? "STOLEN" : "TIMEOUT"))); }

int main(int argc, char **argv) {
    const char *out_h = argc > 1 ? argv[1] : "levels.h";
    const char *out_json = argc > 2 ? argv[2] : "/tmp/levels.json";
    int first = argc > 3 ? atoi(argv[3]) - 1 : -1, last = argc > 4 ? atoi(argv[4]) - 1 : first;
    int pstep = argc > 5 ? atoi(argv[5]) : 12;
    FILE *fh = fopen(out_h, "w"), *fj = fopen(out_json, "w");
    if (!fh || !fj) { printf("cannot open outputs\n"); return 1; }
    fprintf(fh, "/* GENERATED by tools/lvlgen.c from tools/level_src.h — do not edit */\n");
    fprintf(fj, "[\n");
    int bad = 0; sim_skip_visual = 1;
    for (int li = 0; li < NLEV; li++) {
        const LevelSrc *L = &g_src[li];
        LObj objs[64]; int n = 0;
        for (int i = 0; i < 48 && L->objs[i].type != O_END; i++) objs[n++] = L->objs[i];
        objs[n].type = O_END;
        float tmax = 0;
        for (int i = 0; i < 10; i++) if (L->star_t[i] > tmax) tmax = L->star_t[i];
        if (L->mel_t > tmax) tmax = L->mel_t;
        int verbose = (li >= first && li <= last);
        if (verbose) printf("== L%d (%d-%d) \"%s\"\n", li + 1, L->box + 1, li % 6 + 1, L->name);
        /* pass 0: objects that sit on the path */
        for (int k = 0; k < 12 && L->autos[k].o.type != O_END; k++) {
            Result ra = run(objs, L->script, L->autos[k].t + 1.0f, NULL, 1, 0);
            int q = (int)(L->autos[k].t * 120.0f); if (q >= ra.steps) { q = ra.steps - 1; if (verbose) printf("  ! auto %d time beyond path end (%.2fs)\n", k, ra.steps / 120.0f); }
            objs[n] = L->autos[k].o; objs[n].x = roundf(g_px[q] + L->autos[k].o.x); objs[n].y = roundf(g_py[q] + L->autos[k].o.y);
            if (verbose) printf("  auto %d: type %d at (%.0f,%.0f)  [path at %.2fs = (%.0f,%.0f)]\n", k, objs[n].type, objs[n].x, objs[n].y, L->autos[k].t, g_px[q], g_py[q]);
            n++; objs[n].type = O_END;
        }
        /* pass 1: path without the stars and Mel */
        Result r1 = run(objs, L->script, tmax > 0 ? tmax + 2.0f : 14.0f, NULL, 1, verbose && L->dbg_t1 > 0);
        if (verbose && L->dbg_t1 > 0) {
            printf("  path:");
            for (int i = 0; i < r1.steps; i += pstep) { float t = (i + 1) / 120.0f; if (t >= L->dbg_t0 && t <= L->dbg_t1) printf(" %.2f:(%.0f,%.0f)", t, g_px[i], g_py[i]); }
            printf("\n");
        }
        for (int i = 0; i < 10; i++) if (L->star_t[i] > 0) {
            int k = (int)(L->star_t[i] * 120.0f); if (k >= r1.steps) { k = r1.steps - 1; if (verbose) printf("  ! star %d time beyond path end (%.2fs)\n", i, r1.steps / 120.0f); }
            memset(&objs[n], 0, sizeof(LObj)); objs[n].type = O_STAR; objs[n].x = roundf(g_px[k]); objs[n].y = roundf(g_py[k]); n++;
        }
        if (L->mel_t > 0) {
            int k = (int)(L->mel_t * 120.0f); if (k >= r1.steps) { k = r1.steps - 1; if (verbose) printf("  ! mel time beyond path end (%.2fs)\n", r1.steps / 120.0f); }
            memset(&objs[n], 0, sizeof(LObj)); objs[n].type = O_MEL; objs[n].x = roundf(g_px[k] + L->mel_dx); objs[n].y = roundf(g_py[k] + L->mel_dy); objs[n].a = (float)L->mel_flip; n++;
        }
        objs[n].type = O_END;
        int need = sim_max_stars(objs);
        /* pass 2: verify */
        Result r2 = run(objs, L->script, 30.0f, NULL, 1, verbose);
        int ok = (r2.state == ST_EATEN && r2.stars == need && need >= 3 && r2.noeff == 0);
        /* tolerance */
        int nact = 0; while (L->script[nact].act != ACT_END) nact++;
        int quiet = (first >= 0 && !verbose); int win = 0, trials = quiet ? 0 : (ok ? 200 : 1);
        int w3[4] = { 0, 0, 0, 0 }; const float amp[4] = { 0.03f, 0.06f, 0.10f, 0.16f };
        for (int a = 0; a < 4; a++)
            for (int k = 0; k < trials; k++) {
                float jit[64]; for (int q = 0; q < nact; q++) jit[q] = (frand() * 2 - 1) * amp[a];
                Result r = run(objs, L->script, r2.t_end + 2.5f, jit, 0, 0);
                if (a == 2 && r.state == ST_EATEN) win++;
                if (r.state == ST_EATEN && r.stars == need) w3[a]++;
            }
        /* SCAN=k : shift action k and everything after it by -1.5..+1.5 s; E = eaten with all stars, e = eaten, . = not eaten */
        if (getenv("SCAN") && verbose) {
            int k0 = atoi(getenv("SCAN")); char line[200]; int li2 = 0;
            for (int d = -75; d <= 75; d++) {
                float jit[64]; for (int q = 0; q < nact; q++) jit[q] = q >= k0 ? d * 0.02f : 0;
                Result r = run(objs, L->script, r2.t_end + 4.5f, jit, 0, 0);
                line[li2++] = d == 0 ? (r.state == ST_EATEN ? '#' : '!') : r.state == ST_EATEN ? (r.stars == need ? 'E' : 'e') : '.';
            }
            line[li2] = 0; printf("  scan act %d (step .02s, # = now): %s\n", k0, line);
        }
        /* does doing nothing win? */
        Step none[1] = { { 0, ACT_END, 0 } };
        Result r0 = run(objs, none, 16.0f, NULL, 0, 0); if (trials < 1) trials = 1;
        int mx = 0, my = 0, has_mel = 0;
        for (int i = 0; i < n; i++) if (objs[i].type == O_MEL) { mx = (int)objs[i].x; my = (int)objs[i].y; has_mel = 1; }
        if (!quiet || !ok) printf("%sL%-2d %d-%d %-22s %s %d/%d t=%5.2f acts=%-2d | full ±.03:%3d%% ±.06:%3d%% ±.10:%3d%% ±.16:%3d%% any±.10:%3d%% | idle:%s mel=(%d,%d)%s%s\n", verbose ? "  => " : "",
               li + 1, L->box + 1, li % 6 + 1, L->name, stname(r2.state), r2.stars, need, r2.t_end, nact,
               w3[0] * 100 / trials, w3[1] * 100 / trials, w3[2] * 100 / trials, w3[3] * 100 / trials, win * 100 / trials,
               r0.state == ST_EATEN ? "WINS(!)" : "ok", mx, my, has_mel ? "" : " NO MEL", ok ? "" : "   *** NOT SOLVED ***");
        if (verbose) { printf("  stars:"); for (int i = 0; i < n; i++) if (objs[i].type == O_STAR) printf(" (%.0f,%.0f)", objs[i].x, objs[i].y); printf("\n"); }
        if (!ok) bad++;
        /* emit C */
        fprintf(fh, "static const LObj lv%d_objs[] = {", li);
        for (int i = 0; i < n; i++) fprintf(fh, " {%d, %g, %g, %g, %g, %g, %g, %g},", objs[i].type, objs[i].x, objs[i].y, objs[i].a, objs[i].b, objs[i].c, objs[i].d, objs[i].e);
        fprintf(fh, " {0} };\n");
        fprintf(fh, "static const Step lv%d_demo[] = {", li);
        for (int i = 0; i < nact; i++) fprintf(fh, " {%.3ff, %d, %d},", L->script[i].t, L->script[i].act, L->script[i].arg);
        fprintf(fh, " {0, 0, 0} };\n");
        /* json */
        fprintf(fj, "%s{\"name\":\"%d-%d\",\"ok\":%d,\"objs\":[", li ? ",\n" : "", L->box + 1, li % 6 + 1, ok);
        for (int i = 0; i < n; i++) fprintf(fj, "%s[%d,%g,%g,%g,%g,%g,%g,%g]", i ? "," : "", objs[i].type, objs[i].x, objs[i].y, objs[i].a, objs[i].b, objs[i].c, objs[i].d, objs[i].e);
        fprintf(fj, "],\"path\":[");
        for (int i = 0; i < r2.steps; i += 3) fprintf(fj, "%s[%.0f,%.0f]", i ? "," : "", g_px[i], g_py[i]);
        fprintf(fj, "]}");
    }
    fprintf(fh, "\n#define LEVEL_COUNT %d\nstatic const LevelDef g_levels[LEVEL_COUNT] = {\n", NLEV);
    for (int li = 0; li < NLEV; li++) fprintf(fh, "    { \"%s\", \"%s\", %d, lv%d_objs, lv%d_demo },\n", g_src[li].name, g_src[li].hint ? g_src[li].hint : "", g_src[li].box, li, li);
    fprintf(fh, "};\n");
    fprintf(fj, "\n]\n");
    fclose(fh); fclose(fj);
    printf("%d levels, %d unsolved\n", NLEV, bad);
    return bad ? 2 : 0;
}
