#!/usr/bin/env python3
"""Starting points for the offline TAS search: the best full-star runs of the online table.

    /tmp/tas_find x 0 0 keys=1 > /tmp/keys.txt                       (the online keys of the 60 levels; build tas_find first)
    python3 tools/tas_seeds.py https://script.google.com/macros/s/.../exec /tmp/keys.txt [tools/tas_runs/seeds]

Read only: it asks the table for a=top (the list of a level) and a=rep (one recording). Two runs per level are written to
OUTDIR/seedNN.txt, one per line, in the form the table keeps them: "ticks_stars_hex...". tools/tas_find.c reads these files
(seeds=OUTDIR). The folder is not part of source_code.zip: these are runs of real players."""
import os, sys, time, urllib.parse, urllib.request

if len(sys.argv) < 3: print(__doc__); sys.exit(2)
API, KEYS = sys.argv[1], sys.argv[2]
OUT = sys.argv[3] if len(sys.argv) > 3 else os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tas_runs', 'seeds')
os.makedirs(OUT, exist_ok=True)

def get(q):
    err = ''
    for _ in range(3):
        try:
            with urllib.request.urlopen(API + '?' + q, timeout=40) as r: return r.read().decode('utf-8', 'replace')
        except Exception as e: err = e; time.sleep(2)
    return 'err\t%s' % err

total = 0
for ln in open(KEYS):
    lv, key, mx = ln.split(); lv = int(lv); mx = int(mx)
    top = get('a=top&l=' + key).split('\n')
    if not top or not top[0].startswith('ok'): print(lv, key, 'top:', top[0][:60]); continue
    rows = [r.split('\t') for r in top[1:] if r.strip()]
    rows = [r for r in rows if len(r) >= 5 and int(r[2]) >= mx]            # full-star runs only
    rows.sort(key=lambda r: int(r[3]))
    out = []
    for r in rows[:2]:
        rep = get('a=rep&l=%s&p=%s' % (key, urllib.parse.quote(r[4]))).split('\n')
        f = rep[0].split('\t') + (rep[1:2] if len(rep) > 1 else [])
        txt = [x for x in f if '_' in x and x.split('_')[0].isdigit()]
        if txt: out.append(txt[0].strip())
    with open(os.path.join(OUT, 'seed%02d.txt' % lv), 'w') as fh: fh.write('\n'.join(out) + ('\n' if out else ''))
    total += len(out)
    print(lv, key, 'full-star rows', len(rows), 'best', rows[0][3] if rows else '-', 'saved', len(out)); sys.stdout.flush()
print('total seeds', total)
