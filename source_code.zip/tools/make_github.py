#!/usr/bin/env python3
"""Builds everything that goes into the GitHub repository of «Мел-Ням»:

    ../github_upload/       flat folder: README.md, index.html (site for GitHub Pages), pictures, the two game files
    ../MelNyam_GitHub.zip   the same folder zipped

usage: python3 tools/make_github.py <github-user> [repo-name] [address of the online table]
needs: gcc, ffmpeg, python3 with PIL and fonttools+brotli; MelNyam.exe / MelNyam.html / MelNyam.apk / gen/pack.bin already built
       (the .apk: android/build_apk.sh).
The game files are copied as they are, nothing is rebuilt.
The third argument (or the variable MELNYAM_API_URL) goes into online.json: the address of the Apps Script web app that keeps the
records (see ONLINE_SETUP.md). Without it the address that is published right now is kept (online.json of the live site);
if there is none, online.json is written empty and the game keeps its records locally.
online.json also tells the game: the support page (MELNYAM_DONATE_URL; without it the published one is kept; none = no «Поддержать»
button), and the newest version with the size and the SHA-256 of MelNyam.exe and MelNyam.apk (that is what the game's update
check reads, so online.json must be uploaded together with these files, and last).
env: MN_TMP = scratch directory (default /tmp/gh), MN_OUT = the output folder (default ../github_upload),
     MN_ZIP_ONLY=1 = delete the folder after zipping it,
     MN_ONLY_CHANGED=1 = the zip gets only the files that are new or differ from the ones already in the GitHub repository
     MN_ZIP=path = write the zip there (default: MelNyam_GitHub.zip next to the project folder)
     MN_SPLIT=1 = several archives instead of one, NAME_1.zip, NAME_2.zip ... none bigger than MN_SPLIT_MB (default 13.0):
                  a single archive of 25 MB was once not kept by the place the files are handed over through.
                  The last archive holds online.json and the other small files and is the one to upload last
                         (an update is then a small upload, and nothing that is fine there is touched).
"""
import base64, hashlib, io, json, os, re, shutil, subprocess, sys, urllib.request, zipfile
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
USER = sys.argv[1] if len(sys.argv) > 1 else 'USER'
REPO = sys.argv[2] if len(sys.argv) > 2 else 'mel-nyam'
OUT = os.environ.get('MN_OUT') or os.path.join(os.path.dirname(ROOT), 'github_upload')
TMP = os.environ.get('MN_TMP', '/tmp/gh')
API_URL = (sys.argv[3] if len(sys.argv) > 3 else os.environ.get('MELNYAM_API_URL', '')).strip()
assert API_URL == '' or (API_URL.startswith('https://') and API_URL.endswith('/exec')), 'the address must look like https://script.google.com/macros/s/.../exec'
FONT = os.path.join(ROOT, 'fonts/Nunito.ttf')
PAGES = 'https://%s.github.io/%s/' % (USER.lower(), REPO)
REPO_URL = 'https://github.com/%s/%s' % (USER, REPO)
HEADLESS = os.path.join(TMP, 'melnyam_headless')
def http_get(url):
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'melnyam-make-github'}), timeout=30) as r: return r.read()
    except Exception as e:
        print('(no answer from %s: %s)' % (url, e)); return None
DONATE_URL = os.environ.get('MELNYAM_DONATE_URL', '').strip()
if not API_URL or not DONATE_URL:                                          # keep what is published right now: the table, the support page
    live = http_get(PAGES + 'online.json')
    try: live = json.loads(live.decode('utf-8')) if live else {}
    except Exception: live = {}
    API_URL = API_URL or str(live.get('api', '')).strip(); DONATE_URL = DONATE_URL or str(live.get('donate', '')).strip()
assert API_URL == '' or re.fullmatch(r'https://[^\s"\\]+', API_URL), API_URL
assert DONATE_URL == '' or re.fullmatch(r'https://[^\s"\\<>\']+', DONATE_URL), DONATE_URL
_vh = open(os.path.join(ROOT, 'src', 'version.h'), encoding='utf-8').read()     # the one place where the version of all three builds is written
APP_VER = int(re.search(r'^#define APP_VER (\d+)', _vh, re.M).group(1)); APK_VER = re.search(r'^#define APP_VER_NAME "([^"]+)"', _vh, re.M).group(1)

def sh(cmd, **kw):
    subprocess.run(cmd, shell=True, check=True, cwd=ROOT, **kw)
def font(size, weight=1000):
    f = ImageFont.truetype(FONT, size); f.set_variation_by_axes([weight]); return f
def run_script(lines, env=None):
    p = os.path.join(TMP, 'script.txt')
    with open(p, 'w') as f: f.write('\n'.join(lines) + '\n')
    e = dict(os.environ); e.update(env or {})
    subprocess.run([HEADLESS, 'gen/pack.bin', TMP, p], check=True, cwd=ROOT, env=e, stdout=subprocess.DEVNULL)
def ppm(name): return Image.open(os.path.join(TMP, name + '.ppm')).convert('RGB')
def mb(path): return ('%.1f' % (os.path.getsize(path) / 1048576)).replace('.', ',')
def write(name, text):
    with open(os.path.join(OUT, name), 'w', encoding='utf-8', newline='\n') as f: f.write(text)

os.makedirs(TMP, exist_ok=True)
if os.path.isdir(OUT): shutil.rmtree(OUT)
os.makedirs(OUT)
sh('gcc -O2 -w -ffp-contract=off -DNDEBUG -Isrc tools/headless.c src/game.c src/engine.c src/sim.c src/tas.c -lm -o ' + HEADLESS)

# ---------------------------------------------------------------- screenshots
run_script(['size 1280 720', 'wait 1.6', 'shot s1',                      # menu
            'dbg 3 60', 'dbg 5 1', 'wait 0.6', 'shot s2',                # all ten locations, opened
            'dbg 8 0', 'dbg 10 5', 'wait 2.0', 'shot s3',                # 1-6 Тарзан
            'dbg 10 7', 'wait 3.0', 'shot s4',                           # 2-2 Лифт
            'dbg 10 16', 'wait 4.0', 'shot s5',                          # 3-5 Прямо в рот
            'dbg 34 9', 'wait 7.0', 'shot s6',                           # result panel: a counted run that plays itself
            'dbg 10 38', 'wait 3.0', 'shot s7',                          # 7-3: lasers in the club
            'dbg 10 45', 'wait 3.0', 'shot s8',                          # 8-4: portals on the yacht
            'dbg 10 54', 'wait 4.5', 'shot s9',                          # 10-1: the exam
            'dbg 107 0', 'wait 1.0', 'shot s10',                         # level editor
            'size 2560 1440', 'dbg 11 6', 'dbg 5 0', 'wait 2.0', 'shot key'])   # bare key art for the banner
# TAS mode. The level for the editor is a copy of 1-5 «Три верёвки»: it is played by hand (two cuts), then the search finds a faster way.
TAS_LEVEL = '1;0;1,5400,3000;2,3400,1200;2,6400,800;2,9400,1200;4,6080,3190;4,7380,3700;4,8140,5400;8,9580,5580'
run_script(['size 1280 720', 'wait 1.0', 'dbg 137 0', 'dbg 130 0', 'wait 1.0', 'shot s11',                     # the fastest runs of all 60 levels
            'dbg 107 0', 'wait 0.3', 'level ' + TAS_LEVEL, 'wait 0.3', 'dbg 103 0', 'wait 0.7', 'dbg 138 4096', 'wait 1.5', 'dbg 138 4097',
            'wait 5.0', 'shot s12',                                                                            # all the stars: the result panel has the «TAS» button
            'dbg 123 0', 'wait 3.0', 'shot s13'])                                                              # the search inside the game has found a faster run
# 0.4: the settings (with one of Mel's reactions being tried), a recording slowed down to 0.3X, the password of a new account
run_script(['size 1280 720', 'wait 1.0', 'dbg 137 0', 'dbg 140 0', 'wait 0.4', 'dbg 143 5', 'wait 0.9', 'shot s14',
            'dbg 5 0', 'wait 0.3', 'dbg 120 12', 'wait 2.0', 'dbg 146 3', 'wait 1.2', 'shot s15',
            'dbg 5 0', 'wait 0.4', 'dbg 158 1', 'wait 0.3', 'text Тимофей', 'key 2', 'wait 0.4', 'text Mel_2026', 'click 1022 168', 'wait 0.3', 'shot s16'])
for i in range(1, 17):
    ppm('s%d' % i).save(os.path.join(OUT, 'pic_screen%d.jpg' % i), quality=88, optimize=True)
# the numbers for the site come from src/tas_data.h: that is what the game is built from (tools/tas_runs is only the working copy of the search)
_runs = re.findall(r'\{(\d+), (\d+), (\d+), (\d+)\}', re.search(r'tas_runs\[TAS_DATA_LEVELS\] = \{(.*?)\};', open(os.path.join(ROOT, 'src', 'tas_data.h'), encoding='utf-8').read(), re.S).group(1))
assert len(_runs) == 60 and all(int(r[0]) > 0 for r in _runs), 'src/tas_data.h: a run for each of the 60 levels is expected'
TAS_PROVED = str(sum(1 for r in _runs if r[3] == '1'))                    # levels where the exhaustive search has finished
_t = int(round(sum(int(r[0]) for r in _runs) / 120.0)); TAS_TOTAL = '%d\u00a0мин %d\u00a0с' % (_t // 60, _t % 60)      # all 60 runs in a row

# ---------------------------------------------------------------- banner 1280x640 (also the repo's social preview)
SS = 2
key = ppm('key').crop((0, 50, 2560, 1330))                               # 2:1
def outlined(text, cx, cy, size, fill=(255, 255, 255), edge=(30, 16, 90), w=7, weight=1000):
    global key
    f = font(size * SS, weight)
    sh_layer = Image.new('RGBA', key.size, (0, 0, 0, 0)); sd = ImageDraw.Draw(sh_layer)
    sd.text((cx * SS, cy * SS + 5 * SS), text, font=f, fill=(8, 4, 30, 170), anchor='mm', stroke_width=w * SS, stroke_fill=(8, 4, 30, 170))
    blur = sh_layer.filter(ImageFilter.GaussianBlur(3 * SS)); key.paste(blur, (0, 0), blur)
    ImageDraw.Draw(key).text((cx * SS, cy * SS), text, font=f, fill=fill, anchor='mm', stroke_width=w * SS, stroke_fill=edge)
outlined('Перережь верёвку —', 432, 356, 58)
outlined('накорми Мела!', 432, 428, 58, fill=(255, 226, 92))
pill = Image.new('RGBA', key.size, (0, 0, 0, 0)); pd = ImageDraw.Draw(pill)
ptxt = '60 уровней   •   10 локаций   •   рекорды   •   редактор'
pf = font(22 * SS, 800); pw = pd.textlength(ptxt, font=pf)
pd.rounded_rectangle((432 * SS - pw / 2 - 30 * SS, 505 * SS, 432 * SS + pw / 2 + 30 * SS, 557 * SS), radius=26 * SS, fill=(14, 10, 46, 190))
pd.text((432 * SS, 531 * SS), ptxt, font=pf, fill=(255, 255, 255, 240), anchor='mm')
key = Image.alpha_composite(key.convert('RGBA'), pill).convert('RGB')
key.resize((1280, 640), Image.LANCZOS).save(os.path.join(OUT, 'pic_banner.jpg'), quality=92, optimize=True)

# ---------------------------------------------------------------- README buttons (pictures, because README cannot have styled buttons)
def button(path, text, c0, c1, icon):
    S = 3; H = 132; pad = 46; isz = 46
    f = font(46 * S, 1000)
    tw = int(ImageDraw.Draw(Image.new('L', (8, 8))).textlength(text, font=f) / S)
    W = pad + isz + 22 + tw + pad
    im = Image.new('RGBA', (W * S, (H + 14) * S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    r = 40 * S
    dark = tuple(int(c * 0.55) for c in c1)
    d.rounded_rectangle((0, 12 * S, W * S - 1, (H + 12) * S - 1), radius=r, fill=dark + (255,))            # lip
    grad = Image.new('RGBA', (W * S, H * S)); gp = grad.load()
    for y in range(H * S):
        t = y / (H * S - 1); col = tuple(int(c0[k] + (c1[k] - c0[k]) * t) for k in range(3)) + (255,)
        for x in range(W * S): gp[x, y] = col
    mask = Image.new('L', (W * S, H * S), 0); ImageDraw.Draw(mask).rounded_rectangle((0, 0, W * S - 1, H * S - 1), radius=r, fill=255)
    im.paste(grad, (0, 0), mask)
    gloss = Image.new('RGBA', im.size, (0, 0, 0, 0))
    ImageDraw.Draw(gloss).rounded_rectangle((10 * S, 7 * S, (W - 10) * S, int(H * 0.46) * S), radius=28 * S, fill=(255, 255, 255, 56))
    im = Image.alpha_composite(im, gloss); d = ImageDraw.Draw(im)
    cx = (pad + isz / 2) * S; cy = (H / 2 - 2) * S; edge = (22, 20, 60, 255)
    if icon == 'play':
        pts = [(cx - 15 * S, cy - 22 * S), (cx + 22 * S, cy), (cx - 15 * S, cy + 22 * S)]
        d.polygon(pts, fill=(255, 255, 255, 255)); d.line(pts + [pts[0]], fill=edge, width=5 * S, joint='curve')
        d.polygon([(x * 0.86 + cx * 0.14 + 0.5 * S, y * 0.86 + cy * 0.14) for x, y in pts], fill=(255, 255, 255, 255))
    else:                                                                   # download arrow
        pts = [(cx - 9 * S, cy - 24 * S), (cx + 9 * S, cy - 24 * S), (cx + 9 * S, cy - 4 * S), (cx + 22 * S, cy - 4 * S), (cx, cy + 18 * S), (cx - 22 * S, cy - 4 * S), (cx - 9 * S, cy - 4 * S)]
        d.line(pts + [pts[0], pts[1]], fill=edge, width=9 * S, joint='curve'); d.polygon(pts, fill=(255, 255, 255, 255))
        d.rounded_rectangle((cx - 24 * S, cy + 20 * S, cx + 24 * S, cy + 31 * S), radius=5 * S, fill=(255, 255, 255, 255), outline=edge, width=2 * S)
    d.text(((pad + isz + 22) * S, cy), text, font=f, fill=(255, 255, 255, 255), anchor='lm', stroke_width=5 * S, stroke_fill=edge)
    im.resize((W, H + 14), Image.LANCZOS).save(path, optimize=True)
button(os.path.join(OUT, 'pic_btn_play.png'), 'ИГРАТЬ В БРАУЗЕРЕ', (140, 240, 90), (46, 176, 50), 'play')
button(os.path.join(OUT, 'pic_btn_win.png'), 'СКАЧАТЬ ДЛЯ WINDOWS', (104, 190, 255), (44, 110, 226), 'down')
button(os.path.join(OUT, 'pic_btn_zip.png'), 'СКАЧАТЬ АРХИВОМ', (190, 140, 255), (112, 64, 220), 'down')
button(os.path.join(OUT, 'pic_btn_apk.png'), 'СКАЧАТЬ APK-ФАЙЛ', (255, 196, 92), (240, 122, 30), 'down')

# ---------------------------------------------------------------- gameplay GIF (three real runs, 640x360, 15 fps)
GW, GH = 640, 360
segs = [(0, 0.35, 4.3), (20, 0.5, 4.2), (43, 0.5, 4.6)]                    # level index, start, duration
for i, (lv, t0, dur) in enumerate(segs):
    rec = 'ffmpeg -loglevel error -y -f rawvideo -pix_fmt bgra -s %dx%d -r 15 -i - -c:v libx264 -qp 0 -pix_fmt yuv444p %s/g%d.mp4' % (GW, GH, TMP, i)
    run_script(['size %d %d' % (GW, GH), 'dbg 8 0', 'dbg 10 %d' % lv, 'wait %g' % t0, 'rec 4', 'wait %g' % dur, 'recstop'], {'REC_CMD': rec})
sh('ffmpeg -loglevel error -y -i {t}/g0.mp4 -i {t}/g1.mp4 -i {t}/g2.mp4 -filter_complex "[0:v][1:v][2:v]concat=n=3:v=1:a=0,split[a][b];'
   '[a]palettegen=max_colors=220:stats_mode=diff[p];[b][p]paletteuse=dither=bayer:bayer_scale=5:diff_mode=rectangle" {o}/pic_gameplay.gif'.format(t=TMP, o=OUT))

# ---------------------------------------------------------------- game files, source archive
for f in ('MelNyam.exe', 'MelNyam.html', 'MelNyam.apk'): shutil.copy2(os.path.join(ROOT, f), os.path.join(OUT, f))
EXE_MB, HTML_MB, APK_MB = mb(os.path.join(OUT, 'MelNyam.exe')), mb(os.path.join(OUT, 'MelNyam.html')), mb(os.path.join(OUT, 'MelNyam.apk'))
shutil.copy2(os.path.join(ROOT, 'server', 'Code.gs'), os.path.join(OUT, 'google_sheet_script.gs'))
shutil.copy2(os.path.join(ROOT, 'server', 'ONLINE_SETUP.md'), os.path.join(OUT, 'ONLINE_SETUP.md'))
def file_info(name):
    with open(os.path.join(OUT, name), 'rb') as fh: d = fh.read()
    return len(d), hashlib.sha256(d).hexdigest()
CFG = {'api': API_URL}                                                     # what every copy of the game reads at start
if DONATE_URL: CFG['donate'] = DONATE_URL
CFG.update({'ver': APP_VER, 'vname': APK_VER, 'html': 'MelNyam.html'})
for kind in ('exe', 'apk'):
    CFG[kind] = 'MelNyam.' + kind; CFG[kind + '_size'], CFG[kind + '_sha'] = file_info('MelNyam.' + kind)
write('online.json', json.dumps(CFG, ensure_ascii=False, indent=1) + '\n')
with zipfile.ZipFile(os.path.join(OUT, 'source_code.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for base in ('src', 'tools', 'web', 'notes', 'server', 'android'):
        for dp, dn, fn in os.walk(os.path.join(ROOT, base)):
            dn[:] = sorted(x for x in dn if x not in ('__pycache__', 'seeds', 'logs'))      # tools/tas_runs/seeds: runs of real players from the table; logs: search logs
            for f in sorted(fn):
                if f != 'transcripts_whisper.txt' and not f.endswith(('.jks', '.keystore', '.pem')):      # a signing key never goes into the public archive
                    z.write(os.path.join(dp, f), os.path.relpath(os.path.join(dp, f), ROOT))
    for f in ('build.sh', 'README.md', 'gen/pack.bin', 'gen/icon.ico', 'gen/icon.png'): z.write(os.path.join(ROOT, f), f)
    z.writestr('ЧИТАЙ_МЕНЯ.txt', 'Исходный код игры «Мел-Ням».\n\nСборка обеих версий: ./build.sh (что нужно установить — написано в README.md).\n'
               'Готовый пакет ресурсов лежит в gen/pack.bin. Исходные материалы для него (видео, звуки, картинки)\nв архив не входят, поэтому команда ./build.sh assets здесь не сработает.\n\n'
               'Версия для Android: android/build_apk.sh (нужен Android SDK, подробности в начале скрипта).\nКлюч подписи в архив не входит: собранный тобой APK будет подписан другим ключом\nи не установится поверх игры, скачанной с сайта.\n')

# ---------------------------------------------------------------- site page (index.html) for GitHub Pages
SITE = r'''<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Мел-Ням — играть онлайн и скачать бесплатно</title>
<meta name="description" content="Мел-Ням: перережь верёвку — накорми Мела! Бесплатная головоломка. Играй прямо в браузере или скачай на телефон с Android и на компьютер.">
<meta name="theme-color" content="#0b0920">
<meta property="og:type" content="website">
<meta property="og:title" content="Мел-Ням — перережь верёвку, накорми Мела!">
<meta property="og:description" content="Бесплатная головоломка: 60 уровней, 10 локаций, таблица рекордов и редактор уровней. Играй прямо в браузере или скачай на телефон с Android и на компьютер.">
<meta property="og:image" content="@@PAGES@@pic_banner.jpg">
<meta property="og:url" content="@@PAGES@@">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" type="image/png" href="data:image/png;base64,@@ICON@@">
<!-- Шрифт: Nunito, SIL Open Font License 1.1 -->
<style>
@font-face{font-family:Nunito;src:url(data:font/woff2;base64,@@FONT@@) format("woff2");font-weight:500 1000;font-display:swap}
:root{--bg:#0b0920;--card:rgba(255,255,255,.05);--line:rgba(255,255,255,.1);--txt:#efecff;--dim:#b3aee0;--gold:#ffe25c}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--txt);font:600 18px/1.55 Nunito,system-ui,"Segoe UI",Roboto,Arial,sans-serif;-webkit-font-smoothing:antialiased}
body::before{content:"";position:fixed;inset:0;z-index:-1;background:
 radial-gradient(900px 600px at 10% -5%,rgba(150,80,255,.30),transparent 62%),
 radial-gradient(800px 600px at 96% 8%,rgba(40,200,220,.17),transparent 62%),
 radial-gradient(1000px 700px at 50% 108%,rgba(120,60,230,.24),transparent 62%)}
a{color:#9fd2ff}
.wrap{max-width:980px;margin:0 auto;padding:22px 18px 56px}
.banner{display:block;width:100%;height:auto;aspect-ratio:2/1;border-radius:28px;box-shadow:0 18px 60px rgba(0,0,0,.55),0 0 0 1px var(--line)}
.cta{text-align:center;margin:30px 0 6px}
.cta p{margin:20px 0 0;color:var(--dim)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:.55em;font-weight:1000;line-height:1.15;color:#fff;text-decoration:none;
 border-radius:999px;padding:.7em 1.45em;text-shadow:0 2px 0 rgba(20,18,60,.5);box-shadow:0 6px 0 var(--lip),0 14px 30px var(--glow);
 background:linear-gradient(var(--c0),var(--c1));transition:transform .08s,box-shadow .08s,filter .15s;position:relative;-webkit-tap-highlight-color:transparent}
.btn::before{content:"";position:absolute;left:10px;right:10px;top:5px;height:42%;border-radius:999px;background:rgba(255,255,255,.2);pointer-events:none}
.btn:hover{filter:brightness(1.08)}
.btn:active{transform:translateY(4px);box-shadow:0 2px 0 var(--lip),0 8px 18px var(--glow)}
.btn svg{width:1.05em;height:1.05em;flex:none;fill:#fff;filter:drop-shadow(0 2px 0 rgba(20,18,60,.5))}
.play{--c0:#8cf05a;--c1:#2eb032;--lip:#1c6b22;--glow:rgba(46,176,50,.38);font-size:34px;padding:.62em 1.5em}
.win{--c0:#68beff;--c1:#2c6ee2;--lip:#1b4190;--glow:rgba(44,110,226,.34);font-size:22px}
.web{--c0:#be8cff;--c1:#7040dc;--lip:#452791;--glow:rgba(112,64,220,.34);font-size:22px}
.apk{--c0:#ffc45c;--c1:#f07a1e;--lip:#9a4a0e;--glow:rgba(240,122,30,.36);font-size:22px}
.cta .apk{font-size:24px;margin-top:26px}
.cta .sub{margin:14px 0 0;font-size:16px}
.wide{margin-bottom:20px}
.wide ol{columns:2;column-gap:44px}
.wide ol li{break-inside:avoid}
.chips{display:flex;flex-wrap:wrap;justify-content:center;gap:10px;margin:26px 0 0;padding:0;list-style:none}
.chips li{background:var(--card);border:1px solid var(--line);border-radius:999px;padding:6px 16px;font-weight:800;font-size:16px}
.chips b{color:var(--gold);font-weight:1000}
h2{font-size:32px;font-weight:1000;line-height:1.2;margin:64px 0 22px;text-align:center}
h3{font-size:23px;font-weight:1000;line-height:1.25;margin:0 0 6px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.card{background:var(--card);border:1px solid var(--line);border-radius:24px;padding:26px 26px 22px}
.card .btn{margin:14px 0 4px}
.card{scroll-margin-top:18px}
.note{color:var(--dim);font-size:16px;margin:10px 0 0}
.lead2{color:var(--dim);margin:-6px auto 20px;max-width:760px;text-align:center}
ol{margin:16px 0 0;padding-left:1.3em}
ol li{margin:7px 0}
ol li::marker{color:var(--gold);font-weight:1000}
.shot{padding:0;overflow:hidden}
.shot img{display:block;width:100%;height:auto;aspect-ratio:16/9}
.shot div{padding:18px 22px 20px}
.shot p{margin:0}
.tag{display:inline-block;margin-top:12px;font-size:15px;font-weight:800;color:var(--gold);background:rgba(255,226,92,.1);border:1px solid rgba(255,226,92,.25);border-radius:999px;padding:2px 12px}
.gif{display:block;width:100%;max-width:800px;height:auto;aspect-ratio:16/9;margin:0 auto;border-radius:24px;box-shadow:0 14px 44px rgba(0,0,0,.5),0 0 0 1px var(--line)}
.news{display:grid;gap:12px;max-width:860px;margin:22px auto 0;padding:0;list-style:none}
.news li{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:14px 20px}
.news b{color:#fff}
.keys{display:grid;grid-template-columns:repeat(2,1fr);gap:12px 20px;max-width:860px;margin:0 auto;padding:0;list-style:none}
.keys li{display:flex;align-items:center;gap:14px;background:var(--card);border:1px solid var(--line);border-radius:18px;padding:12px 18px}
kbd{flex:none;min-width:86px;text-align:center;font:1000 16px Nunito,system-ui,sans-serif;color:#1b1640;background:linear-gradient(#fff,#d9d4ff);border-radius:10px;padding:5px 10px;box-shadow:0 3px 0 #8f86d8}
.faq{max-width:860px;margin:0 auto}
details{background:var(--card);border:1px solid var(--line);border-radius:18px;margin:12px 0;padding:0 20px}
summary{cursor:pointer;font-weight:1000;font-size:19px;padding:15px 0;list-style:none;display:flex;justify-content:space-between;align-items:center;gap:12px}
summary::-webkit-details-marker{display:none}
summary::after{content:"+";flex:none;font-size:26px;line-height:1;color:var(--gold)}
details[open] summary::after{content:"–"}
details p{margin:0 0 16px;color:#dcd8ff}
code{font:700 .92em ui-monospace,Consolas,monospace;background:rgba(255,255,255,.09);border-radius:6px;padding:1px 6px}
footer{margin:64px 0 0;padding:26px 0 0;border-top:1px solid var(--line);color:var(--dim);font-size:15px;text-align:center}
footer p{margin:6px 0}
@media (max-width:820px){
 body{font-size:17px}.grid2,.grid3,.keys{grid-template-columns:1fr}.banner{border-radius:18px}
 h2{font-size:27px;margin-top:52px}.play{font-size:27px}.win,.web,.apk{font-size:19px}.cta .apk{font-size:21px}.card{padding:22px 20px 18px}.shot{padding:0}
 .wide ol{columns:1}
}
</style>
</head>
<body>
<div class="wrap">

<img class="banner" src="pic_banner.jpg" width="1280" height="640" alt="Мел-Ням — перережь верёвку, накорми Мела!">

<div class="cta">
  <a class="btn play" href="MelNyam.html"><svg viewBox="0 0 24 24"><path d="M6 3.5v17a1 1 0 0 0 1.5.86l14-8.5a1 1 0 0 0 0-1.72l-14-8.5A1 1 0 0 0 6 3.5z"/></svg>ИГРАТЬ СЕЙЧАС</a>
  <p>Игра откроется прямо в браузере. Скачивать ничего не нужно.</p>
  <a class="btn apk" href="MelNyam.apk" download="MelNyam.apk"><svg viewBox="0 0 24 24"><path d="M9 1.5h6V10h5l-8 8.500L4 10h5zM3.500 20h17v3h-17z"/></svg>Скачать APK-файл</a>
  <p class="sub">Игра для телефона или планшета с Android, @@APK_MB@@ МБ. <a href="#android">Как установить</a></p>
  <ul class="chips">
    <li><b>60</b> уровней</li><li><b>10</b> локаций</li><li>рекорды и редактор уровней</li><li>без рекламы</li><li>версия <b>@@APK_VER@@</b></li>
  </ul>
</div>

<h2 id="download">Скачать игру</h2>
<div class="card wide" id="android">
  <h3>Версия для Android</h3>
  <a class="btn apk" href="MelNyam.apk" download="MelNyam.apk"><svg viewBox="0 0 24 24"><path d="M9 1.5h6V10h5l-8 8.500L4 10h5zM3.500 20h17v3h-17z"/></svg>Скачать APK-файл</a>
  <p class="note">Один файл, @@APK_MB@@ МБ, версия @@APK_VER@@. Нужен Android 7 или новее. Играть можно без интернета, а рекорды и уровни других игроков работают с интернетом — так же, как на сайте.</p>
  <ol>
    <li>Открой эту страницу на телефоне и нажми кнопку. Если браузер предупредит, что файл может быть опасным, подтверди скачивание.</li>
    <li>Когда файл скачается, нажми «Открыть». Не успел — найди <code>MelNyam.apk</code> в папке «Загрузки».</li>
    <li>Телефон скажет, что установка из этого источника запрещена. Нажми «Настройки», включи «Разрешить установку из этого источника» и вернись назад.</li>
    <li>Нажми «Установить». Если Play Защита спросит про неизвестное приложение, выбери «Всё равно установить» или «Проверить приложение».</li>
    <li>На рабочем столе или в списке приложений появится значок «Мел-Ням @@APK_VER@@». Нет на рабочем столе? Зажми значок в списке приложений и перетащи его туда.</li>
    <li>Вышла новая версия? С версии 0.4 игра сама предложит обновиться. Версию 0.3 и старше обнови вручную: скачай новый APK и установи его поверх старого. Прогресс сохранится.</li>
  </ol>
</div>
<div class="grid2">
  <div class="card">
    <h3>Версия для Windows</h3>
    <a class="btn win" href="MelNyam.exe" download="MelNyam.exe"><svg viewBox="0 0 24 24"><path d="M9 1.5h6V10h5l-8 8.500L4 10h5zM3.500 20h17v3h-17z"/></svg>Скачать MelNyam.exe</a>
    <p class="note">Один файл, @@EXE_MB@@ МБ. Устанавливать не нужно.</p>
    <ol>
      <li>Нажми кнопку. Файл сохранится в папку «Загрузки».</li>
      <li>Если браузер спросит, сохранять ли файл, выбери «Сохранить».</li>
      <li>Дважды кликни по файлу <code>MelNyam.exe</code>.</li>
      <li>Появилось синее окно «Система Windows защитила ваш компьютер»? Нажми «Подробнее», потом «Выполнить в любом случае».</li>
    </ol>
  </div>
  <div class="card">
    <h3>Браузерная версия</h3>
    <a class="btn web" href="MelNyam.html" download="MelNyam.html"><svg viewBox="0 0 24 24"><path d="M9 1.5h6V10h5l-8 8.500L4 10h5zM3.500 20h17v3h-17z"/></svg>Скачать MelNyam.html</a>
    <p class="note">Один файл, @@HTML_MB@@ МБ. Работает без интернета на Windows, Mac и Linux.</p>
    <ol>
      <li>Нажми кнопку. Файл сохранится в папку «Загрузки».</li>
      <li>Дважды кликни по файлу <code>MelNyam.html</code>.</li>
      <li>Игра откроется в браузере. Интернет ей больше не нужен.</li>
    </ol>
  </div>
</div>

<h2>Как это выглядит</h2>
<img class="gif" src="pic_gameplay.gif" width="640" height="360" alt="Запись игры: три уровня">

<h2>Что в игре</h2>
<div class="grid3">
  <div class="card shot">
    <img src="pic_screen2.jpg" width="1280" height="720" loading="lazy" alt="Выбор локации">
    <div><h3>10 локаций, 60 уровней</h3><p>Стримерская, Пентхаус, Вилла, Спортзал, Гараж, Самолёт, Клуб, Яхта, Остров и Арена. В каждой локации шесть уровней и своя новая механика.</p><span class="tag">локации открываются за звёзды</span></div>
  </div>
  <div class="card shot">
    <img src="pic_screen7.jpg" width="1280" height="720" loading="lazy" alt="Уровень с лазерами в локации «Клуб»">
    <div><h3>Девять механик</h3><p>Верёвки и липучки, пузыри и шипы, груши-воздуходуйки, батуты, рельсы, кнопки гравитации, лазеры, порталы и воришки, которые утаскивают бутылку.</p><span class="tag">каждая со своей локацией</span></div>
  </div>
  <div class="card shot">
    <img src="pic_screen9.jpg" width="1280" height="720" loading="lazy" alt="Экзамен в локации «Арена»">
    <div><h3>Экзамен на Арене</h3><p>Шесть уровней, где все механики сразу и десять звёзд. Подсказок и показа решения нет: порядок действий придётся найти самому.</p><span class="tag">нужно 120 звёзд</span></div>
  </div>
</div>
<div class="grid3" style="margin-top:20px">
  <div class="card shot">
    <img src="pic_screen6.jpg" width="1280" height="720" loading="lazy" alt="Уровень пройден">
    <div><h3>Рекорды</h3><p>У каждого уровня своя таблица: сто лучших игроков по времени. Запись чужого прохождения можно посмотреть, но только после того, как прошёл уровень сам.</p><span class="tag">время идёт в углу экрана</span></div>
  </div>
  <div class="card shot">
    <img src="pic_screen10.jpg" width="1280" height="720" loading="lazy" alt="Редактор уровней">
    <div><h3>Редактор уровней</h3><p>Собери свой уровень из тех же деталей, пройди его сам и опубликуй. Его увидят все игроки, и у него будет своя таблица рекордов.</p><span class="tag">8 мест для своих уровней</span></div>
  </div>
  <div class="card shot">
    <img src="pic_screen8.jpg" width="1280" height="720" loading="lazy" alt="Уровень с порталами в локации «Яхта»">
    <div><h3>Мел живой</h3><p>Он здоровается, торопит, выпрашивает бутылку и хохочет. Каждая разбитая бутылка злит его сильнее: он краснеет, а потом вскакивает и кричит.</p><span class="tag">настоящие видео и голос</span></div>
  </div>
</div>

<h2>Новое в версии @@APK_VER@@</h2>
<p class="lead2">Аккаунт с паролем, настройки, скорость записей и обновление одной кнопкой.</p>
<div class="grid3">
  <div class="card shot">
    <img src="pic_screen16.jpg" width="1280" height="720" loading="lazy" alt="Пароль для нового аккаунта">
    <div><h3>Аккаунт с паролем</h3><p>Придумай ник и пароль — и заходи в свой аккаунт с любого устройства: с телефона, с компьютера, из браузера. Ник, рекорды и пройденные уровни будут те же. Уже играл раньше? Игра предложит добавить пароль, а все рекорды останутся твоими.</p><span class="tag">один ник — один игрок</span></div>
  </div>
  <div class="card shot">
    <img src="pic_screen14.jpg" width="1280" height="720" loading="lazy" alt="Настройки игры">
    <div><h3>Настройки</h3><p>Кнопка с шестерёнкой в главном меню. Отдельная громкость для звуков, музыки и речи. Выключатели для речи Мела, облачка с текстом, подсказок, тряски экрана, искр и таймера. И список всех эмоций Мела: любую можно посмотреть и выключить.</p><span class="tag">17 эмоций Мела</span></div>
  </div>
  <div class="card shot">
    <img src="pic_screen15.jpg" width="1280" height="720" loading="lazy" alt="Запись прохождения, замедленная до 0.3X">
    <div><h3>Скорость записи</h3><p>Когда смотришь чужой рекорд, свою запись или TAS, вверху есть полоска скорости: от 0.1X до 5X. Замедли запись, чтобы разглядеть каждое действие, или ускорь, чтобы не ждать.</p><span class="tag">от 0.1X до 5X</span></div>
  </div>
</div>
<ul class="news">
  <li><b>Обновление одной кнопкой.</b> При запуске игра проверяет, не вышла ли новая версия. Если вышла, предлагает обновиться: версия для Windows сама скачивает и заменяет свой файл, приложение для Android скачивает новый APK и открывает установщик, страница в браузере просто загружается заново. Прогресс и аккаунт остаются.</li>
  <li><b>Звук на телефонах.</b> Звук в браузере и в приложении для Android переделан: он больше не должен заикаться, когда игре не хватает скорости. Всё ещё заикается? Напиши автору: ссылка на GitHub внизу страницы.</li>@@SITE_DONATE_NEWS@@
</ul>

<h2>Режим TAS</h2>
<p class="lead2">TAS (tool-assisted speedrun) — прохождение, которое рассчитал компьютер. Он режет верёвки с точностью до 1/120 секунды и никогда не промахивается.</p>
<div class="grid2">
  <div class="card shot">
    <img src="pic_screen11.jpg" width="1280" height="720" loading="lazy" alt="Режим TAS: самые быстрые прохождения всех 60 уровней">
    <div><h3>Самые быстрые прохождения</h3><p>Собери все 222 звезды, и в главном меню появится оранжевая кнопка «TAS». За ней прохождения всех 60 уровней, которые нашёл перебор: миллионы вариантов на каждый уровень. Все уровни подряд TAS проходит за @@TAS_TOTAL@@. Рядом стоят твои рекорды: сразу видно, сколько ещё можно выиграть.</p><span class="tag">открывается за все звёзды</span></div>
  </div>
  <div class="card shot">
    <img src="pic_screen13.jpg" width="1280" height="720" loading="lazy" alt="Игра нашла самый быстрый путь для уровня игрока">
    <div><h3>TAS для любого уровня</h3><p>Прошёл на все звёзды уровень другого игрока или свой уровень в редакторе? На панели результата появится кнопка «TAS». Игра за несколько секунд переберёт варианты и покажет самый быстрый путь, который нашла.</p><span class="tag">поиск идёт прямо в игре</span></div>
  </div>
</div>

<h2>Управление</h2>
<ul class="keys">
  <li><kbd>Мышь</kbd>Проведи по верёвке с зажатой кнопкой, чтобы её перерезать</li>
  <li><kbd>Клик</kbd>Лопнуть пузырь, дунуть грушей, нажать кнопку гравитации</li>
  <li><kbd>Тянуть</kbd>Сдвинуть гвоздь по рельсу</li>
  <li><kbd>Esc</kbd>Пауза. Там же кнопка «Показать решение» (на Арене её нет)</li>
  <li><kbd>R</kbd>Начать уровень заново</li>
  <li><kbd>Enter</kbd>Следующий уровень</li>
  <li><kbd>F</kbd>Полный экран</li>
  <li><kbd>M</kbd>Включить или выключить звук</li>
  <li><kbd>Палец</kbd>На телефоне и планшете так же. Экран лучше повернуть горизонтально</li>
  <li><kbd>Назад</kbd>В версии для Android: пауза или возврат на прошлый экран</li>
</ul>

<h2>Частые вопросы</h2>
<div class="faq">
  <details><summary>Это вирус?</summary><p>Нет. Версии для компьютера ничего не устанавливают и не просят никаких разрешений. Версия для Android — обычное приложение с двумя разрешениями: доступ в интернет и установка собственных обновлений (Android каждый раз спрашивает тебя, обновлять или нет). В интернет игра выходит за таблицей рекордов, за уровнями других игроков и чтобы проверить, нет ли новой версии. Исходный код открыт и лежит на GitHub: любой может его прочитать и собрать игру сам.</p></details>
  <details><summary>Что игра передаёт в интернет?</summary><p>Ник, результаты уровней с записью прохождения и уровни, которые ты сам опубликовал. Пока игра открыта, она ещё сообщает таблице рекордов, что ты в игре и на каком экране (это видит только автор игры — так он замечает ботов). Пароль в интернет не уходит: игра отправляет только его необратимый «отпечаток». Ни почты, ни имени, ни адреса игра не спрашивает.</p></details>
  <details><summary>Как попасть в таблицу рекордов?</summary><p>Пройди уровень. После первой победы игра предложит создать аккаунт: придумай ник и пароль. После этого твои результаты сами уходят в таблицу. Считается одна попытка: от начала уровня до того, как Мел съел бутылку. Рекорды смотри в главном меню, кнопка «Рекорды».</p></details>
  <details><summary>Зачем нужен пароль?</summary><p>Чтобы аккаунт был только твоим и работал на всех устройствах. В главном меню нажми кнопку с человечком, потом «Войти», и введи ник и пароль: рекорды и пройденные уровни подтянутся из таблицы. В пароле должно быть не меньше 8 символов: заглавная буква, строчная буква, цифра и знак.</p></details>
  <details><summary>Забыл пароль</summary><p>Узнать старый пароль нельзя: его не знает даже автор игры. Но автор может выдать новый. Напиши ему — например, во вкладке Issues на GitHub (ссылка внизу страницы) — и назови свой ник.</p></details>
  <details><summary>Как обновить игру?</summary><p>Игра сама проверяет при запуске, не вышла ли новая версия, и показывает окно «Вышло обновление!». Нажми «Обновить». На Android откроется системный установщик — нажми в нём «Обновить» или «Установить»; в первый раз Android может попросить разрешить игре устанавливать обновления. Версии 0.3 и старше так не умеют: их один раз нужно обновить вручную, скачав новый файл с этой страницы.</p></details>
  <details><summary>Написано «Онлайн-таблица пока не подключена»</summary><p>Значит, общая таблица сейчас недоступна или нет интернета. Твои рекорды никуда не пропадут: они сохраняются на устройстве и уйдут в таблицу, когда она заработает.</p></details>
  <details><summary>Windows, Android или браузер ругается на файл. Это нормально?</summary><p>Да. Так бывает с новыми программами, которых нет в магазинах приложений и у которых нет платной цифровой подписи. В синем окне Windows нажми «Подробнее», потом «Выполнить в любом случае». На Android разреши установку из браузера, а в окне Play Защиты выбери «Всё равно установить».</p></details>
  <details><summary>APK не устанавливается</summary><p>Проверь версию системы: нужен Android 7 или новее. Освободи место на телефоне: когда память почти заполнена, Android не ставит новые приложения. Если телефон всё равно пишет «Приложение не установлено», удали старую версию игры и установи новую заново — прогресс при этом сотрётся. На iPhone APK не работает: там играй в браузере.</p></details>
  <details><summary>В браузере нет звука</summary><p>Кликни по игре один раз: браузеры включают звук только после первого клика. Проверь, что звук не выключен на вкладке, в меню игры (кнопка с динамиком) и в настройках игры (кнопка с шестерёнкой: громкость звуков, музыки и речи).</p></details>
  <details><summary>Где хранится прогресс?</summary><p>В браузерной версии — в памяти браузера. Если почистить данные сайта, прогресс пропадёт. В версии для Windows — в файле <code>%APPDATA%\MelNyam\save.dat</code>. В версии для Android — в самом приложении: он пропадёт, если удалить игру или стереть её данные. Если у тебя есть аккаунт, пройденные уровни и звёзды не потеряются: войди в аккаунт заново (или на другом устройстве), и игра возьмёт их из таблицы рекордов.</p></details>
  <details><summary>Файл .exe не запускается</summary><p>Версия для Windows рассчитана на 64-разрядную систему. Если она не запускается, играй в браузере: игра там точно такая же.</p></details>
  <details><summary>Игра тормозит</summary><p>Закрой лишние вкладки и программы. Если не помогло, уменьши окно игры: чем меньше картинка, тем легче компьютеру. В приложении для Android помогает обновление: открой Google Play и обнови «Android System WebView» и Chrome.</p></details>
  <details><summary>Не могу пройти уровень</summary><p>Нажми паузу и выбери «Показать решение». Игра сама пройдёт уровень на три звезды, а потом даст повторить. На Арене решений нет: там экзамен.</p></details>
</div>

<footer>
  <p>Неофициальная фан-пародия. Игра бесплатная, без рекламы и покупок. Автор не связан с Mellstroy.</p>@@SITE_DONATE_FOOT@@
  <p>Исходный код и все файлы: <a href="@@REPO_URL@@">github.com/@@USER@@/@@REPO@@</a></p>
</footer>

</div>
</body>
</html>
'''
def site_font():
    from fontTools.ttLib import TTFont
    from fontTools import subset
    from fontTools.varLib import instancer
    f = TTFont(FONT)
    chars = set(SITE) | set('АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя'
                            'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 .,:;!?-–—«»"\'()/%+•…№')
    o = subset.Options(); o.layout_features = ['kern', 'liga', 'mark', 'mkmk', 'ccmp', 'locl']; o.name_IDs = [1, 2, 4, 6]; o.notdef_outline = True
    s = subset.Subsetter(o); s.populate(text=''.join(sorted(c for c in chars if ord(c) >= 32))); s.subset(f)
    b = io.BytesIO(); f.save(b); b.seek(0)                                   # reload: the instancer needs fully loaded tables
    f = instancer.instantiateVariableFont(TTFont(b), {'wght': (500, 1000)})
    f.flavor = 'woff2'; b = io.BytesIO(); f.save(b); return base64.b64encode(b.getvalue()).decode()
ib = io.BytesIO(); Image.open(os.path.join(ROOT, 'gen/icon.png')).convert('RGBA').resize((64, 64), Image.LANCZOS).save(ib, 'PNG', optimize=True)
site = SITE
# the support page: only if there is one. A plain link and plain words: nothing is sold, nothing is promised for it.
SITE_DONATE_NEWS = ('\n  <li><b>Поддержать игру.</b> Игра бесплатная и такой останется. Если она тебе нравится, автору можно сказать «спасибо» добровольным переводом: в главном меню появилась кнопка «Поддержать». За перевод в игре ничего не даётся. Младше 18? Сначала спроси родителей.</li>' if DONATE_URL else '')
SITE_DONATE_FOOT = ('\n  <p>Нравится игра? Автора можно <a href="%s" rel="noopener">поддержать добровольным переводом</a>. Получатель перевода — отец автора. За перевод в игре ничего не даётся. Младше 18? Сначала спроси родителей.</p>' % DONATE_URL if DONATE_URL else '')
SITE = SITE.replace('@@SITE_DONATE_NEWS@@', SITE_DONATE_NEWS).replace('@@SITE_DONATE_FOOT@@', SITE_DONATE_FOOT); site = SITE
for k, v in (('@@FONT@@', site_font()), ('@@ICON@@', base64.b64encode(ib.getvalue()).decode()), ('@@PAGES@@', PAGES), ('@@REPO_URL@@', REPO_URL),
             ('@@USER@@', USER), ('@@REPO@@', REPO), ('@@EXE_MB@@', EXE_MB), ('@@HTML_MB@@', HTML_MB), ('@@APK_MB@@', APK_MB), ('@@APK_VER@@', APK_VER), ('@@TAS_PROVED@@', TAS_PROVED), ('@@TAS_TOTAL@@', TAS_TOTAL)):
    site = site.replace(k, v)
assert '@@' not in site
write('index.html', site)

# ---------------------------------------------------------------- README.md
README = '''<p align="center"><img src="pic_banner.jpg" alt="Мел-Ням — перережь верёвку, накорми Мела!" width="100%"></p>

<p align="center">
  <a href="@@PAGES@@MelNyam.html"><img src="pic_btn_play.png" alt="Играть в браузере" height="66"></a>
  &nbsp;&nbsp;
  <a href="MelNyam.exe?raw=true"><img src="pic_btn_win.png" alt="Скачать для Windows" height="66"></a>
  &nbsp;&nbsp;
  <a href="MelNyam.apk?raw=true"><img src="pic_btn_apk.png" alt="Скачать APK-файл для Android" height="66"></a>
</p>

# Мел-Ням

**Перережь верёвку — накорми Мела!**

Головоломка в духе Cut the Rope. На верёвке висит бутылочка, внизу ждёт Мел. Режь верёвки, лопай пузыри,
дуй грушами и собери по дороге три звезды. Мел реагирует вживую: здоровается, торопит, краснеет от злости и кричит «О май гад!».

- 60 уровней в десяти локациях, в каждой локации своя механика
- экзамен на Арене: все механики сразу, десять звёзд, никаких подсказок
- таблица рекордов для каждого уровня: сто лучших по времени, записи прохождений можно смотреть
- редактор уровней: собери свой уровень и опубликуй его для всех
- режим TAS: самые быстрые прохождения всех уровней, которые нашёл компьютер
- аккаунт с паролем: один ник и одни рекорды на всех твоих устройствах
- настройки: громкость звуков, музыки и речи, любую эмоцию Мела можно выключить
- любую запись можно замедлить до 0.1X или ускорить до 5X
- настоящие видеореакции и голос Мела
- работает в браузере, на Windows и на Android, обновляется одной кнопкой
- бесплатно и без рекламы

Сейчас здесь лежит версия **@@APK_VER@@**. Что в ней нового — [ниже](#новое-в-версии-@@VER_ANCHOR@@).

Сайт игры: **@@PAGES@@**

<p align="center"><img src="pic_gameplay.gif" alt="Запись игры: три уровня" width="640"></p>

## Как начать играть

Игра во всех версиях одинаковая. Выбери, как удобнее:

| Версия | Скачивать | Интернет | Где работает |
|---|---|---|---|
| В браузере | не нужно | нужен | компьютер, планшет, телефон |
| `MelNyam.exe` | @@EXE_MB@@ МБ | не нужен | Windows |
| `MelNyam.apk` | @@APK_MB@@ МБ | не нужен | телефон и планшет с Android 7 и новее |
| `MelNyam.html` | @@HTML_MB@@ МБ | не нужен | Windows, Mac, Linux |

Рекорды и уровни других игроков работают с интернетом в любой версии.

### Способ 1. Сразу в браузере — ничего не надо скачивать

1. Нажми зелёную кнопку **«Играть в браузере»** вверху страницы.
2. Подожди несколько секунд, пока игра загрузится.
3. Нажми **«Играть»**. Звук появится после первого клика — так устроены браузеры.

То же самое можно сделать с сайта игры: открой @@PAGES@@ и нажми **«Играть сейчас»**.

Так можно играть на компьютере и ноутбуке с любой системой. На планшете и телефоне игра тоже запускается — поверни экран горизонтально.

### Способ 2. Скачать на компьютер с Windows

1. Нажми синюю кнопку **«Скачать для Windows»** вверху страницы. Скачается один файл `MelNyam.exe` (@@EXE_MB@@ МБ).
2. Если браузер спросит, сохранять ли файл, или напишет, что такой файл «редко скачивают», выбери **«Сохранить»**.
3. Открой папку **«Загрузки»** и дважды кликни по `MelNyam.exe`.
4. Может появиться синее окно **«Система Windows защитила ваш компьютер»**. Нажми в нём **«Подробнее»**, а потом **«Выполнить в любом случае»**.
5. Игра запущена. Устанавливать ничего не нужно.

> Синее окно появляется у всех программ, у которых нет платной цифровой подписи. У этой игры её нет.

### Способ 3. Установить на телефон с Android

1. Открой эту страницу или [сайт игры](@@PAGES@@) на телефоне и нажми оранжевую кнопку **«Скачать APK-файл»**.
   Скачается один файл `MelNyam.apk` (@@APK_MB@@ МБ).
2. Если браузер предупредит, что файл может быть опасным, подтверди скачивание.
3. Когда файл скачается, нажми **«Открыть»**. Не успел — найди `MelNyam.apk` в папке **«Загрузки»**.
4. Телефон скажет, что установка из этого источника запрещена. Нажми **«Настройки»**, включи
   **«Разрешить установку из этого источника»** и вернись назад.
5. Нажми **«Установить»**. Если Play Защита спросит про неизвестное приложение, выбери **«Всё равно установить»**
   или **«Проверить приложение»**.
6. На рабочем столе или в списке приложений появится значок **«Мел-Ням @@APK_VER@@»**. Запускай игру с него.
   Если значка нет на рабочем столе, зажми его в списке приложений и перетащи туда.

> Нужен Android 7 или новее. Предупреждения появляются у всех приложений, которых нет в Google Play. У игры одно разрешение: доступ в интернет.
> С версии 0.4 игра сама предлагает обновиться, когда выходит новая версия. Версию 0.3 и старше обнови вручную: скачай новый APK
> и установи его поверх старого, прогресс сохранится. На iPhone APK не работает — там играй в браузере.

### Способ 4. Браузерная версия, которая работает без интернета

<p><a href="../../archive/refs/heads/main.zip"><img src="pic_btn_zip.png" alt="Скачать архивом" height="52"></a></p>

1. Нажми фиолетовую кнопку **«Скачать архивом»**. Скачается архив `@@REPO@@-main.zip` со всеми файлами игры.
2. Открой папку **«Загрузки»**, нажми по архиву правой кнопкой мыши и выбери **«Извлечь всё»**.
3. Открой получившуюся папку и дважды кликни по `MelNyam.html`. Игра откроется в браузере, интернет ей больше не нужен.

> Можно проще: на [сайте игры](@@PAGES@@) есть кнопка «Скачать MelNyam.html». Она скачивает этот файл одним кликом, без архива.

## Обзор игры

В каждом уровне задача одна: доставить бутылочку Мелу. По дороге стоит собрать три звезды — за звёзды открываются новые локации.
Любой уровень можно переигрывать сколько угодно раз.

### Десять локаций

<p align="center"><img src="pic_screen2.jpg" alt="Выбор локации" width="640"></p>

В каждой локации шесть уровней и одна новая механика. Локации открываются за звёзды.

| № | Локация | Что нового | Сколько звёзд нужно |
|---|---|---|---|
| 1 | Стримерская | верёвки и липучки: липучка сама цепляет бутылку, когда та залетает в пунктирный круг | открыта сразу |
| 2 | Пентхаус | пузыри несут бутылку вверх, на шипах она разбивается | 8 |
| 3 | Вилла | груши-воздуходуйки толкают бутылку струёй воздуха | 20 |
| 4 | Спортзал | батуты подбрасывают бутылку | 34 |
| 5 | Гараж | рельсы: гвоздь с верёвкой можно двигать | 48 |
| 6 | Самолёт | кнопки гравитации: всё падает вверх | 62 |
| 7 | Клуб | лазеры: бутылка сгорает, если задеть луч | 76 |
| 8 | Яхта | порталы переносят бутылку в другое место | 90 |
| 9 | Остров | воришки утаскивают бутылку, если долго ждать | 104 |
| 10 | Арена | экзамен: все механики сразу | 120 |

<p align="center">
  <img src="pic_screen3.jpg" alt="Локация «Стримерская»" width="49%"> <img src="pic_screen4.jpg" alt="Локация «Пентхаус»" width="49%">
</p>
<p align="center">
  <img src="pic_screen7.jpg" alt="Локация «Клуб»: лазеры" width="49%"> <img src="pic_screen8.jpg" alt="Локация «Яхта»: порталы" width="49%">
</p>

### Экзамен на Арене

<p align="center"><img src="pic_screen9.jpg" alt="Экзамен в локации «Арена»" width="640"></p>

Последняя локация — экзамен. В каждом из шести уровней собраны все механики и лежит десять звёзд.
Подсказок нет, кнопка «Показать решение» не работает: порядок действий нужно найти самому, а счёт идёт на доли секунды.

### Рекорды

У каждого уровня есть своя таблица рекордов: сто лучших игроков. Выше стоит тот, кто собрал больше звёзд, а при равных звёздах — тот, кто быстрее.
Время одной попытки идёт в углу экрана. После первой победы игра спросит ник и сама отправит результат.

Рядом с каждым рекордом есть кнопка просмотра: игра покажет запись этого прохождения. Смотреть чужие записи можно только на уровнях,
которые ты уже прошёл сам. Таблица открывается из главного меню кнопкой **«Рекорды»**.

### Редактор уровней

<p align="center"><img src="pic_screen10.jpg" alt="Редактор уровней" width="640"></p>

Кнопка **«Редактор»** в главном меню. Добавляй детали кнопками справа, перетаскивай их мышкой или пальцем, меняй длину верёвок и наклон.
Кнопка **«Проба»** запускает уровень. Опубликовать можно только уровень, который ты прошёл сам: так игра проверяет, что он проходим.
Опубликованные уровни лежат во вкладке **«Уровни игроков»**, у каждого своя таблица рекордов.

### Новое в версии @@APK_VER@@

**Аккаунт с паролем.** В главном меню слева вверху — кнопка с человечком. Придумай ник и пароль, и аккаунт будет только твоим.
На другом устройстве нажми эту же кнопку, потом **«Войти»**: ник, рекорды и пройденные уровни будут те же.
В пароле должно быть не меньше 8 символов: заглавная буква, строчная буква, цифра и знак. Пароль нужно ввести два раза.
Уже играл в версию 0.3? Игра сама предложит добавить пароль, и все твои рекорды и уровни останутся твоими.

<p align="center">
  <img src="pic_screen16.jpg" alt="Пароль для нового аккаунта" width="49%"> <img src="pic_screen14.jpg" alt="Настройки игры" width="49%">
</p>

**Настройки.** Кнопка с шестерёнкой в главном меню. Отдельная громкость для звуков, музыки и речи.
Выключатели: речь Мела, облачко с текстом, подсказки, тряска и вспышки, искры и конфетти, таймер уровня.
И список всех 17 эмоций Мела: каждую можно посмотреть кнопкой справа и выключить, если она мешает.

**Скорость записи.** Когда смотришь чужой рекорд, свою запись или TAS, вверху экрана есть полоска скорости: от 0.1X до 5X.
Кнопка рядом с ней возвращает обычную скорость. На клавиатуре — стрелки влево и вправо.

<p align="center"><img src="pic_screen15.jpg" alt="Запись прохождения, замедленная до 0.3X" width="640"></p>

**Обновление одной кнопкой.** При запуске игра проверяет, не вышла ли новая версия. Если вышла, появляется окно «Вышло обновление!».
`MelNyam.exe` сам скачивает новый файл, проверяет его и заменяет себя. Приложение для Android скачивает новый APK, проверяет его
и открывает системный установщик. Страница в браузере загружается заново. Прогресс и аккаунт остаются на месте.
Версии 0.3 и старше так не умеют: их один раз нужно обновить вручную.

**Звук на телефонах.** Звук в браузере и в приложении для Android переделан: он больше не должен заикаться, когда игре не хватает скорости.
Всё ещё заикается? Напиши во вкладке [Issues](../../issues), на каком телефоне.
@@README_DONATE_NEWS@@
### Режим TAS

<p align="center"><img src="pic_screen11.jpg" alt="Режим TAS: самые быстрые прохождения всех 60 уровней" width="640"></p>

TAS (tool-assisted speedrun) — это прохождение, которое рассчитал компьютер. Он режет верёвки с точностью до 1/120 секунды и никогда не промахивается.

Собери все 222 звезды, и в главном меню справа вверху появится оранжевая кнопка **«TAS»**. За ней — самые быстрые прохождения всех 60 уровней.
Нажми на уровень, и игра покажет запись. Под временем TAS стоит твой рекорд: сразу видно, сколько ещё можно выиграть.
Все 60 уровней подряд TAS проходит за @@TAS_TOTAL@@.

Зелёная галочка на уровне значит, что перебор дошёл до конца: пройти этот уровень со всеми звёздами быстрее нельзя. Таких уровней @@TAS_PROVED@@ из 60.
На остальных уровнях показан самый быстрый путь из найденных. Если твой рекорд окажется быстрее, игра начнёт новый поиск уже от твоего прохождения.

<p align="center">
  <img src="pic_screen12.jpg" alt="Панель результата с кнопкой «TAS»" width="49%"> <img src="pic_screen13.jpg" alt="Игра нашла самый быстрый путь" width="49%">
</p>

TAS есть и для уровней игроков, и для твоих уровней в редакторе. Пройди уровень на все звёзды, и на панели результата появится кнопка **«TAS»**.
Игра сама переберёт варианты и покажет самый быстрый путь, который нашла. Обычно это занимает несколько секунд.

### Мел реагирует на всё

<p align="center"><img src="pic_screen6.jpg" alt="Уровень пройден на три звезды" width="640"></p>

Мел сидит за столом и следит за бутылкой. На первом уровне после запуска игры он здоровается, а когда бутылка рядом, кричит «Дай его!».
Каждая разбитая бутылка злит его сильнее: он краснеет и наконец выдаёт «Я уже красный! Культурно уже не получится!».
Если долго думать, он торопит: «Быстрее! Быстрее!!!». А если много раз ошибиться на сложном уровне, вскакивает и кричит.
Ругательства в игре закрыты писком.

### Меню и выбор локации

<p align="center">
  <img src="pic_screen1.jpg" alt="Главное меню" width="49%"> <img src="pic_screen2.jpg" alt="Выбор локации" width="49%">
</p>

## Управление

| Что сделать | Как |
|---|---|
| Перерезать верёвку | провести по ней мышкой с зажатой кнопкой или пальцем |
| Лопнуть пузырь | кликнуть по пузырю |
| Дунуть грушей | кликнуть по груше |
| Перевернуть гравитацию | кликнуть по кнопке со стрелкой |
| Сдвинуть гвоздь по рельсу | потянуть его мышкой или пальцем |
| Пауза | Esc |
| Начать уровень заново | R |
| Следующий уровень | Enter |
| Включить или выключить звук | M |
| Полный экран | F |

Не получается уровень? Нажми паузу и выбери **«Показать решение»** — игра сама пройдёт его на три звезды. На Арене решений нет.

## Частые вопросы

**Это вирус?**<br>
Нет. Версии для компьютера ничего не устанавливают и не просят никаких разрешений. Версия для Android — обычное приложение
с двумя разрешениями: доступ в интернет и установка собственных обновлений (Android каждый раз спрашивает тебя, обновлять или нет).
В интернет игра выходит за таблицей рекордов, за уровнями других игроков и чтобы проверить, нет ли новой версии.
Исходный код лежит здесь же, в файле `source_code.zip`: любой может его прочитать и собрать игру сам.

**Что игра передаёт в интернет?**<br>
Ник, результаты уровней с записью прохождения и уровни, которые ты сам опубликовал. Пока игра открыта, она ещё сообщает таблице рекордов,
что ты в игре и на каком экране (это видит только автор игры — так он замечает ботов).
Пароль в интернет не уходит: игра отправляет только его необратимый «отпечаток». Ни почты, ни имени, ни адреса игра не спрашивает.

**Как попасть в таблицу рекордов?**<br>
Пройди уровень. После первой победы игра предложит создать аккаунт: придумай ник и пароль. После этого твои результаты сами уходят в таблицу.

**Зачем нужен пароль?**<br>
Чтобы аккаунт был только твоим и работал на всех устройствах: кнопка с человечком в главном меню, потом «Войти».

**Забыл пароль.**<br>
Узнать старый пароль нельзя: его не знает даже автор игры. Но автор может выдать новый. Напиши во вкладке [Issues](../../issues) и назови свой ник.

**Как обновить игру?**<br>
Игра сама проверяет при запуске, не вышла ли новая версия, и предлагает обновиться. На Android откроется системный установщик:
нажми в нём «Обновить» или «Установить». В первый раз Android может попросить разрешить игре устанавливать обновления.

**Написано «Онлайн-таблица пока не подключена».**<br>
Общая таблица сейчас недоступна или нет интернета. Твои рекорды сохраняются на устройстве и уйдут в таблицу, когда она заработает.

**Windows, Android или браузер ругается на файл. Это нормально?**<br>
Да. Так бывает с новыми программами, которых нет в магазинах приложений и у которых нет платной цифровой подписи.
Как запустить игру, написано выше: для Windows — в способе 2, для Android — в способе 3.

**APK не устанавливается.**<br>
Проверь версию системы: нужен Android 7 или новее. Освободи место на телефоне: когда память почти заполнена, Android не ставит новые приложения.
Если телефон всё равно пишет «Приложение не установлено», удали старую версию игры и установи новую заново — прогресс при этом сотрётся.

**В браузере нет звука.**<br>
Кликни по игре один раз. Проверь, что звук не выключен на вкладке и в меню игры (кнопка с динамиком).

**Где хранится прогресс?**<br>
В браузерной версии — в памяти браузера: если почистить данные сайта, прогресс пропадёт.
В версии для Windows — в файле `%APPDATA%\\MelNyam\\save.dat`.
В версии для Android — в самом приложении: он пропадёт, если удалить игру или стереть её данные.
Если у тебя есть аккаунт, пройденные уровни и звёзды не потеряются: войди в аккаунт заново, и игра возьмёт их из таблицы рекордов.

**Файл `MelNyam.exe` не запускается.**<br>
Версия для Windows рассчитана на 64-разрядную систему. Если она не запускается, играй в браузере: игра там точно такая же.

**Игра тормозит.**<br>
Закрой лишние вкладки и программы. Если не помогло, уменьши окно игры: чем меньше картинка, тем легче компьютеру.
В приложении для Android помогает обновление: открой Google Play и обнови «Android System WebView» и Chrome.

**У меня Mac, Linux или iPhone.**<br>
Играй в браузере — это способ 1. Для телефонов с Android есть приложение — способ 3.

**Нашёл ошибку или придумал уровень.**<br>
Напиши во вкладке [Issues](../../issues).

## Понравилась игра?

Поставь проекту звезду — кнопка **Star** вверху страницы. Так игру увидит больше людей.
@@README_DONATE@@

## Что лежит в этом проекте

| Файл | Что это |
|---|---|
| `MelNyam.exe` | игра для Windows |
| `MelNyam.html` | игра для браузера, один файл |
| `MelNyam.apk` | игра для Android |
| `index.html` | страница сайта игры |
| `source_code.zip` | исходный код игры и скрипт сборки |
| `online.json` | что игра читает при запуске: адрес таблицы рекордов, номер свежей версии с размером и контрольной суммой файлов, адрес страницы поддержки |
| `google_sheet_script.gs` | скрипт для Google Таблицы, в которой хранятся рекорды, уровни игроков и аккаунты |
| `ONLINE_SETUP.md` | инструкция для автора: как подключить и обновить таблицу рекордов |
| `pic_*` | картинки для этой страницы и для сайта |

## Для тех, кто разбирается

Игра написана на C на собственном движке: программный рендер, своя физика верёвок, свой звуковой микшер
(в браузере звуки играет сам браузер, через узлы Web Audio: так звук не зависит от скорости кадров).
Один и тот же код собирается в `MelNyam.exe` (mingw-w64) и в `MelNyam.html` (clang, WebAssembly).
`MelNyam.apk` — это та же страница `MelNyam.html` внутри приложения с одним WebView (папка `android` в `source_code.zip`).
Физика считается одинаково во всех версиях, поэтому запись прохождения — это просто список действий игрока:
игра проигрывает её заново и так же проверяет каждый чужой рекорд. Рекорды, уровни игроков и аккаунты хранятся в Google Таблице
через Apps Script (`google_sheet_script.gs`).

Аккаунты: игра отправляет не пароль, а его SHA-256; в таблице лежит хеш от этого хеша с солью, а устройство получает свой ключ входа.
Обновление: игра читает `online.json`, и если версия там новее, скачивает файл с этого же сайта и берёт его,
только если совпали размер и SHA-256. Приложение для Android после этого передаёт файл системному установщику,
а тот ставит обновление, только если оно подписано тем же ключом.

Режим TAS — это поиск по состояниям физики (`src/tas.c`). Перебор идёт волной, тик за тиком: на каждом тике он пробует каждое возможное действие,
одинаковые состояния склеивает, а состояния, из которых уже не успеть быстрее лучшего найденного пути, отбрасывает
по оценке оставшегося времени. Затем лучший путь шлифуется сдвигами действий на один тик.
Для 60 основных уровней поиск сделан заранее с большим запасом (`tools/tas_find.c`), результат лежит в `src/tas_data.h`.
Галочка «быстрее нельзя» ставится только там, где перебор без склейки похожих состояний дошёл до конца.
На уровнях с рельсами её не бывает: у рельсы слишком много положений, чтобы перебрать все.

## Про права

Это неофициальная фан-пародия. Игра бесплатная, в ней нет рекламы и покупок, автор не связан с Mellstroy.
Видео и голос взяты из открытых источников, права на них принадлежат их владельцам.
Если вы правообладатель и хотите, чтобы материалы убрали, напишите в [Issues](../../issues) — их удалят.
'''
README_DONATE_NEWS = ('\n**Поддержать игру.** В главном меню появилась кнопка «Поддержать». Игра бесплатная и такой останется, за перевод в ней ничего не даётся.\n' if DONATE_URL else '')
README_DONATE = ('\nИгра бесплатная и такой останется. Если хочется сказать автору «спасибо», можно [поддержать его добровольным переводом](%s).\nПолучатель перевода — отец автора. За перевод в игре ничего не даётся. Младше 18? Сначала спроси родителей.\n' % DONATE_URL if DONATE_URL else '')
for k, v in (('@@README_DONATE_NEWS@@', README_DONATE_NEWS), ('@@README_DONATE@@', README_DONATE), ('@@VER_ANCHOR@@', APK_VER.replace('.', '')),
             ('@@PAGES@@', PAGES), ('@@REPO@@', REPO), ('@@EXE_MB@@', EXE_MB), ('@@HTML_MB@@', HTML_MB), ('@@APK_MB@@', APK_MB), ('@@APK_VER@@', APK_VER), ('@@TAS_PROVED@@', TAS_PROVED), ('@@TAS_TOTAL@@', TAS_TOTAL)):
    README = README.replace(k, v)
assert '@@' not in README
write('README.md', README)

# ---------------------------------------------------------------- zip of the whole folder
zpath = os.environ.get('MN_ZIP') or os.path.join(os.path.dirname(ROOT), 'MelNyam_GitHub.zip')
zbase = zpath[:-4] if zpath.lower().endswith('.zip') else zpath
for old_zip in [zpath] + [zbase + '_%d.zip' % i for i in range(1, 9)]:
    if os.path.exists(old_zip): os.remove(old_zip)
names = sorted(os.listdir(OUT)); state = {f: '' for f in names}
if os.environ.get('MN_ONLY_CHANGED') == '1':                               # what is already in the repository, by git blob hash
    listing = http_get('https://api.github.com/repos/%s/%s/contents/' % (USER, REPO))
    try: there = {e['name']: e['sha'] for e in json.loads(listing.decode('utf-8'))} if listing else None
    except Exception: there = None
    if there is None: print('(the repository listing is not available: the zip gets every file)')
    else:
        for f in names:
            with open(os.path.join(OUT, f), 'rb') as fh: d = fh.read()
            state[f] = 'same' if there.get(f) == hashlib.sha1(b'blob %d\0' % len(d) + d).hexdigest() else ('changed' if f in there else 'new')
picked = [f for f in names if state[f] != 'same']
def zipped_size(f):                                                       # how much room the file takes inside an archive
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z: z.write(os.path.join(OUT, f), f)
    return len(b.getvalue())
if os.environ.get('MN_SPLIT') == '1':
    # The big files first, each into the first archive that still has room. Everything small (the site, the pictures, online.json)
    # goes into one last archive: online.json names the new files, so it has to be uploaded after them.
    cap = float(os.environ.get('MN_SPLIT_MB', '13.0')) * 1e6; zs = {f: zipped_size(f) for f in picked}
    big = sorted((f for f in picked if zs[f] > 2e6), key=lambda f: -zs[f]); small = [f for f in picked if zs[f] <= 2e6]; bins = []
    for f in big:
        for b in bins:
            if sum(zs[x] for x in b) + zs[f] <= cap: b.append(f); break
        else: bins.append([f])
    if small:
        last = [b for b in bins if sum(zs[x] for x in b) + sum(zs[x] for x in small) <= cap]
        if last: bins.remove(last[-1]); bins.append(last[-1] + small)       # room in one of them: it becomes the last archive
        else: bins.append(small)
    zips = [(zbase + '_%d.zip' % (i + 1), sorted(b)) for i, b in enumerate(bins)] if len(bins) > 1 else [(zpath, picked)]
else: zips = [(zpath, picked)]
part = {}
for zi, (zp, fl) in enumerate(zips):
    with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in fl: z.write(os.path.join(OUT, f), f); part[f] = ' -> %s' % os.path.basename(zp) if len(zips) > 1 else ''
shutil.rmtree(TMP, ignore_errors=True)
tot = 0
for f in names:
    n = os.path.getsize(os.path.join(OUT, f)); tot += n; print('%-22s %8.1f KB  %s%s' % (f, n / 1024, {'same': 'already on GitHub: not in the zip', 'changed': 'CHANGED', 'new': 'NEW'}.get(state[f], ''), part.get(f, '')))
print('%d files, %.1f MB; %s' % (len(names), tot / 1048576, '; '.join('%s: %d files, %.1f MB (%d bytes)' % (os.path.basename(zp), len(fl), os.path.getsize(zp) / 1048576, os.path.getsize(zp)) for zp, fl in zips)))
print('repo :', REPO_URL); print('pages:', PAGES)
print('online.json:', API_URL or '(empty: the records stay on the device)', '| support page:', DONATE_URL or '(none)', '| version %d (%s)' % (APP_VER, APK_VER))
if os.environ.get('MN_ZIP_ONLY') == '1': shutil.rmtree(OUT)
