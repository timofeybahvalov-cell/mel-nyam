#!/bin/bash
# «Мел-Ням» — builds both targets from the same C sources:
#     MelNyam.exe    Windows x64, one file, no DLLs / no installer   (mingw-w64)
#     MelNyam.html   WebAssembly, one self-contained page            (clang + wasi-libc)
#
#   ./build.sh            build both (assets are rebuilt only if gen/pack.bin is missing)
#   ./build.sh assets     rebuild gen/pack.bin first (needs python3 + PIL + numpy + ffmpeg)
#   ./build.sh test       also run the headless self-tests (all 60 levels are solved by their stored solution; all 60 TAS runs fit)
#
# Debian/Ubuntu packages: gcc-mingw-w64-x86-64-win32 clang lld wasi-libc libclang-rt-19-dev-wasm32 [binaryen] [ffmpeg]
set -e
cd "$(dirname "$0")"
CFLAGS="-O2 -ffp-contract=off -DNDEBUG -Isrc -Wall -Wno-misleading-indentation -Wno-unused-function"
GAME="src/game.c src/engine.c src/sim.c src/tas.c"

if [ "$1" = "assets" ] || [ ! -f gen/pack.bin ]; then python3 tools/make_assets.py; fi

if [ "$1" = "test" ]; then
  gcc $CFLAGS tools/headless.c $GAME -lm -o /tmp/melnyam_headless
  /tmp/melnyam_headless gen/pack.bin /tmp demotest | tail -1
  /tmp/melnyam_headless gen/pack.bin /tmp tastest | tail -1
fi

echo "== Windows"
x86_64-w64-mingw32-windres src/res.rc -O coff -o gen/res.o
x86_64-w64-mingw32-gcc $CFLAGS -mwindows -static -s -o MelNyam.exe src/plat_win32.c $GAME gen/res.o -lgdi32 -lwinmm -lwininet
rm -f gen/res.o
ls -l MelNyam.exe | awk '{printf "MelNyam.exe: %.2f MB\n", $5/1048576}'

echo "== Web"
clang --target=wasm32-wasi -mexec-model=reactor -DPIX_RGBA $CFLAGS -Wl,-z,stack-size=1048576 -Wl,--strip-all -o gen/game.wasm src/plat_web.c $GAME
if command -v wasm2js >/dev/null; then wasm2js gen/game.wasm -O2 -o gen/game_js.mjs; else rm -f gen/game_js.mjs; echo "(wasm2js not found: building without the plain-JS fallback)"; fi
python3 tools/pack_html.py MelNyam.html
