/* ============================================================================
   «МЕЛ-НЯМ» — the game itself: screens, level rendering, Mel's reactions, UI.
   Platform independent; runs on MEL-ENGINE (engine.c) and the simulation (sim.c).
   ============================================================================ */
#include "engine.h"
#include "sim.h"
#include "levels.h"
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define BOXES 3
#define PER_BOX 6
#define MEL_SC 1.2f          /* scale of Mel's sticker in a level                               */
#define FACE_U 17.0f         /* sprite units: the mouth is this much below the face centre       */
#define DESK_U 48.0f         /* sprite units: desk top (back edge) below the face centre         */
#define FACE_UP (FACE_U * MEL_SC)
#define DESK_DROP (DESK_U * MEL_SC)

/* ---------------- palette ---------------- */
#define C_PANEL1 0x3A2A8CFFu
#define C_PANEL2 0x1E1456FFu
#define C_EDGE   0x9D7BFFFFu
#define C_GOLD   0xFFD23FFFu
#define C_PINK   0xFF4FB8FFu
#define C_CYAN   0x46E6FFFFu
#define C_GREEN1 0x8CF04EFFu
#define C_GREEN2 0x2FAE3AFFu
#define C_BLUE1  0x5CC3FFFFu
#define C_BLUE2  0x2B6FE8FFu
#define C_VIO1   0xA98BFFFFu
#define C_VIO2   0x6038D8FFu
#define C_RED1   0xFF8B7AFFu
#define C_RED2   0xD9363EFFu
#define C_ORG1   0xFFC65AFFu
#define C_ORG2   0xF07E1EFFu
#define C_INK    0x241650FFu

/* ---------------- assets ---------------- */
static Image *I_bottle, *I_desk, *I_deskbig, *I_blower, *I_star, *I_star0, *I_glow, *I_wglow, *I_spark, *I_dot, *I_pin, *I_bubble, *I_logo;
static Image *I_bg[BOXES], *I_cover[BOXES];
static Font F_ui, F_txt;
enum { S_CUT, S_ATTACH, S_STAR1, S_STAR2, S_STAR3, S_BUBBLE, S_POP, S_BLOW, S_CLICK, S_TICK, S_WHOOSH, S_WIN, S_FAIL, S_BREAK, S_GULP, S_START, S_MUSIC,
       V_AM, V_AM1, V_HELLO, V_BRAVO, V_OMG, V_OBIDNO, V_POSIDIM, V_LAUGH, V_UUU, V_STOP, V_SCREAM, S_COUNT };
static const char *const snd_names[S_COUNT] = { "s_cut", "s_attach", "s_star1", "s_star2", "s_star3", "s_bubble", "s_pop", "s_blow", "s_click", "s_tick", "s_whoosh",
    "s_win", "s_fail", "s_break", "s_gulp", "s_start", "music",
    "v_am", "v_am1", "v_hello", "v_bravo", "v_omg", "v_obidno", "v_posidim", "v_laugh", "v_uuu", "v_stop", "v_scream" };
static Sound *SND[S_COUNT];
enum { CL_IDLE, CL_SMILE, CL_OMG, CL_AM, CL_SAD, CL_BORED, CL_LAUGH, CL_N };
static const char *const clip_names[CL_N] = { "clip_idle", "clip_smile", "clip_omg", "clip_am", "clip_sad", "clip_bored", "clip_laugh" };
static Clip CLP[CL_N];

static const char *const box_name[BOXES] = { "Стримерская", "Пентхаус", "Вилла" };
static const char *const box_sub[BOXES] = { "Верёвки и липучки", "Пузыри и шипы", "Груши-воздуходуйки" };
static const int box_need[BOXES] = { 0, 8, 20 };
static const u32 box_c1[BOXES] = { C_VIO1, C_BLUE1, C_ORG1 }, box_c2[BOXES] = { C_VIO2, C_BLUE2, C_ORG2 };

/* ---------------- global state ---------------- */
enum { SC_MENU, SC_BOXES, SC_LEVELS, SC_PLAY, SC_FINAL };
static int scr = SC_MENU, scr_next = -1, scr_arg, scr_arg2;
static float g_fade = 1.0f, g_time, g_dt;
static int sel_box;
static int hello_done;
static float shake_t, shake_amp, flash_t;

static struct { float x, y, downx, downy, upx, upy; int down, pressed, released, active, moved, game, tapped; } P;
static float B_anim[96];
static int ui_block;

/* ---------------- save ---------------- */
#define SAVE_MAGIC 0x324E4C4Du
typedef struct { u32 magic; u8 best[32]; u8 sound, music, r0, r1; } SaveData;
static SaveData SV;
static void save_store(void) { plat_save(&SV, (int)sizeof(SV)); }
static void save_load(void) {
    SaveData t; memset(&SV, 0, sizeof(SV)); SV.magic = SAVE_MAGIC; SV.sound = 1; SV.music = 1;
    if (plat_load(&t, (int)sizeof(t)) == (int)sizeof(t) && t.magic == SAVE_MAGIC) SV = t;
}
static int lvl_done(int i) { return SV.best[i] > 0; }
static int lvl_stars(int i) { return SV.best[i] ? SV.best[i] - 1 : 0; }
static int box_stars(int b) { int n = 0; for (int i = 0; i < PER_BOX; i++) n += lvl_stars(b * PER_BOX + i); return n; }
static int total_stars(void) { int n = 0; for (int i = 0; i < LEVEL_COUNT; i++) n += lvl_stars(i); return n; }
static int box_open(int b) { return total_stars() >= box_need[b]; }
static int lvl_open(int i) { if (!box_open(i / PER_BOX)) return 0; return (i % PER_BOX) == 0 || lvl_done(i - 1); }
static void apply_volumes(void) { snd_volumes(SV.sound ? 1.0f : 0.0f, SV.music ? 0.5f : 0.0f); }

/* ---------------- sound helpers ---------------- */
static void sfx_p(int id, float vol, float x, float pitch) { snd_play(SND[id], vol, clampf((x - 640.0f) / 900.0f, -0.7f, 0.7f), pitch); }
static void sfx(int id, float vol, float x) { sfx_p(id, vol, x, rnd_range(0.97f, 1.03f)); }

/* ============================== Mel ============================== */
typedef struct {
    int clip, loop; float t, pop, dy, react;
    float am_cool; int am_count; float idle_t, voice_t;
    char say[120]; float say_t, say_dur, say_size; int say_side; float say_ox, say_oy;
} MelState;
static MelState M;
static Sim S;

static float clip_len(int c) { return CLP[c].n / CLP[c].fps; }
static void mel_set(int clip, int loop) {
    if (M.clip == clip && M.loop == loop && loop) return;
    M.clip = clip; M.loop = loop; M.t = 0; M.pop = 1; M.react = 0;
}
static void mel_react(int clip, float hold) { mel_set(clip, 0); M.t = 0; M.react = clip_len(clip) + hold; }
static int mel_frame(void) {
    const Clip *c = &CLP[M.clip]; int n = c->n, f = (int)(M.t * c->fps);
    if (n <= 1) return 0;
    if (M.loop) { int per = 2 * (n - 1); f %= per; return f < n ? f : per - f; }      /* ping-pong: no jump at the loop point */
    return f >= n ? n - 1 : f;
}
static void mel_update(float dt) {
    M.t += dt; if (M.pop > 0) M.pop = maxf(0, M.pop - dt * 5.0f);
    if (M.voice_t > 0) M.voice_t -= dt;
    if (M.say_t > 0) M.say_t -= dt;
    if (M.am_cool > 0) M.am_cool -= dt;
    if (M.react > 0) { M.react -= dt; if (M.react <= 0) mel_set(CL_IDLE, 1); }
    float want = maxf(0, DESK_U + 4.0f - CLP[M.clip].avail);
    M.dy += (want - M.dy) * minf(1.0f, dt * 14.0f);
}
static void draw_mel(float fx, float fy, float sc, float alpha) {
    const Image *im = clip_frame(&CLP[M.clip], mel_frame());
    float p = M.pop > 0 ? 1.0f + 0.09f * sinf(M.pop * PI) : 1.0f;
    gfx_image_ex(im, fx, fy + M.dy * sc, sc * p, sc * p, 0, alpha);
}
/* speech */
static void bubble_place(void);
static void say_text(const char *txt, float dur, float size) {
    strncpy(M.say, txt, sizeof(M.say) - 1); M.say[sizeof(M.say) - 1] = 0; M.say_t = M.say_dur = dur; M.say_size = size;
    if (scr == SC_PLAY) bubble_place();
}
static void say(int vid, const char *txt) {
    const Sound *s = SND[vid]; float d = s ? (float)s->n / (float)s->rate : 1.0f;
    snd_play_voice(s, 1.0f); M.voice_t = d;
    if (txt) say_text(txt, maxf(d + 0.3f, 1.3f), 27.0f);
}

/* ============================== particles ============================== */
enum { PT_DOT, PT_SPARK, PT_STAR, PT_SHARD, PT_RING, PT_PUFF, PT_CONF, PT_DROP };
typedef struct { float x, y, vx, vy, rot, vr, life, max, size, grav, drag; u32 col; int kind; } Part;
#define MAXP 420
static Part parts[MAXP]; static int nparts;
static Part *part_new(int kind, float x, float y, float vx, float vy, float life, float size, u32 col) {
    Part *p = &parts[nparts < MAXP ? nparts++ : (int)(rnd_u32() % MAXP)];
    p->kind = kind; p->x = x; p->y = y; p->vx = vx; p->vy = vy; p->life = p->max = life; p->size = size; p->col = col;
    p->rot = rnd_range(0, TAU); p->vr = rnd_range(-6, 6); p->grav = 0; p->drag = 0;
    return p;
}
static void parts_update(float dt) {
    for (int i = 0; i < nparts; i++) {
        Part *p = &parts[i]; p->life -= dt;
        if (p->life <= 0) { parts[i] = parts[--nparts]; i--; continue; }
        float k = 1.0f - p->drag * dt; if (k < 0) k = 0;
        p->vx *= k; p->vy = p->vy * k + p->grav * dt; p->x += p->vx * dt; p->y += p->vy * dt; p->rot += p->vr * dt;
    }
}
static void parts_draw(void) {
    for (int i = 0; i < nparts; i++) {
        const Part *p = &parts[i]; float f = p->life / p->max, a = f < 0.4f ? f / 0.4f : 1.0f;
        switch (p->kind) {
        case PT_DOT: { float s = p->size / 16.0f * (0.4f + 0.6f * f); gfx_image_tint(I_dot, p->x, p->y, s, s, 0, color_alpha(p->col, a), 0); } break;
        case PT_SPARK: { float s = p->size / 48.0f * (0.3f + 0.7f * f); gfx_image_tint(I_spark, p->x, p->y, s, s, p->rot, color_alpha(p->col, a), 1); } break;
        case PT_STAR: { float s = p->size / 60.0f * (0.5f + 0.5f * f); gfx_image_ex(I_star, p->x, p->y, s, s, p->rot, a); } break;
        case PT_SHARD: {
            float s = p->size, c = cosf(p->rot), n = sinf(p->rot); u32 col = color_alpha(p->col, a);
            gfx_tri(p->x + c * s, p->y + n * s, p->x - c * s * 0.6f - n * s * 0.5f, p->y - n * s * 0.6f + c * s * 0.5f,
                    p->x - c * s * 0.4f + n * s * 0.7f, p->y - n * s * 0.4f - c * s * 0.7f, col);
        } break;
        case PT_RING: { float e = ease_out_cubic(1.0f - f); gfx_ring(p->x, p->y, p->size * (0.4f + 1.4f * e), 5.0f * f + 1.0f, color_alpha(p->col, f)); } break;
        case PT_PUFF: { float s = p->size / 75.0f * (0.6f + 1.2f * (1.0f - f)); gfx_image_tint(I_wglow, p->x, p->y, s, s, 0, color_alpha(p->col, f * 0.8f), 0); } break;
        case PT_CONF: {
            float w = p->size, h = p->size * 0.55f * fabsf(cosf(p->rot * 1.7f)) + 1.0f, c = cosf(p->rot), n = sinf(p->rot); u32 col = color_alpha(p->col, a);
            float ax = c * w, ay = n * w, bx = -n * h, by = c * h;
            gfx_tri(p->x - ax - bx, p->y - ay - by, p->x + ax - bx, p->y + ay - by, p->x + ax + bx, p->y + ay + by, col);
            gfx_tri(p->x - ax - bx, p->y - ay - by, p->x + ax + bx, p->y + ay + by, p->x - ax + bx, p->y - ay + by, col);
        } break;
        case PT_DROP: gfx_circle(p->x, p->y, p->size * (0.4f + 0.6f * f), color_alpha(p->col, a)); break;
        }
    }
}
static void fx_ring(float x, float y, float size, u32 col, float life) { part_new(PT_RING, x, y, 0, 0, life, size, col); }
static void fx_star(float x, float y) {
    fx_ring(x, y, 34, 0xFFF3A0FF, 0.45f);
    for (int i = 0; i < 12; i++) { float a = rnd_range(0, TAU), v = rnd_range(120, 380); Part *p = part_new(PT_SPARK, x, y, cosf(a) * v, sinf(a) * v, rnd_range(0.35f, 0.7f), rnd_range(26, 52), 0xFFE680FF); p->drag = 3.0f; }
    for (int i = 0; i < 5; i++) { float a = rnd_range(0, TAU), v = rnd_range(140, 300); Part *p = part_new(PT_STAR, x, y, cosf(a) * v, sinf(a) * v - 80, rnd_range(0.5f, 0.8f), rnd_range(14, 22), WHITE); p->grav = 500; p->drag = 1.5f; }
}
static void fx_cut(float x, float y) {
    part_new(PT_SPARK, x, y, 0, 0, 0.18f, 70, WHITE)->vr = 0;
    for (int i = 0; i < 7; i++) { float a = rnd_range(0, TAU), v = rnd_range(60, 220); Part *p = part_new(PT_DOT, x, y, cosf(a) * v, sinf(a) * v - 40, rnd_range(0.3f, 0.55f), rnd_range(7, 12), (i & 1) ? 0xF3D49BFF : 0xC98F4EFF); p->grav = 700; p->drag = 1.0f; }
}
static void fx_pop(float x, float y) {
    fx_ring(x, y, 44, 0xD8F6FFFF, 0.3f);
    for (int i = 0; i < 14; i++) { float a = i * TAU / 14 + rnd_range(-0.15f, 0.15f), v = rnd_range(160, 300); Part *p = part_new(PT_DROP, x + cosf(a) * 38, y + sinf(a) * 38, cosf(a) * v, sinf(a) * v, rnd_range(0.25f, 0.45f), rnd_range(3, 6), 0xCFF3FFFF); p->grav = 600; p->drag = 2.0f; }
}
static void fx_blow(const Blower *b) {
    for (int i = 0; i < 9; i++) {
        float sp = rnd_range(-0.22f, 0.22f), c = cosf(b->ang + sp), s = sinf(b->ang + sp), v = rnd_range(260, 620);
        Part *p = part_new(PT_PUFF, b->x + b->dx * 62, b->y + b->dy * 62, c * v, s * v, rnd_range(0.35f, 0.6f), rnd_range(22, 40), 0xFFFFFFFF); p->drag = 2.4f;
    }
}
static void fx_break(float x, float y) {
    static const u32 cols[5] = { 0xCDEFFFFF, 0x9ED9F5FF, 0xFFFFFFFF, 0x7FC3E8FF, 0xD9363EFF };
    fx_ring(x, y, 40, WHITE, 0.3f);
    for (int i = 0; i < 20; i++) { float a = rnd_range(0, TAU), v = rnd_range(120, 480); Part *p = part_new(PT_SHARD, x, y, cosf(a) * v, sinf(a) * v - 120, rnd_range(0.6f, 1.1f), rnd_range(6, 14), cols[i % 5]); p->grav = 1100; p->drag = 0.6f; p->vr = rnd_range(-12, 12); }
    for (int i = 0; i < 10; i++) { float a = rnd_range(0, TAU), v = rnd_range(100, 300); Part *p = part_new(PT_DROP, x, y, cosf(a) * v, sinf(a) * v - 60, rnd_range(0.4f, 0.7f), rnd_range(3, 6), 0xDFF6FFFF); p->grav = 900; }
    shake_t = 0.35f; shake_amp = 9; flash_t = 0.12f;
}
static void fx_eat(float x, float y) {
    fx_ring(x, y, 30, 0xFFFFFFFF, 0.35f);
    for (int i = 0; i < 10; i++) { float a = rnd_range(-PI, 0), v = rnd_range(120, 320); Part *p = part_new(PT_SPARK, x, y, cosf(a) * v, sinf(a) * v, rnd_range(0.35f, 0.6f), rnd_range(24, 44), (i & 1) ? 0xBFF6FFFF : 0xFFFFFFFF); p->drag = 2.5f; }
    for (int i = 0; i < 8; i++) { float a = rnd_range(-PI, 0), v = rnd_range(120, 300); Part *p = part_new(PT_DROP, x, y, cosf(a) * v, sinf(a) * v, rnd_range(0.35f, 0.6f), rnd_range(3, 5), 0xCFF3FFFF); p->grav = 900; }
}
static void fx_confetti(float x0, float x1, float y, int n) {
    static const u32 cols[6] = { C_GOLD, C_PINK, C_CYAN, C_GREEN1, 0xFFFFFFFF, C_VIO1 };
    for (int i = 0; i < n; i++) { Part *p = part_new(PT_CONF, rnd_range(x0, x1), y + rnd_range(-20, 20), rnd_range(-160, 160), rnd_range(-420, -60), rnd_range(1.6f, 2.8f), rnd_range(5, 9), cols[rnd_u32() % 6]); p->grav = 520; p->drag = 1.1f; p->vr = rnd_range(-7, 7); }
}

/* ============================== small drawing helpers ============================== */
static void arc(float cx, float cy, float r, float a0, float a1, float th, u32 col) {
    int n = (int)(fabsf(a1 - a0) * r / 4.0f) + 2; if (n > 64) n = 64;
    float px = cx + cosf(a0) * r, py = cy + sinf(a0) * r;
    for (int i = 1; i <= n; i++) { float a = a0 + (a1 - a0) * (float)i / (float)n, x = cx + cosf(a) * r, y = cy + sinf(a) * r; gfx_capsule(px, py, x, y, th * 0.5f, col); px = x; py = y; }
}
static void dashed_circle(float cx, float cy, float r, float ph, float th, u32 col) {
    int n = (int)(TAU * r / 30.0f); if (n < 8) n = 8;
    for (int i = 0; i < n; i++) {
        float a0 = ph + i * TAU / n, a1 = a0 + TAU / n * 0.5f;
        gfx_capsule(cx + cosf(a0) * r, cy + sinf(a0) * r, cx + cosf(a1) * r, cy + sinf(a1) * r, th * 0.5f, col);
    }
}
enum { IC_NONE, IC_PLAY, IC_PAUSE, IC_RESTART, IC_GRID, IC_BACK, IC_NEXT, IC_SOUND, IC_SOUND_OFF, IC_MUSIC, IC_MUSIC_OFF, IC_FULL, IC_EXIT, IC_HINT, IC_LOCK, IC_HOME };
static void icon(int ic, float x, float y, float s, u32 c) {
    float t = s * 0.17f;
    switch (ic) {
    case IC_PLAY: gfx_tri(x - s * 0.38f, y - s * 0.58f, x - s * 0.38f, y + s * 0.58f, x + s * 0.62f, y, c); break;
    case IC_PAUSE: gfx_capsule(x - s * 0.3f, y - s * 0.42f, x - s * 0.3f, y + s * 0.42f, t, c); gfx_capsule(x + s * 0.3f, y - s * 0.42f, x + s * 0.3f, y + s * 0.42f, t, c); break;
    case IC_RESTART: {
        float r = s * 0.52f, a1 = 300.0f * PI / 180.0f; arc(x, y, r, 25.0f * PI / 180.0f, a1, t * 1.7f, c);
        float px = x + cosf(a1) * r, py = y + sinf(a1) * r, tx = -sinf(a1), ty = cosf(a1), rx = cosf(a1), ry = sinf(a1), h = s * 0.42f, w = s * 0.34f;
        gfx_tri(px + tx * h, py + ty * h, px + rx * w, py + ry * w, px - rx * w, py - ry * w, c);
    } break;
    case IC_GRID: for (int i = 0; i < 4; i++) { float ox = (i & 1) ? s * 0.08f : -s * 0.52f, oy = (i & 2) ? s * 0.08f : -s * 0.52f; gfx_rrect(x + ox, y + oy, s * 0.44f, s * 0.44f, s * 0.11f, c); } break;
    case IC_BACK: gfx_capsule(x + s * 0.2f, y - s * 0.48f, x - s * 0.3f, y, t, c); gfx_capsule(x - s * 0.3f, y, x + s * 0.2f, y + s * 0.48f, t, c); break;
    case IC_NEXT: gfx_capsule(x - s * 0.2f, y - s * 0.48f, x + s * 0.3f, y, t, c); gfx_capsule(x + s * 0.3f, y, x - s * 0.2f, y + s * 0.48f, t, c); break;
    case IC_SOUND: case IC_SOUND_OFF:
        gfx_rrect(x - s * 0.62f, y - s * 0.2f, s * 0.36f, s * 0.4f, s * 0.07f, c);
        gfx_tri(x - s * 0.42f, y, x - s * 0.02f, y - s * 0.52f, x - s * 0.02f, y + s * 0.52f, c);
        if (ic == IC_SOUND) { arc(x + s * 0.02f, y, s * 0.3f, -0.8f, 0.8f, t * 1.3f, c); arc(x + s * 0.02f, y, s * 0.58f, -0.8f, 0.8f, t * 1.3f, c); }
        else { gfx_capsule(x + s * 0.2f, y - s * 0.22f, x + s * 0.62f, y + s * 0.22f, t * 0.75f, c); gfx_capsule(x + s * 0.62f, y - s * 0.22f, x + s * 0.2f, y + s * 0.22f, t * 0.75f, c); }
        break;
    case IC_MUSIC: case IC_MUSIC_OFF:
        gfx_circle(x - s * 0.3f, y + s * 0.4f, s * 0.2f, c); gfx_circle(x + s * 0.32f, y + s * 0.26f, s * 0.2f, c);
        gfx_capsule(x - s * 0.14f, y + s * 0.4f, x - s * 0.14f, y - s * 0.4f, t * 0.6f, c); gfx_capsule(x + s * 0.48f, y + s * 0.26f, x + s * 0.48f, y - s * 0.54f, t * 0.6f, c);
        gfx_capsule(x - s * 0.14f, y - s * 0.4f, x + s * 0.48f, y - s * 0.54f, t * 0.9f, c);
        if (ic == IC_MUSIC_OFF) gfx_capsule(x - s * 0.6f, y - s * 0.6f, x + s * 0.6f, y + s * 0.6f, t * 0.8f, C_RED1);
        break;
    case IC_FULL: for (int i = 0; i < 4; i++) {
            float sx = (i & 1) ? 1.0f : -1.0f, sy = (i & 2) ? 1.0f : -1.0f, cx = x + sx * s * 0.5f, cy = y + sy * s * 0.5f;
            gfx_capsule(cx, cy, cx - sx * s * 0.32f, cy, t * 0.75f, c); gfx_capsule(cx, cy, cx, cy - sy * s * 0.32f, t * 0.75f, c);
        } break;
    case IC_EXIT: gfx_capsule(x - s * 0.4f, y - s * 0.4f, x + s * 0.4f, y + s * 0.4f, t, c); gfx_capsule(x + s * 0.4f, y - s * 0.4f, x - s * 0.4f, y + s * 0.4f, t, c); break;
    case IC_HINT: gfx_text(&F_ui, "?", x, y, s * 1.5f, c, AL_CENTER); break;
    case IC_LOCK:
        arc(x, y - s * 0.12f, s * 0.3f, PI, TAU, t * 1.1f, c);
        gfx_rrect(x - s * 0.5f, y - s * 0.1f, s, s * 0.72f, s * 0.14f, c);
        gfx_circle(x, y + s * 0.2f, s * 0.11f, 0x00000070);
        break;
    case IC_HOME:
        gfx_tri(x - s * 0.62f, y - s * 0.02f, x, y - s * 0.62f, x + s * 0.62f, y - s * 0.02f, c);
        gfx_rrect(x - s * 0.42f, y - s * 0.06f, s * 0.84f, s * 0.6f, s * 0.08f, c);
        break;
    }
}
static int in_box(float px, float py, float x, float y, float w, float h) { return px >= x - w * 0.5f && px <= x + w * 0.5f && py >= y - h * 0.5f && py <= y + h * 0.5f; }
/* Buttons are evaluated once per frame, but a press and its release may both arrive between two frames
   (touch, trackpad taps) and the pointer may have moved on since: test the recorded press/release points. */
static int btn_logic(int id, float x, float y, float w, float h, int enabled) {
    int ok = enabled && !ui_block, inside = ok && in_box(P.x, P.y, x, y, w, h);
    if (ok && P.pressed && in_box(P.downx, P.downy, x, y, w, h)) P.active = id;
    float target = (inside && P.down && P.active == id) ? -1.0f : (inside ? 1.0f : 0.0f);
    B_anim[id] += (target - B_anim[id]) * minf(1.0f, g_dt * 20.0f);
    if (ok && P.released && P.active == id && in_box(P.upx, P.upy, x, y, w, h)) { P.active = 0; P.released = 0; sfx(S_CLICK, 0.7f, x); return 1; }
    return 0;
}
static int wbtn(int id, float x, float y, float w, float h, const char *label, u32 c0, u32 c1, float tsize, int ic, int enabled) {
    int click = btn_logic(id, x, y, w, h, enabled);
    float a = B_anim[id], s = 1.0f + 0.045f * maxf(a, 0), press = a < 0 ? -a : 0;
    float W = w * s, H = h * s, X = x - W * 0.5f, Y = y - H * 0.5f + press * 4.0f, rad = H * 0.38f;
    if (!enabled) { c0 = 0x8C88A8FFu; c1 = 0x5C5878FFu; }
    gfx_rrect(X - 2, y - H * 0.5f + 9, W + 4, H, rad, 0x00000048);
    gfx_rrect(X, y - H * 0.5f + 6, W, H, rad, color_lerp(c1, 0x000000FF, 0.45f));
    gfx_rrect_grad(X, Y, W, H, rad, c0, c1);
    gfx_rrect(X + 7, Y + 5, W - 14, H * 0.40f, H * 0.22f, 0xFFFFFF34);
    float tx = x, ty = Y + H * 0.5f - 1;
    if (ic) { float tw = gfx_text_w(&F_ui, label, tsize * s), is = tsize * s * 0.48f; tx = x + is * 0.8f; icon(ic, tx - tw * 0.5f - is * 1.25f, ty, is, WHITE); }
    gfx_text(&F_ui, label, tx, ty, tsize * s, enabled ? WHITE : 0xFFFFFFA0u, AL_CENTER);
    return click;
}
static int rbtn(int id, float x, float y, float r, int ic, u32 c0, u32 c1, int enabled) {
    int click = btn_logic(id, x, y, r * 2, r * 2, enabled);
    float a = B_anim[id], s = 1.0f + 0.07f * maxf(a, 0), press = a < 0 ? -a : 0, R = r * s, Y = y + press * 3.0f;
    if (!enabled) { c0 = 0x8C88A8FFu; c1 = 0x5C5878FFu; }
    gfx_circle(x, y + 7, R + 1, 0x00000048);
    gfx_circle(x, y + 4.5f, R, color_lerp(c1, 0x000000FF, 0.45f));
    gfx_rrect_grad(x - R, Y - R, R * 2, R * 2, R, c0, c1);
    gfx_rrect(x - R * 0.62f, Y - R * 0.86f, R * 1.24f, R * 0.7f, R * 0.35f, 0xFFFFFF30);
    icon(ic, x + 1.5f, Y + 2.0f, R * 0.74f, 0x00000050); icon(ic, x, Y, R * 0.74f, WHITE);
    return click;
}
static void panel(float x, float y, float w, float h) {
    gfx_rrect(x - 4, y + 6, w + 8, h + 8, 36, 0x00000060);
    gfx_rrect(x, y, w, h, 34, C_EDGE);
    gfx_rrect_grad(x + 5, y + 5, w - 10, h - 10, 29, C_PANEL1, C_PANEL2);
    gfx_rrect(x + 14, y + 12, w - 28, 26, 13, 0xFFFFFF14);
}
static void star_icon(float x, float y, float size, int full, float alpha) { float s = size / 60.0f; gfx_image_ex(full ? I_star : I_star0, x, y, s, s, 0, alpha); }

/* background (cover-scaled once into a cache at framebuffer resolution) */
/* Big static glows are baked into the cache too: full-screen additive sprites are the most
   expensive thing a software renderer can do every frame. */
enum { DECO_NONE, DECO_MENU, DECO_LEVEL };
static Image *bgc; static u32 bgc_key;
static Image *snap; static int snap_ok;
static void bg_draw(int which, float darken, int deco, int arg, float sx, float sy) {
    u32 key = 1u + (u32)which * 1000003u + (u32)(darken * 100.0f) * 7919u + (u32)deco * 104729u + (u32)arg * 613u;
    int w = gfx_fb_w(), h = gfx_fb_h();
    if (!bgc || bgc->w != w || bgc->h != h) { if (bgc) img_free(bgc); bgc = img_new(w, h, 1); bgc_key = 0; }
    if (bgc_key != key) {
        gfx_set_target(bgc); gfx_offset(0, 0); gfx_cover(I_bg[which], darken);
        if (deco == DECO_MENU) gfx_image_tint(I_wglow, (float)arg, 318, 6.0f, 5.0f, 0, RGBA(150, 110, 255, 80), 1);
        else if (deco == DECO_LEVEL && S.has_mel) gfx_image_tint(I_wglow, S.mx, S.my - FACE_UP + 6, 2.9f, 2.4f, 0, RGBA(170, 150, 255, 46), 1);
        gfx_set_target(NULL); bgc_key = key;
    }
    gfx_offset(sx, sy); gfx_copy_from(bgc);
}
static void snap_take(void) {
    int w = gfx_fb_w(), h = gfx_fb_h();
    if (!snap || snap->w != w || snap->h != h) { if (snap) img_free(snap); snap = img_new(w, h, 1); }
    gfx_grab(snap); snap_ok = 1;
}
static int snap_usable(void) { return snap_ok && snap && snap->w == gfx_fb_w() && snap->h == gfx_fb_h(); }

/* ============================== level state ============================== */
enum { PH_PLAY, PH_WIN, PH_FAIL };
static int L_idx, L_demo, L_phase, L_paused, L_acted, L_newbest, L_shown, L_react_done, L_conf;
static int L_ghost;                                 /* capture aid: the stored solution plays, everything else is a normal run */
static int g_capflags;                              /* capture aid: 1 hide the HUD, 2 hide speech bubbles, 4 bare menu */
static int L_demo_done[40], star_seen[MAX_STARS], L_got;
static float L_acc, L_t, L_pt, hud_pop[3], L_toast_t; static const char *L_toast = "";
typedef struct { float x0, y0, x1, y1, t; int slot, on; } Fly;
static Fly fly[3];
typedef struct { float x, y, t; } TPt;
#define TRAIL_N 40
static TPt trail[TRAIL_N]; static int trail_n;
typedef struct { float x0, y0, x1, y1, t; } Slash;
static Slash slash[6];
static float tapfx_x, tapfx_y, tapfx_t;

static const float hud_sx[3] = { 44, 98, 152 }; static const float hud_sy = 42;
#define HUD_RX 1158.0f
#define HUD_PX 1228.0f
#define HUD_BY 46.0f
#define HUD_BR 28.0f
static int hud_hit(float x, float y) {
    float d0 = hypotf(x - HUD_RX, y - HUD_BY), d1 = hypotf(x - HUD_PX, y - HUD_BY);
    return d0 < HUD_BR + 8 || d1 < HUD_BR + 8;
}
static void trail_add(float x, float y) {
    if (trail_n == TRAIL_N) { memmove(trail, trail + 1, sizeof(TPt) * (TRAIL_N - 1)); trail_n--; }
    trail[trail_n].x = x; trail[trail_n].y = y; trail[trail_n].t = g_time; trail_n++;
}
static void slash_add(float x0, float y0, float x1, float y1) {
    int k = 0; for (int i = 0; i < 6; i++) if (slash[i].t <= 0) { k = i; break; }
    slash[k].x0 = x0; slash[k].y0 = y0; slash[k].x1 = x1; slash[k].y1 = y1; slash[k].t = 0.3f;
}
static void level_start(int idx, int demo) {
    L_idx = idx; L_demo = (demo == 1); L_ghost = (demo == 2); sel_box = g_levels[idx].box;
    sim_load(&S, g_levels[idx].objs);
    L_acc = 0; L_t = 0; L_pt = 0; L_phase = PH_PLAY; L_paused = 0; L_acted = 0; L_newbest = 0; L_shown = 0; L_react_done = 0; L_conf = 0; L_got = 0;
    memset(L_demo_done, 0, sizeof(L_demo_done)); memset(star_seen, 0, sizeof(star_seen)); memset(fly, 0, sizeof(fly)); memset(slash, 0, sizeof(slash));
    memset(hud_pop, 0, sizeof(hud_pop));
    nparts = 0; trail_n = 0; tapfx_t = 0; shake_t = 0; flash_t = 0; L_toast_t = 0; snap_ok = 0;
    M.say_t = 0; M.am_count = 0; M.am_cool = 0; M.idle_t = 0; M.dy = 0; mel_set(CL_IDLE, 1); M.t = rnd_range(0, 2);
    P.game = 0;
    if (demo) { L_toast_t = 0; }
    else if (g_levels[idx].hint && g_levels[idx].hint[0] && !lvl_done(idx)) say_text(g_levels[idx].hint, 7.0f, 23.0f);
    sfx(S_START, 0.5f, 640);
}
static void acted(void) { L_acted = 1; M.idle_t = 0; if (M.say_t > 0.25f && M.say_size < 25.0f) M.say_t = 0.25f; }

static void on_events(void) {
    u32 ev = S.events; S.events = 0; if (!ev) return;
    if (ev & EV_CUT) { sfx(S_CUT, 0.85f, S.cut_x); fx_cut(S.cut_x, S.cut_y); acted(); }
    if (ev & EV_ATTACH) { sfx(S_ATTACH, 0.7f, S.ev_x); fx_ring(S.ev_x, S.ev_y, 30, 0xFFFFFFFF, 0.4f); }
    if (ev & EV_BUBBLE_IN) { sfx(S_BUBBLE, 0.8f, S.c.x); fx_ring(S.c.x, S.c.y, 40, 0xD8F6FFFF, 0.3f); }
    if (ev & EV_BUBBLE_POP) { sfx(S_POP, 0.9f, S.ev_x); fx_pop(S.ev_x, S.ev_y); acted(); }
    if (ev & EV_BLOW) { const Blower *b = &S.blower[S.ev_blower]; sfx(S_BLOW, 0.8f, b->x); fx_blow(b); acted(); }
    if (ev & EV_STAR) for (int i = 0; i < S.nstars; i++) if (S.star[i].got && !star_seen[i]) {
        star_seen[i] = 1; int k = L_got++; if (k > 2) k = 2;
        sfx_p(S_STAR1 + k, 0.8f, S.star[i].x, 1.0f); fx_star(S.star[i].x, S.star[i].y);
        fly[k].x0 = S.star[i].x; fly[k].y0 = S.star[i].y; fly[k].x1 = hud_sx[k]; fly[k].y1 = hud_sy; fly[k].t = 0; fly[k].on = 1; fly[k].slot = k;
        M.idle_t = 0;
        if (S.mouth_dist > MOUTH_NEAR + 40 && M.clip != CL_AM) {
            if (L_got == 3 && M.voice_t <= 0) { mel_react(CL_OMG, 0.2f); say(V_OMG, "О май гад!"); }
            else if (M.clip == CL_IDLE || M.clip == CL_BORED) mel_react(CL_SMILE, 0.0f);
        }
    }
    if (ev & EV_EAT) { sfx(S_GULP, 0.9f, S.mx); fx_eat(S.mx, S.my); L_phase = PH_WIN; L_pt = 0; if (M.clip != CL_AM) mel_set(CL_AM, 1); }
    if (ev & EV_BREAK) {
        sfx(S_BREAK, 0.9f, S.c.x); fx_break(S.c.x, S.c.y); L_phase = PH_FAIL; L_pt = 0; mel_set(CL_SAD, 1);
        if (rnd_u32() & 1) say(V_SCREAM, "А-А-А-А!"); else say(V_STOP, "Стоп-стоп-стоп!");
    }
    if (ev & EV_LOST) { sfx(S_FAIL, 0.7f, 640); L_phase = PH_FAIL; L_pt = 0; mel_set(CL_SAD, 1); say(V_OBIDNO, "Обидно, да..."); }
}

static int input_ok(void) { return scr == SC_PLAY && scr_next < 0 && L_phase == PH_PLAY && !L_paused && !L_demo && !L_ghost; }
static int click_cut(float x, float y) {
    float best = 22.0f, bqx = 0, bqy = 0; int br = -1, bj = 0;
    for (int i = 0; i < MAX_ROPES; i++) {
        const Rope *r = &S.rope[i]; if (!r->active || r->cut) continue;
        for (int j = 0; j < r->n - 1; j++) {
            float ax = r->p[j].x, ay = r->p[j].y, dx = r->p[j + 1].x - ax, dy = r->p[j + 1].y - ay, l2 = dx * dx + dy * dy;
            float t = l2 > 1e-6f ? ((x - ax) * dx + (y - ay) * dy) / l2 : 0.5f; t = clampf(t, 0.1f, 0.9f);
            float qx = ax + dx * t, qy = ay + dy * t, d = hypotf(x - qx, y - qy);
            if (d < best) { best = d; br = i; bj = j; bqx = qx; bqy = qy; }
        }
    }
    if (br < 0) return 0;
    const Rope *r = &S.rope[br]; float dx = r->p[bj + 1].x - r->p[bj].x, dy = r->p[bj + 1].y - r->p[bj].y, l = hypotf(dx, dy); if (l < 1e-4f) return 0;
    float nx = -dy / l, ny = dx / l;
    slash_add(bqx - nx * 34, bqy - ny * 34, bqx + nx * 34, bqy + ny * 34);
    return sim_cut(&S, bqx - nx * 12, bqy - ny * 12, bqx + nx * 12, bqy + ny * 12);
}
static void demo_fx(const Step *st) {
    if (st->act == ACT_CUT) {
        for (int i = 0; i < MAX_ROPES; i++) { const Rope *r = &S.rope[i];
            if (r->active && !r->cut && r->pin == st->arg) { int j = r->n / 2; if (j > r->n - 2) j = r->n - 2;
                float x = (r->p[j].x + r->p[j + 1].x) * 0.5f, y = (r->p[j].y + r->p[j + 1].y) * 0.5f, dx = r->p[j + 1].x - r->p[j].x, dy = r->p[j + 1].y - r->p[j].y, l = hypotf(dx, dy) + 1e-4f;
                slash_add(x + dy / l * 40, y - dx / l * 40, x - dy / l * 40, y + dx / l * 40); } }
    } else if (st->act == ACT_POP) { tapfx_x = S.c.x; tapfx_y = S.c.y; tapfx_t = 0.4f; }
    else if (st->act == ACT_BLOW && st->arg < S.nblowers) { tapfx_x = S.blower[st->arg].x; tapfx_y = S.blower[st->arg].y; tapfx_t = 0.4f; }
}

/* ---------- speech bubble placement ---------- */
static float bubble_w, bubble_h; static int bubble_lines;
static void bubble_measure(void) {
    float size = M.say_size, maxw = 300.0f, tw = gfx_text_w(&F_txt, M.say, size);
    bubble_lines = gfx_text_wrap(&F_txt, M.say, 0, 0, size, maxw, size * 1.25f, 0, AL_CENTER, 0);
    bubble_w = (bubble_lines > 1 ? maxw : tw) + 40.0f; bubble_h = bubble_lines * size * 1.25f + 26.0f;
}
static int rect_has(float cx, float cy, float w, float h, float px, float py, float m) { return px > cx - w * 0.5f - m && px < cx + w * 0.5f + m && py > cy - h * 0.5f - m && py < cy + h * 0.5f + m; }
static void bubble_place(void) {
    bubble_measure();
    float fx = S.mx, fy = S.my - FACE_UP, w = bubble_w, h = bubble_h;
    float cand[6][2] = { { 84 + w * 0.5f, -58 }, { -(84 + w * 0.5f), -58 }, { 46 + w * 0.5f, -(76 + h * 0.5f) }, { -(46 + w * 0.5f), -(76 + h * 0.5f) }, { 0, -(96 + h * 0.5f) }, { 104 + w * 0.5f, 10 } };
    int best = 0; float bs = 1e9f;
    for (int k = 0; k < 6; k++) {
        float cx = fx + cand[k][0], cy = fy + cand[k][1], sc = (float)k * 0.5f;
        if (cx - w * 0.5f < 10 || cx + w * 0.5f > DESIGN_W - 10 || cy - h * 0.5f < 10 || cy + h * 0.5f > DESIGN_H - 10) sc += 200;
        if ((cx - w * 0.5f < 245 && cy - h * 0.5f < 96) || (cx + w * 0.5f > 1100 && cy - h * 0.5f < 96)) sc += 60;
        if (rect_has(cx, cy, w, h, S.c.x, S.c.y, 40)) sc += 12;
        for (int i = 0; i < S.npins; i++) if (rect_has(cx, cy, w, h, S.pin[i].x, S.pin[i].y, 26)) sc += 10;
        for (int i = 0; i < S.nstars; i++) if (rect_has(cx, cy, w, h, S.star[i].x, S.star[i].y, 34)) sc += 14;
        for (int i = 0; i < S.nbubbles; i++) if (rect_has(cx, cy, w, h, S.bubble[i].x, S.bubble[i].y, 50)) sc += 10;
        for (int i = 0; i < S.nblowers; i++) if (rect_has(cx, cy, w, h, S.blower[i].x, S.blower[i].y, 60)) sc += 10;
        for (int i = 0; i < S.nspikes; i++) for (int q = 0; q <= 4; q++) if (rect_has(cx, cy, w, h, lerpf(S.spikes[i].x0, S.spikes[i].x1, q / 4.0f), lerpf(S.spikes[i].y0, S.spikes[i].y1, q / 4.0f), 22)) sc += 4;
        for (int i = 0; i < MAX_ROPES; i++) if (S.rope[i].active) for (int j = 0; j < S.rope[i].n; j += 3) if (rect_has(cx, cy, w, h, S.rope[i].p[j].x, S.rope[i].p[j].y, 8)) sc += 1.5f;
        if (sc < bs) { bs = sc; best = k; }
    }
    M.say_ox = cand[best][0]; M.say_oy = cand[best][1];
}
/* draws the speech bubble; (fx,fy) = face centre, bubble centre = face + (ox,oy)*k */
static void draw_say(float fx, float fy, float ox, float oy, float k) {
    if (M.say_t <= 0 || !M.say[0]) return;
    bubble_measure();
    float age = M.say_dur - M.say_t, a = clampf(M.say_t / 0.18f, 0, 1), sc = ease_out_back(clampf(age / 0.22f, 0, 1)) * (0.85f + 0.15f * a);
    if (sc <= 0.02f) return;
    float w = bubble_w * sc, h = bubble_h * sc, cx = fx + ox * k, cy = fy + oy * k, size = M.say_size * sc;
    float dx = cx - fx, dy = cy - fy, l = hypotf(dx, dy) + 1e-4f; dx /= l; dy /= l;
    float tx = fx + dx * 54.0f * k, ty = fy + dy * 54.0f * k;                       /* tail tip near the face */
    float bx = clampf(tx, cx - w * 0.5f + 20, cx + w * 0.5f - 20), by = clampf(ty, cy - h * 0.5f + 14, cy + h * 0.5f - 14);
    float ex = bx - tx, ey = by - ty, el = hypotf(ex, ey) + 1e-4f, nx = -ey / el, ny = ex / el;
    u32 ink = color_alpha(C_INK, a), wh = color_alpha(0xFFFFFFFF, a);
    gfx_rrect(cx - w * 0.5f - 3.5f, cy - h * 0.5f - 3.5f, w + 7, h + 7, 22 * sc + 3.5f, ink);
    gfx_tri(tx - ex / el * 6, ty - ey / el * 6, bx + nx * 16, by + ny * 16, bx - nx * 16, by - ny * 16, ink);
    gfx_rrect(cx - w * 0.5f, cy - h * 0.5f, w, h, 22 * sc, wh);
    gfx_tri(tx, ty, bx + nx * 11, by + ny * 11, bx - nx * 11, by - ny * 11, wh);
    float lh = size * 1.25f;
    gfx_text_wrap(&F_txt, M.say, cx, cy - (bubble_lines - 1) * lh * 0.5f, size, 300.0f * sc + 2.0f, lh, ink, AL_CENTER, 1);
}

/* ============================== level rendering ============================== */
static void draw_rope(const Rope *r) {
    float f = r->cut ? clampf(r->fade, 0, 1) : 1.0f, k = 0.25f + 0.75f * f;
    u32 oc = 0x3B2313FFu, c0 = 0xF6DBA6FFu, c1 = 0xD9A262FFu;
    if (r->cut) { oc = color_alpha(oc, f); c0 = color_lerp(0x3B2313FFu, c0, f); c1 = color_lerp(0x3B2313FFu, c1, f); oc = 0x3B2313FFu; }
    for (int i = 0; i < r->n - 1; i++) { if (r->cut && i == r->cut_at) continue; gfx_capsule(r->p[i].x, r->p[i].y, r->p[i + 1].x, r->p[i + 1].y, 5.0f * k, oc); }
    for (int i = 0; i < r->n - 1; i++) { if (r->cut && i == r->cut_at) continue; gfx_capsule(r->p[i].x, r->p[i].y, r->p[i + 1].x, r->p[i + 1].y, 3.0f * k, (i & 1) ? c1 : c0); }
}
static void draw_spikes(const Spikes *k) {
    float dx = k->x1 - k->x0, dy = k->y1 - k->y0, l = hypotf(dx, dy); if (l < 1) return; dx /= l; dy /= l;
    float nx = -dy, ny = dx; int n = (int)(l / 20.0f + 0.5f); if (n < 1) n = 1; float st = l / n;
    for (int side = -1; side <= 1; side += 2) for (int i = 0; i < n; i++) {
        float m = (i + 0.5f) * st, px = k->x0 + dx * m, py = k->y0 + dy * m, hx = nx * 19.0f * side, hy = ny * 19.0f * side, w = st * 0.5f;
        gfx_tri(px - dx * (w + 1.5f), py - dy * (w + 1.5f), px + dx * (w + 1.5f), py + dy * (w + 1.5f), px + hx * 1.13f, py + hy * 1.13f, 0x1B1F38FFu);
        gfx_tri(px - dx * (w - 1.5f), py - dy * (w - 1.5f), px + dx * (w - 1.5f), py + dy * (w - 1.5f), px + hx, py + hy, 0xDCE5F7FFu);
        gfx_tri(px, py, px + dx * (w - 1.5f), py + dy * (w - 1.5f), px + hx, py + hy, 0x8D9AC0FFu);
    }
    gfx_capsule(k->x0, k->y0, k->x1, k->y1, 7.5f, 0x1B1F38FFu);
    gfx_capsule(k->x0, k->y0, k->x1, k->y1, 5.0f, 0x59658EFFu);
    gfx_capsule(k->x0 - nx * 1.6f, k->y0 - ny * 1.6f, k->x1 - nx * 1.6f, k->y1 - ny * 1.6f, 1.6f, 0xAEB9DAFFu);
    gfx_circle(k->x0, k->y0, 3.2f, 0xE94B5AFFu); gfx_circle(k->x1, k->y1, 3.2f, 0xE94B5AFFu);
}
static void draw_blower(const Blower *b) {
    float sq = b->squeeze, t = g_time;
    for (int i = 0; i < 3; i++) {                 /* direction chevrons */
        float ph = fmodf(t * 1.4f + i * 0.33f, 1.0f), d = 78.0f + ph * 62.0f, a = sinf(ph * PI) * 0.55f;
        float cx = b->x + b->dx * d, cy = b->y + b->dy * d, nx = -b->dy, ny = b->dx; u32 c = RGBA(255, 255, 255, (int)(a * 255));
        gfx_capsule(cx - b->dx * 7 + nx * 9, cy - b->dy * 7 + ny * 9, cx, cy, 2.2f, c);
        gfx_capsule(cx - b->dx * 7 - nx * 9, cy - b->dy * 7 - ny * 9, cx, cy, 2.2f, c);
    }
    gfx_image_ex(I_blower, b->x - b->dx * 8, b->y - b->dy * 8, 1.0f + 0.10f * sq, 1.0f - 0.30f * sq, b->ang, 1);
}
static void draw_desk(float x, float top, float sc, int floating, const Image *im) {
    if (!floating) { gfx_image_ex(im, x, top, sc, sc, 0, 1); return; }
    float cut = top + 60.0f * sc, t = g_time;
    for (int i = -1; i <= 1; i += 2) {
        float jx = x + i * 82.0f * sc, fl = 0.75f + 0.25f * sinf(t * 23.0f + i);
        gfx_image_tint(I_wglow, jx, cut + 26 * sc, 0.5f * sc, 0.95f * sc * fl, 0, RGBA(90, 230, 255, 170), 1);
        gfx_tri(jx - 11 * sc, cut + 12 * sc, jx + 11 * sc, cut + 12 * sc, jx, cut + (34 + 10 * fl) * sc, RGBA(190, 250, 255, 210));
    }
    gfx_clip(0, 0, DESIGN_W, cut); gfx_image_ex(im, x, top, sc, sc, 0, 1); gfx_clip_reset();
    gfx_rrect(x - 142 * sc, cut - 5 * sc, 284 * sc, 22 * sc, 11 * sc, 0x15103AFFu);
    gfx_rrect(x - 136 * sc, cut - 1 * sc, 272 * sc, 6 * sc, 3 * sc, C_CYAN);
    gfx_rrect(x - 98 * sc, cut + 9 * sc, 32 * sc, 8 * sc, 4 * sc, 0x3A3F6EFFu); gfx_rrect(x + 66 * sc, cut + 9 * sc, 32 * sc, 8 * sc, 4 * sc, 0x3A3F6EFFu);
}
static int mel_floating(void) { return S.my - FACE_UP + DESK_DROP + 104.0f < 650.0f; }
static void draw_mel_scene(void) {
    if (!S.has_mel) return;
    float fx = S.mx, fy = S.my - FACE_UP, top = fy + DESK_DROP;
    gfx_clip(0, 0, DESIGN_W, top + 6); draw_mel(fx, fy, MEL_SC, 1.0f); gfx_clip_reset();
    draw_desk(fx, top, 1.0f, mel_floating(), I_desk);
}
static void draw_bottle(void) {
    float x = S.c.x, y = S.c.y, sc = 1.0f, rot = S.rot;
    if (S.state == ST_BROKEN) return;
    if (S.state == ST_EATEN) {
        float f = clampf(S.state_t / 0.2f, 0, 1), e = ease_in_cubic(f);
        x = lerpf(x, S.mx, e); y = lerpf(y, S.my, e); sc = 1.0f - e; rot += f * 3.0f; if (sc <= 0.02f) return;
    }
    gfx_image_ex(I_bottle, x, y, sc, sc, rot, 1);
    if (S.in_bubble && S.state == ST_PLAY) {
        float w = sinf(g_time * 5.0f) * 0.04f, g = ease_out_elastic(clampf(S.bubble_t / 0.5f, 0, 1));
        gfx_image_ex(I_bubble, x, y, (1.0f + w) * g, (1.0f - w) * g, 0, 1);
    }
}
static void draw_scene(void) {
    float t = g_time;
    for (int i = 0; i < S.npins; i++) { const Pin *p = &S.pin[i]; if (p->autopin && !p->used) dashed_circle(p->x, p->y, p->r, t * 0.25f, 3.6f, 0xFFFFFFA8u); }
    draw_mel_scene();
    for (int i = 0; i < S.nspikes; i++) draw_spikes(&S.spikes[i]);
    for (int i = 0; i < S.nblowers; i++) draw_blower(&S.blower[i]);
    for (int i = 0; i < S.nbubbles; i++) { const Bubble *b = &S.bubble[i]; if (b->used) continue; float w = sinf(t * 3.0f + i * 1.7f) * 0.035f; gfx_image_ex(I_bubble, b->x, b->y + sinf(t * 1.8f + i) * 3.0f, 1.0f + w, 1.0f - w, 0, 1); }
    for (int i = 0; i < MAX_ROPES; i++) if (S.rope[i].active) draw_rope(&S.rope[i]);
    for (int i = 0; i < S.npins; i++) { const Pin *p = &S.pin[i]; float s = 1.0f + 0.35f * p->pulse; gfx_image_ex(I_pin, p->x, p->y, s, s, 0, 1); }
    for (int i = 0; i < S.nstars; i++) {
        const Star *st = &S.star[i]; if (st->got) continue;
        float ph = t * 2.2f + i * 2.1f, y = st->y + sinf(ph) * 3.5f, s = 0.92f + 0.05f * sinf(ph * 1.4f);
        gfx_image_tint(I_glow, st->x, y, 0.62f, 0.62f, 0, RGBA(255, 255, 255, (int)(120 + 50 * sinf(ph))), 1);
        gfx_image_ex(I_star, st->x, y, s, s, sinf(ph * 0.7f) * 0.14f, 1);
        float sp = fmodf(t * 0.7f + i * 0.37f, 1.0f), ss = sinf(clampf(sp * 2.2f, 0, 1) * PI) * 0.8f; if (ss > 0.2f) gfx_image_tint(I_spark, st->x + 13, y - 15, ss, ss, sp * 2.0f, 0xFFFFFFFFu, 1);
    }
    draw_bottle();
}
static void draw_trail(void) {
    for (int i = 0; i < 6; i++) if (slash[i].t > 0) {
        Slash *s = &slash[i]; float f = s->t / 0.3f, h = clampf((1.0f - f) / 0.35f, 0, 1), tl = clampf((1.0f - f) / 0.8f - 0.25f, 0, 1);
        float ax = lerpf(s->x0, s->x1, tl), ay = lerpf(s->y0, s->y1, tl), bx = lerpf(s->x0, s->x1, h), by = lerpf(s->y0, s->y1, h);
        gfx_capsule2(ax, ay, bx, by, 1.0f, 7.5f * f + 1.5f, RGBA(120, 230, 255, 120)); gfx_capsule2(ax, ay, bx, by, 0.5f, 4.0f * f + 0.8f, 0xFFFFFFFFu);
    }
    while (trail_n > 0 && g_time - trail[0].t > 0.24f) { memmove(trail, trail + 1, sizeof(TPt) * (size_t)(trail_n - 1)); trail_n--; }
    for (int pass = 0; pass < 2; pass++) for (int i = 0; i + 1 < trail_n; i++) {
        float a0 = 1.0f - (g_time - trail[i].t) / 0.24f, a1 = 1.0f - (g_time - trail[i + 1].t) / 0.24f; if (a0 < 0) a0 = 0; if (a1 < 0) a1 = 0;
        if (pass == 0) gfx_capsule2(trail[i].x, trail[i].y, trail[i + 1].x, trail[i + 1].y, 9.0f * a0, 9.0f * a1, RGBA(110, 225, 255, 110));
        else gfx_capsule2(trail[i].x, trail[i].y, trail[i + 1].x, trail[i + 1].y, 4.5f * a0, 4.5f * a1, 0xFFFFFFFFu);
    }
    if (tapfx_t > 0) { float f = tapfx_t / 0.4f; gfx_ring(tapfx_x, tapfx_y, 18 + 44 * (1 - f), 6 * f + 1, RGBA(255, 255, 255, (int)(255 * f))); gfx_circle(tapfx_x, tapfx_y, 12 * f, RGBA(255, 255, 255, (int)(200 * f))); }
}
static void draw_hud(void) {
    char buf[96];
    gfx_rrect(14, 12, 176, 60, 30, 0x0E0A2E96u);
    for (int i = 0; i < 3; i++) {
        int got = i < L_got && !fly[i].on; float p = hud_pop[i], s = 46.0f * (1.0f + 0.5f * sinf(p * PI));
        star_icon(hud_sx[i], hud_sy, got ? s : 44.0f, got, 1);
    }
    snprintf(buf, sizeof(buf), "%d-%d", g_levels[L_idx].box + 1, L_idx % PER_BOX + 1);
    gfx_text(&F_ui, buf, 20, 92, 21, 0xFFFFFFE6u, AL_LEFT);
    float na = clampf((4.0f - L_t) / 0.6f, 0, 1);
    if (na > 0 && !L_demo) gfx_text(&F_ui, g_levels[L_idx].name, 26 + gfx_text_w(&F_ui, buf, 21), 92, 21, RGBA(255, 255, 255, (int)(230 * na)), AL_LEFT);
    if (L_demo) {
        float bl = 0.65f + 0.35f * sinf(g_time * 5.0f), x0 = 30 + gfx_text_w(&F_ui, buf, 21);
        gfx_rrect(x0, 78, 92, 28, 14, RGBA(255, 79, 184, (int)(235 * bl))); gfx_text(&F_ui, "ДЕМО", x0 + 46, 92, 19, WHITE, AL_CENTER);
    }
    for (int i = 0; i < 3; i++) if (fly[i].on) {
        float f = clampf(fly[i].t / 0.55f, 0, 1), e = ease_in_out(f);
        float x = lerpf(fly[i].x0, fly[i].x1, e), y = lerpf(fly[i].y0, fly[i].y1, e) - sinf(f * PI) * 70.0f, s = lerpf(1.0f, 46.0f / 60.0f, e) * (1.0f + 0.3f * sinf(f * PI));
        gfx_image_tint(I_glow, x, y, 0.7f, 0.7f, 0, RGBA(255, 255, 255, 150), 1);
        gfx_image_ex(I_star, x, y, s, s, f * TAU, 1);
    }
}

/* ============================== screens ============================== */
static void go(int s, int arg, int arg2) { if (scr_next >= 0) return; scr_next = s; scr_arg = arg; scr_arg2 = arg2; sfx(S_WHOOSH, 0.45f, 640); }
static void enter(int s, int a, int a2) {
    scr = s; nparts = 0; M.say_t = 0; P.active = 0;
    if (s == SC_PLAY) level_start(a, a2);
    else if (s == SC_MENU) { mel_set(CL_IDLE, 1); M.dy = 0; }
    else if (s == SC_FINAL) { mel_set(CL_LAUGH, 1); say(V_BRAVO, NULL); fx_confetti(100, 1180, -10, 140); }
    if (s == SC_LEVELS) sel_box = a;
}
static void restart_level(int demo) { level_start(L_idx, demo); g_fade = 0.55f; }

static void title_text(const char *s, float x, float y, float size) { gfx_text(&F_ui, s, x, y, size, WHITE, AL_CENTER); }
static void cam_frame(float x, float y, float w, float h) {
    gfx_rrect(x - 4, y - 4, w + 8, h + 8, 24, C_PINK);
    gfx_rrect_grad(x, y, w, h, 20, 0x3B2A80FFu, 0x130B3AFFu);
}
static void cam_overlay(float x, float y) {
    float bl = 0.6f + 0.4f * sinf(g_time * 5.0f);
    gfx_rrect(x + 12, y + 12, 78, 28, 14, 0x000000A0u);
    gfx_circle(x + 28, y + 26, 7, RGBA(255, 60, 70, (int)(255 * bl)));
    gfx_text(&F_txt, "LIVE", x + 62, y + 26.5f, 19, WHITE, AL_CENTER);
}
/* big Mel inside a "webcam" frame; bottom-aligned */
static void draw_mel_cam(float x, float y, float w, float h) {
    cam_frame(x, y, w, h);
    const Clip *c = &CLP[M.clip]; float uh = c->h / c->scale, k = clampf((h * 0.82f) / uh, 1.4f, 2.6f);
    gfx_clip(x + 3, y + 3, w - 6, h - 6);
    float dy = M.dy; M.dy = 0; draw_mel(x + w * 0.5f, y + h - 3 - c->avail * k + 3, k, 1.0f); M.dy = dy;
    gfx_clip_reset();
    cam_overlay(x, y);
}

static void scr_menu(void) {
    float mx = 985, my = 318, sc = 1.9f;
    bg_draw(0, 0.62f, DECO_MENU, (int)mx, 0, 0);
    gfx_clip(0, 0, DESIGN_W, my + DESK_U * sc + 8); draw_mel(mx, my, sc, 1.0f); gfx_clip_reset();
    draw_desk(mx, my + DESK_U * sc, sc * 0.86f, 0, I_deskbig ? I_deskbig : I_desk);
    if (P.pressed && !ui_block && fabsf(P.downx - mx) < 110 && fabsf(P.downy - my) < 120) {        /* easter egg: poke Mel */
        static int k; static const int v[7] = { V_AM, V_LAUGH, V_UUU, V_OMG, V_STOP, V_POSIDIM, V_BRAVO };
        static const char *const tx[7] = { "Ам-ам-ам!", "Ха-ха-ха!", "У-у-у-у!", "О май гад!", "Стоп-стоп-стоп!", "Не, ещё посидим!", "Браво, босс!" };
        static const int cl[7] = { CL_AM, CL_LAUGH, CL_SMILE, CL_OMG, CL_SAD, CL_BORED, CL_LAUGH };
        mel_set(cl[k], 1); M.react = maxf(2.2f, (float)SND[v[k]]->n / (float)SND[v[k]]->rate + 0.3f); say(v[k], tx[k]); k = (k + 1) % 7;
        for (int i = 0; i < 8; i++) { float a = rnd_range(0, TAU); Part *p = part_new(PT_SPARK, P.x, P.y, cosf(a) * 200, sinf(a) * 200, 0.4f, 36, 0xFFE680FFu); p->drag = 3; }
    }
    float bob = sinf(g_time * 1.3f) * 5.0f, in = ease_out_back(clampf(g_time / 0.7f, 0, 1));
    gfx_image_ex(I_logo, 432, 168 + bob, 0.74f * in, 0.74f * in, sinf(g_time * 0.9f) * 0.02f, 1);
    if (!(g_capflags & 4)) {                           /* (capture aid 4: bare key art, no widgets) */
        if (wbtn(1, 432, 404, 340, 104, "ИГРАТЬ", C_GREEN1, C_GREEN2, 54, IC_PLAY, 1)) go(SC_BOXES, 0, 0);
        int caps = plat_caps(), n = 2 + ((caps & 2) ? 1 : 0) + ((caps & 1) ? 1 : 0); float x = 432 - (n - 1) * 44.0f;
        if (rbtn(2, x, 528, 33, SV.sound ? IC_SOUND : IC_SOUND_OFF, C_VIO1, C_VIO2, 1)) { SV.sound = !SV.sound; apply_volumes(); save_store(); } x += 88;
        if (rbtn(3, x, 528, 33, SV.music ? IC_MUSIC : IC_MUSIC_OFF, C_VIO1, C_VIO2, 1)) { SV.music = !SV.music; apply_volumes(); save_store(); } x += 88;
        if (caps & 2) { if (rbtn(4, x, 528, 33, IC_FULL, C_BLUE1, C_BLUE2, 1)) plat_fullscreen(); x += 88; }
        if (caps & 1) { if (rbtn(5, x, 528, 33, IC_EXIT, C_RED1, C_RED2, 1)) plat_quit(); }
        char buf[64]; snprintf(buf, sizeof(buf), "%d / %d", total_stars(), LEVEL_COUNT * 3);
        float tw = gfx_text_w(&F_ui, buf, 30);
        gfx_rrect(432 - tw * 0.5f - 52, 596, tw + 86, 46, 23, 0x0E0A2EA0u); star_icon(432 - tw * 0.5f - 22, 619, 36, 1, 1); gfx_text(&F_ui, buf, 432 + 16, 620, 30, WHITE, AL_CENTER);
        gfx_text(&F_txt, "Неофициальная фан-пародия  •  собственный движок MEL-ENGINE", 432, 690, 17, 0xFFFFFFA0u, AL_CENTER);
    }
    parts_draw();
    if (!(g_capflags & 2)) draw_say(mx, my, 100.0f, -168.0f, 1.0f);
    if (!hello_done && g_time > 0.7f) { hello_done = 1; say(V_HELLO, "Hello! I'm Mellstroy!"); }
}
static void back_button(int target, int arg) { if (rbtn(6, 62, 62, 32, IC_BACK, C_VIO1, C_VIO2, 1)) go(target, arg, 0); }
static void total_badge(void) {
    char buf[32]; snprintf(buf, sizeof(buf), "%d/%d", total_stars(), LEVEL_COUNT * 3);
    float tw = gfx_text_w(&F_ui, buf, 30);
    gfx_rrect(1250 - tw - 76, 38, tw + 76, 50, 25, 0x0E0A2EA0u); star_icon(1250 - tw - 46, 63, 38, 1, 1); gfx_text(&F_ui, buf, 1250 - 16, 64, 30, WHITE, AL_RIGHT);
}
static void scr_boxes(void) {
    static float lock_shake[BOXES];
    bg_draw(0, 0.42f, DECO_NONE, 0, 0, 0);
    title_text("Выбери локацию", 640, 82, 54);
    back_button(SC_MENU, 0); total_badge();
    int tot = total_stars();
    for (int b = 0; b < BOXES; b++) {
        float x = 270 + b * 370.0f, y = 338; int open = box_open(b);
        int click = btn_logic(10 + b, x, y + 30, 320, 330, 1);
        float a = B_anim[10 + b], s = 1.0f + 0.035f * maxf(a, 0) - 0.02f * (a < 0 ? -a : 0);
        if (lock_shake[b] > 0) { lock_shake[b] -= g_dt; x += sinf(lock_shake[b] * 50.0f) * 8.0f * lock_shake[b] / 0.35f; }
        float W = 316 * s, H = 336 * s;
        gfx_rrect(x - W * 0.5f - 3, y + 30 - H * 0.5f + 8, W + 6, H, 38, 0x00000060u);
        gfx_rrect(x - W * 0.5f, y + 30 - H * 0.5f, W, H, 36, open ? box_c1[b] : 0x7C7896FFu);
        gfx_rrect_grad(x - W * 0.5f + 5, y + 30 - H * 0.5f + 5, W - 10, H - 10, 31, C_PANEL1, C_PANEL2);
        gfx_image_ex(I_cover[b], x, y - 26 * s, s * 0.98f, s * 0.98f, 0, 1);
        gfx_text(&F_ui, box_name[b], x, y + 96 * s, 33 * s, WHITE, AL_CENTER);
        gfx_text(&F_txt, box_sub[b], x, y + 131 * s, 18.5f * s, 0xD8CCFFFFu, AL_CENTER);
        char buf[48];
        if (open) {
            snprintf(buf, sizeof(buf), "%d/%d", box_stars(b), PER_BOX * 3); float tw = gfx_text_w(&F_ui, buf, 27 * s);
            star_icon(x - tw * 0.5f - 6, y + 166 * s, 32 * s, 1, 1); gfx_text(&F_ui, buf, x + 20, y + 167 * s, 27 * s, C_GOLD, AL_CENTER);
        } else {
            gfx_rrect(x - 147 * s, y - 26 * s - 93 * s, 294 * s, 186 * s, 29, 0x0A0620B4u);
            icon(IC_LOCK, x, y - 30 * s, 44 * s, 0xFFFFFFE6u);
            snprintf(buf, sizeof(buf), "Собери ещё %d", box_need[b] - tot); float tw = gfx_text_w(&F_ui, buf, 23 * s);
            gfx_text(&F_ui, buf, x - 16, y + 167 * s, 23 * s, 0xFFFFFFE0u, AL_CENTER); star_icon(x + tw * 0.5f + 4, y + 166 * s, 28 * s, 1, 1);
        }
        if (click) { if (open) go(SC_LEVELS, b, 0); else { lock_shake[b] = 0.35f; sfx(S_TICK, 0.8f, x); } }
    }
}
static void scr_levels(void) {
    static float lock_shake[PER_BOX];
    int b = sel_box; char buf[16];
    bg_draw(b, 0.5f, DECO_NONE, 0, 0, 0);
    title_text(box_name[b], 640, 78, 54);
    gfx_text(&F_txt, box_sub[b], 640, 124, 22, 0xE4DCFFFFu, AL_CENTER);
    back_button(SC_BOXES, 0); total_badge();
    for (int i = 0; i < PER_BOX; i++) {
        int li = b * PER_BOX + i, open = lvl_open(li), st = lvl_stars(li);
        float x = 640 + (i % 3 - 1) * 216.0f, y = 290 + (i / 3) * 206.0f;
        int click = btn_logic(20 + i, x, y, 170, 170, 1);
        float a = B_anim[20 + i], s = 1.0f + 0.05f * maxf(a, 0), press = a < 0 ? -a : 0, W = 164 * s, yy = y + press * 4;
        if (lock_shake[i] > 0) { lock_shake[i] -= g_dt; x += sinf(lock_shake[i] * 50.0f) * 7.0f * lock_shake[i] / 0.35f; }
        u32 c0 = open ? box_c1[b] : 0x8C88A8FFu, c1 = open ? box_c2[b] : 0x56526EFFu;
        gfx_rrect(x - W * 0.5f - 2, y - W * 0.5f + 10, W + 4, W, 40, 0x00000058u);
        gfx_rrect(x - W * 0.5f, y - W * 0.5f + 7, W, W, 38, color_lerp(c1, 0x000000FFu, 0.45f));
        gfx_rrect_grad(x - W * 0.5f, yy - W * 0.5f, W, W, 38, c0, c1);
        gfx_rrect(x - W * 0.5f + 8, yy - W * 0.5f + 6, W - 16, W * 0.36f, 26, 0xFFFFFF2Cu);
        if (open) {
            snprintf(buf, sizeof(buf), "%d", i + 1); gfx_text(&F_ui, buf, x, yy - 18 * s, 78 * s, WHITE, AL_CENTER);
            for (int k = 0; k < 3; k++) star_icon(x + (k - 1) * 40.0f * s, yy + 48 * s - (k == 1 ? 5 * s : 0), 40 * s, k < st, 1);
        } else icon(IC_LOCK, x, yy, 40 * s, 0xFFFFFFD0u);
        if (click) { if (open) go(SC_PLAY, li, 0); else { lock_shake[i] = 0.35f; sfx(S_TICK, 0.8f, x); } }
    }
    gfx_text(&F_txt, g_levels[b * PER_BOX].box == b ? "Собери все три звезды на каждом уровне!" : "", 640, 668, 20, 0xFFFFFFB0u, AL_CENTER);
}
static void scr_final(void) {
    bg_draw(2, 0.5f, DECO_NONE, 0, 0, 0);
    char buf[96];
    panel(190, 110, 900, 500);
    draw_mel_cam(214, 134, 330, 452);
    title_text("Игра пройдена!", 812, 190, 52);
    gfx_text_wrap(&F_txt, "Мел сыт и доволен. Все чекушки доставлены по адресу!", 812, 262, 25, 480, 33, 0xE8E0FFFFu, AL_CENTER, 1);
    snprintf(buf, sizeof(buf), "%d / %d", total_stars(), LEVEL_COUNT * 3); float tw = gfx_text_w(&F_ui, buf, 50);
    star_icon(812 - tw * 0.5f - 20, 392, 66, 1, 1); gfx_text(&F_ui, buf, 812 + 30, 394, 50, C_GOLD, AL_CENTER);
    if (total_stars() < LEVEL_COUNT * 3) gfx_text(&F_txt, "А слабо собрать все звёзды?", 812, 452, 22, 0xFFFFFFC0u, AL_CENTER);
    else gfx_text(&F_txt, "Все звёзды собраны. Браво, босс!", 812, 452, 22, C_GOLD, AL_CENTER);
    if (wbtn(30, 812, 530, 300, 78, "В меню", C_GREEN1, C_GREEN2, 40, IC_HOME, 1)) go(SC_MENU, 0, 0);
    if (rnd_f() < g_dt * 1.2f) fx_confetti(100, 1180, -10, 24);
    parts_draw();
}

/* ---------- play ---------- */
#define WIN_T0 1.15f          /* seconds after the gulp when the result panel starts to slide in */
static void finish_win(void) {
    int st = S.stars; if (st > 3) st = 3;
    if (!L_demo) {
        if (SV.best[L_idx] < st + 1) { L_newbest = SV.best[L_idx] > 0; SV.best[L_idx] = (u8)(st + 1); save_store(); }
    }
    sfx_p(S_WIN, 0.8f, 640, 1.0f);
    if (L_demo) { mel_set(CL_SMILE, 1); return; }
    if (st == 3) { mel_set(CL_LAUGH, 1); say(V_BRAVO, "Браво, босс!"); }
    else if (st == 2) { mel_set(CL_SMILE, 1); if (rnd_u32() & 1) say(V_UUU, "У-у-у-у!"); else say(V_LAUGH, "Ха-ха-ха!"); }
    else { mel_set(CL_SMILE, 1); say(V_POSIDIM, "Не, ещё посидим!"); }
}
static void next_level(void) {
    int n = L_idx + 1;
    if (n >= LEVEL_COUNT) { go(SC_FINAL, 0, 0); return; }
    if (lvl_open(n)) go(SC_PLAY, n, 0); else go(SC_BOXES, 0, 0);
}
static void play_update(float dt) {
    if (L_paused || scr_next >= 0) return;
    L_t += dt;
    L_acc += dt; if (L_acc > 0.1f) L_acc = 0.1f;
    while (L_acc >= SIM_DT) {
        L_acc -= SIM_DT;
        if ((L_demo || L_ghost) && S.state == ST_PLAY) {
            const Step *sc = g_levels[L_idx].demo;
            for (int a = 0; a < 40 && sc[a].act != ACT_END; a++) if (!L_demo_done[a] && S.time >= sc[a].t) { L_demo_done[a] = 1; demo_fx(&sc[a]); sim_do(&S, &sc[a]); on_events(); }
        }
        sim_step(&S); on_events();
    }
    for (int i = 0; i < 3; i++) {
        if (fly[i].on) { fly[i].t += dt; if (fly[i].t >= 0.55f) { fly[i].on = 0; hud_pop[i] = 1.0f; part_new(PT_RING, fly[i].x1, fly[i].y1, 0, 0, 0.3f, 22, 0xFFF3A0FFu); } }
        if (hud_pop[i] > 0) hud_pop[i] = maxf(0, hud_pop[i] - dt * 3.0f);
    }
    for (int i = 0; i < 6; i++) if (slash[i].t > 0) slash[i].t -= dt;
    if (tapfx_t > 0) tapfx_t -= dt;
    if (L_toast_t > 0) L_toast_t -= dt;
    /* Mel's behaviour */
    if (L_phase == PH_PLAY) {
        M.idle_t += dt;
        int near = S.mouth_dist < MOUTH_NEAR;
        if (near && M.clip != CL_AM) {
            mel_set(CL_AM, 1); M.idle_t = 0;
            if (M.am_cool <= 0 && M.am_count < 3 && M.voice_t <= 0) { say(V_AM1, "Ам-ам-ам!"); M.am_cool = 5.0f; M.am_count++; }
        } else if (!near && M.clip == CL_AM && S.mouth_dist > MOUTH_NEAR * 1.3f) mel_set(CL_IDLE, 1);
        if (M.clip == CL_IDLE && M.idle_t > 11.0f) { mel_set(CL_BORED, 1); M.react = clip_len(CL_BORED) * 2.0f; M.idle_t = 0; }
    } else if (L_phase == PH_WIN) {
        L_pt += dt;
        if (!L_react_done && L_pt > 0.42f) { L_react_done = 1; finish_win(); }
        if (L_demo && L_pt > 2.3f) { restart_level(0); L_toast = "Теперь сам!"; L_toast_t = 2.2f; }
    } else {
        L_pt += dt;
        if (L_pt > 2.0f || (L_pt > 0.5f && P.pressed && !hud_hit(P.downx, P.downy))) { int d = L_demo ? 1 : (L_ghost ? 2 : 0); restart_level(d); }
    }
}
static void draw_toast(void) {
    if (L_toast_t <= 0) return;
    float a = clampf(L_toast_t / 0.3f, 0, 1), w = gfx_text_w(&F_ui, L_toast, 30) + 60;
    gfx_rrect(640 - w * 0.5f, 26, w, 52, 26, RGBA(14, 10, 46, (int)(190 * a)));
    gfx_text(&F_ui, L_toast, 640, 52, 30, RGBA(255, 255, 255, (int)(255 * a)), AL_CENTER);
}
static void draw_pause(void) {
    panel(410, 96, 460, 528);
    title_text("Пауза", 640, 150, 50);
    if (wbtn(40, 640, 232, 350, 66, "Продолжить", C_GREEN1, C_GREEN2, 33, IC_PLAY, 1)) L_paused = 0;
    if (wbtn(41, 640, 310, 350, 66, "Заново", C_BLUE1, C_BLUE2, 33, IC_RESTART, 1)) restart_level(0);
    if (wbtn(42, 640, 388, 350, 66, "Показать решение", C_ORG1, C_ORG2, 29, IC_NONE, 1)) restart_level(1);
    if (wbtn(43, 640, 466, 350, 66, "К уровням", C_VIO1, C_VIO2, 33, IC_GRID, 1)) go(SC_LEVELS, sel_box, 0);
    if (rbtn(44, 596, 558, 29, SV.sound ? IC_SOUND : IC_SOUND_OFF, C_VIO1, C_VIO2, 1)) { SV.sound = !SV.sound; apply_volumes(); save_store(); }
    if (rbtn(45, 684, 558, 29, SV.music ? IC_MUSIC : IC_MUSIC_OFF, C_VIO1, C_VIO2, 1)) { SV.music = !SV.music; apply_volumes(); save_store(); }
}
static void draw_win(void) {
    float t = L_pt - WIN_T0; if (t <= 0 || L_demo) return;
    int st = S.stars > 3 ? 3 : S.stars;
    float e = ease_out_back(clampf(t / 0.4f, 0, 1)), oy = (1.0f - e) * 560.0f;
    gfx_offset(0, oy);
    float px = 240, py = 138, pw = 800, ph = 444;
    panel(px, py, pw, ph);
    draw_mel_cam(px + 24, py + 24, 300, ph - 48);
    float cx = px + 324 + (pw - 324) * 0.5f;
    title_text(st == 3 ? "Идеально!" : (st == 0 ? "Доставлено!" : "Уровень пройден!"), cx, py + 62, st == 3 ? 52 : 42);
    for (int i = 0; i < 3; i++) {
        float sx = cx + (i - 1) * 112.0f, sy = py + 178 - (i == 1 ? 18 : 0), ts = t - 0.45f - i * 0.32f;
        star_icon(sx, sy, 92, 0, 1);
        if (i < st && ts > 0) {
            if (L_shown <= i) { L_shown = i + 1; sfx_p(S_STAR1 + i, 0.7f, sx, 1.0f); fx_ring(sx, sy + oy, 50, 0xFFF3A0FFu, 0.4f);
                for (int k = 0; k < 8; k++) { float a = rnd_range(0, TAU), v = rnd_range(150, 360); Part *p = part_new(PT_SPARK, sx, sy + oy, cosf(a) * v, sinf(a) * v, 0.5f, 40, 0xFFE680FFu); p->drag = 3; } }
            float s = ease_out_elastic(clampf(ts / 0.6f, 0, 1));
            gfx_image_tint(I_glow, sx, sy, 1.1f * s, 1.1f * s, 0, RGBA(255, 255, 255, 120), 1);
            star_icon(sx, sy, 98 * s, 1, 1);
        }
    }
    const char *msg = st == 3 ? "Мел в восторге. Браво, босс!" : (st == 2 ? "Почти! Не хватает одной звезды." : (st == 1 ? "Маловато звёзд. Ещё посидим?" : "Чекушка доехала, но без звёзд."));
    if (L_newbest && st > 0) msg = "Новый рекорд уровня!";
    gfx_text(&F_txt, msg, cx, py + 268, 23, 0xE8E0FFFFu, AL_CENTER);
    int ready = t > 0.7f; float by = py + 360;
    if (rbtn(50, cx - 176, by, 36, IC_GRID, C_VIO1, C_VIO2, ready)) go(SC_LEVELS, sel_box, 0);
    if (rbtn(51, cx - 90, by, 36, IC_RESTART, C_BLUE1, C_BLUE2, ready)) restart_level(0);
    if (wbtn(52, cx + 76, by, 210, 76, "Дальше", C_GREEN1, C_GREEN2, 36, IC_NONE, ready)) next_level();
    gfx_offset(0, 0);
    if (st == 3 && !L_conf && t > 0.5f) { L_conf = 1; fx_confetti(px + 60, px + pw - 60, py - 10, 90); }
}
static void scr_play(void) {
    int win = (L_phase == PH_WIN && !L_demo && L_pt > WIN_T0), frozen = L_paused || (win && L_pt > WIN_T0 + 0.5f);
    if (frozen && snap_usable()) { gfx_offset(0, 0); gfx_copy_from(snap); }       /* frozen, dimmed backdrop: one memcpy */
    else {
        float sx = 0, sy = 0;
        if (shake_t > 0) { float k = shake_t / 0.35f; sx = rnd_range(-1, 1) * shake_amp * k; sy = rnd_range(-1, 1) * shake_amp * k; }
        bg_draw(sel_box, 1.0f, DECO_LEVEL, L_idx + 1, sx, sy);
        draw_scene();
        if (!win) parts_draw();
        draw_trail();
        if (S.has_mel && !win && !(g_capflags & 2)) draw_say(S.mx, S.my - FACE_UP, M.say_ox, M.say_oy, 1.0f);
        gfx_offset(0, 0);
        if (flash_t > 0) gfx_fade(RGBA(255, 255, 255, (int)(150 * flash_t / 0.12f)));
        if (!(g_capflags & 1)) {
            draw_hud();
            draw_toast();
            int hud_on = !L_paused && !(L_phase == PH_WIN && L_pt > 1.0f);
            if (rbtn(60, HUD_RX, HUD_BY, HUD_BR, IC_RESTART, C_BLUE1, C_BLUE2, hud_on)) restart_level(0);
            if (rbtn(61, HUD_PX, HUD_BY, HUD_BR, IC_PAUSE, C_VIO1, C_VIO2, hud_on && L_phase == PH_PLAY)) L_paused = 1;
        }
        snap_ok = 0;
        if (L_paused) gfx_fade(0x0A0626B0u);
        else if (win) gfx_fade(RGBA(10, 6, 38, (int)(150 * clampf((L_pt - WIN_T0) / 0.3f, 0, 1))));
        if (frozen) snap_take();
    }
    if (win) { draw_win(); parts_draw(); }
    if (L_paused) draw_pause();
}

/* ============================== app entry points ============================== */
void app_init(const u8 *pack, int packsize, int audio_rate) {
    pack_init(pack, packsize); audio_init(audio_rate);
    I_bottle = img_load("bottle"); I_desk = img_load("desk"); I_deskbig = img_load("desk_big"); I_blower = img_load("blower");
    I_star = img_load("star"); I_star0 = img_load("star_empty"); I_glow = img_load("glow"); I_wglow = img_load("wglow"); I_spark = img_load("spark"); I_dot = img_load("dot");
    I_pin = img_load("pin"); I_bubble = img_load("bubble"); I_logo = img_load("logo");
    for (int i = 0; i < BOXES; i++) { char nm[16]; snprintf(nm, sizeof(nm), "bg%d", i); I_bg[i] = img_load(nm); snprintf(nm, sizeof(nm), "cover%d", i); I_cover[i] = img_load(nm); }
    font_load(&F_ui, "ui"); font_load(&F_txt, "txt");
    for (int i = 0; i < S_COUNT; i++) SND[i] = snd_load(snd_names[i]);
    for (int i = 0; i < CL_N; i++) clip_load(&CLP[i], clip_names[i]);
    save_load(); apply_volumes();
    rnd_seed(0xC0FFEE01u);
    mel_set(CL_IDLE, 1);
    snd_music(SND[S_MUSIC]);
    g_fade = 1.0f;
}
void app_resize(u32 *px, int w, int h) { gfx_set_framebuffer(px, w, h); bgc_key = 0; snap_ok = 0; }

void app_pointer(int type, float x, float y) {
    float ox = P.x, oy = P.y; P.x = x; P.y = y;
    if (type == 1) {
        P.down = 1; P.pressed = 1; P.active = 0; P.downx = x; P.downy = y; P.moved = 0; P.game = 0; P.tapped = 0;
        if (input_ok() && !hud_hit(x, y)) {
            P.game = 1; trail_n = 0; trail_add(x, y);
            if (sim_tap(&S, x, y)) { P.tapped = 1; tapfx_x = x; tapfx_y = y; tapfx_t = 0.25f; on_events(); }
        }
    } else if (type == 0) {
        if (P.down && P.game && input_ok()) {
            if (hypotf(x - ox, y - oy) > 0.01f) { if (sim_cut(&S, ox, oy, x, y)) on_events(); trail_add(x, y); }
            if (hypotf(x - P.downx, y - P.downy) > 9.0f) P.moved = 1;
        }
    } else if (type == 2) {
        if (P.down) { P.released = 1; P.upx = x; P.upy = y; if (P.game && !P.moved && !P.tapped && input_ok()) { if (click_cut(x, y)) on_events(); } }
        P.down = 0; P.game = 0;
    }
}
void app_key(int key, int down) {
    if (!down || scr_next >= 0) return;
    switch (key) {
    case KEY_ESC:
        if (scr == SC_PLAY) { if (L_phase == PH_PLAY) L_paused = !L_paused; else if (L_phase == PH_WIN) go(SC_LEVELS, sel_box, 0); }
        else if (scr == SC_LEVELS) go(SC_BOXES, 0, 0);
        else if (scr == SC_BOXES || scr == SC_FINAL) go(SC_MENU, 0, 0);
        break;
    case KEY_R: if (scr == SC_PLAY && !(L_phase == PH_WIN && L_pt < 1.5f)) restart_level(0); break;
    case KEY_M: SV.music = SV.sound = !(SV.music || SV.sound); apply_volumes(); save_store(); break;
    case KEY_F: if (plat_caps() & 2) plat_fullscreen(); break;
    case KEY_ENTER: case KEY_SPACE:
        if (scr == SC_MENU) go(SC_BOXES, 0, 0);
        else if (scr == SC_PLAY && L_phase == PH_WIN && L_pt > 1.9f && !L_demo) next_level();
        else if (scr == SC_PLAY && L_paused) L_paused = 0;
        break;
    default: break;
    }
}
void app_frame(float dt) {
    if (dt > 0.1f) dt = 0.1f; if (dt < 0) dt = 0;
    g_dt = dt; g_time += dt;
    ui_block = (scr_next >= 0) || g_fade > 0.6f;
    if (scr_next >= 0) { g_fade += dt * 5.0f; if (g_fade >= 1.0f) { g_fade = 1.0f; enter(scr_next, scr_arg, scr_arg2); scr_next = -1; } }
    else if (g_fade > 0) { g_fade -= dt * 4.0f; if (g_fade < 0) g_fade = 0; }
    if (shake_t > 0) shake_t -= dt; if (flash_t > 0) flash_t -= dt;
    mel_update(dt);
    if (scr == SC_PLAY) play_update(dt);
    if (!(scr == SC_PLAY && L_paused)) parts_update(dt);
    gfx_offset(0, 0); gfx_clip_reset();
    switch (scr) {
    case SC_MENU: scr_menu(); break;
    case SC_BOXES: scr_boxes(); break;
    case SC_LEVELS: scr_levels(); break;
    case SC_PLAY: scr_play(); break;
    case SC_FINAL: scr_final(); break;
    }
    if (g_fade > 0) gfx_fade(RGBA(8, 5, 26, (int)(255 * clampf(g_fade, 0, 1))));
    P.pressed = 0; P.released = 0;
}
/* test hooks for the headless harness */
int app_debug(int cmd, int arg) {
    switch (cmd) {
    case 1: scr_next = -1; enter(SC_PLAY, arg, 0); g_fade = 0; return 0;
    case 2: scr_next = -1; enter(SC_PLAY, arg, 1); g_fade = 0; return 0;
    case 3: for (int i = 0; i < LEVEL_COUNT; i++) if (SV.best[i] < (u8)(arg + 1)) SV.best[i] = (u8)(arg + 1); return 0;
    case 4: return S.state | (S.stars << 4) | (L_phase << 8) | (scr << 12) | (L_demo << 16);
    case 5: scr_next = -1; enter(arg, sel_box, 0); g_fade = 0; return 0;
    case 6: sel_box = arg; return 0;
    case 7: L_paused = arg; return 0;
    case 8: memset(SV.best, 0, sizeof(SV.best)); return 0;
    case 9: return total_stars();
    case 10: scr_next = -1; enter(SC_PLAY, arg, 2); g_fade = 0; return 0;      /* play the stored solution as a normal-looking run */
    case 11: g_capflags = arg; return 0;
    }
    return 0;
}
