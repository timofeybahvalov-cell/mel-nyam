/* ============================================================================
   «МЕЛ-НЯМ» — the game itself: screens, level rendering, Mel's reactions, UI.
   Platform independent; runs on MEL-ENGINE (engine.c) and the simulation (sim.c).
   ============================================================================ */
#include "engine.h"
#include "sim.h"
#include "levels.h"
#include "version.h"
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define BOXES 10
#define PER_BOX 6
#define MAXLV 64
#define MEL_SC 1.2f          /* scale of Mel's sticker in a level                               */
#define FACE_U 17.0f         /* sprite units: the mouth is this much below the face centre       */
#define DESK_U 48.0f         /* sprite units: desk top (back edge) below the face centre         */
#define FACE_UP (FACE_U * MEL_SC)
#define DESK_DROP (DESK_U * MEL_SC)

/* ---------------- palette ---------------- */
#define C_PANEL1 0x3A2A8CFFu
#define C_PANEL2 0x1E1456FFu
#define C_EDGE   0x9D7BFFFFu
#define C_GOLD   0xFFD23FFFu
#define C_PINK   0xFF4FB8FFu
#define C_CYAN   0x46E6FFFFu
#define C_GREEN1 0x8CF04EFFu
#define C_GREEN2 0x2FAE3AFFu
#define C_BLUE1  0x5CC3FFFFu
#define C_BLUE2  0x2B6FE8FFu
#define C_VIO1   0xA98BFFFFu
#define C_VIO2   0x6038D8FFu
#define C_RED1   0xFF8B7AFFu
#define C_RED2   0xD9363EFFu
#define C_ORG1   0xFFC65AFFu
#define C_ORG2   0xF07E1EFFu
#define C_INK    0x241650FFu

/* ---------------- assets ---------------- */
static Image *I_bottle, *I_desk, *I_deskbig, *I_blower, *I_star, *I_star0, *I_glow, *I_wglow, *I_spark, *I_dot, *I_pin, *I_bubble, *I_logo;
static Image *I_bg[BOXES], *I_cover[BOXES];
static Font F_ui, F_txt;
enum { S_CUT, S_ATTACH, S_STAR1, S_STAR2, S_STAR3, S_BUBBLE, S_POP, S_BLOW, S_CLICK, S_TICK, S_WHOOSH, S_WIN, S_FAIL, S_BREAK, S_GULP, S_START, S_MUSIC,
       S_BOUNCE, S_PORTAL, S_GRAV, S_ZAP, S_STEAL, S_SQUEAK, S_GLASS, S_SPLASH,
       V_AM, V_AM1, V_HELLO, V_BRAVO, V_OMG, V_OBIDNO, V_POSIDIM, V_LAUGH, V_UUU, V_STOP, V_SCREAM,
       V_HI, V_RED, V_GIVE, V_DAVAI, V_LUDO, V_FASTER, V_BEST, V_RAGE, S_COUNT };
static const char *const snd_names[S_COUNT] = { "s_cut", "s_attach", "s_star1", "s_star2", "s_star3", "s_bubble", "s_pop", "s_blow", "s_click", "s_tick", "s_whoosh",
    "s_win", "s_fail", "s_break", "s_gulp", "s_start", "music",
    "s_bounce", "s_portal", "s_grav", "s_zap", "s_steal", "s_squeak", "s_glass", "s_splash",
    "v_am", "v_am1", "v_hello", "v_bravo", "v_omg", "v_obidno", "v_posidim", "v_laugh", "v_uuu", "v_stop", "v_scream",
    "v_hi", "v_red", "v_give", "v_davai", "v_ludo", "v_faster", "v_best", "v_rage" };
static Sound *SND[S_COUNT];
enum { CL_IDLE, CL_SMILE, CL_OMG, CL_AM, CL_SAD, CL_BORED, CL_LAUGH, CL_ANGRY, CL_RAGE, CL_FASTER, CL_BEST, CL_N };
static const char *const clip_names[CL_N] = { "clip_idle", "clip_smile", "clip_omg", "clip_am", "clip_sad", "clip_bored", "clip_laugh", "clip_angry", "clip_rage", "clip_faster", "clip_best" };
static const int clip_fallback[CL_N] = { 0, 0, 0, 0, 0, 0, 0, CL_SAD, CL_OMG, CL_SAD, CL_LAUGH };      /* used when an optional clip is not in the pack */
static Clip CLP[CL_N];

static const char *const box_name[BOXES] = { "Стримерская", "Пентхаус", "Вилла", "Спортзал", "Гараж", "Самолёт", "Клуб", "Яхта", "Остров", "Арена" };
static const char *const box_sub[BOXES] = { "Верёвки и липучки", "Пузыри и шипы", "Груши-воздуходуйки", "Батуты", "Рельсы", "Гравитация", "Лазеры", "Порталы", "Воришки", "Экзамен: всё сразу" };
static const int box_need[BOXES] = { 0, 8, 20, 34, 48, 62, 76, 90, 104, 120 };
static const u32 box_c1[BOXES] = { C_VIO1, C_BLUE1, C_ORG1, C_GREEN1, 0xB9C4DCFFu, C_CYAN, C_PINK, 0x6FE3D2FFu, 0xFFE06AFFu, C_RED1 };
static const u32 box_c2[BOXES] = { C_VIO2, C_BLUE2, C_ORG2, C_GREEN2, 0x5A6788FFu, 0x1E8FC0FFu, 0xB8257FFFu, 0x1C8F86FFu, 0xD9930FFFu, C_RED2 };

/* ---------------- global state ---------------- */
enum { SC_MENU, SC_BOXES, SC_LEVELS, SC_PLAY, SC_FINAL, SC_CHAPTERS, SC_RECORDS, SC_HUB, SC_EDITOR, SC_TAS, SC_SETTINGS };
static int scr = SC_MENU, scr_next = -1, scr_arg, scr_arg2;
static float g_fade = 1.0f, g_time, g_dt;
static int sel_box;
static int hello_done;
static float shake_t, shake_amp, flash_t;

static struct { float x, y, downx, downy, upx, upy; int down, pressed, released, active, moved, game, tapped; } P;
static float B_anim[800];
static int ui_block;

/* ---------------- save ---------------- */
#define SAVE_MAGIC 0x334E4C4Du
#define SAVE_V1 0x324E4C4Du          /* V0.1: { magic, best[32], sound, music, r0, r1 } */
typedef struct { u32 magic; u8 sound, music, r0, r1; u32 uid; char nick[32]; u8 best[MAXLV]; u32 ticks[MAXLV]; u8 sent[MAXLV]; } SaveData;
static SaveData SV;
static int lv_max[MAXLV], stars_all;                /* stars available in each level / in the whole game */
static void save_store(void) { plat_save(&SV, (int)sizeof(SV)); }
static void save_load(void) {
    u8 buf[sizeof(SaveData)]; u32 mg = 0;
    memset(&SV, 0, sizeof(SV)); SV.magic = SAVE_MAGIC; SV.sound = 1; SV.music = 1;
    int n = plat_load(buf, (int)sizeof(buf)); if (n >= 4) memcpy(&mg, buf, 4);
    if (n == (int)sizeof(SaveData) && mg == SAVE_MAGIC) memcpy(&SV, buf, sizeof(SV));
    else if (n >= 40 && mg == SAVE_V1) { memcpy(SV.best, buf + 4, 18); SV.sound = buf[36]; SV.music = buf[37]; }     /* keep the progress of V0.1 */
    SV.nick[sizeof(SV.nick) - 1] = 0;
    while (!SV.uid) SV.uid = plat_random() & 0x7FFFFFFFu;
}
static int lvl_done(int i) { return SV.best[i] > 0; }
static int lvl_stars(int i) { return SV.best[i] ? SV.best[i] - 1 : 0; }
static int box_stars(int b) { int n = 0; for (int i = 0; i < PER_BOX; i++) n += lvl_stars(b * PER_BOX + i); return n; }
static int box_max(int b) { int n = 0; for (int i = 0; i < PER_BOX; i++) n += lv_max[b * PER_BOX + i]; return n; }
static int total_stars(void) { int n = 0; for (int i = 0; i < LEVEL_COUNT; i++) n += lvl_stars(i); return n; }
static int box_open(int b) { return total_stars() >= box_need[b]; }
static int lvl_open(int i) { if (!box_open(i / PER_BOX)) return 0; return (i % PER_BOX) == 0 || lvl_done(i - 1); }
/* ---------------- settings and the account: the named blob "cfg" (the progress stays in the save file, exactly as before) ---------------- */
#define CFG_MAGIC 0x31474643u
/* Mel's reactions that can be switched off one by one (Settings) */
enum { EM_HELLO, EM_GREET, EM_GIVE, EM_HURRY, EM_BORED, EM_STARS, EM_WOW, EM_BRAVO, EM_BEST, EM_SOSO, EM_SORRY, EM_STOP, EM_SCREAM, EM_RED, EM_RAGE, EM_LUDO, EM_POKE, EM_N };
typedef struct {
    u32 magic; u8 vol_sfx, vol_music, vol_voice, speech, bubbles, hints, shake, sparks, timer, acc, r0, r1; u32 emo_off;
    char token[48]; u32 r[8];                        /* acc: this device is signed in; token: what the table gave it for that */
} Cfg;
static Cfg CFG;
static void cfg_store(void) { plat_store("cfg", &CFG, (int)sizeof(CFG)); }
static void cfg_load(void) {
    static Cfg c; int n = plat_fetch("cfg", &c, (int)sizeof(c));
    memset(&CFG, 0, sizeof(CFG)); CFG.magic = CFG_MAGIC; CFG.vol_sfx = CFG.vol_music = CFG.vol_voice = 100;
    CFG.speech = CFG.bubbles = CFG.hints = CFG.shake = CFG.sparks = CFG.timer = 1;
    if (n == (int)sizeof(c) && c.magic == CFG_MAGIC) {
        CFG = c; CFG.token[sizeof(CFG.token) - 1] = 0;
        if (CFG.vol_sfx > 100) CFG.vol_sfx = 100; if (CFG.vol_music > 100) CFG.vol_music = 100; if (CFG.vol_voice > 100) CFG.vol_voice = 100;
    }
}
static int emo_on(int e) { return !((CFG.emo_off >> e) & 1u); }
static int speech_on(void) { return CFG.speech && SV.sound && CFG.vol_voice > 0; }
static void apply_volumes(void) {
    float on = SV.sound ? 1.0f : 0.0f;
    snd_volumes(on * (float)CFG.vol_sfx / 100.0f, SV.music ? 0.5f * (float)CFG.vol_music / 100.0f : 0.0f, speech_on() ? (float)CFG.vol_voice / 100.0f : 0.0f);
}
static const char *fmt_time(int ticks, char *buf, int n) {
    int cs = (int)(((long long)ticks * 100 + SIM_HZ / 2) / SIM_HZ);
    snprintf(buf, (size_t)n, "%d:%02d.%02d", cs / 6000, cs / 100 % 60, cs % 100); return buf;
}

/* ---------------- sound helpers ---------------- */
static void sfx_p(int id, float vol, float x, float pitch) { snd_play(SND[id], vol, clampf((x - 640.0f) / 900.0f, -0.7f, 0.7f), pitch); }
static void sfx(int id, float vol, float x) { sfx_p(id, vol, x, rnd_range(0.97f, 1.03f)); }

/* ============================== Mel ============================== */
typedef struct {
    int clip, loop; float t, pop, dy, react, red, red_to;
    float am_cool; int am_count; float idle_t, voice_t;
    char say[120]; float say_t, say_dur, say_size; int say_side; float say_ox, say_oy;
} MelState;
static MelState M;
static Sim S;
/* the level being played: one of the built-in ones, one from the editor or one published by another player */
typedef struct { const char *name, *hint; int box, kind, flip, maxst, idx; const LObj *objs; const Step *demo; char key[24]; } CurLevel;
static CurLevel CUR;                                  /* kind: 0 built-in, 1 editor test, 2 published */
static float mel_fy(void) { return CUR.flip ? S.my + FACE_UP : S.my - FACE_UP; }      /* centre of Mel's face (he hangs upside down in some levels) */

static float clip_len(int c) { return CLP[c].n / CLP[c].fps; }
static void mel_set(int clip, int loop) {
    if (!CLP[clip].n) clip = clip_fallback[clip];
    if (M.clip == clip && M.loop == loop && loop) return;
    M.clip = clip; M.loop = loop; M.t = 0; M.pop = 1; M.react = 0;
}
static void mel_react(int clip, float hold) { mel_set(clip, 0); M.t = 0; M.react = clip_len(clip) + hold; }
static int mel_frame(void) {
    const Clip *c = &CLP[M.clip]; int n = c->n, f = (int)(M.t * c->fps);
    if (n <= 1) return 0;
    if (M.loop) { int per = 2 * (n - 1); f %= per; return f < n ? f : per - f; }      /* ping-pong: no jump at the loop point */
    return f >= n ? n - 1 : f;
}
static void mel_update(float dt) {
    M.t += dt; if (M.pop > 0) M.pop = maxf(0, M.pop - dt * 5.0f);
    if (M.voice_t > 0) M.voice_t -= dt;
    if (M.say_t > 0) M.say_t -= dt;
    if (M.am_cool > 0) M.am_cool -= dt;
    if (M.react > 0) { M.react -= dt; if (M.react <= 0) mel_set(CL_IDLE, 1); }
    M.red += (M.red_to - M.red) * minf(1.0f, dt * 2.5f);
    float want = maxf(0, DESK_U + 4.0f - CLP[M.clip].avail);
    if (M.clip == CL_RAGE) want = -clampf(CLP[CL_RAGE].avail - DESK_U - 8.0f, 0, 62.0f);        /* he jumps up from his chair */
    M.dy += (want - M.dy) * minf(1.0f, dt * 14.0f);
}
static void draw_mel_f(float fx, float fy, float sc, float alpha, int flip) {
    const Image *im = clip_frame(&CLP[M.clip], mel_frame());
    float p = M.pop > 0 ? 1.0f + 0.09f * sinf(M.pop * PI) : 1.0f, r = clampf(M.red, 0, 1);
    u32 col = RGBA(255, (int)(255.0f - 135.0f * r), (int)(255.0f - 150.0f * r), (int)(clampf(alpha, 0, 1) * 255.0f + 0.5f));      /* the angrier, the redder */
    gfx_image_tint(im, fx, fy + (flip ? -M.dy : M.dy) * sc, sc * p, sc * p, flip ? PI : 0.0f, col, 0);
}
static void draw_mel(float fx, float fy, float sc, float alpha) { draw_mel_f(fx, fy, sc, alpha, 0); }
/* speech */
static void bubble_place(void);
static void say_text(const char *txt, float dur, float size) {
    strncpy(M.say, txt, sizeof(M.say) - 1); M.say[sizeof(M.say) - 1] = 0; M.say_t = M.say_dur = dur; M.say_size = size;
    if (scr == SC_PLAY) bubble_place();
}
static void say2(int vid, int fallback, const char *txt) {
    if (!SND[vid] && fallback >= 0) vid = fallback;
    const Sound *s = SND[vid]; float d = s ? (float)s->n / (float)s->rate : 1.0f;
    if (speech_on()) snd_play_voice(s, 1.0f);            /* Settings: the voice and the bubbles can be switched off separately */
    M.voice_t = d;
    if (txt && CFG.bubbles) say_text(txt, maxf(maxf(d + 0.3f, 1.3f), 0.9f + 0.028f * (float)strlen(txt)), 27.0f);
}
static void say(int vid, const char *txt) { say2(vid, -1, txt); }

/* ============================== particles ============================== */
enum { PT_DOT, PT_SPARK, PT_STAR, PT_SHARD, PT_RING, PT_PUFF, PT_CONF, PT_DROP };
typedef struct { float x, y, vx, vy, rot, vr, life, max, size, grav, drag; u32 col; int kind; } Part;
#define MAXP 420
static Part parts[MAXP]; static int nparts;
static Part *part_new(int kind, float x, float y, float vx, float vy, float life, float size, u32 col) {
    static Part none;
    Part *p = !CFG.sparks ? &none : &parts[nparts < MAXP ? nparts++ : (int)(rnd_u32() % MAXP)];      /* Settings: no sparks, no confetti */
    p->kind = kind; p->x = x; p->y = y; p->vx = vx; p->vy = vy; p->life = p->max = life; p->size = size; p->col = col;
    p->rot = rnd_range(0, TAU); p->vr = rnd_range(-6, 6); p->grav = 0; p->drag = 0;
    return p;
}
static void parts_update(float dt) {
    for (int i = 0; i < nparts; i++) {
        Part *p = &parts[i]; p->life -= dt;
        if (p->life <= 0) { parts[i] = parts[--nparts]; i--; continue; }
        float k = 1.0f - p->drag * dt; if (k < 0) k = 0;
        p->vx *= k; p->vy = p->vy * k + p->grav * dt; p->x += p->vx * dt; p->y += p->vy * dt; p->rot += p->vr * dt;
    }
}
static void parts_draw(void) {
    for (int i = 0; i < nparts; i++) {
        const Part *p = &parts[i]; float f = p->life / p->max, a = f < 0.4f ? f / 0.4f : 1.0f;
        switch (p->kind) {
        case PT_DOT: { float s = p->size / 16.0f * (0.4f + 0.6f * f); gfx_image_tint(I_dot, p->x, p->y, s, s, 0, color_alpha(p->col, a), 0); } break;
        case PT_SPARK: { float s = p->size / 48.0f * (0.3f + 0.7f * f); gfx_image_tint(I_spark, p->x, p->y, s, s, p->rot, color_alpha(p->col, a), 1); } break;
        case PT_STAR: { float s = p->size / 60.0f * (0.5f + 0.5f * f); gfx_image_ex(I_star, p->x, p->y, s, s, p->rot, a); } break;
        case PT_SHARD: {
            float s = p->size, c = cosf(p->rot), n = sinf(p->rot); u32 col = color_alpha(p->col, a);
            gfx_tri(p->x + c * s, p->y + n * s, p->x - c * s * 0.6f - n * s * 0.5f, p->y - n * s * 0.6f + c * s * 0.5f,
                    p->x - c * s * 0.4f + n * s * 0.7f, p->y - n * s * 0.4f - c * s * 0.7f, col);
        } break;
        case PT_RING: { float e = ease_out_cubic(1.0f - f); gfx_ring(p->x, p->y, p->size * (0.4f + 1.4f * e), 5.0f * f + 1.0f, color_alpha(p->col, f)); } break;
        case PT_PUFF: { float s = p->size / 75.0f * (0.6f + 1.2f * (1.0f - f)); gfx_image_tint(I_wglow, p->x, p->y, s, s, 0, color_alpha(p->col, f * 0.8f), 0); } break;
        case PT_CONF: {
            float w = p->size, h = p->size * 0.55f * fabsf(cosf(p->rot * 1.7f)) + 1.0f, c = cosf(p->rot), n = sinf(p->rot); u32 col = color_alpha(p->col, a);
            float ax = c * w, ay = n * w, bx = -n * h, by = c * h;
            gfx_tri(p->x - ax - bx, p->y - ay - by, p->x + ax - bx, p->y + ay - by, p->x + ax + bx, p->y + ay + by, col);
            gfx_tri(p->x - ax - bx, p->y - ay - by, p->x + ax + bx, p->y + ay + by, p->x - ax + bx, p->y - ay + by, col);
        } break;
        case PT_DROP: gfx_circle(p->x, p->y, p->size * (0.4f + 0.6f * f), color_alpha(p->col, a)); break;
        }
    }
}
static void fx_ring(float x, float y, float size, u32 col, float life) { part_new(PT_RING, x, y, 0, 0, life, size, col); }
static void fx_star(float x, float y) {
    fx_ring(x, y, 34, 0xFFF3A0FF, 0.45f);
    for (int i = 0; i < 12; i++) { float a = rnd_range(0, TAU), v = rnd_range(120, 380); Part *p = part_new(PT_SPARK, x, y, cosf(a) * v, sinf(a) * v, rnd_range(0.35f, 0.7f), rnd_range(26, 52), 0xFFE680FF); p->drag = 3.0f; }
    for (int i = 0; i < 5; i++) { float a = rnd_range(0, TAU), v = rnd_range(140, 300); Part *p = part_new(PT_STAR, x, y, cosf(a) * v, sinf(a) * v - 80, rnd_range(0.5f, 0.8f), rnd_range(14, 22), WHITE); p->grav = 500; p->drag = 1.5f; }
}
static void fx_cut(float x, float y) {
    part_new(PT_SPARK, x, y, 0, 0, 0.18f, 70, WHITE)->vr = 0;
    for (int i = 0; i < 7; i++) { float a = rnd_range(0, TAU), v = rnd_range(60, 220); Part *p = part_new(PT_DOT, x, y, cosf(a) * v, sinf(a) * v - 40, rnd_range(0.3f, 0.55f), rnd_range(7, 12), (i & 1) ? 0xF3D49BFF : 0xC98F4EFF); p->grav = 700; p->drag = 1.0f; }
}
static void fx_pop(float x, float y) {
    fx_ring(x, y, 44, 0xD8F6FFFF, 0.3f);
    for (int i = 0; i < 14; i++) { float a = i * TAU / 14 + rnd_range(-0.15f, 0.15f), v = rnd_range(160, 300); Part *p = part_new(PT_DROP, x + cosf(a) * 38, y + sinf(a) * 38, cosf(a) * v, sinf(a) * v, rnd_range(0.25f, 0.45f), rnd_range(3, 6), 0xCFF3FFFF); p->grav = 600; p->drag = 2.0f; }
}
static void fx_blow(const Blower *b) {
    for (int i = 0; i < 9; i++) {
        float sp = rnd_range(-0.22f, 0.22f), c = cosf(b->ang + sp), s = sinf(b->ang + sp), v = rnd_range(260, 620);
        Part *p = part_new(PT_PUFF, b->x + b->dx * 62, b->y + b->dy * 62, c * v, s * v, rnd_range(0.35f, 0.6f), rnd_range(22, 40), 0xFFFFFFFF); p->drag = 2.4f;
    }
}
static void fx_break(float x, float y) {
    static const u32 cols[5] = { 0xCDEFFFFF, 0x9ED9F5FF, 0xFFFFFFFF, 0x7FC3E8FF, 0xD9363EFF };
    fx_ring(x, y, 40, WHITE, 0.3f);
    for (int i = 0; i < 20; i++) { float a = rnd_range(0, TAU), v = rnd_range(120, 480); Part *p = part_new(PT_SHARD, x, y, cosf(a) * v, sinf(a) * v - 120, rnd_range(0.6f, 1.1f), rnd_range(6, 14), cols[i % 5]); p->grav = 1100; p->drag = 0.6f; p->vr = rnd_range(-12, 12); }
    for (int i = 0; i < 10; i++) { float a = rnd_range(0, TAU), v = rnd_range(100, 300); Part *p = part_new(PT_DROP, x, y, cosf(a) * v, sinf(a) * v - 60, rnd_range(0.4f, 0.7f), rnd_range(3, 6), 0xDFF6FFFF); p->grav = 900; }
    shake_t = 0.35f; shake_amp = 9; flash_t = 0.12f;
}
static void fx_eat(float x, float y) {
    fx_ring(x, y, 30, 0xFFFFFFFF, 0.35f);
    for (int i = 0; i < 10; i++) { float a = rnd_range(-PI, 0), v = rnd_range(120, 320); Part *p = part_new(PT_SPARK, x, y, cosf(a) * v, sinf(a) * v, rnd_range(0.35f, 0.6f), rnd_range(24, 44), (i & 1) ? 0xBFF6FFFF : 0xFFFFFFFF); p->drag = 2.5f; }
    for (int i = 0; i < 8; i++) { float a = rnd_range(-PI, 0), v = rnd_range(120, 300); Part *p = part_new(PT_DROP, x, y, cosf(a) * v, sinf(a) * v, rnd_range(0.35f, 0.6f), rnd_range(3, 5), 0xCFF3FFFF); p->grav = 900; }
}
static void fx_confetti(float x0, float x1, float y, int n) {
    static const u32 cols[6] = { C_GOLD, C_PINK, C_CYAN, C_GREEN1, 0xFFFFFFFF, C_VIO1 };
    for (int i = 0; i < n; i++) { Part *p = part_new(PT_CONF, rnd_range(x0, x1), y + rnd_range(-20, 20), rnd_range(-160, 160), rnd_range(-420, -60), rnd_range(1.6f, 2.8f), rnd_range(5, 9), cols[rnd_u32() % 6]); p->grav = 520; p->drag = 1.1f; p->vr = rnd_range(-7, 7); }
}

/* ============================== small drawing helpers ============================== */
static void arc(float cx, float cy, float r, float a0, float a1, float th, u32 col) {
    int n = (int)(fabsf(a1 - a0) * r / 4.0f) + 2; if (n > 64) n = 64;
    float px = cx + cosf(a0) * r, py = cy + sinf(a0) * r;
    for (int i = 1; i <= n; i++) { float a = a0 + (a1 - a0) * (float)i / (float)n, x = cx + cosf(a) * r, y = cy + sinf(a) * r; gfx_capsule(px, py, x, y, th * 0.5f, col); px = x; py = y; }
}
static void dashed_circle(float cx, float cy, float r, float ph, float th, u32 col) {
    int n = (int)(TAU * r / 30.0f); if (n < 8) n = 8;
    for (int i = 0; i < n; i++) {
        float a0 = ph + i * TAU / n, a1 = a0 + TAU / n * 0.5f;
        gfx_capsule(cx + cosf(a0) * r, cy + sinf(a0) * r, cx + cosf(a1) * r, cy + sinf(a1) * r, th * 0.5f, col);
    }
}
enum { IC_NONE, IC_PLAY, IC_PAUSE, IC_RESTART, IC_GRID, IC_BACK, IC_NEXT, IC_SOUND, IC_SOUND_OFF, IC_MUSIC, IC_MUSIC_OFF, IC_FULL, IC_EXIT, IC_HINT, IC_LOCK, IC_HOME,
       IC_CUP, IC_EDIT, IC_TRASH, IC_OK, IC_PLUS, IC_MINUS, IC_UP, IC_DOWN, IC_GLOBE, IC_ROT, IC_COPY, IC_GEAR, IC_HEART, IC_USER, IC_EYE, IC_EYE_OFF, IC_GET };
static void icon(int ic, float x, float y, float s, u32 c) {
    float t = s * 0.17f;
    switch (ic) {
    case IC_PLAY: gfx_tri(x - s * 0.38f, y - s * 0.58f, x - s * 0.38f, y + s * 0.58f, x + s * 0.62f, y, c); break;
    case IC_PAUSE: gfx_capsule(x - s * 0.3f, y - s * 0.42f, x - s * 0.3f, y + s * 0.42f, t, c); gfx_capsule(x + s * 0.3f, y - s * 0.42f, x + s * 0.3f, y + s * 0.42f, t, c); break;
    case IC_RESTART: {
        float r = s * 0.52f, a1 = 300.0f * PI / 180.0f; arc(x, y, r, 25.0f * PI / 180.0f, a1, t * 1.7f, c);
        float px = x + cosf(a1) * r, py = y + sinf(a1) * r, tx = -sinf(a1), ty = cosf(a1), rx = cosf(a1), ry = sinf(a1), h = s * 0.42f, w = s * 0.34f;
        gfx_tri(px + tx * h, py + ty * h, px + rx * w, py + ry * w, px - rx * w, py - ry * w, c);
    } break;
    case IC_GRID: for (int i = 0; i < 4; i++) { float ox = (i & 1) ? s * 0.08f : -s * 0.52f, oy = (i & 2) ? s * 0.08f : -s * 0.52f; gfx_rrect(x + ox, y + oy, s * 0.44f, s * 0.44f, s * 0.11f, c); } break;
    case IC_BACK: gfx_capsule(x + s * 0.2f, y - s * 0.48f, x - s * 0.3f, y, t, c); gfx_capsule(x - s * 0.3f, y, x + s * 0.2f, y + s * 0.48f, t, c); break;
    case IC_NEXT: gfx_capsule(x - s * 0.2f, y - s * 0.48f, x + s * 0.3f, y, t, c); gfx_capsule(x + s * 0.3f, y, x - s * 0.2f, y + s * 0.48f, t, c); break;
    case IC_SOUND: case IC_SOUND_OFF:
        gfx_rrect(x - s * 0.62f, y - s * 0.2f, s * 0.36f, s * 0.4f, s * 0.07f, c);
        gfx_tri(x - s * 0.42f, y, x - s * 0.02f, y - s * 0.52f, x - s * 0.02f, y + s * 0.52f, c);
        if (ic == IC_SOUND) { arc(x + s * 0.02f, y, s * 0.3f, -0.8f, 0.8f, t * 1.3f, c); arc(x + s * 0.02f, y, s * 0.58f, -0.8f, 0.8f, t * 1.3f, c); }
        else { gfx_capsule(x + s * 0.2f, y - s * 0.22f, x + s * 0.62f, y + s * 0.22f, t * 0.75f, c); gfx_capsule(x + s * 0.62f, y - s * 0.22f, x + s * 0.2f, y + s * 0.22f, t * 0.75f, c); }
        break;
    case IC_MUSIC: case IC_MUSIC_OFF:
        gfx_circle(x - s * 0.3f, y + s * 0.4f, s * 0.2f, c); gfx_circle(x + s * 0.32f, y + s * 0.26f, s * 0.2f, c);
        gfx_capsule(x - s * 0.14f, y + s * 0.4f, x - s * 0.14f, y - s * 0.4f, t * 0.6f, c); gfx_capsule(x + s * 0.48f, y + s * 0.26f, x + s * 0.48f, y - s * 0.54f, t * 0.6f, c);
        gfx_capsule(x - s * 0.14f, y - s * 0.4f, x + s * 0.48f, y - s * 0.54f, t * 0.9f, c);
        if (ic == IC_MUSIC_OFF) gfx_capsule(x - s * 0.6f, y - s * 0.6f, x + s * 0.6f, y + s * 0.6f, t * 0.8f, C_RED1);
        break;
    case IC_FULL: for (int i = 0; i < 4; i++) {
            float sx = (i & 1) ? 1.0f : -1.0f, sy = (i & 2) ? 1.0f : -1.0f, cx = x + sx * s * 0.5f, cy = y + sy * s * 0.5f;
            gfx_capsule(cx, cy, cx - sx * s * 0.32f, cy, t * 0.75f, c); gfx_capsule(cx, cy, cx, cy - sy * s * 0.32f, t * 0.75f, c);
        } break;
    case IC_EXIT: gfx_capsule(x - s * 0.4f, y - s * 0.4f, x + s * 0.4f, y + s * 0.4f, t, c); gfx_capsule(x + s * 0.4f, y - s * 0.4f, x - s * 0.4f, y + s * 0.4f, t, c); break;
    case IC_HINT: gfx_text(&F_ui, "?", x, y, s * 1.5f, c, AL_CENTER); break;
    case IC_LOCK:
        arc(x, y - s * 0.12f, s * 0.3f, PI, TAU, t * 1.1f, c);
        gfx_rrect(x - s * 0.5f, y - s * 0.1f, s, s * 0.72f, s * 0.14f, c);
        gfx_circle(x, y + s * 0.2f, s * 0.11f, 0x00000070);
        break;
    case IC_HOME:
        gfx_tri(x - s * 0.62f, y - s * 0.02f, x, y - s * 0.62f, x + s * 0.62f, y - s * 0.02f, c);
        gfx_rrect(x - s * 0.42f, y - s * 0.06f, s * 0.84f, s * 0.6f, s * 0.08f, c);
        break;
    case IC_CUP:
        gfx_rrect(x - s * 0.4f, y - s * 0.62f, s * 0.8f, s * 0.74f, s * 0.3f, c);
        arc(x - s * 0.4f, y - s * 0.3f, s * 0.24f, PI * 0.5f, PI * 1.5f, t * 0.9f, c); arc(x + s * 0.4f, y - s * 0.3f, s * 0.24f, -PI * 0.5f, PI * 0.5f, t * 0.9f, c);
        gfx_rrect(x - s * 0.09f, y, s * 0.18f, s * 0.42f, s * 0.04f, c); gfx_rrect(x - s * 0.36f, y + s * 0.4f, s * 0.72f, s * 0.2f, s * 0.08f, c);
        break;
    case IC_EDIT:
        gfx_capsule(x - s * 0.24f, y + s * 0.24f, x + s * 0.44f, y - s * 0.44f, t * 1.3f, c);
        gfx_tri(x - s * 0.64f, y + s * 0.64f, x - s * 0.44f, y + s * 0.12f, x - s * 0.12f, y + s * 0.44f, c);
        break;
    case IC_TRASH:
        gfx_rrect(x - s * 0.52f, y - s * 0.5f, s * 1.04f, s * 0.17f, s * 0.06f, c); gfx_rrect(x - s * 0.17f, y - s * 0.68f, s * 0.34f, s * 0.22f, s * 0.06f, c);
        gfx_rrect(x - s * 0.38f, y - s * 0.24f, s * 0.76f, s * 0.9f, s * 0.12f, c);
        break;
    case IC_OK: gfx_capsule(x - s * 0.5f, y + s * 0.02f, x - s * 0.14f, y + s * 0.4f, t, c); gfx_capsule(x - s * 0.14f, y + s * 0.4f, x + s * 0.54f, y - s * 0.4f, t, c); break;
    case IC_PLUS: gfx_capsule(x - s * 0.5f, y, x + s * 0.5f, y, t, c); gfx_capsule(x, y - s * 0.5f, x, y + s * 0.5f, t, c); break;
    case IC_MINUS: gfx_capsule(x - s * 0.5f, y, x + s * 0.5f, y, t, c); break;
    case IC_UP: gfx_capsule(x - s * 0.48f, y + s * 0.22f, x, y - s * 0.28f, t, c); gfx_capsule(x, y - s * 0.28f, x + s * 0.48f, y + s * 0.22f, t, c); break;
    case IC_DOWN: gfx_capsule(x - s * 0.48f, y - s * 0.22f, x, y + s * 0.28f, t, c); gfx_capsule(x, y + s * 0.28f, x + s * 0.48f, y - s * 0.22f, t, c); break;
    case IC_GLOBE:
        gfx_ring(x, y, s * 0.62f, t * 0.8f, c); gfx_capsule(x - s * 0.58f, y, x + s * 0.58f, y, t * 0.4f, c); gfx_capsule(x, y - s * 0.58f, x, y + s * 0.58f, t * 0.4f, c);
        arc(x - s * 0.9f, y, s * 1.1f, -0.55f, 0.55f, t * 0.8f, c); arc(x + s * 0.9f, y, s * 1.1f, PI - 0.55f, PI + 0.55f, t * 0.8f, c);
        break;
    case IC_ROT: {
        float r = s * 0.5f, a1 = 250.0f * PI / 180.0f; arc(x, y, r, -70.0f * PI / 180.0f, a1, t * 1.5f, c);
        float px = x + cosf(a1) * r, py = y + sinf(a1) * r, tx = -sinf(a1), ty = cosf(a1), rx = cosf(a1), ry = sinf(a1), h = s * 0.4f, w = s * 0.32f;
        gfx_tri(px + tx * h, py + ty * h, px + rx * w, py + ry * w, px - rx * w, py - ry * w, c);
    } break;
    case IC_COPY: gfx_rrect(x - s * 0.5f, y - s * 0.5f, s * 0.7f, s * 0.7f, s * 0.12f, color_alpha(c, 0.6f)); gfx_rrect(x - s * 0.2f, y - s * 0.2f, s * 0.7f, s * 0.7f, s * 0.12f, c); break;
    case IC_GEAR:
        for (int i = 0; i < 8; i++) { float a = (float)i * TAU / 8.0f + 0.39f, ca = cosf(a), sa = sinf(a); gfx_capsule(x + ca * s * 0.42f, y + sa * s * 0.42f, x + ca * s * 0.66f, y + sa * s * 0.66f, t * 0.95f, c); }
        gfx_ring(x, y, s * 0.4f, s * 0.24f, c);
        break;
    case IC_HEART:
        gfx_circle(x - s * 0.29f, y - s * 0.2f, s * 0.34f, c); gfx_circle(x + s * 0.29f, y - s * 0.2f, s * 0.34f, c);
        gfx_tri(x - s * 0.6f, y - s * 0.02f, x + s * 0.6f, y - s * 0.02f, x, y + s * 0.66f, c);
        gfx_rect(x - s * 0.3f, y - s * 0.24f, s * 0.6f, s * 0.26f, c);
        break;
    case IC_USER:
        gfx_circle(x, y - s * 0.36f, s * 0.36f, c);
        gfx_rrect(x - s * 0.7f, y + s * 0.1f, s * 1.4f, s * 1.1f, s * 0.55f, c);
        break;
    case IC_EYE: case IC_EYE_OFF:
        arc(x, y + s * 0.62f, s * 0.95f, -PI * 0.5f - 0.72f, -PI * 0.5f + 0.72f, t * 0.9f, c); arc(x, y - s * 0.62f, s * 0.95f, PI * 0.5f - 0.72f, PI * 0.5f + 0.72f, t * 0.9f, c);
        gfx_circle(x, y, s * 0.2f, c);
        if (ic == IC_EYE_OFF) gfx_capsule(x - s * 0.56f, y + s * 0.5f, x + s * 0.56f, y - s * 0.5f, t * 0.8f, c);
        break;
    case IC_GET:
        gfx_capsule(x, y - s * 0.6f, x, y + s * 0.12f, t, c); gfx_capsule(x - s * 0.34f, y - s * 0.2f, x, y + s * 0.16f, t, c); gfx_capsule(x + s * 0.34f, y - s * 0.2f, x, y + s * 0.16f, t, c);
        gfx_capsule(x - s * 0.52f, y + s * 0.56f, x + s * 0.52f, y + s * 0.56f, t, c);
        break;
    }
}
static int in_box(float px, float py, float x, float y, float w, float h) { return px >= x - w * 0.5f && px <= x + w * 0.5f && py >= y - h * 0.5f && py <= y + h * 0.5f; }
/* Buttons are evaluated once per frame, but a press and its release may both arrive between two frames
   (touch, trackpad taps) and the pointer may have moved on since: test the recorded press/release points. */
static int btn_logic(int id, float x, float y, float w, float h, int enabled) {
    int ok = enabled && !ui_block, inside = ok && in_box(P.x, P.y, x, y, w, h);
    if (ok && P.pressed && in_box(P.downx, P.downy, x, y, w, h)) P.active = id;
    float target = (inside && P.down && P.active == id) ? -1.0f : (inside ? 1.0f : 0.0f);
    B_anim[id] += (target - B_anim[id]) * minf(1.0f, g_dt * 20.0f);
    if (ok && P.released && P.active == id && in_box(P.upx, P.upy, x, y, w, h)) { P.active = 0; P.released = 0; sfx(S_CLICK, 0.7f, x); return 1; }
    return 0;
}
static int wbtn(int id, float x, float y, float w, float h, const char *label, u32 c0, u32 c1, float tsize, int ic, int enabled) {
    int click = btn_logic(id, x, y, w, h, enabled);
    float a = B_anim[id], s = 1.0f + 0.045f * maxf(a, 0), press = a < 0 ? -a : 0;
    float W = w * s, H = h * s, X = x - W * 0.5f, Y = y - H * 0.5f + press * 4.0f, rad = H * 0.38f;
    if (!enabled) { c0 = 0x8C88A8FFu; c1 = 0x5C5878FFu; }
    gfx_rrect(X - 2, y - H * 0.5f + 9, W + 4, H, rad, 0x00000048);
    gfx_rrect(X, y - H * 0.5f + 6, W, H, rad, color_lerp(c1, 0x000000FF, 0.45f));
    gfx_rrect_grad(X, Y, W, H, rad, c0, c1);
    gfx_rrect(X + 7, Y + 5, W - 14, H * 0.40f, H * 0.22f, 0xFFFFFF34);
    float tx = x, ty = Y + H * 0.5f - 1;
    if (ic) { float tw = gfx_text_w(&F_ui, label, tsize * s), is = tsize * s * 0.48f; tx = x + is * 0.8f; icon(ic, tx - tw * 0.5f - is * 1.25f, ty, is, WHITE); }
    gfx_text(&F_ui, label, tx, ty, tsize * s, enabled ? WHITE : 0xFFFFFFA0u, AL_CENTER);
    return click;
}
static int rbtn(int id, float x, float y, float r, int ic, u32 c0, u32 c1, int enabled) {
    int click = btn_logic(id, x, y, r * 2, r * 2, enabled);
    float a = B_anim[id], s = 1.0f + 0.07f * maxf(a, 0), press = a < 0 ? -a : 0, R = r * s, Y = y + press * 3.0f;
    if (!enabled) { c0 = 0x8C88A8FFu; c1 = 0x5C5878FFu; }
    gfx_circle(x, y + 7, R + 1, 0x00000048);
    gfx_circle(x, y + 4.5f, R, color_lerp(c1, 0x000000FF, 0.45f));
    gfx_rrect_grad(x - R, Y - R, R * 2, R * 2, R, c0, c1);
    gfx_rrect(x - R * 0.62f, Y - R * 0.86f, R * 1.24f, R * 0.7f, R * 0.35f, 0xFFFFFF30);
    icon(ic, x + 1.5f, Y + 2.0f, R * 0.74f, 0x00000050); icon(ic, x, Y, R * 0.74f, WHITE);
    return click;
}
static void panel(float x, float y, float w, float h) {
    gfx_rrect(x - 4, y + 6, w + 8, h + 8, 36, 0x00000060);
    gfx_rrect(x, y, w, h, 34, C_EDGE);
    gfx_rrect_grad(x + 5, y + 5, w - 10, h - 10, 29, C_PANEL1, C_PANEL2);
    gfx_rrect(x + 14, y + 12, w - 28, 26, 13, 0xFFFFFF14);
}
/* an on/off switch; returns 1 when it was clicked */
static int tgl(int id, float x, float y, int on, int enabled) {
    int click = btn_logic(id, x, y, 76, 44, enabled); float a = B_anim[id], w = 62, h = 32, k = on ? 1.0f : 0.0f;
    u32 c = !enabled ? 0x5C5878FFu : (on ? C_GREEN2 : 0x4A4470FFu);
    gfx_rrect(x - w * 0.5f - 2, y - h * 0.5f - 2, w + 4, h + 4, h * 0.5f + 2, 0x0E0A2EC0u);
    gfx_rrect(x - w * 0.5f, y - h * 0.5f, w, h, h * 0.5f, a > 0 ? color_lerp(c, WHITE, 0.12f * a) : c);
    gfx_circle(x + (k - 0.5f) * (w - h), y, h * 0.5f - 4, enabled ? WHITE : 0xFFFFFF90u);
    return click;
}
/* a slider: the value is 0..1; returns 1 while it is being dragged, 2 in the frame it is let go */
static int sld_drag;
static int slider(int id, float x, float y, float w, float *v, u32 col) {
    int res = 0;
    if (!ui_block && P.pressed && P.downx > x - 24 && P.downx < x + w + 24 && fabsf(P.downy - y) < 28) { P.active = id; sld_drag = id; }
    if (sld_drag == id) {
        if (P.down) { *v = clampf((P.x - x) / w, 0, 1); res = 1; }
        else { if (P.released && P.upx > -500.0f) *v = clampf((P.upx - x) / w, 0, 1); sld_drag = 0; res = 2; }      /* (a finger that was lifted is reported far away) */
    }
    float kx = x + *v * w;
    gfx_rrect(x - 4, y - 5, w + 8, 10, 5, 0x0E0A2EC0u); gfx_rrect(x, y - 3, w, 6, 3, 0xFFFFFF38u); if (*v > 0.004f) gfx_rrect(x, y - 3, *v * w, 6, 3, col);
    gfx_circle(kx, y + 2, 15, 0x00000050u); gfx_circle(kx, y, res == 1 ? 15 : 13, WHITE); gfx_circle(kx, y, res == 1 ? 9 : 7, col);
    return res;
}
static void star_icon(float x, float y, float size, int full, float alpha) { float s = size / 60.0f; gfx_image_ex(full ? I_star : I_star0, x, y, s, s, 0, alpha); }

/* background (cover-scaled once into a cache at framebuffer resolution) */
/* Big static glows are baked into the cache too: full-screen additive sprites are the most
   expensive thing a software renderer can do every frame. */
enum { DECO_NONE, DECO_MENU, DECO_LEVEL, DECO_EDIT };
static void editor_backdrop(int which);
static Image *bgc; static u32 bgc_key;
static Image *snap; static int snap_ok;
static void bg_draw(int which, float darken, int deco, int arg, float sx, float sy) {
    u32 key = 1u + (u32)which * 1000003u + (u32)(darken * 100.0f) * 7919u + (u32)deco * 104729u + (u32)arg * 613u;
    int w = gfx_fb_w(), h = gfx_fb_h();
    if (!bgc || bgc->w != w || bgc->h != h) { if (bgc) img_free(bgc); bgc = img_new(w, h, 1); bgc_key = 0; }
    if (bgc_key != key) {
        gfx_set_target(bgc); gfx_offset(0, 0); gfx_cover(I_bg[which], darken);
        if (deco == DECO_MENU) gfx_image_tint(I_wglow, (float)arg, 318, 6.0f, 5.0f, 0, RGBA(150, 110, 255, 80), 1);
        else if (deco == DECO_EDIT) editor_backdrop(which);
        else if (deco == DECO_LEVEL && S.has_mel) gfx_image_tint(I_wglow, S.mx, mel_fy() + (CUR.flip ? -6.0f : 6.0f), 2.9f, 2.4f, 0, RGBA(170, 150, 255, 46), 1);
        gfx_set_target(NULL); bgc_key = key;
    }
    gfx_offset(sx, sy); gfx_copy_from(bgc);
}
static void snap_take(void) {
    int w = gfx_fb_w(), h = gfx_fb_h();
    if (!snap || snap->w != w || snap->h != h) { if (snap) img_free(snap); snap = img_new(w, h, 1); }
    gfx_grab(snap); snap_ok = 1;
}
static int snap_usable(void) { return snap_ok && snap && snap->w == gfx_fb_w() && snap->h == gfx_fb_h(); }

/* ============================== level state ============================== */
enum { PH_PLAY, PH_WIN, PH_FAIL };
enum { LM_PLAY, LM_DEMO, LM_GHOST, LM_REPLAY };     /* a normal run / the stored solution as a demo / the same as a normal-looking run (capture aid) / a recorded run */
static int L_idx, L_mode, L_demo, L_ghost, L_replay, L_phase, L_paused, L_acted, L_newbest, L_shown, L_react_done, L_conf, L_ticks, L_hurry;
static int g_capflags;                              /* capture aid: 1 hide the HUD, 2 hide speech bubbles, 4 bare menu */
static int L_auto;                                  /* test aid: the stored solution is fed in as if the player did it (a real run, recorded and counted) */
static int L_demo_done[40], star_seen[MAX_STARS], L_got;
static float L_acc, L_t, L_pt, L_failhold, hud_pop[MAX_STARS], L_toast_t; static const char *L_toast = "";
static int V_attempt, V_fails, V_breaks, V_red_said, G_streak, G_give;      /* V_: since the level was entered, G_: across levels */
static int play_back = SC_LEVELS, play_back_arg;    /* where "back" leads from the level */
typedef struct { float x0, y0, x1, y1, t; int slot, on; } Fly;
static Fly fly[MAX_STARS];
typedef struct { float x, y, t; } TPt;
#define TRAIL_N 40
static TPt trail[TRAIL_N]; static int trail_n;
typedef struct { float x0, y0, x1, y1, t; } Slash;
static Slash slash[6];
static float tapfx_x, tapfx_y, tapfx_t;
typedef struct { float x, y, t, dir, seed; int on, edge; } Spill;          /* the spilled drink */
static Spill spill[3]; static int spill_k;
static int rail_drag = -1, rail_q = -1, steal_rope = -1;

/* Replays. The simulation is deterministic and advances in whole ticks, so a run is fully described by the list of
   player actions: tick << 15 | action << 12 | argument. */
#define REC_MAX 1500
typedef struct { int n, ticks, stars, over; u32 a[REC_MAX]; } Replay;
static Replay REC, PLAYB; static int playb_i; static char playb_who[48];
static int playb_tas;                               /* the recording that is played is a TAS run (2: the exhaustive search has finished for it) */

/* How fast a recording is shown (any one: a player's, a TAS run, the stored solution): 0.1x .. 5x. Only the pace of the
   show changes: the simulation still goes through exactly the same steps. Every launch starts at 1x. */
static float rp_speed = 1.0f, rp_now = 1.0f;         /* rp_now: the pace of this frame (1 when nothing is being watched) */
#define RP_X 452.0f
#define RP_W 300.0f
#define RP_Y 42.0f
static int rp_viewing(void) { return scr == SC_PLAY && (L_replay || L_demo); }
static float rp_pos(float v) { return v <= 1.0f ? (v - 0.1f) / 0.9f * 0.5f : 0.5f + (v - 1.0f) / 4.0f * 0.5f; }
static float rp_val(float p) {
    float v = p <= 0.5f ? 0.1f + p / 0.5f * 0.9f : 1.0f + (p - 0.5f) / 0.5f * 4.0f;
    if (fabsf(p - 0.5f) < 0.03f) v = 1.0f;                                    /* 1x is easy to hit */
    return clampf(floorf(v * 10.0f + 0.5f) / 10.0f, 0.1f, 5.0f);
}
static void rp_step(int dir) {                       /* keyboard: the next / previous round value */
    static const float st[11] = { 0.1f, 0.2f, 0.3f, 0.5f, 0.7f, 1.0f, 1.5f, 2.0f, 3.0f, 4.0f, 5.0f }; int k = 0;
    if (dir > 0) { for (k = 0; k < 10 && st[k] <= rp_speed + 0.01f; k++) {} } else { for (k = 10; k > 0 && st[k] >= rp_speed - 0.01f; k--) {} }
    rp_speed = st[k];
}
static void hud_star_pos(int i, float *x, float *y, float *size) {
    if (CUR.maxst <= 3) { *x = 44.0f + 54.0f * (float)i; *y = 42.0f; *size = 46.0f; }
    else { *x = 35.0f + 33.5f * (float)(i % 5); *y = 28.0f + 28.0f * (float)(i / 5); *size = 30.0f; }
}
#define HUD_RX 1158.0f
#define HUD_PX 1228.0f
#define HUD_BY 46.0f
#define HUD_BR 28.0f
static int hud_hit(float x, float y) {
    float d0 = hypotf(x - HUD_RX, y - HUD_BY), d1 = hypotf(x - HUD_PX, y - HUD_BY);
    if (rp_viewing() && x > RP_X - 40 && x < RP_X + RP_W + 130 && y < 76) return 1;      /* the speed bar */
    return d0 < HUD_BR + 8 || d1 < HUD_BR + 8;
}
static void trail_add(float x, float y) {
    if (trail_n == TRAIL_N) { memmove(trail, trail + 1, sizeof(TPt) * (TRAIL_N - 1)); trail_n--; }
    trail[trail_n].x = x; trail[trail_n].y = y; trail[trail_n].t = g_time; trail_n++;
}
static void slash_add(float x0, float y0, float x1, float y1) {
    int k = 0; for (int i = 0; i < 6; i++) if (slash[i].t <= 0) { k = i; break; }
    slash[k].x0 = x0; slash[k].y0 = y0; slash[k].x1 = x1; slash[k].y1 = y1; slash[k].t = 0.3f;
}
static void level_key(int idx, char *out, int n);
static void cur_builtin(int idx) {
    const LevelDef *d = &g_levels[idx]; memset(&CUR, 0, sizeof(CUR));
    CUR.name = d->name; CUR.hint = d->hint; CUR.box = d->box; CUR.objs = d->objs; CUR.demo = d->demo; CUR.idx = idx; CUR.maxst = lv_max[idx];
    for (const LObj *o = d->objs; o->type != O_END; o++) if (o->type == O_MEL && o->a > 0.5f) CUR.flip = 1;
    level_key(idx, CUR.key, (int)sizeof(CUR.key));
}
static int level_hint(void) { return CUR.hint && CUR.hint[0] && !(CUR.kind == 0 && (CUR.box == 9 || lvl_done(CUR.idx))); }     /* no hints in the exam */
static void level_start(int mode) {
    L_mode = mode; L_demo = (mode == LM_DEMO); L_ghost = (mode == LM_GHOST); L_replay = (mode == LM_REPLAY); L_idx = CUR.idx; L_auto = 0;
    if (CUR.kind == 0) sel_box = CUR.box;
    sim_load(&S, CUR.objs);
    L_acc = 0; L_t = 0; L_pt = 0; L_phase = PH_PLAY; L_paused = 0; L_acted = 0; L_newbest = 0; L_shown = 0; L_react_done = 0; L_conf = 0; L_got = 0; L_ticks = 0; L_hurry = 0; L_failhold = 2.0f;
    memset(L_demo_done, 0, sizeof(L_demo_done)); memset(star_seen, 0, sizeof(star_seen)); memset(fly, 0, sizeof(fly)); memset(slash, 0, sizeof(slash));
    memset(hud_pop, 0, sizeof(hud_pop)); memset(spill, 0, sizeof(spill));
    nparts = 0; trail_n = 0; tapfx_t = 0; shake_t = 0; flash_t = 0; L_toast_t = 0; snap_ok = 0;
    REC.n = 0; REC.over = 0; REC.ticks = 0; REC.stars = 0; playb_i = 0; rail_drag = -1; steal_rope = -1;
    if (M.voice_t <= 0.2f) M.say_t = 0;                      /* a line that is still being spoken keeps its bubble across the restart */
    M.am_count = 0; M.am_cool = 0; M.idle_t = 0; M.dy = 0; mel_set(CL_IDLE, 1); M.t = rnd_range(0, 2);
    P.game = 0;
    if (mode == LM_PLAY) { V_attempt++; if (M.say_t <= 0 && CFG.hints && level_hint()) say_text(CUR.hint, 7.0f, 23.0f); }
    sfx(S_START, 0.5f, 640);
}
static void acted(void) { L_acted = 1; M.idle_t = 0; if (M.say_t > 0.25f && M.say_size < 25.0f) M.say_t = 0.25f; }

static void spill_add(float x, float y, int edge) {
    Spill *sp = &spill[spill_k++ % 3]; sp->x = x; sp->y = y; sp->t = 0; sp->on = 1; sp->edge = edge; sp->dir = (float)S.gdir; sp->seed = rnd_f();
}
static void fx_zap(float x, float y) {
    for (int i = 0; i < 14; i++) { float a = rnd_range(0, TAU), v = rnd_range(140, 420); Part *p = part_new(PT_SPARK, x, y, cosf(a) * v, sinf(a) * v, rnd_range(0.25f, 0.5f), rnd_range(26, 50), (i & 1) ? 0xFF6A8AFFu : 0xFFE0A0FFu); p->drag = 3.0f; }
    for (int i = 0; i < 6; i++) { Part *p = part_new(PT_PUFF, x + rnd_range(-14, 14), y + rnd_range(-14, 14), rnd_range(-40, 40), rnd_range(-120, -40), rnd_range(0.6f, 1.0f), rnd_range(26, 44), 0x50506CFFu); p->drag = 1.2f; }
}
static void fx_edge(float x, float y, float nx, float ny) {      /* the bottle has left the map and smashed: glass and drink fly back in */
    static const u32 cols[4] = { 0xCDEFFFFFu, 0x9ED9F5FFu, 0xFFFFFFFFu, 0x7FC3E8FFu };
    for (int i = 0; i < 16; i++) {
        float sp = rnd_range(-0.9f, 0.9f), c = cosf(sp), n = sinf(sp), dx = nx * c - ny * n, dy = nx * n + ny * c, v = rnd_range(260, 620);
        Part *p = part_new(i < 9 ? PT_SHARD : PT_DROP, x + rnd_range(-16, 16), y + rnd_range(-6, 6), dx * v, dy * v, rnd_range(0.5f, 0.95f), i < 9 ? rnd_range(5, 11) : rnd_range(3, 6), cols[i & 3]);
        p->grav = 1000.0f * (float)S.gdir; p->drag = 0.7f; p->vr = rnd_range(-12, 12);
    }
    fx_ring(x, y, 46, 0xD8F6FFFFu, 0.35f); shake_t = 0.25f; shake_amp = 6;
}
static void fx_portal(const Portal *p, u32 col) {
    fx_ring(p->x, p->y, 40, col, 0.4f);
    for (int i = 0; i < 9; i++) { float a = rnd_range(0, TAU), v = rnd_range(120, 300); Part *q = part_new(PT_SPARK, p->x, p->y, cosf(a) * v, sinf(a) * v, rnd_range(0.3f, 0.55f), rnd_range(24, 42), col); q->drag = 3.0f; }
}
static void fx_grav(void) {
    float d = (float)S.gdir;
    for (int i = 0; i < 22; i++) { Part *p = part_new(PT_SPARK, rnd_range(30, 1250), rnd_range(60, 660), 0, d * rnd_range(260, 620), rnd_range(0.35f, 0.7f), rnd_range(22, 40), (i & 1) ? 0xC9B6FFFFu : 0x9CF4FFFFu); p->drag = 1.0f; p->vr = 0; }
    flash_t = 0.07f;
}
/* capture aid: the last scripted or manual action, read by the harness through app_debug 16..19 */
static int cap_ev_n, cap_ev_type; static float cap_ev_x, cap_ev_y;
static void cap_ev(int type, float x, float y) { cap_ev_n++; cap_ev_type = type; cap_ev_x = x; cap_ev_y = y; }

static const u32 portal_col[3] = { 0xFFA23CFFu, 0x46E6FFFFu, 0x9CF04EFFu };
static void on_fail(int kind) {             /* 0 fell off the map, 1 smashed on spikes, 2 stolen, 3 burnt by a laser */
    L_phase = PH_FAIL; L_pt = 0; L_failhold = 2.0f; rail_drag = -1;
    if (L_mode != LM_PLAY) { mel_set(CL_SAD, 1); return; }
    int brk = (kind == 1 || kind == 3), v, fb = -1, clip = CL_SAD, special = 0; const char *tx;
    V_fails++; G_streak++; if (brk) V_breaks++;
    M.red_to = emo_on(EM_RED) ? clampf((float)V_breaks / 4.0f, 0, 1) : 0;   /* sad first, then angrier and redder with every broken bottle */
    if (brk && V_breaks >= 4 && !V_red_said && emo_on(EM_RED)) { V_red_said = 1; v = V_RED; fb = V_SCREAM; tx = "Я уже красный! Культурно уже не получится!"; clip = CL_ANGRY; special = 1; }
    else if (CUR.box >= 3 && V_fails >= 6 && V_fails % 6 == 0 && emo_on(EM_RAGE)) { v = V_RAGE; fb = V_SCREAM; tx = "А-А-А-А! Эх ты, #@$%&!!!"; clip = CL_RAGE; special = 1; shake_t = 0.5f; shake_amp = 7; }
    else if (G_streak >= 3 && G_streak % 8 == 3 && emo_on(EM_LUDO)) { v = V_LUDO; fb = V_LAUGH; tx = "Начинаем наше лудо-приключение! Да-да, нет-нет, да будет свет..."; clip = CL_SMILE; special = 1; }
    else if (kind == 0) { v = V_OBIDNO; tx = "Обидно, да..."; if (!emo_on(EM_SORRY)) v = -1; }
    else if (kind == 2 || V_breaks <= 1) { v = V_STOP; tx = "Стоп-стоп-стоп!"; if (!emo_on(EM_STOP)) v = -1; }
    else { v = V_SCREAM; tx = "А-А-А-А!"; if (V_breaks >= 3) clip = CL_ANGRY; if (!emo_on(EM_SCREAM)) { v = -1; clip = CL_SAD; } }
    mel_set(clip, 1); if (v >= 0) say2(v, fb, tx);                         /* a reaction that is switched off: he is just sad, silently */
    if (special) L_failhold = clampf(M.voice_t + 0.4f, 2.0f, 6.5f);
}
static void on_events(void) {
    u32 ev = S.events; S.events = 0; if (!ev) return;
    if (ev & EV_CUT) { sfx(S_CUT, 0.85f, S.cut_x); fx_cut(S.cut_x, S.cut_y); acted(); }
    if (ev & EV_ATTACH) { sfx(S_ATTACH, 0.7f, S.ev_x); fx_ring(S.ev_x, S.ev_y, 30, 0xFFFFFFFF, 0.4f); }
    if (ev & EV_BUBBLE_IN) { sfx(S_BUBBLE, 0.8f, S.c.x); fx_ring(S.c.x, S.c.y, 40, 0xD8F6FFFF, 0.3f); }
    if (ev & EV_BUBBLE_POP) { sfx(S_POP, 0.9f, S.pop_x); fx_pop(S.pop_x, S.pop_y); acted(); }
    if (ev & EV_BLOW) { const Blower *b = &S.blower[S.ev_blower]; sfx(S_BLOW, 0.8f, b->x); fx_blow(b); acted(); }
    if (ev & EV_BOUNCE) {
        const Bouncer *b = &S.bouncer[S.ev_bouncer]; sfx_p(SND[S_BOUNCE] ? S_BOUNCE : S_ATTACH, 0.8f, b->x, rnd_range(0.94f, 1.08f)); fx_ring(S.c.x, S.c.y, 26, 0xFFD0F0FFu, 0.3f);
        for (int i = 0; i < 6; i++) { float a = rnd_range(0, TAU), v = rnd_range(120, 260); Part *p = part_new(PT_SPARK, S.c.x, S.c.y, cosf(a) * v, sinf(a) * v, 0.35f, 30, 0xFFC0E8FFu); p->drag = 3; }
    }
    if (ev & EV_PORTAL) {
        const Portal *a = &S.portal[S.ev_portal], *b = &S.portal[S.ev_portal2]; u32 col = portal_col[a->pair % 3];
        sfx(SND[S_PORTAL] ? S_PORTAL : S_WHOOSH, 0.8f, b->x); fx_portal(a, col); fx_portal(b, col);
    }
    if (ev & EV_GRAV) { const GravBtn *g = &S.grav[S.ev_grav]; sfx_p(SND[S_GRAV] ? S_GRAV : S_WHOOSH, 0.8f, g->x, S.gdir < 0 ? 1.12f : 0.9f); fx_grav(); acted(); }
    if (ev & EV_THIEF_FALL) {
        sfx(SND[S_SQUEAK] ? S_SQUEAK : S_TICK, 0.8f, S.thief_x);
        for (int i = 0; i < 5; i++) { Part *p = part_new(PT_PUFF, S.thief_x + rnd_range(-10, 10), S.thief_y + rnd_range(-10, 10), rnd_range(-60, 60), rnd_range(-60, 60), 0.4f, 24, 0xFFFFFFFFu); p->drag = 2; }
    }
    if (ev & EV_STAR) for (int i = 0; i < S.nstars; i++) if (S.star[i].got && !star_seen[i]) {
        star_seen[i] = 1; int k = L_got++; if (k >= MAX_STARS) k = MAX_STARS - 1;
        float hx, hy, hs; hud_star_pos(k, &hx, &hy, &hs);
        sfx_p(S_STAR1 + (k > 2 ? 2 : k), 0.8f, S.star[i].x, k > 2 ? 1.0f + 0.06f * (float)(k - 2) : 1.0f); fx_star(S.star[i].x, S.star[i].y);
        fly[k].x0 = S.star[i].x; fly[k].y0 = S.star[i].y; fly[k].x1 = hx; fly[k].y1 = hy; fly[k].t = 0; fly[k].on = 1; fly[k].slot = k;
        M.idle_t = 0;
        if (S.mouth_dist > MOUTH_NEAR + 40 && M.clip != CL_AM) {
            if (L_got == CUR.maxst && M.voice_t <= 0 && emo_on(EM_STARS)) { mel_react(CL_OMG, 0.2f); say(V_UUU, "У-у-у-у!"); }
            else if (M.clip == CL_IDLE || M.clip == CL_BORED) mel_react(CL_SMILE, 0.0f);
        }
    }
    if (ev & EV_EAT) { sfx(S_GULP, 0.9f, S.mx); fx_eat(S.mx, S.my); L_phase = PH_WIN; L_pt = 0; L_ticks = S.tick; rail_drag = -1; if (M.clip != CL_AM) mel_set(CL_AM, 1); }
    if (ev & EV_BREAK) {
        int burn = (ev & EV_BURN) != 0;
        sfx(S_BREAK, 0.9f, S.c.x); sfx_p(S_GLASS, 0.9f, S.c.x, rnd_range(0.95f, 1.05f)); if (burn) sfx(S_ZAP, 0.9f, S.c.x);
        fx_break(S.c.x, S.c.y); if (burn) fx_zap(S.c.x, S.c.y);
        spill_add(S.c.x, S.c.y, 0); on_fail(burn ? 3 : 1);
    }
    if (ev & EV_LOST) {                                  /* it smashes somewhere below the map: glass crunch, and the drink splashes back */
        float x = clampf(S.c.x, 0, DESIGN_W), y = clampf(S.c.y, 0, DESIGN_H), nx = 0, ny = 0;
        if (S.c.y > DESIGN_H) ny = -1; else if (S.c.y < 0) ny = 1; else if (S.c.x < 0) nx = 1; else nx = -1;
        sfx(S_FAIL, 0.6f, 640); sfx_p(S_GLASS, 0.85f, x, rnd_range(0.9f, 1.0f)); sfx(S_SPLASH, 0.7f, x);
        fx_edge(x, y, nx, ny); spill_add(x, y, 1); on_fail(0);
    }
    if (ev & EV_STOLEN) {
        steal_rope = -1; float bd = 1e9f;
        for (int i = 0; i < MAX_ROPES; i++) { float tx, ty; if (S.rope[i].active && S.rope[i].thief == 1 && sim_thief_pos(&S, i, &tx, &ty)) { float d = hypotf(tx - S.c.x, ty - S.c.y); if (d < bd) { bd = d; steal_rope = i; } } }
        sfx(SND[S_STEAL] ? S_STEAL : S_FAIL, 0.9f, S.c.x); fx_ring(S.c.x, S.c.y, 40, 0xFFE680FFu, 0.4f); on_fail(2);
    }
}

static int input_ok(void) { return scr == SC_PLAY && scr_next < 0 && L_phase == PH_PLAY && !L_paused && L_mode == LM_PLAY; }
static void rec_add(int act, int arg) {
    if (L_mode != LM_PLAY) return;
    if (REC.n < REC_MAX && S.tick < (1 << 17)) REC.a[REC.n++] = ((u32)S.tick << 15) | ((u32)act << 12) | ((u32)arg & 4095u); else REC.over = 1;
}
static int player_act(int act, int arg) { if (!sim_act(&S, act, arg)) return 0; rec_add(act, arg); on_events(); return 1; }
static int player_swipe(float x0, float y0, float x1, float y1) {
    int n = sim_cut(&S, x0, y0, x1, y1); if (!n) return 0;
    for (int i = 0; i < S.ncut; i++) rec_add(ACT_CUT, S.cutlog[i].pin | ((S.cutlog[i].link + 1) << 4));
    cap_ev(1, S.cut_x, S.cut_y); on_events(); return n;
}
static int click_cut(float x, float y) {
    float best = 22.0f, bqx = 0, bqy = 0; int br = -1, bj = 0;
    for (int i = 0; i < MAX_ROPES; i++) {
        const Rope *r = &S.rope[i]; if (!r->active || r->cut) continue;
        for (int j = 0; j < r->n - 1; j++) {
            float ax = r->p[j].x, ay = r->p[j].y, dx = r->p[j + 1].x - ax, dy = r->p[j + 1].y - ay, l2 = dx * dx + dy * dy;
            float t = l2 > 1e-6f ? ((x - ax) * dx + (y - ay) * dy) / l2 : 0.5f; t = clampf(t, 0.1f, 0.9f);
            float qx = ax + dx * t, qy = ay + dy * t, d = hypotf(x - qx, y - qy);
            if (d < best) { best = d; br = i; bj = j; bqx = qx; bqy = qy; }
        }
    }
    if (br < 0) return 0;
    const Rope *r = &S.rope[br]; float dx = r->p[bj + 1].x - r->p[bj].x, dy = r->p[bj + 1].y - r->p[bj].y, l = hypotf(dx, dy); if (l < 1e-4f) return 0;
    float nx = -dy / l, ny = dx / l;
    slash_add(bqx - nx * 34, bqy - ny * 34, bqx + nx * 34, bqy + ny * 34);
    return player_swipe(bqx - nx * 12, bqy - ny * 12, bqx + nx * 12, bqy + ny * 12);
}
/* visual feedback for an action that comes from a script or a recording instead of the pointer */
static void act_fx(int act, int arg) {
    if (act == ACT_CUT) {
        int pin = arg & 15;
        for (int i = 0; i < MAX_ROPES; i++) { const Rope *r = &S.rope[i];
            if (r->active && !r->cut && r->pin == pin) { int j = ((arg >> 4) & 63) - 1; if (j < 0) j = r->n / 2; if (j > r->n - 2) j = r->n - 2;
                float x = (r->p[j].x + r->p[j + 1].x) * 0.5f, y = (r->p[j].y + r->p[j + 1].y) * 0.5f, dx = r->p[j + 1].x - r->p[j].x, dy = r->p[j + 1].y - r->p[j].y, l = hypotf(dx, dy) + 1e-4f;
                slash_add(x + dy / l * 40, y - dx / l * 40, x - dy / l * 40, y + dx / l * 40); cap_ev(1, x, y); } }
    } else if (act == ACT_POP) { tapfx_x = S.c.x; tapfx_y = S.c.y; tapfx_t = 0.4f; cap_ev(2, S.c.x, S.c.y); }
    else if (act == ACT_BLOW && arg < S.nblowers) { tapfx_x = S.blower[arg].x; tapfx_y = S.blower[arg].y; tapfx_t = 0.4f; cap_ev(3, tapfx_x, tapfx_y); }
    else if (act == ACT_GRAV && arg < S.ngravs) { tapfx_x = S.grav[arg].x; tapfx_y = S.grav[arg].y; tapfx_t = 0.4f; cap_ev(3, tapfx_x, tapfx_y); }
    else if (act == ACT_SLIDE && (arg & 15) < S.npins) { const Pin *p = &S.pin[arg & 15]; if (tapfx_t <= 0.1f) { tapfx_x = p->x; tapfx_y = p->y; tapfx_t = 0.4f; cap_ev(4, p->x, p->y); } }
}

/* ---------- speech bubble placement ---------- */
static float bubble_w, bubble_h; static int bubble_lines;
static void bubble_measure(void) {
    float size = M.say_size, maxw = 300.0f, tw = gfx_text_w(&F_txt, M.say, size);
    bubble_lines = gfx_text_wrap(&F_txt, M.say, 0, 0, size, maxw, size * 1.25f, 0, AL_CENTER, 0);
    bubble_w = (bubble_lines > 1 ? maxw : tw) + 40.0f; bubble_h = bubble_lines * size * 1.25f + 26.0f;
}
static int rect_has(float cx, float cy, float w, float h, float px, float py, float m) { return px > cx - w * 0.5f - m && px < cx + w * 0.5f + m && py > cy - h * 0.5f - m && py < cy + h * 0.5f + m; }
static void bubble_place(void) {
    bubble_measure();
    float fx = S.mx, fy = mel_fy(), w = bubble_w, h = bubble_h;
    float cand[6][2] = { { 84 + w * 0.5f, -58 }, { -(84 + w * 0.5f), -58 }, { 46 + w * 0.5f, -(76 + h * 0.5f) }, { -(46 + w * 0.5f), -(76 + h * 0.5f) }, { 0, -(96 + h * 0.5f) }, { 104 + w * 0.5f, 10 } };
    if (CUR.flip) for (int k = 0; k < 6; k++) cand[k][1] = -cand[k][1];
    int best = 0; float bs = 1e9f;
    for (int k = 0; k < 6; k++) {
        float cx = fx + cand[k][0], cy = fy + cand[k][1], sc = (float)k * 0.5f;
        if (cx - w * 0.5f < 10 || cx + w * 0.5f > DESIGN_W - 10 || cy - h * 0.5f < 10 || cy + h * 0.5f > DESIGN_H - 10) sc += 200;
        if ((cx - w * 0.5f < 245 && cy - h * 0.5f < 96) || (cx + w * 0.5f > 1100 && cy - h * 0.5f < 96)) sc += 60;
        if (rect_has(cx, cy, w, h, S.c.x, S.c.y, 40)) sc += 12;
        for (int i = 0; i < S.npins; i++) if (rect_has(cx, cy, w, h, S.pin[i].x, S.pin[i].y, 26)) sc += 10;
        for (int i = 0; i < S.nstars; i++) if (rect_has(cx, cy, w, h, S.star[i].x, S.star[i].y, 34)) sc += 14;
        for (int i = 0; i < S.nbubbles; i++) if (rect_has(cx, cy, w, h, S.bubble[i].x, S.bubble[i].y, 50)) sc += 10;
        for (int i = 0; i < S.nblowers; i++) if (rect_has(cx, cy, w, h, S.blower[i].x, S.blower[i].y, 60)) sc += 10;
        for (int i = 0; i < S.nbouncers; i++) if (rect_has(cx, cy, w, h, S.bouncer[i].x, S.bouncer[i].y, 50)) sc += 8;
        for (int i = 0; i < S.nportals; i++) if (rect_has(cx, cy, w, h, S.portal[i].x, S.portal[i].y, 40)) sc += 10;
        for (int i = 0; i < S.ngravs; i++) if (rect_has(cx, cy, w, h, S.grav[i].x, S.grav[i].y, 40)) sc += 12;
        for (int i = 0; i < S.nlasers; i++) for (int q = 0; q <= 4; q++) if (rect_has(cx, cy, w, h, lerpf(S.laser[i].x0, S.laser[i].x1, q / 4.0f), lerpf(S.laser[i].y0, S.laser[i].y1, q / 4.0f), 16)) sc += 3;
        for (int i = 0; i < S.nspikes; i++) for (int q = 0; q <= 4; q++) if (rect_has(cx, cy, w, h, lerpf(S.spikes[i].x0, S.spikes[i].x1, q / 4.0f), lerpf(S.spikes[i].y0, S.spikes[i].y1, q / 4.0f), 22)) sc += 4;
        for (int i = 0; i < MAX_ROPES; i++) if (S.rope[i].active) for (int j = 0; j < S.rope[i].n; j += 3) if (rect_has(cx, cy, w, h, S.rope[i].p[j].x, S.rope[i].p[j].y, 8)) sc += 1.5f;
        if (sc < bs) { bs = sc; best = k; }
    }
    M.say_ox = cand[best][0]; M.say_oy = cand[best][1];
}
/* draws the speech bubble; (fx,fy) = face centre, bubble centre = face + (ox,oy)*k */
static void draw_say(float fx, float fy, float ox, float oy, float k) {
    if (M.say_t <= 0 || !M.say[0]) return;
    bubble_measure();
    float age = M.say_dur - M.say_t, a = clampf(M.say_t / 0.18f, 0, 1), sc = ease_out_back(clampf(age / 0.22f, 0, 1)) * (0.85f + 0.15f * a);
    if (sc <= 0.02f) return;
    float w = bubble_w * sc, h = bubble_h * sc, cx = fx + ox * k, cy = fy + oy * k, size = M.say_size * sc;
    float dx = cx - fx, dy = cy - fy, l = hypotf(dx, dy) + 1e-4f; dx /= l; dy /= l;
    float tx = fx + dx * 54.0f * k, ty = fy + dy * 54.0f * k;                       /* tail tip near the face */
    float bx = clampf(tx, cx - w * 0.5f + 20, cx + w * 0.5f - 20), by = clampf(ty, cy - h * 0.5f + 14, cy + h * 0.5f - 14);
    float ex = bx - tx, ey = by - ty, el = hypotf(ex, ey) + 1e-4f, nx = -ey / el, ny = ex / el;
    u32 ink = color_alpha(C_INK, a), wh = color_alpha(0xFFFFFFFF, a);
    gfx_rrect(cx - w * 0.5f - 3.5f, cy - h * 0.5f - 3.5f, w + 7, h + 7, 22 * sc + 3.5f, ink);
    gfx_tri(tx - ex / el * 6, ty - ey / el * 6, bx + nx * 16, by + ny * 16, bx - nx * 16, by - ny * 16, ink);
    gfx_rrect(cx - w * 0.5f, cy - h * 0.5f, w, h, 22 * sc, wh);
    gfx_tri(tx, ty, bx + nx * 11, by + ny * 11, bx - nx * 11, by - ny * 11, wh);
    float lh = size * 1.25f;
    gfx_text_wrap(&F_txt, M.say, cx, cy - (bubble_lines - 1) * lh * 0.5f, size, 300.0f * sc + 2.0f, lh, ink, AL_CENTER, 1);
}

/* ============================== level rendering ============================== */
static void draw_rope(const Rope *r) {
    float f = r->cut ? clampf(r->fade, 0, 1) : 1.0f, k = 0.25f + 0.75f * f;
    u32 oc = 0x3B2313FFu, c0 = 0xF6DBA6FFu, c1 = 0xD9A262FFu;
    if (r->cut) { oc = color_alpha(oc, f); c0 = color_lerp(0x3B2313FFu, c0, f); c1 = color_lerp(0x3B2313FFu, c1, f); oc = 0x3B2313FFu; }
    for (int i = 0; i < r->n - 1; i++) { if (r->cut && i == r->cut_at) continue; gfx_capsule(r->p[i].x, r->p[i].y, r->p[i + 1].x, r->p[i + 1].y, 5.0f * k, oc); }
    for (int i = 0; i < r->n - 1; i++) { if (r->cut && i == r->cut_at) continue; gfx_capsule(r->p[i].x, r->p[i].y, r->p[i + 1].x, r->p[i + 1].y, 3.0f * k, (i & 1) ? c1 : c0); }
}
static void draw_spikes(const Spikes *k) {
    float dx = k->x1 - k->x0, dy = k->y1 - k->y0, l = hypotf(dx, dy); if (l < 1) return; dx /= l; dy /= l;
    float nx = -dy, ny = dx; int n = (int)(l / 20.0f + 0.5f); if (n < 1) n = 1; float st = l / n;
    for (int side = -1; side <= 1; side += 2) for (int i = 0; i < n; i++) {
        float m = (i + 0.5f) * st, px = k->x0 + dx * m, py = k->y0 + dy * m, hx = nx * 19.0f * side, hy = ny * 19.0f * side, w = st * 0.5f;
        gfx_tri(px - dx * (w + 1.5f), py - dy * (w + 1.5f), px + dx * (w + 1.5f), py + dy * (w + 1.5f), px + hx * 1.13f, py + hy * 1.13f, 0x1B1F38FFu);
        gfx_tri(px - dx * (w - 1.5f), py - dy * (w - 1.5f), px + dx * (w - 1.5f), py + dy * (w - 1.5f), px + hx, py + hy, 0xDCE5F7FFu);
        gfx_tri(px, py, px + dx * (w - 1.5f), py + dy * (w - 1.5f), px + hx, py + hy, 0x8D9AC0FFu);
    }
    gfx_capsule(k->x0, k->y0, k->x1, k->y1, 7.5f, 0x1B1F38FFu);
    gfx_capsule(k->x0, k->y0, k->x1, k->y1, 5.0f, 0x59658EFFu);
    gfx_capsule(k->x0 - nx * 1.6f, k->y0 - ny * 1.6f, k->x1 - nx * 1.6f, k->y1 - ny * 1.6f, 1.6f, 0xAEB9DAFFu);
    gfx_circle(k->x0, k->y0, 3.2f, 0xE94B5AFFu); gfx_circle(k->x1, k->y1, 3.2f, 0xE94B5AFFu);
}
static void draw_blower(const Blower *b) {
    float sq = b->squeeze, t = g_time;
    for (int i = 0; i < 3; i++) {                 /* direction chevrons */
        float ph = fmodf(t * 1.4f + i * 0.33f, 1.0f), d = 78.0f + ph * 62.0f, a = sinf(ph * PI) * 0.55f;
        float cx = b->x + b->dx * d, cy = b->y + b->dy * d, nx = -b->dy, ny = b->dx; u32 c = RGBA(255, 255, 255, (int)(a * 255));
        gfx_capsule(cx - b->dx * 7 + nx * 9, cy - b->dy * 7 + ny * 9, cx, cy, 2.2f, c);
        gfx_capsule(cx - b->dx * 7 - nx * 9, cy - b->dy * 7 - ny * 9, cx, cy, 2.2f, c);
    }
    gfx_image_ex(I_blower, b->x - b->dx * 8, b->y - b->dy * 8, 1.0f + 0.10f * sq, 1.0f - 0.30f * sq, b->ang, 1);
}
static void draw_desk(float x, float top, float sc, int floating, const Image *im) {
    if (!floating) { gfx_image_ex(im, x, top, sc, sc, 0, 1); return; }
    float cut = top + 60.0f * sc, t = g_time;
    for (int i = -1; i <= 1; i += 2) {
        float jx = x + i * 82.0f * sc, fl = 0.75f + 0.25f * sinf(t * 23.0f + i);
        gfx_image_tint(I_wglow, jx, cut + 26 * sc, 0.5f * sc, 0.95f * sc * fl, 0, RGBA(90, 230, 255, 170), 1);
        gfx_tri(jx - 11 * sc, cut + 12 * sc, jx + 11 * sc, cut + 12 * sc, jx, cut + (34 + 10 * fl) * sc, RGBA(190, 250, 255, 210));
    }
    gfx_clip(0, 0, DESIGN_W, cut); gfx_image_ex(im, x, top, sc, sc, 0, 1); gfx_clip_reset();
    gfx_rrect(x - 142 * sc, cut - 5 * sc, 284 * sc, 22 * sc, 11 * sc, 0x15103AFFu);
    gfx_rrect(x - 136 * sc, cut - 1 * sc, 272 * sc, 6 * sc, 3 * sc, C_CYAN);
    gfx_rrect(x - 98 * sc, cut + 9 * sc, 32 * sc, 8 * sc, 4 * sc, 0x3A3F6EFFu); gfx_rrect(x + 66 * sc, cut + 9 * sc, 32 * sc, 8 * sc, 4 * sc, 0x3A3F6EFFu);
}
static int mel_floating(void) { return !CUR.flip && S.my - FACE_UP + DESK_DROP + 104.0f < 650.0f; }
static void draw_mel_scene(void) {
    if (!S.has_mel) return;
    float fx = S.mx, fy = mel_fy();
    if (CUR.flip) {                                     /* upside down: the desk hangs from the ceiling */
        float top = fy - DESK_DROP;
        gfx_clip(0, top - 6, DESIGN_W, DESIGN_H); draw_mel_f(fx, fy, MEL_SC, 1.0f, 1); gfx_clip_reset();
        gfx_image_ex(I_desk, fx, top, 1.0f, 1.0f, PI, 1);
        return;
    }
    float top = fy + DESK_DROP;
    gfx_clip(0, 0, DESIGN_W, top + 6); draw_mel(fx, fy, MEL_SC, 1.0f); gfx_clip_reset();
    draw_desk(fx, top, 1.0f, mel_floating(), I_desk);
}
/* ---------- objects of the new locations ---------- */
static void draw_spills(void) {
    for (int i = 0; i < 3; i++) if (spill[i].on) {
        const Spill *sp = &spill[i]; float t = sp->t, g = ease_out_cubic(clampf(t / 0.45f, 0, 1)), a = clampf((5.0f - t) / 0.8f, 0, 1), k = sp->edge ? 1.7f : 1.0f;
        u32 c0 = RGBA(150, 215, 255, (int)(125 * a)), c1 = RGBA(240, 252, 255, (int)(190 * a));
        for (int q = 0; q < 7; q++) {
            float an = q * 0.898f + sp->seed * TAU, rr = (15.0f + 8.0f * sinf(q * 2.3f + sp->seed * 9.0f)) * g * k;
            gfx_circle(sp->x + cosf(an) * 24.0f * g * k, sp->y + sinf(an) * 12.0f * g * k, rr, c0);
        }
        gfx_circle(sp->x, sp->y, 24.0f * g * k, c0);
        if (!sp->edge) for (int q = 0; q < 4; q++) {          /* it runs down (or up, when gravity is flipped) */
            float ox = (q - 1.5f) * 13.0f + 5.0f * sinf(q * 3.1f + sp->seed * 7.0f), mx = 78.0f + 34.0f * sinf(q * 1.7f + sp->seed * 5.0f);
            float len = clampf((t - 0.12f * q) * (70.0f + 22.0f * q), 0, mx); if (len <= 0) continue;
            gfx_capsule(sp->x + ox, sp->y, sp->x + ox, sp->y + len * sp->dir, 4.6f - q * 0.5f, c0);
            gfx_circle(sp->x + ox, sp->y + len * sp->dir, 6.2f - q * 0.4f, c0); gfx_circle(sp->x + ox - 1.5f, sp->y + (len - 2.0f) * sp->dir, 2.2f, c1);
        }
        gfx_circle(sp->x - 8.0f * g * k, sp->y - 6.0f * g, 5.5f * g * k, c1); gfx_circle(sp->x + 11.0f * g * k, sp->y + 2.0f * g, 3.0f * g * k, c1);
    }
}
static void draw_rail(const Pin *p) {
    float dx = p->x1 - p->x0, dy = p->y1 - p->y0, l = hypotf(dx, dy); if (l < 1) return; dx /= l; dy /= l;
    gfx_capsule(p->x0, p->y0, p->x1, p->y1, 10.0f, 0x15103AFFu);
    gfx_capsule(p->x0, p->y0, p->x1, p->y1, 7.0f, 0x7E8AB8FFu);
    gfx_capsule(p->x0 + dy * 2.5f, p->y0 - dx * 2.5f, p->x1 + dy * 2.5f, p->y1 - dx * 2.5f, 1.6f, 0xC9D3F2FFu);
    gfx_capsule(p->x0, p->y0, p->x1, p->y1, 2.6f, 0x23284CFFu);
    for (float m = 22.0f; m < l - 10.0f; m += 22.0f) gfx_circle(p->x0 + dx * m, p->y0 + dy * m, 1.7f, 0x7E8AB8FFu);
    gfx_circle(p->x0, p->y0, 6.0f, 0xE94B5AFFu); gfx_circle(p->x1, p->y1, 6.0f, 0xE94B5AFFu);
}
static void draw_rail_knob(const Pin *p, int idx) {
    float dx = p->x1 - p->x0, dy = p->y1 - p->y0, l = hypotf(dx, dy); if (l < 1) return; dx /= l; dy /= l;
    int held = (rail_drag == idx); float w = held ? 1.0f : 0.5f + 0.5f * sinf(g_time * 4.0f), r = held ? 21.0f : 19.0f;
    for (int sd = -1; sd <= 1; sd += 2) {                /* "drag me" chevrons along the rail */
        float u = p->u + (float)sd * 40.0f / l; if (u < -0.02f || u > 1.02f) continue;
        float cx = p->x + dx * (33.0f + 4.0f * w) * sd, cy = p->y + dy * (33.0f + 4.0f * w) * sd; u32 c = RGBA(255, 255, 255, (int)(110 + 120 * w));
        gfx_capsule(cx - dx * 7 * sd + dy * 8, cy - dy * 7 * sd - dx * 8, cx, cy, 2.4f, c);
        gfx_capsule(cx - dx * 7 * sd - dy * 8, cy - dy * 7 * sd + dx * 8, cx, cy, 2.4f, c);
    }
    gfx_circle(p->x, p->y + 3, r + 1, 0x00000050u); gfx_circle(p->x, p->y, r + 2.5f, 0x15103AFFu); gfx_circle(p->x, p->y, r, held ? 0xFFE680FFu : C_CYAN);
    gfx_circle(p->x - 5, p->y - 6, r * 0.42f, 0xFFFFFF60u);
}
static void draw_bouncer(const Bouncer *b) {
    float k = b->pulse, hl = b->hl, th = 9.0f + 5.0f * sinf(k * PI);
    float x0 = b->x - b->dx * hl, y0 = b->y - b->dy * hl, x1 = b->x + b->dx * hl, y1 = b->y + b->dy * hl;
    gfx_capsule(x0, y0 + 4, x1, y1 + 4, th + 3.0f, 0x00000040u);
    gfx_capsule(x0, y0, x1, y1, th + 3.0f, 0x1B1F38FFu);
    gfx_capsule(x0, y0, x1, y1, th, color_lerp(0xFF4FA0FFu, 0xFFFFFFFFu, k * 0.6f));
    int n = (int)(hl / 14.0f); if (n < 2) n = 2;
    for (int i = -n + 1; i < n; i += 2) { float m = (float)i / (float)n * hl; gfx_capsule(b->x + b->dx * (m - 4), b->y + b->dy * (m - 4), b->x + b->dx * (m + 4), b->y + b->dy * (m + 4), th * 0.72f, 0xFFE9F5FFu); }
    gfx_capsule(x0 + b->nx * th * 0.45f, y0 + b->ny * th * 0.45f, x1 + b->nx * th * 0.45f, y1 + b->ny * th * 0.45f, 1.5f, 0xFFFFFF90u);
    gfx_circle(x0, y0, th + 1.0f, 0x1B1F38FFu); gfx_circle(x1, y1, th + 1.0f, 0x1B1F38FFu); gfx_circle(x0, y0, th - 2.0f, C_GOLD); gfx_circle(x1, y1, th - 2.0f, C_GOLD);
}
static void draw_portal(const Portal *p) {
    float t = g_time, r = PORTAL_R + 5.0f + 7.0f * sinf(p->pulse * PI); u32 c = portal_col[p->pair % 3];
    gfx_image_tint(I_wglow, p->x, p->y, 1.25f, 1.25f, 0, color_alpha(c, 0.5f), 1);
    gfx_circle(p->x, p->y + 3, r + 6, 0x00000050u); gfx_circle(p->x, p->y, r + 6.5f, 0x15103AFFu); gfx_circle(p->x, p->y, r + 4.0f, 0xA7B3D6FFu); gfx_circle(p->x, p->y, r - 1.0f, 0x15103AFFu);
    gfx_circle(p->x, p->y, r - 3.0f, color_lerp(0x0B0824FFu, c, 0.22f + 0.5f * p->pulse));
    for (int i = 0; i < 3; i++) { float a0 = t * (2.4f + 0.8f * i) * (i & 1 ? -1.0f : 1.0f) + i * 2.1f; arc(p->x, p->y, r - 8.0f - 6.5f * i, a0, a0 + 2.3f, 3.6f - 0.6f * i, color_alpha(c, 0.95f - 0.2f * i)); }
    gfx_circle(p->x, p->y, 3.5f, WHITE);
    for (int i = 0; i < 6; i++) { float a = i * TAU / 6.0f + 0.52f; gfx_circle(p->x + cosf(a) * (r + 5.2f), p->y + sinf(a) * (r + 5.2f), 1.8f, 0x4A5378FFu); }
    if (!p->keep) {                                      /* where the bottle will fly out */
        float w = 0.5f + 0.5f * sinf(t * 5.0f), d = r + 15.0f + 4.0f * w, cx = p->x + p->dx * d, cy = p->y + p->dy * d, nx = -p->dy, ny = p->dx;
        gfx_tri(cx + p->dx * 11, cy + p->dy * 11, cx + nx * 9, cy + ny * 9, cx - nx * 9, cy - ny * 9, 0x15103AFFu);
        gfx_tri(cx + p->dx * 7.5f, cy + p->dy * 7.5f, cx + nx * 5.5f + p->dx * 1.5f, cy + ny * 5.5f + p->dy * 1.5f, cx - nx * 5.5f + p->dx * 1.5f, cy - ny * 5.5f + p->dy * 1.5f, c);
    }
}
static void draw_grav(const GravBtn *g) {
    float k = g->pulse, r = 29.0f + 5.0f * sinf(k * PI), d = (float)S.gdir, bob = sinf(g_time * 4.0f) * 2.5f * d, y = g->y;
    gfx_image_tint(I_wglow, g->x, y, 1.0f, 1.0f, 0, S.gdir < 0 ? RGBA(255, 120, 220, 110) : RGBA(150, 130, 255, 90), 1);
    gfx_circle(g->x, y + 4, r + 2, 0x00000050u); gfx_circle(g->x, y, r + 3.0f, 0x15103AFFu);
    gfx_rrect_grad(g->x - r, y - r, r * 2, r * 2, r, S.gdir < 0 ? 0xFF8AD8FFu : C_VIO1, S.gdir < 0 ? 0xB8257FFFu : C_VIO2);
    gfx_rrect(g->x - r * 0.62f, y - r * 0.86f, r * 1.24f, r * 0.62f, r * 0.31f, 0xFFFFFF30u);
    float ay = y + bob;                                  /* the arrow shows where things fall now */
    gfx_capsule(g->x, ay - 11 * d, g->x, ay + 5 * d, 4.2f, WHITE);
    gfx_tri(g->x - 12, ay + 3 * d, g->x + 12, ay + 3 * d, g->x, ay + 17 * d, WHITE);
}
static void draw_laser(int i) {
    const Laser *l = &S.laser[i]; int on = sim_laser_on(&S, i); float w = sim_laser_wait(&S, i), t = g_time;
    float dx = l->x1 - l->x0, dy = l->y1 - l->y0, len = hypotf(dx, dy); if (len < 1) return; dx /= len; dy /= len;
    if (S.state != ST_PLAY && l->off_t > 0) w = 9.0f;
    if (on) {
        float fl = 0.82f + 0.18f * sinf(t * 47.0f + i), end = (l->off_t > 0 && w < 0.22f) ? w / 0.22f : 1.0f;      /* thins out just before it goes off */
        gfx_capsule(l->x0, l->y0, l->x1, l->y1, 10.0f * fl * end + 1.0f, RGBA(255, 40, 90, 60));
        gfx_capsule(l->x0, l->y0, l->x1, l->y1, 5.5f * fl * end + 0.6f, RGBA(255, 70, 110, 210));
        gfx_capsule(l->x0, l->y0, l->x1, l->y1, 2.2f * end + 0.4f, 0xFFF0F4FFu);
    } else {
        float a = w < 0.6f ? 0.3f + 0.7f * (0.5f + 0.5f * sinf(t * 34.0f)) : 0.26f;                             /* blinks before it fires again */
        u32 c = RGBA(255, 110, 140, (int)(255 * a));
        for (float m = fmodf(t * 30.0f, 22.0f); m < len - 6.0f; m += 22.0f) gfx_capsule(l->x0 + dx * m, l->y0 + dy * m, l->x0 + dx * (m + 8.0f), l->y0 + dy * (m + 8.0f), w < 0.6f ? 2.2f : 1.5f, c);
    }
    for (int e = 0; e < 2; e++) {
        float x = e ? l->x1 : l->x0, y = e ? l->y1 : l->y0;
        gfx_circle(x, y + 2, 13.0f, 0x00000050u); gfx_circle(x, y, 13.0f, 0x15103AFFu); gfx_circle(x, y, 10.0f, 0x59658EFFu); gfx_circle(x - 2.5f, y - 3.0f, 4.0f, 0xAEB9DAFFu);
        gfx_circle(x, y, 5.0f, on ? 0xFF5078FFu : (w < 0.6f ? 0xFFB040FFu : 0x6A2038FFu)); if (on) gfx_circle(x, y, 2.2f, WHITE);
    }
}
/* a little masked monkey that climbs down the rope to steal the bottle; mood: 0 waits, 1 climbs, 2 falls, 3 got it */
static void draw_thief(float x, float y, float rot, int mood) {
    float cs = cosf(rot), sn = sinf(rot), t = g_time, sw = mood == 1 ? sinf(t * 13.0f) : 0.0f;
#define TP(ox, oy) x + (ox) * cs - (oy) * sn, y + (ox) * sn + (oy) * cs
    u32 fur = 0x9A6638FFu, dark = 0x2E1A0EFFu, skin = 0xF6D2A6FFu;
    float tw = sinf(t * 3.0f) * 4.0f;
    gfx_capsule(TP(9, 20), TP(19 + tw, 27), 3.2f, dark); gfx_capsule(TP(19 + tw, 27), TP(24 + tw, 18), 3.0f, dark); gfx_capsule(TP(9, 20), TP(19 + tw, 27), 1.7f, fur);
    gfx_circle(TP(0, 13), 13.0f, dark); gfx_circle(TP(0, 13), 11.0f, fur); gfx_circle(TP(0, 15), 6.2f, skin);
    if (mood == 2) { gfx_capsule(TP(-9, 6), TP(-20, -8), 4.3f, dark); gfx_capsule(TP(9, 6), TP(20, -8), 4.3f, dark); gfx_capsule(TP(-9, 6), TP(-20, -8), 2.6f, fur); gfx_capsule(TP(9, 6), TP(20, -8), 2.6f, fur); }
    else { gfx_capsule(TP(-9, 6), TP(-3, -22 + 5 * sw), 4.3f, dark); gfx_capsule(TP(9, 6), TP(3, -22 - 5 * sw), 4.3f, dark); gfx_capsule(TP(-9, 6), TP(-3, -22 + 5 * sw), 2.6f, fur); gfx_capsule(TP(9, 6), TP(3, -22 - 5 * sw), 2.6f, fur); }
    gfx_circle(TP(-13, -9), 6.8f, dark); gfx_circle(TP(13, -9), 6.8f, dark); gfx_circle(TP(-13, -9), 4.4f, skin); gfx_circle(TP(13, -9), 4.4f, skin);
    gfx_circle(TP(0, -7), 13.8f, dark); gfx_circle(TP(0, -7), 11.8f, fur);
    gfx_circle(TP(0, -2.5f), 7.6f, skin);
    gfx_capsule(TP(-9.5f, -10.5f), TP(9.5f, -10.5f), 4.4f, 0x15103AFFu);
    if (mood == 0) { gfx_capsule(TP(-6.5f, -10.5f), TP(-2.5f, -10.5f), 1.0f, WHITE); gfx_capsule(TP(2.5f, -10.5f), TP(6.5f, -10.5f), 1.0f, WHITE); }
    else { float er = mood == 2 ? 3.1f : 2.5f; gfx_circle(TP(-4.6f, -10.5f), er, WHITE); gfx_circle(TP(4.6f, -10.5f), er, WHITE); gfx_circle(TP(-4.6f, -10.0f), 1.2f, 0x15103AFFu); gfx_circle(TP(4.6f, -10.0f), 1.2f, 0x15103AFFu); }
    if (mood == 2) gfx_circle(TP(0, -0.5f), 3.0f, dark); else if (mood == 3) gfx_capsule(TP(-4, -1), TP(4, -1), 1.8f, WHITE); else gfx_capsule(TP(-2.5f, -0.5f), TP(2.5f, -0.5f), 1.0f, dark);
#undef TP
}
static void rope_at(const Rope *r, float f, float *x, float *y) {
    f = clampf(f, 0, 1) * (float)(r->n - 1); int i = (int)f; if (i > r->n - 2) i = r->n - 2; f -= (float)i;
    *x = lerpf(r->p[i].x, r->p[i + 1].x, f); *y = lerpf(r->p[i].y, r->p[i + 1].y, f);
}
static int thief_xy(int i, float *x, float *y, int *mood) {          /* where rope i's thief is drawn */
    const Rope *r = &S.rope[i]; if (!r->active || !r->thief) return 0;
    if (r->thief == 2) { *x = r->tx; *y = r->ty; *mood = 2; return 1; }
    float f = r->len > 1 ? r->thief_s / r->len : 0; *mood = (S.time < r->thief_t0 || S.state != ST_PLAY) ? 0 : 1;
    if (S.state == ST_STOLEN && i == steal_rope) { f *= 1.0f - ease_in_out(clampf((S.state_t - 0.25f) / 0.9f, 0, 1)); *mood = 3; }      /* back up with the loot */
    rope_at(r, f, x, y); return 1;
}
static void draw_thieves(void) {
    for (int i = 0; i < MAX_ROPES; i++) {
        float x, y; int mood; if (!thief_xy(i, &x, &y, &mood)) continue;
        const Rope *r = &S.rope[i]; float rot = 0;
        if (mood == 2) rot = r->ty * 0.03f;
        else { float ax, ay, bx, by, f = r->len > 1 ? r->thief_s / r->len : 0; rope_at(r, f - 0.04f, &ax, &ay); rope_at(r, f + 0.04f, &bx, &by); rot = clampf(atan2f(bx - ax, by - ay) * -0.6f, -0.7f, 0.7f) * (float)S.gdir; if (S.gdir < 0) rot += PI; }
        if (mood == 0 && S.state == ST_PLAY && fmodf(g_time + i * 0.4f, 1.6f) < 1.1f) gfx_text(&F_ui, "z", x + 17, y - 22 - fmodf(g_time + i * 0.4f, 1.6f) * 9.0f, 17, 0xFFFFFFD0u, AL_CENTER);
        draw_thief(x, y, rot, mood);
    }
}
static void draw_bottle(void) {
    float x = S.c.x, y = S.c.y, sc = 1.0f, rot = S.rot;
    if (S.state == ST_BROKEN) return;
    if (S.state == ST_EATEN) {
        float f = clampf(S.state_t / 0.2f, 0, 1), e = ease_in_cubic(f);
        x = lerpf(x, S.mx, e); y = lerpf(y, S.my, e); sc = 1.0f - e; rot += f * 3.0f; if (sc <= 0.02f) return;
    }
    if (S.state == ST_STOLEN && steal_rope >= 0) {       /* the thief carries it away */
        float tx, ty, e = ease_out_cubic(clampf(S.state_t / 0.25f, 0, 1)); int mood;
        if (thief_xy(steal_rope, &tx, &ty, &mood)) { x = lerpf(x, tx, e); y = lerpf(y, ty + 20.0f * (float)S.gdir, e); sc = 1.0f - 0.25f * e; rot += e * 0.5f; }
    }
    gfx_image_ex(I_bottle, x, y, sc, sc, rot, 1);
    if (S.in_bubble && S.state == ST_PLAY) {
        float w = sinf(g_time * 5.0f) * 0.04f, g = ease_out_elastic(clampf(S.bubble_t / 0.5f, 0, 1));
        gfx_image_ex(I_bubble, x, y, (1.0f + w) * g, (1.0f - w) * g, 0, 1);
    }
}
static void draw_scene(void) {
    float t = g_time;
    draw_spills();
    for (int i = 0; i < S.npins; i++) if (S.pin[i].rail) draw_rail(&S.pin[i]);
    for (int i = 0; i < S.npins; i++) { const Pin *p = &S.pin[i]; if (p->autopin && !p->used) dashed_circle(p->x, p->y, p->r, t * 0.25f, 3.6f, 0xFFFFFFA8u); }
    draw_mel_scene();
    for (int i = 0; i < S.nportals; i++) draw_portal(&S.portal[i]);
    for (int i = 0; i < S.nspikes; i++) draw_spikes(&S.spikes[i]);
    for (int i = 0; i < S.nbouncers; i++) draw_bouncer(&S.bouncer[i]);
    for (int i = 0; i < S.nblowers; i++) draw_blower(&S.blower[i]);
    for (int i = 0; i < S.ngravs; i++) draw_grav(&S.grav[i]);
    for (int i = 0; i < S.nbubbles; i++) { const Bubble *b = &S.bubble[i]; if (b->used) continue; float w = sinf(t * 3.0f + i * 1.7f) * 0.035f; gfx_image_ex(I_bubble, b->x, b->y + sinf(t * 1.8f + i) * 3.0f, 1.0f + w, 1.0f - w, 0, 1); }
    for (int i = 0; i < S.nlasers; i++) draw_laser(i);
    for (int i = 0; i < MAX_ROPES; i++) if (S.rope[i].active) draw_rope(&S.rope[i]);
    for (int i = 0; i < S.npins; i++) { const Pin *p = &S.pin[i]; float s = 1.0f + 0.35f * p->pulse; if (p->rail) draw_rail_knob(p, i); gfx_image_ex(I_pin, p->x, p->y, s, s, 0, 1); }
    for (int i = 0; i < S.nstars; i++) {
        const Star *st = &S.star[i]; if (st->got) continue;
        float ph = t * 2.2f + i * 2.1f, y = st->y + sinf(ph) * 3.5f, s = 0.92f + 0.05f * sinf(ph * 1.4f);
        gfx_image_tint(I_glow, st->x, y, 0.62f, 0.62f, 0, RGBA(255, 255, 255, (int)(120 + 50 * sinf(ph))), 1);
        gfx_image_ex(I_star, st->x, y, s, s, sinf(ph * 0.7f) * 0.14f, 1);
        float sp = fmodf(t * 0.7f + i * 0.37f, 1.0f), ss = sinf(clampf(sp * 2.2f, 0, 1) * PI) * 0.8f; if (ss > 0.2f) gfx_image_tint(I_spark, st->x + 13, y - 15, ss, ss, sp * 2.0f, 0xFFFFFFFFu, 1);
    }
    if (S.state != ST_STOLEN) draw_bottle();
    draw_thieves();
    if (S.state == ST_STOLEN) draw_bottle();
}
static void draw_trail(void) {
    for (int i = 0; i < 6; i++) if (slash[i].t > 0) {
        Slash *s = &slash[i]; float f = s->t / 0.3f, h = clampf((1.0f - f) / 0.35f, 0, 1), tl = clampf((1.0f - f) / 0.8f - 0.25f, 0, 1);
        float ax = lerpf(s->x0, s->x1, tl), ay = lerpf(s->y0, s->y1, tl), bx = lerpf(s->x0, s->x1, h), by = lerpf(s->y0, s->y1, h);
        gfx_capsule2(ax, ay, bx, by, 1.0f, 7.5f * f + 1.5f, RGBA(120, 230, 255, 120)); gfx_capsule2(ax, ay, bx, by, 0.5f, 4.0f * f + 0.8f, 0xFFFFFFFFu);
    }
    while (trail_n > 0 && g_time - trail[0].t > 0.24f) { memmove(trail, trail + 1, sizeof(TPt) * (size_t)(trail_n - 1)); trail_n--; }
    for (int pass = 0; pass < 2; pass++) for (int i = 0; i + 1 < trail_n; i++) {
        float a0 = 1.0f - (g_time - trail[i].t) / 0.24f, a1 = 1.0f - (g_time - trail[i + 1].t) / 0.24f; if (a0 < 0) a0 = 0; if (a1 < 0) a1 = 0;
        if (pass == 0) gfx_capsule2(trail[i].x, trail[i].y, trail[i + 1].x, trail[i + 1].y, 9.0f * a0, 9.0f * a1, RGBA(110, 225, 255, 110));
        else gfx_capsule2(trail[i].x, trail[i].y, trail[i + 1].x, trail[i + 1].y, 4.5f * a0, 4.5f * a1, 0xFFFFFFFFu);
    }
    if (tapfx_t > 0) { float f = tapfx_t / 0.4f; gfx_ring(tapfx_x, tapfx_y, 18 + 44 * (1 - f), 6 * f + 1, RGBA(255, 255, 255, (int)(255 * f))); gfx_circle(tapfx_x, tapfx_y, 12 * f, RGBA(255, 255, 255, (int)(200 * f))); }
}
static void draw_hud(void) {
    char buf[96], tb[24]; int n = CUR.maxst;
    gfx_rrect(14, 12, n <= 3 ? 176 : 180, 60, 30, 0x0E0A2E96u);
    for (int i = 0; i < n; i++) {
        float x, y, sz; hud_star_pos(i, &x, &y, &sz);
        int got = i < L_got && !fly[i].on; float p = hud_pop[i], s = sz * (1.0f + 0.5f * sinf(p * PI));
        star_icon(x, y, got ? s : sz * 0.96f, got, 1);
    }
    if (CUR.kind == 0) snprintf(buf, sizeof(buf), "%d-%d", CUR.box + 1, CUR.idx % PER_BOX + 1); else snprintf(buf, sizeof(buf), "%s", CUR.kind == 1 ? "Проба" : "Игрок");
    gfx_text(&F_ui, buf, 20, 92, 21, 0xFFFFFFE6u, AL_LEFT);
    float x0 = 30 + gfx_text_w(&F_ui, buf, 21);
    /* the time of this attempt (simulation ticks, so it is the same on every machine) */
    int ticks = L_phase == PH_WIN ? L_ticks : S.tick;
    fmt_time(ticks, tb, (int)sizeof(tb));
    float tw = gfx_text_w(&F_ui, "0:00.00", 21) + 22;
    if (CFG.timer || L_demo || L_replay) { gfx_rrect(x0, 78, tw, 28, 14, 0x0E0A2E96u); gfx_text(&F_ui, tb, x0 + 11, 92, 21, L_phase == PH_WIN ? C_GOLD : WHITE, AL_LEFT); x0 += tw + 10; }
    float na = clampf((4.0f - L_t) / 0.6f, 0, 1);
    if (na > 0 && L_mode == LM_PLAY && CUR.name) gfx_text(&F_ui, CUR.name, x0, 92, 21, RGBA(255, 255, 255, (int)(230 * na)), AL_LEFT);
    if (L_demo || L_replay) {
        int tas = L_replay && playb_tas;
        float bl = 0.65f + 0.35f * sinf(g_time * 5.0f); const char *lab = L_demo ? "ДЕМО" : (tas ? "TAS" : "ЗАПИСЬ"); float w = gfx_text_w(&F_ui, lab, 19) + 30;
        gfx_rrect(x0, 78, w, 28, 14, L_demo ? RGBA(255, 79, 184, (int)(235 * bl)) : (tas ? RGBA(255, 140, 26, (int)(240 * bl)) : RGBA(40, 170, 230, (int)(235 * bl)))); gfx_text(&F_ui, lab, x0 + w * 0.5f, 92, 19, WHITE, AL_CENTER);
        if (L_replay && playb_who[0]) gfx_text(&F_ui, playb_who, x0 + w + 10, 92, 21, 0xFFFFFFE6u, AL_LEFT);
    }
    for (int i = 0; i < n; i++) if (fly[i].on) {
        float sx, sy, sz; hud_star_pos(i, &sx, &sy, &sz);
        float f = clampf(fly[i].t / 0.55f, 0, 1), e = ease_in_out(f);
        float x = lerpf(fly[i].x0, fly[i].x1, e), y = lerpf(fly[i].y0, fly[i].y1, e) - sinf(f * PI) * 70.0f, s = lerpf(1.0f, sz / 60.0f, e) * (1.0f + 0.3f * sinf(f * PI));
        gfx_image_tint(I_glow, x, y, 0.7f, 0.7f, 0, RGBA(255, 255, 255, 150), 1);
        gfx_image_ex(I_star, x, y, s, s, f * TAU, 1);
    }
}

/* ============================== screens ============================== */
static void go(int s, int arg, int arg2) { if (scr_next >= 0) return; scr_next = s; scr_arg = arg; scr_arg2 = arg2; sfx(S_WHOOSH, 0.45f, 640); }
static int G_greeted;                                  /* Mel has already said hello since the game was started */
static void visit_reset(void) { V_attempt = 0; V_fails = 0; V_breaks = 0; V_red_said = 0; M.red_to = 0; M.red = 0; }
static void hub_enter(int a); static void records_enter(int a); static void editor_enter(int a); static void tas_enter(int a); static void settings_enter(int a);
static void enter(int s, int a, int a2) {
    scr = s; nparts = 0; M.say_t = 0; P.active = 0;
    if (s == SC_PLAY) {
        if (a >= 0) { cur_builtin(a); play_back = SC_LEVELS; play_back_arg = CUR.box; }       /* a < 0: CUR was prepared by the caller */
        visit_reset(); level_start(a2);
        if (a2 == LM_PLAY && SND[V_HI] && !G_greeted && emo_on(EM_GREET)) {      /* the first level after the game was started: Mel greets the chat (once per launch) */
            int hint = M.say_t > 0; G_greeted = 1; say(V_HI, hint ? NULL : "Ребята, всем привет! Это я, блогер Меллстрой!");
        }
    }
    else if (s == SC_MENU) { mel_set(CL_IDLE, 1); M.dy = 0; M.red = M.red_to = 0; }
    else if (s == SC_FINAL) { mel_set(CL_LAUGH, 1); if (emo_on(EM_BRAVO)) say(V_BRAVO, NULL); fx_confetti(100, 1180, -10, 140); M.red = M.red_to = 0; }
    else if (s == SC_HUB) hub_enter(a);
    else if (s == SC_RECORDS) records_enter(a);
    else if (s == SC_EDITOR) editor_enter(a);
    else if (s == SC_TAS) tas_enter(a);
    else if (s == SC_SETTINGS) settings_enter(a);
    if (s == SC_LEVELS) sel_box = a;
}
static void restart_level(int mode) { level_start(mode); g_fade = 0.55f; }

static void title_text(const char *s, float x, float y, float size) { gfx_text(&F_ui, s, x, y, size, WHITE, AL_CENTER); }
static void cam_frame(float x, float y, float w, float h) {
    gfx_rrect(x - 4, y - 4, w + 8, h + 8, 24, C_PINK);
    gfx_rrect_grad(x, y, w, h, 20, 0x3B2A80FFu, 0x130B3AFFu);
}
static void cam_overlay(float x, float y) {
    float bl = 0.6f + 0.4f * sinf(g_time * 5.0f);
    gfx_rrect(x + 12, y + 12, 78, 28, 14, 0x000000A0u);
    gfx_circle(x + 28, y + 26, 7, RGBA(255, 60, 70, (int)(255 * bl)));
    gfx_text(&F_txt, "LIVE", x + 62, y + 26.5f, 19, WHITE, AL_CENTER);
}
/* big Mel inside a "webcam" frame; bottom-aligned */
static float mel_cam_k(float h, float kmin) { const Clip *c = &CLP[M.clip]; return clampf((h * 0.82f) / (c->h / c->scale), kmin, 2.6f); }
static void draw_mel_cam_k(float x, float y, float w, float h, float kmin) {
    cam_frame(x, y, w, h);
    const Clip *c = &CLP[M.clip]; float k = mel_cam_k(h, kmin);
    gfx_clip(x + 3, y + 3, w - 6, h - 6);
    float dy = M.dy; M.dy = 0; draw_mel(x + w * 0.5f, y + h - 3 - c->avail * k + 3, k, 1.0f); M.dy = dy;
    gfx_clip_reset();
    cam_overlay(x, y);
}
static void draw_mel_cam(float x, float y, float w, float h) { draw_mel_cam_k(x, y, w, h, 1.4f); }

static int tas_unlocked(void);
static void acc_open(void); static const char *acc_label(void); static int donate_has(void); static void donate_open(void); static int upd_pending(void); static void upd_open(void); static const char *upd_label(void);
static void scr_menu(void) {
    float mx = 985, my = 318, sc = 1.9f;
    bg_draw(0, 0.62f, DECO_MENU, (int)mx, 0, 0);
    gfx_clip(0, 0, DESIGN_W, my + DESK_U * sc + 8); draw_mel(mx, my, sc, 1.0f); gfx_clip_reset();
    draw_desk(mx, my + DESK_U * sc, sc * 0.86f, 0, I_deskbig ? I_deskbig : I_desk);
    if (P.pressed && !ui_block && emo_on(EM_POKE) && fabsf(P.downx - mx) < 110 && fabsf(P.downy - my) < 120) {        /* easter egg: poke Mel */
        static int k; static const int v[7] = { V_AM, V_LAUGH, V_UUU, V_OMG, V_STOP, V_POSIDIM, V_BRAVO };
        static const char *const tx[7] = { "Ам-ам-ам!", "Ха-ха-ха!", "У-у-у-у!", "О май гад!", "Стоп-стоп-стоп!", "Не, ещё посидим!", "Браво, босс!" };
        static const int cl[7] = { CL_AM, CL_LAUGH, CL_SMILE, CL_OMG, CL_SAD, CL_BORED, CL_LAUGH };
        mel_set(cl[k], 1); M.react = maxf(2.2f, (float)SND[v[k]]->n / (float)SND[v[k]]->rate + 0.3f); say(v[k], tx[k]); k = (k + 1) % 7;
        for (int i = 0; i < 8; i++) { float a = rnd_range(0, TAU); Part *p = part_new(PT_SPARK, P.x, P.y, cosf(a) * 200, sinf(a) * 200, 0.4f, 36, 0xFFE680FFu); p->drag = 3; }
    }
    float bob = sinf(g_time * 1.3f) * 5.0f, in = ease_out_back(clampf(g_time / 0.7f, 0, 1));
    gfx_image_ex(I_logo, 432, 160 + bob, 0.72f * in, 0.72f * in, sinf(g_time * 0.9f) * 0.02f, 1);
    if (!(g_capflags & 4)) {                           /* (capture aid 4: bare key art, no widgets) */
        if (wbtn(1, 432, 388, 348, 96, "ИГРАТЬ", C_GREEN1, C_GREEN2, 52, IC_PLAY, 1)) go(SC_CHAPTERS, 0, 0);
        if (wbtn(7, 432 - 90, 490, 168, 64, "Рекорды", C_ORG1, C_ORG2, 25, IC_CUP, 1)) go(SC_RECORDS, -1, 0);
        if (wbtn(8, 432 + 90, 490, 168, 64, "Редактор", C_BLUE1, C_BLUE2, 25, IC_EDIT, 1)) go(SC_HUB, 0, 0);
        int caps = plat_caps(), n = 3 + ((caps & 2) ? 1 : 0) + ((caps & 1) ? 1 : 0); float x = 432 - (n - 1) * 40.0f;
        if (rbtn(10, x, 572, 30, IC_GEAR, C_ORG1, C_ORG2, 1)) go(SC_SETTINGS, 0, 0); x += 80;
        if (rbtn(2, x, 572, 30, SV.sound ? IC_SOUND : IC_SOUND_OFF, C_VIO1, C_VIO2, 1)) { SV.sound = !SV.sound; apply_volumes(); save_store(); } x += 80;
        if (rbtn(3, x, 572, 30, SV.music ? IC_MUSIC : IC_MUSIC_OFF, C_VIO1, C_VIO2, 1)) { SV.music = !SV.music; apply_volumes(); save_store(); } x += 80;
        if (caps & 2) { if (rbtn(4, x, 572, 30, IC_FULL, C_BLUE1, C_BLUE2, 1)) plat_fullscreen(); x += 80; }
        if (caps & 1) { if (rbtn(5, x, 572, 30, IC_EXIT, C_RED1, C_RED2, 1)) plat_quit(); }
        if (tas_unlocked() && wbtn(9, 1204, 48, 108, 50, "TAS", C_ORG1, C_ORG2, 29, IC_NONE, 1)) go(SC_TAS, 0, 0);      /* all the stars of the chapter: the fastest runs there can be */
        if (wbtn(12, 150, 48, 252, 50, acc_label(), C_VIO1, C_VIO2, 22, IC_USER, 1)) acc_open();                      /* the account: nick + password, the same on every device */
        if (upd_pending() && wbtn(13, 432, 48, 276, 50, upd_label(), C_GREEN1, C_GREEN2, 22, IC_GET, 1)) upd_open();     /* a newer version is on the site */
        if (donate_has() && wbtn(11, 1128, 664, 236, 52, "Поддержать", C_PINK, 0xB8257FFFu, 24, IC_HEART, 1)) donate_open();
        char buf[64]; snprintf(buf, sizeof(buf), "%d / %d", total_stars(), stars_all);
        float tw = gfx_text_w(&F_ui, buf, 28);
        gfx_rrect(432 - tw * 0.5f - 50, 624, tw + 84, 42, 21, 0x0E0A2EA0u); star_icon(432 - tw * 0.5f - 21, 645, 33, 1, 1); gfx_text(&F_ui, buf, 432 + 16, 646, 28, WHITE, AL_CENTER);
        gfx_text(&F_txt, "Неофициальная фан-пародия  •  собственный движок MEL-ENGINE  •  V" APP_VER_NAME, 432, 694, 17, 0xFFFFFFA0u, AL_CENTER);
    }
    parts_draw();
    if (!(g_capflags & 2)) draw_say(mx, my, 100.0f, -168.0f, 1.0f);
    if (!hello_done && g_time > 0.7f) { hello_done = 1; if (emo_on(EM_HELLO)) say(V_HELLO, "Hello! I'm Mellstroy!"); }
}
static void back_button(int target, int arg) { if (rbtn(6, 62, 62, 32, IC_BACK, C_VIO1, C_VIO2, 1)) go(target, arg, 0); }
static void total_badge(void) {
    char buf[32]; snprintf(buf, sizeof(buf), "%d/%d", total_stars(), stars_all);
    float tw = gfx_text_w(&F_ui, buf, 30);
    gfx_rrect(1250 - tw - 76, 38, tw + 76, 50, 25, 0x0E0A2EA0u); star_icon(1250 - tw - 46, 63, 38, 1, 1); gfx_text(&F_ui, buf, 1250 - 16, 64, 30, WHITE, AL_RIGHT);
}
/* a big picture card (chapters); returns 1 when clicked */
static int big_card(int id, float x, float y, const Image *cover, int ic, const char *name, const char *sub, u32 col, int open, const char *bottom, int star, float *shake) {
    int click = btn_logic(id, x, y + 30, 320, 330, 1);
    float a = B_anim[id], s = 1.0f + 0.035f * maxf(a, 0) - 0.02f * (a < 0 ? -a : 0);
    if (*shake > 0) { *shake -= g_dt; x += sinf(*shake * 50.0f) * 8.0f * *shake / 0.35f; }
    float W = 316 * s, H = 336 * s;
    gfx_rrect(x - W * 0.5f - 3, y + 30 - H * 0.5f + 8, W + 6, H, 38, 0x00000060u);
    gfx_rrect(x - W * 0.5f, y + 30 - H * 0.5f, W, H, 36, open ? col : 0x7C7896FFu);
    gfx_rrect_grad(x - W * 0.5f + 5, y + 30 - H * 0.5f + 5, W - 10, H - 10, 31, C_PANEL1, C_PANEL2);
    if (cover) gfx_image_ex(cover, x, y - 26 * s, s * 0.98f, s * 0.98f, 0, 1);
    else { gfx_rrect_grad(x - 147 * s, y - 119 * s, 294 * s, 186 * s, 29, color_lerp(col, 0x1E1456FFu, 0.35f), 0x1E1456FFu); if (ic) icon(ic, x, y - 28 * s, 62 * s, 0xFFFFFFE6u); else gfx_text(&F_ui, "?", x, y - 28 * s, 120 * s, 0xFFFFFF90u, AL_CENTER); }
    gfx_text(&F_ui, name, x, y + 96 * s, 33 * s, WHITE, AL_CENTER);
    gfx_text(&F_txt, sub, x, y + 131 * s, 18.5f * s, 0xD8CCFFFFu, AL_CENTER);
    if (!open && cover) { gfx_rrect(x - 147 * s, y - 26 * s - 93 * s, 294 * s, 186 * s, 29, 0x0A0620B4u); icon(IC_LOCK, x, y - 30 * s, 44 * s, 0xFFFFFFE6u); }
    float tw = gfx_text_w(&F_ui, bottom, 26 * s);
    if (star) { star_icon(x - tw * 0.5f - 6, y + 166 * s, 32 * s, 1, 1); gfx_text(&F_ui, bottom, x + 20, y + 167 * s, 26 * s, C_GOLD, AL_CENTER); }
    else gfx_text(&F_ui, bottom, x, y + 167 * s, 23 * s, 0xFFFFFFE0u, AL_CENTER);
    return click;
}
/* one chapter per streamer; ten locations in a chapter, six levels in a location */
static void scr_chapters(void) {
    static float sh[3]; char buf[48];
    bg_draw(0, 0.42f, DECO_NONE, 0, 0, 0);
    title_text("Выбери главу", 640, 82, 54);
    back_button(SC_MENU, 0); total_badge();
    snprintf(buf, sizeof(buf), "%d/%d", total_stars(), stars_all);
    if (big_card(10, 270, 338, I_cover[0], 0, "Глава 1: Меллстрой", "10 локаций • 60 уровней", C_VIO1, 1, buf, 1, &sh[0])) go(SC_BOXES, 0, 0);
    if (big_card(11, 640, 338, NULL, IC_GLOBE, "Уровни игроков", "Придуманы в редакторе", C_CYAN, 1, "Открыть", 0, &sh[1])) go(SC_HUB, 1, 0);
    if (big_card(12, 1010, 338, NULL, 0, "Глава 2", "Новый стример", 0x8C88A8FFu, 0, "Скоро...", 0, &sh[2])) { sh[2] = 0.35f; sfx(S_TICK, 0.8f, 1010); }
}
static void scr_boxes(void) {
    static float lock_shake[BOXES];
    bg_draw(0, 0.42f, DECO_NONE, 0, 0, 0);
    title_text("Глава 1: выбери локацию", 640, 66, 46);
    back_button(SC_CHAPTERS, 0); total_badge();
    int tot = total_stars();
    for (int b = 0; b < BOXES; b++) {
        float x = 148 + (b % 5) * 246.0f, y = 250 + (b / 5) * 272.0f; int open = box_open(b);
        int click = btn_logic(40 + b, x, y, 232, 256, 1);
        float a = B_anim[40 + b], s = 1.0f + 0.04f * maxf(a, 0) - 0.02f * (a < 0 ? -a : 0);
        if (lock_shake[b] > 0) { lock_shake[b] -= g_dt; x += sinf(lock_shake[b] * 50.0f) * 7.0f * lock_shake[b] / 0.35f; }
        float W = 230 * s, H = 254 * s;
        gfx_rrect(x - W * 0.5f - 2, y - H * 0.5f + 7, W + 4, H, 30, 0x00000060u);
        gfx_rrect(x - W * 0.5f, y - H * 0.5f, W, H, 28, open ? box_c1[b] : 0x7C7896FFu);
        gfx_rrect_grad(x - W * 0.5f + 4, y - H * 0.5f + 4, W - 8, H - 8, 24, C_PANEL1, C_PANEL2);
        gfx_image_ex(I_cover[b], x, y - 52 * s, s * 0.72f, s * 0.72f, 0, 1);
        char buf[48]; snprintf(buf, sizeof(buf), "%d. %s", b + 1, box_name[b]);
        gfx_text(&F_ui, buf, x, y + 38 * s, 24 * s, WHITE, AL_CENTER);
        gfx_text(&F_txt, box_sub[b], x, y + 65 * s, 15.5f * s, 0xD8CCFFFFu, AL_CENTER);
        if (open) {
            snprintf(buf, sizeof(buf), "%d/%d", box_stars(b), box_max(b)); float tw = gfx_text_w(&F_ui, buf, 23 * s);
            star_icon(x - tw * 0.5f - 5, y + 98 * s, 27 * s, 1, 1); gfx_text(&F_ui, buf, x + 17, y + 99 * s, 23 * s, C_GOLD, AL_CENTER);
        } else {
            gfx_rrect(x - 106 * s, y - 52 * s - 67 * s, 212 * s, 134 * s, 21, 0x0A0620B4u);
            icon(IC_LOCK, x, y - 55 * s, 36 * s, 0xFFFFFFE6u);
            snprintf(buf, sizeof(buf), "Нужно ещё %d", box_need[b] - tot); float tw = gfx_text_w(&F_ui, buf, 19 * s);
            gfx_text(&F_ui, buf, x - 13, y + 99 * s, 19 * s, 0xFFFFFFE0u, AL_CENTER); star_icon(x + tw * 0.5f + 3, y + 98 * s, 23 * s, 1, 1);
        }
        if (click) { if (open) go(SC_LEVELS, b, 0); else { lock_shake[b] = 0.35f; sfx(S_TICK, 0.8f, x); } }
    }
}
static void scr_levels(void) {
    static float lock_shake[PER_BOX];
    int b = sel_box; char buf[32];
    bg_draw(b, 0.5f, DECO_NONE, 0, 0, 0);
    snprintf(buf, sizeof(buf), "%d. %s", b + 1, box_name[b]); title_text(buf, 640, 78, 54);
    gfx_text(&F_txt, box_sub[b], 640, 124, 22, 0xE4DCFFFFu, AL_CENTER);
    back_button(SC_BOXES, 0); total_badge();
    for (int i = 0; i < PER_BOX; i++) {
        int li = b * PER_BOX + i, open = lvl_open(li), st = lvl_stars(li), mx = lv_max[li];
        float x = 640 + (i % 3 - 1) * 216.0f, y = 282 + (i / 3) * 214.0f;
        int click = btn_logic(20 + i, x, y, 170, 170, 1);
        float a = B_anim[20 + i], s = 1.0f + 0.05f * maxf(a, 0), press = a < 0 ? -a : 0, W = 164 * s, yy = y + press * 4;
        if (lock_shake[i] > 0) { lock_shake[i] -= g_dt; x += sinf(lock_shake[i] * 50.0f) * 7.0f * lock_shake[i] / 0.35f; }
        u32 c0 = open ? box_c1[b] : 0x8C88A8FFu, c1 = open ? box_c2[b] : 0x56526EFFu;
        gfx_rrect(x - W * 0.5f - 2, y - W * 0.5f + 10, W + 4, W, 40, 0x00000058u);
        gfx_rrect(x - W * 0.5f, y - W * 0.5f + 7, W, W, 38, color_lerp(c1, 0x000000FFu, 0.45f));
        gfx_rrect_grad(x - W * 0.5f, yy - W * 0.5f, W, W, 38, c0, c1);
        gfx_rrect(x - W * 0.5f + 8, yy - W * 0.5f + 6, W - 16, W * 0.36f, 26, 0xFFFFFF2Cu);
        if (open) {
            snprintf(buf, sizeof(buf), "%d", i + 1);
            if (mx <= 3) {
                gfx_text(&F_ui, buf, x, yy - 18 * s, 78 * s, WHITE, AL_CENTER);
                for (int k = 0; k < mx; k++) star_icon(x + (k - (mx - 1) * 0.5f) * 40.0f * s, yy + 48 * s - (k == 1 && mx == 3 ? 5 * s : 0), 40 * s, k < st, 1);
            } else {
                gfx_text(&F_ui, buf, x, yy - 30 * s, 64 * s, WHITE, AL_CENTER);
                for (int k = 0; k < mx; k++) star_icon(x + (k % 5 - 2) * 27.0f * s, yy + (28 + 26 * (k / 5)) * s, 26 * s, k < st, 1);
            }
            if (lvl_done(li) && SV.ticks[li]) { char tb[24]; gfx_text(&F_ui, fmt_time((int)SV.ticks[li], tb, (int)sizeof(tb)), x, y + 106, 19, 0xFFFFFFE0u, AL_CENTER); }
        } else icon(IC_LOCK, x, yy, 40 * s, 0xFFFFFFD0u);
        if (click) { if (open) go(SC_PLAY, li, 0); else { lock_shake[i] = 0.35f; sfx(S_TICK, 0.8f, x); } }
    }
    if (rbtn(26, 1218, 150, 30, IC_CUP, C_ORG1, C_ORG2, 1)) go(SC_RECORDS, b * PER_BOX, 0);
    gfx_text(&F_txt, b == 9 ? "Экзамен: все механики сразу, 10 звёзд и никаких подсказок!" : "Собери все три звезды на каждом уровне!", 640, 690, 20, 0xFFFFFFB0u, AL_CENTER);
}
static void scr_final(void) {
    bg_draw(9, 0.5f, DECO_NONE, 0, 0, 0);
    char buf[96];
    panel(190, 110, 900, 500);
    draw_mel_cam(214, 134, 330, 452);
    title_text("Глава пройдена!", 812, 190, 52);
    gfx_text_wrap(&F_txt, "Мел сыт и доволен. Экзамен сдан, все чекушки доставлены по адресу!", 812, 262, 25, 480, 33, 0xE8E0FFFFu, AL_CENTER, 1);
    snprintf(buf, sizeof(buf), "%d / %d", total_stars(), stars_all); float tw = gfx_text_w(&F_ui, buf, 50);
    star_icon(812 - tw * 0.5f - 20, 392, 66, 1, 1); gfx_text(&F_ui, buf, 812 + 30, 394, 50, C_GOLD, AL_CENTER);
    if (total_stars() < stars_all) gfx_text(&F_txt, "А слабо собрать все звёзды?", 812, 452, 22, 0xFFFFFFC0u, AL_CENTER);
    else gfx_text(&F_txt, "Все звёзды собраны. Браво, босс!", 812, 452, 22, C_GOLD, AL_CENTER);
    if (wbtn(30, 812, 530, 300, 78, "В меню", C_GREEN1, C_GREEN2, 40, IC_HOME, 1)) go(SC_MENU, 0, 0);
    if (rnd_f() < g_dt * 1.2f) fx_confetti(100, 1180, -10, 24);
    parts_draw();
}

#define WIN_T0 1.15f          /* seconds after the gulp when the result panel starts to slide in */
#include "g_online.inc"       /* replays, records, the online table, the level editor */
#include "g_tas.inc"          /* TAS mode: the fastest full-star runs */
#include "g_settings.inc"     /* settings: volumes, switches, Mel's reactions one by one */

/* ---------- play ---------- */
static void finish_win(void) {
    int mx = CUR.maxst, st = S.stars > mx ? mx : S.stars;
    sfx_p(S_WIN, 0.8f, 640, 1.0f);
    if (L_mode != LM_PLAY) { mel_set(CL_SMILE, 1); if (L_replay && playb_tas) tas_end_toast(); return; }
    G_streak = 0; M.red_to = 0;
    REC.ticks = L_ticks; REC.stars = st;
    int had_tas = tas_unlocked();
    on_level_won(st);
    if (!had_tas && tas_unlocked()) tas_news = 1;      /* the last star of the chapter: tell the player about the new button (see tas_search_update) */
    if (st == mx && mx > 0 && V_attempt == 1 && emo_on(EM_WOW)) { mel_set(CL_LAUGH, 1); say(V_OMG, "О май гад!"); }  /* perfect at the first try */
    else if (L_hurry && emo_on(EM_BEST)) { mel_set(CL_BEST, 1); say2(V_BEST, V_LAUGH, "Кто лучший? Ахаха!"); }        /* he had to hurry the player up */
    else if (st == mx && emo_on(EM_BRAVO)) { mel_set(CL_LAUGH, 1); say(V_BRAVO, "Браво, босс!"); }
    else if (!emo_on(EM_SOSO) || st == mx) mel_set(CL_SMILE, 1);                                                      /* switched off: he just smiles */
    else if (st * 3 >= mx * 2) { mel_set(CL_SMILE, 1); if (rnd_u32() & 1) say(V_UUU, "У-у-у-у!"); else say(V_LAUGH, "Ха-ха-ха!"); }
    else { mel_set(CL_SMILE, 1); say(V_POSIDIM, "Не, ещё посидим!"); }
}
static void leave_level(void) { go(play_back, play_back_arg, 0); }
static void next_level(void) {
    if (CUR.kind != 0) { leave_level(); return; }
    int n = L_idx + 1;
    if (n >= LEVEL_COUNT) { go(SC_FINAL, 0, 0); return; }
    if (lvl_open(n)) go(SC_PLAY, n, 0); else go(SC_BOXES, 0, 0);
}
static void play_update(float dt) {
    if (L_paused || scr_next >= 0) return;
    L_t += dt;
    L_acc += dt; if (L_acc > 0.1f * maxf(1.0f, rp_now)) L_acc = 0.1f * maxf(1.0f, rp_now);
    while (L_acc >= SIM_DT) {
        L_acc -= SIM_DT;
        if ((L_demo || L_ghost) && S.state == ST_PLAY && CUR.demo) {
            const Step *sc = CUR.demo;
            for (int a = 0; a < 40 && sc[a].act != ACT_END; a++) if (!L_demo_done[a] && S.time >= sc[a].t) { L_demo_done[a] = 1; act_fx(sc[a].act, sc[a].arg); sim_do(&S, &sc[a]); on_events(); }
        }
        if (L_auto && L_mode == LM_PLAY && S.state == ST_PLAY && CUR.demo) {
            const Step *sc = CUR.demo;
            for (int a = 0; a < 40 && sc[a].act != ACT_END; a++) if (!L_demo_done[a] && S.time >= sc[a].t) { L_demo_done[a] = 1; act_fx(sc[a].act, sc[a].arg); player_act(sc[a].act, sc[a].arg); }
        }
        if (L_replay && S.state == ST_PLAY)
            while (playb_i < PLAYB.n && (int)(PLAYB.a[playb_i] >> 15) <= S.tick) { u32 a = PLAYB.a[playb_i++]; int act = (int)((a >> 12) & 7u), arg = (int)(a & 4095u); act_fx(act, arg); sim_act(&S, act, arg); on_events(); }
        sim_step(&S); on_events();
    }
    for (int i = 0; i < MAX_STARS; i++) {
        if (fly[i].on) { fly[i].t += dt; if (fly[i].t >= 0.55f) { fly[i].on = 0; hud_pop[i] = 1.0f; part_new(PT_RING, fly[i].x1, fly[i].y1, 0, 0, 0.3f, 22, 0xFFF3A0FFu); } }
        if (hud_pop[i] > 0) hud_pop[i] = maxf(0, hud_pop[i] - dt * 3.0f);
    }
    for (int i = 0; i < 6; i++) if (slash[i].t > 0) slash[i].t -= dt;
    for (int i = 0; i < 3; i++) if (spill[i].on) spill[i].t += dt;
    if (tapfx_t > 0) tapfx_t -= dt;
    if (L_toast_t > 0) L_toast_t -= g_dt;
    /* Mel's behaviour */
    if (L_phase == PH_PLAY) {
        M.idle_t += dt;
        int near = S.mouth_dist < MOUTH_NEAR;
        if (near && M.clip != CL_AM) {
            mel_set(CL_AM, 1); M.idle_t = 0;
            if (M.am_cool <= 0 && M.am_count < 3 && M.voice_t <= 0 && emo_on(EM_GIVE)) {   /* the bottle is close: "give it to me!" */
                int alt = G_give++ & 1;
                if (alt && SND[V_DAVAI]) say(V_DAVAI, "#@$%, давай!"); else if (SND[V_GIVE]) say(V_GIVE, "Дай его!"); else say(V_AM1, "Ам-ам-ам!");
                M.am_cool = 5.0f; M.am_count++;
            }
        } else if (!near && M.clip == CL_AM && S.mouth_dist > MOUTH_NEAR * 1.3f) mel_set(CL_IDLE, 1);
        if (L_mode == LM_PLAY && !L_hurry && !near && M.idle_t > 13.0f && M.voice_t <= 0 && emo_on(EM_HURRY)) {      /* the player thinks for too long */
            L_hurry = 1; M.idle_t = 0; mel_react(CL_FASTER, 0.9f); say2(V_FASTER, -1, "Быстрее! Быстрее!!!");
        } else if (M.clip == CL_IDLE && M.idle_t > 8.0f && M.react <= 0 && emo_on(EM_BORED)) { mel_set(CL_BORED, 1); M.react = clip_len(CL_BORED) * 2.0f; }
        if (L_replay && playb_i >= PLAYB.n && S.tick > PLAYB.ticks + SIM_HZ * 6) { L_toast = "Запись закончилась"; L_toast_t = 2.0f; leave_level(); }
    } else if (L_phase == PH_WIN) {
        L_pt += g_dt;                                /* the result is held for the same real time at any speed of the show */
        if (!L_react_done && L_pt > 0.42f) { L_react_done = 1; finish_win(); }
        if (L_demo && L_pt > 2.3f) { restart_level(LM_PLAY); L_toast = "Теперь сам!"; L_toast_t = 2.2f; }
        if (L_replay && L_pt > 2.8f) leave_level();
    } else {
        L_pt += g_dt;
        if (L_pt > L_failhold || (L_pt > 0.5f && P.pressed && !hud_hit(P.downx, P.downy))) { if (L_replay) leave_level(); else restart_level(L_mode); }
    }
}
static void draw_toast(void) {
    if (L_toast_t <= 0) return;
    float a = clampf(L_toast_t / 0.3f, 0, 1), w = gfx_text_w(&F_ui, L_toast, 30) + 60, y = rp_viewing() ? 122.0f : 26.0f;
    gfx_rrect(640 - w * 0.5f, y, w, 52, 26, RGBA(14, 10, 46, (int)(190 * a)));
    gfx_text(&F_ui, L_toast, 640, y + 26, 30, RGBA(255, 255, 255, (int)(255 * a)), AL_CENTER);
}
static void draw_pause(void) {
    int can_demo = CUR.demo && !(CUR.kind == 0 && CUR.box == 9);
    panel(410, 96, 460, 528);
    title_text("Пауза", 640, 150, 50);
    if (wbtn(40, 640, 232, 350, 66, "Продолжить", C_GREEN1, C_GREEN2, 33, IC_PLAY, 1)) L_paused = 0;
    if (wbtn(41, 640, 310, 350, 66, "Заново", C_BLUE1, C_BLUE2, 33, IC_RESTART, 1)) restart_level(L_replay ? LM_REPLAY : LM_PLAY);
    if (wbtn(42, 640, 388, 350, 66, can_demo ? "Показать решение" : (CUR.kind == 0 ? "Экзамен: без подсказок" : "Решения нет"), C_ORG1, C_ORG2, can_demo ? 29 : 24, IC_NONE, can_demo)) restart_level(LM_DEMO);
    if (wbtn(43, 640, 466, 350, 66, CUR.kind == 1 ? "В редактор" : (play_back == SC_LEVELS ? "К уровням" : "Назад"), C_VIO1, C_VIO2, 33, IC_GRID, 1)) leave_level();
    if (rbtn(44, 596, 558, 29, SV.sound ? IC_SOUND : IC_SOUND_OFF, C_VIO1, C_VIO2, 1)) { SV.sound = !SV.sound; apply_volumes(); save_store(); }
    if (rbtn(45, 684, 558, 29, SV.music ? IC_MUSIC : IC_MUSIC_OFF, C_VIO1, C_VIO2, 1)) { SV.music = !SV.music; apply_volumes(); save_store(); }
}
static void draw_win(void) {
    float t = L_pt - WIN_T0; if (t <= 0 || L_mode != LM_PLAY) return;
    int mx = CUR.maxst, st = S.stars > mx ? mx : S.stars, big = mx <= 3; char tb[24], tb2[24], buf[96];
    float e = ease_out_back(clampf(t / 0.4f, 0, 1)), oy = (1.0f - e) * 560.0f;
    gfx_offset(0, oy);
    float px = 240, py = 138, pw = 800, ph = 444;
    panel(px, py, pw, ph);
    draw_mel_cam(px + 24, py + 24, 300, ph - 48);
    float cx = px + 324 + (pw - 324) * 0.5f;
    title_text(st == mx && mx > 0 ? "Идеально!" : (st == 0 ? "Доставлено!" : "Уровень пройден!"), cx, py + (big ? 62 : 54), st == mx && mx > 0 ? 52 : 42);
    for (int i = 0; i < mx; i++) {
        float sx = big ? cx + (i - (mx - 1) * 0.5f) * 112.0f : cx + (i % 5 - 2) * 80.0f, sy = big ? py + 170 - (i == 1 && mx == 3 ? 18 : 0) : py + 124 + 66 * (i / 5);
        float sz = big ? 92.0f : 60.0f, ts = t - 0.45f - i * (big ? 0.32f : 0.13f);
        star_icon(sx, sy, sz, 0, 1);
        if (i < st && ts > 0) {
            if (L_shown <= i) { L_shown = i + 1; sfx_p(S_STAR1 + (i > 2 ? 2 : i), 0.7f, sx, i > 2 ? 1.0f + 0.06f * (float)(i - 2) : 1.0f); fx_ring(sx, sy + oy, sz * 0.55f, 0xFFF3A0FFu, 0.4f);
                for (int k = 0; k < (big ? 8 : 5); k++) { float a = rnd_range(0, TAU), v = rnd_range(150, 360); Part *p = part_new(PT_SPARK, sx, sy + oy, cosf(a) * v, sinf(a) * v, 0.5f, 40, 0xFFE680FFu); p->drag = 3; } }
            float s = ease_out_elastic(clampf(ts / 0.6f, 0, 1));
            gfx_image_tint(I_glow, sx, sy, sz / 84.0f * s, sz / 84.0f * s, 0, RGBA(255, 255, 255, 120), 1);
            star_icon(sx, sy, sz * 1.06f * s, 1, 1);
        }
    }
    /* time of this attempt and the personal best */
    fmt_time(L_ticks, tb, (int)sizeof(tb));
    if (L_newbest || win_first) snprintf(buf, sizeof(buf), "Время %s", tb);
    else if (win_best_ticks > 0) snprintf(buf, sizeof(buf), "Время %s  •  рекорд %s", tb, fmt_time(win_best_ticks, tb2, (int)sizeof(tb2)));
    else snprintf(buf, sizeof(buf), "Время %s", tb);
    gfx_text(&F_ui, buf, cx, py + 256, 25, WHITE, AL_CENTER);
    const char *msg = st == mx ? "Мел в восторге. Браво, босс!" : (st * 3 >= mx * 2 ? "Почти! Не хватает звёзд." : (st > 0 ? "Маловато звёзд. Ещё посидим?" : "Чекушка доехала, но без звёзд."));
    if (L_newbest) msg = "Новый личный рекорд!";
    gfx_text(&F_txt, msg, cx, py + 292, 22, L_newbest ? C_GOLD : 0xE8E0FFFFu, AL_CENTER);
    int ready = t > 0.7f; float by = py + 366;
    const char *nxt = CUR.kind == 0 ? "Дальше" : (CUR.kind == 1 ? "Готово" : "К списку");
    if (tas_offered(st)) {                            /* one more button: the fastest run of this level */
        if (rbtn(50, cx - 192, by, 30, IC_GRID, C_VIO1, C_VIO2, ready)) leave_level();
        if (rbtn(51, cx - 120, by, 30, IC_RESTART, C_BLUE1, C_BLUE2, ready)) restart_level(LM_PLAY);
        if (rbtn(53, cx - 48, by, 30, IC_CUP, C_ORG1, C_ORG2, ready && CUR.kind != 1)) { if (CUR.kind == 0) go(SC_RECORDS, CUR.idx, 0); else go(SC_RECORDS, -2, 0); }
        if (wbtn(54, cx + 38, by, 88, 64, "TAS", C_ORG1, C_ORG2, 28, IC_NONE, ready)) tas_from_win();
        if (wbtn(52, cx + 158, by, 128, 72, nxt, C_GREEN1, C_GREEN2, CUR.kind == 0 ? 29 : (CUR.kind == 1 ? 27 : 23), IC_NONE, ready)) next_level();
    } else {
        if (rbtn(50, cx - 196, by, 34, IC_GRID, C_VIO1, C_VIO2, ready)) leave_level();
        if (rbtn(51, cx - 118, by, 34, IC_RESTART, C_BLUE1, C_BLUE2, ready)) restart_level(LM_PLAY);
        if (rbtn(53, cx - 40, by, 34, IC_CUP, C_ORG1, C_ORG2, ready && CUR.kind != 1)) { if (CUR.kind == 0) go(SC_RECORDS, CUR.idx, 0); else go(SC_RECORDS, -2, 0); }
        if (wbtn(52, cx + 110, by, 204, 76, nxt, C_GREEN1, C_GREEN2, CUR.kind == 0 ? 36 : 30, IC_NONE, ready)) next_level();
    }
    gfx_offset(0, 0);
    if (st == mx && mx > 0 && !L_conf && t > 0.5f) { L_conf = 1; fx_confetti(px + 60, px + pw - 60, py - 10, 90); }
}
static void draw_speed_bar(int enabled) {
    char buf[16]; float p = rp_pos(rp_speed); int was = ui_block; if (!enabled) ui_block = 1;
    gfx_rrect(RP_X - 44, 14, RP_W + 172, 56, 28, 0x0E0A2EB4u);
    for (int i = 0; i < 3; i++) {                       /* marks: 0.1x, 1x, 5x */
        static const char *const lab[3] = { "0.1", "1", "5" }; float mx = RP_X + RP_W * 0.5f * (float)i;
        gfx_rrect(mx - 1.5f, RP_Y - 9, 3, 18, 1.5f, 0xFFFFFF50u); gfx_text(&F_txt, lab[i], mx, RP_Y + 19, 13, 0xFFFFFFA0u, AL_CENTER);
    }
    if (slider(64, RP_X, RP_Y - 3, RP_W, &p, C_ORG1)) rp_speed = rp_val(p);
    snprintf(buf, sizeof(buf), "%d.%dX", (int)(rp_speed * 10.0f + 0.5f) / 10, (int)(rp_speed * 10.0f + 0.5f) % 10);
    if (wbtn(63, RP_X + RP_W + 70, RP_Y, 92, 40, buf, fabsf(rp_speed - 1.0f) < 0.01f ? C_VIO1 : C_ORG1, fabsf(rp_speed - 1.0f) < 0.01f ? C_VIO2 : C_ORG2, 23, IC_NONE, 1)) rp_speed = 1.0f;      /* a click: back to 1x */
    ui_block = was;
}
static void scr_play(void) {
    int win = (L_phase == PH_WIN && L_mode == LM_PLAY && L_pt > WIN_T0), frozen = L_paused || (win && L_pt > WIN_T0 + 0.5f);
    if (frozen && snap_usable()) { gfx_offset(0, 0); gfx_copy_from(snap); }       /* frozen, dimmed backdrop: one memcpy */
    else {
        float sx = 0, sy = 0;
        if (shake_t > 0 && CFG.shake) { float k = shake_t / 0.35f; sx = rnd_range(-1, 1) * shake_amp * k; sy = rnd_range(-1, 1) * shake_amp * k; }
        bg_draw(CUR.box, 1.0f, DECO_LEVEL, CUR.kind ? 900 + ((int)S.mx * 3 + (int)S.my * 5 + CUR.flip) % 4000 : L_idx + 1, sx, sy);
        draw_scene();
        if (!win) parts_draw();
        draw_trail();
        if (S.has_mel && !win && !(g_capflags & 2)) draw_say(S.mx, mel_fy(), M.say_ox, M.say_oy, 1.0f);
        gfx_offset(0, 0);
        if (flash_t > 0 && CFG.shake) gfx_fade(RGBA(255, 255, 255, (int)(150 * flash_t / 0.12f)));
        if (!(g_capflags & 1)) {
            draw_hud();
            draw_toast();
            int hud_on = !L_paused && !(L_phase == PH_WIN && L_pt > 1.0f);
            if (rbtn(60, HUD_RX, HUD_BY, HUD_BR, IC_RESTART, C_BLUE1, C_BLUE2, hud_on)) restart_level(L_replay ? LM_REPLAY : LM_PLAY);
            if (rbtn(61, HUD_PX, HUD_BY, HUD_BR, IC_PAUSE, C_VIO1, C_VIO2, hud_on && L_phase == PH_PLAY)) L_paused = 1;
            if (L_replay || L_demo) draw_speed_bar(!L_paused);
        }
        snap_ok = 0;
        if (L_paused) gfx_fade(0x0A0626B0u);
        else if (win) gfx_fade(RGBA(10, 6, 38, (int)(150 * clampf((L_pt - WIN_T0) / 0.3f, 0, 1))));
        if (frozen) snap_take();
    }
    if (win) { draw_win(); parts_draw(); }
    if (L_paused) draw_pause();
}

/* ============================== app entry points ============================== */
void app_init(const u8 *pack, int packsize, int audio_rate) {
    pack_init(pack, packsize); audio_init(audio_rate);
    I_bottle = img_load("bottle"); I_desk = img_load("desk"); I_deskbig = img_load("desk_big"); I_blower = img_load("blower");
    I_star = img_load("star"); I_star0 = img_load("star_empty"); I_glow = img_load("glow"); I_wglow = img_load("wglow"); I_spark = img_load("spark"); I_dot = img_load("dot");
    I_pin = img_load("pin"); I_bubble = img_load("bubble"); I_logo = img_load("logo");
    for (int i = 0; i < BOXES; i++) {
        char nm[16]; snprintf(nm, sizeof(nm), "bg%d", i); I_bg[i] = img_load(nm); snprintf(nm, sizeof(nm), "cover%d", i); I_cover[i] = img_load(nm);
        if (!I_bg[i]) I_bg[i] = I_bg[i % 3]; if (!I_cover[i]) I_cover[i] = I_cover[i % 3];
    }
    for (int i = 0; i < LEVEL_COUNT && i < MAXLV; i++) { lv_max[i] = sim_max_stars(g_levels[i].objs); stars_all += lv_max[i]; }
    font_load(&F_ui, "ui"); font_load(&F_txt, "txt");
    for (int i = 0; i < S_COUNT; i++) SND[i] = snd_load(snd_names[i]);
    for (int i = 0; i < CL_N; i++) clip_load(&CLP[i], clip_names[i]);
    save_load(); cfg_load(); apply_volumes();
    rnd_seed(0xC0FFEE01u);
    online_init();
    mel_set(CL_IDLE, 1);
    snd_music(SND[S_MUSIC]);
    g_fade = 1.0f;
}
void app_resize(u32 *px, int w, int h) { gfx_set_framebuffer(px, w, h); bgc_key = 0; snap_ok = 0; }

void app_pointer(int type, float x, float y) {
    float ox = P.x, oy = P.y; P.x = x; P.y = y;
    if (type == 1) {
        P.down = 1; P.pressed = 1; P.active = 0; P.downx = x; P.downy = y; P.moved = 0; P.game = 0; P.tapped = 0; rail_drag = -1;
        if (input_ok() && !hud_hit(x, y)) {
            int act, arg;
            P.game = 1; trail_n = 0;
            if (sim_pick(&S, x, y, &act, &arg)) { P.tapped = 1; if (player_act(act, arg)) { tapfx_x = x; tapfx_y = y; tapfx_t = 0.25f; cap_ev(act == ACT_POP ? 2 : 3, x, y); } }
            else if ((rail_drag = sim_rail_pick(&S, x, y)) >= 0) { P.tapped = 1; rail_q = -1; cap_ev(4, x, y); }      /* grabbed a pin that rides on a rail */
            else trail_add(x, y);
        }
    } else if (type == 0) {
        if (P.down && P.game && input_ok()) {
            if (rail_drag >= 0) { int q = sim_rail_q(&S, rail_drag, x, y); if (q != rail_q) { rail_q = q; player_act(ACT_SLIDE, rail_drag | (q << 4)); acted(); } }
            else if (hypotf(x - ox, y - oy) > 0.01f) { player_swipe(ox, oy, x, y); trail_add(x, y); }
            if (hypotf(x - P.downx, y - P.downy) > 9.0f) P.moved = 1;
        }
    } else if (type == 2) {
        if (P.down) { P.released = 1; P.upx = x; P.upy = y; if (P.game && !P.moved && !P.tapped && input_ok()) click_cut(x, y); }
        P.down = 0; P.game = 0; rail_drag = -1;
    }
}
void app_key(int key, int down) {
    if (!down || scr_next >= 0) return;
    if (ui_key(key)) return;                             /* text input, lists and the editor take the keys first */
    switch (key) {
    case KEY_ESC:
        if (scr == SC_PLAY) { if (L_phase == PH_PLAY && L_mode == LM_PLAY) L_paused = !L_paused; else leave_level(); }
        else if (scr == SC_LEVELS) go(SC_BOXES, 0, 0);
        else if (scr == SC_BOXES) go(SC_CHAPTERS, 0, 0);
        else if (scr != SC_MENU) go(SC_MENU, 0, 0);
        break;
    case KEY_R: if (scr == SC_PLAY && !(L_phase == PH_WIN && L_pt < 1.5f)) restart_level(L_replay ? LM_REPLAY : LM_PLAY); break;
    case KEY_M: SV.music = SV.sound = !(SV.music || SV.sound); apply_volumes(); save_store(); break;
    case KEY_LEFT: case KEY_RIGHT: if (rp_viewing() && !L_paused) rp_step(key == KEY_RIGHT ? 1 : -1); break;      /* the speed of a recording */
    case KEY_F: if (plat_caps() & 2) plat_fullscreen(); break;
    case KEY_ENTER: case KEY_SPACE:
        if (scr == SC_MENU) go(SC_CHAPTERS, 0, 0);
        else if (scr == SC_PLAY && L_phase == PH_WIN && L_pt > 1.9f && L_mode == LM_PLAY) next_level();
        else if (scr == SC_PLAY && L_paused) L_paused = 0;
        break;
    default: break;
    }
}
void app_char(u32 cp) { ui_char(cp); }
void app_frame(float dt) {
    if (dt > 0.1f) dt = 0.1f; if (dt < 0) dt = 0;
    g_dt = dt; g_time += dt;
    ui_block = (scr_next >= 0) || g_fade > 0.6f || modal_on();
    if (scr_next >= 0) { g_fade += dt * 5.0f; if (g_fade >= 1.0f) { g_fade = 1.0f; enter(scr_next, scr_arg, scr_arg2); scr_next = -1; } }
    else if (g_fade > 0) { g_fade -= dt * 4.0f; if (g_fade < 0) g_fade = 0; }
    if (shake_t > 0) shake_t -= dt; if (flash_t > 0) flash_t -= dt;
    mel_update(dt);
    online_update(dt);
    tas_search_update();
    rp_now = rp_viewing() ? rp_speed : 1.0f;
    if (scr == SC_PLAY) play_update(dt * rp_now);
    if (!(scr == SC_PLAY && L_paused)) parts_update(dt * rp_now);
    gfx_offset(0, 0); gfx_clip_reset();
    switch (scr) {
    case SC_MENU: scr_menu(); break;
    case SC_CHAPTERS: scr_chapters(); break;
    case SC_BOXES: scr_boxes(); break;
    case SC_LEVELS: scr_levels(); break;
    case SC_PLAY: scr_play(); break;
    case SC_FINAL: scr_final(); break;
    case SC_RECORDS: scr_records(); break;
    case SC_HUB: scr_hub(); break;
    case SC_EDITOR: scr_editor(); break;
    case SC_TAS: scr_tas(); break;
    case SC_SETTINGS: scr_settings(); break;
    }
    modal_draw();                                        /* nick / name input, messages */
    if (g_fade > 0) gfx_fade(RGBA(8, 5, 26, (int)(255 * clampf(g_fade, 0, 1))));
    P.pressed = 0; P.released = 0;
}
/* The physics must give the same numbers in every build, or replays would not match:
   this runs the stored solution of a level through the bare simulation and hashes every position. */
static int sim_hash_level(int idx) {
    static Sim T; const Step *sc = g_levels[idx].demo; int done[64] = { 0 }; u32 h = 2166136261u, b;
    sim_load(&T, g_levels[idx].objs);
    for (int n = 0; n < SIM_HZ * 60 && T.state == ST_PLAY; n++) {
        for (int a = 0; a < 64 && sc[a].act != ACT_END; a++) if (!done[a] && T.time >= sc[a].t) { done[a] = 1; sim_do(&T, &sc[a]); }
        sim_step(&T);
        memcpy(&b, &T.c.x, 4); h = (h ^ b) * 16777619u; memcpy(&b, &T.c.y, 4); h = (h ^ b) * 16777619u;
    }
    h = (h ^ (u32)T.tick) * 16777619u; h = (h ^ (u32)(T.state | (T.stars << 4))) * 16777619u;
    return (int)(h & 0x7FFFFFFFu);
}
/* test hooks for the headless harness */
int app_debug(int cmd, int arg) {
    switch (cmd) {
    case 1: scr_next = -1; enter(SC_PLAY, arg, LM_PLAY); g_fade = 0; return 0;
    case 2: scr_next = -1; enter(SC_PLAY, arg, LM_DEMO); g_fade = 0; return 0;
    case 3: for (int i = 0; i < LEVEL_COUNT; i++) { int v = arg > lv_max[i] ? lv_max[i] : arg; if (SV.best[i] < (u8)(v + 1)) SV.best[i] = (u8)(v + 1); } return 0;
    case 4: return S.state | (S.stars << 4) | (L_phase << 8) | (scr << 12) | (L_demo << 16);
    case 5: scr_next = -1; enter(arg, sel_box, 0); g_fade = 0; return 0;
    case 6: sel_box = arg; return 0;
    case 7: L_paused = arg; return 0;
    case 8: memset(SV.best, 0, sizeof(SV.best)); memset(SV.ticks, 0, sizeof(SV.ticks)); return 0;
    case 9: return total_stars();
    case 35:                                                                    /* tests and captures: bring up one of Mel's special reactions */
        if (scr != SC_PLAY) return -1;
        if (arg == 1) { V_breaks = 3; V_red_said = 0; on_fail(1); } else if (arg == 2) { V_fails = 5; on_fail(0); } else if (arg == 3) M.idle_t = 12.9f;
        else if (arg == 4) L_hurry = 1; else if (arg == 5) { G_streak = 2; V_fails = 0; on_fail(0); }
        return 0;
    case 34: scr_next = -1; enter(SC_PLAY, arg, LM_PLAY); L_auto = 1; g_fade = 0; return 0;      /* a real, counted run that plays itself */
    case 10: scr_next = -1; enter(SC_PLAY, arg, LM_GHOST); g_fade = 0; return 0;      /* play the stored solution as a normal-looking run */
    case 11: g_capflags = arg; return 0;
    case 12: return (int)(S.c.x * 8.0f);                                        /* 12..20: more capture aids */
    case 13: return (int)(S.c.y * 8.0f);
    case 14: return (int)(S.mx * 8.0f);
    case 15: return (int)(mel_fy() * 8.0f);
    case 16: return cap_ev_n;
    case 17: return cap_ev_type;
    case 18: return (int)(cap_ev_x * 8.0f);
    case 19: return (int)(cap_ev_y * 8.0f);
    case 20: SV.music = arg ? 1 : 0; apply_volumes(); return 0;
    case 21: SV.sound = arg ? 1 : 0; apply_volumes(); return 0;
    case 22: return (M.say_t > 0.18f && M.say[0]) ? 1 : 0;                      /* 22..24: is a speech bubble shown, its centre x relative to the face, its width (x8) */
    case 23: return (int)(M.say_ox * 8.0f);
    case 24: bubble_measure(); return (int)(bubble_w * 8.0f);
    case 25: return arg >= 0 && arg < LEVEL_COUNT ? lv_max[arg] : 0;            /* stars in a level */
    case 26: return S.tick;
    case 27: return L_ticks;
    case 28: return LEVEL_COUNT;
    case 29: return REC.n;
    case 30: return sim_hash_level(arg);                                        /* the same number in every build, or the physics differ */
    case 31: return SIM_VERSION;
    case 32: return (int)(M.red * 100.0f);
    case 33: return V_fails | (V_breaks << 8) | (G_streak << 16);
    default: return cmd >= 140 && cmd < 180 ? v04_debug(cmd, arg) : (cmd >= 120 && cmd < 140 ? tas_debug(cmd, arg) : online_debug(cmd, arg));
    }
    return 0;
}
