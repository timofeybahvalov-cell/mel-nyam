/* ============================================================================
   «МЕЛ-НЯМ» V0.5 — the player's profile and what is built on it:
     чекушки (the currency), skins of the bottle and the shop, achievements, daily and weekly missions,
     the progress kept in the account (one account = one progress on every device), the support chat,
     the music of the locations.
   Included by game.c (one translation unit), after g_settings.inc.
   ============================================================================ */

/* ---------------- the clock ---------------- */
static int t_off;                                    /* the table's clock minus the clock of this device (seconds), once the table has answered */
static u32 now_s(void) { int t = plat_ctl(PC_TIME, NULL, 0, 0); return t > 0 ? (u32)(t + t_off) : 0; }
#define MSK 10800u                                   /* days and weeks turn over at midnight, Moscow time */
static u32 day_of(u32 t) { return (t + MSK) / 86400u; }
static u32 week_of(u32 day) { return (day + 3u) / 7u; }      /* weeks start on Monday */
static u32 day_left(u32 t) { return 86400u - (t + MSK) % 86400u; }
static u32 week_left(u32 t) { return (6u - (day_of(t) + 3u) % 7u) * 86400u + day_left(t); }

/* ---------------- the profile ---------------- */
enum { CN_WINS, CN_PERFECT, CN_CUTS, CN_POPS, CN_FAILS, CN_FIRST, CN_RECORDS, CN_PUB, CN_OTHERS, CN_WATCH, CN_DAILY, CN_WEEKLY, CN_POKE, CN_FAST, CN_TOP1, CN_TAS, CN_CLEAN, CN_N = 24 };
enum { MK_NONE, MK_WINS, MK_STARS, MK_PERFECT, MK_BOX, MK_FIRST, MK_RECORD, MK_FAST, MK_CUTS, MK_POPS, MK_TIME, MK_WATCH, MK_OTHERS, MK_EDITOR, MK_RUN, MK_VIEWS, MK_DAILIES,
       MK_FEED, MK_PLAY, MK_PLACE, MK_VISIT, MK_SLEEP, MK_N };      /* (the last five: V0.6, the monthly missions about the house and the little Mel) */
typedef struct { u8 kind, arg, done, r; u16 target, prog, reward, r2; u32 mask[2]; } Mission;      /* mask: the levels already counted (a mission wants different levels) */
/* V0.6 (g_home.inc): the house of an account, the monthly missions */
static int home_earned(void); static int home_spent(void); static Mission *month_cur(void); static void month_done(void); static void home_level_won(void);
static void home_switch(u32 uid); static void home_flush(void); static void home_init(void); static void home_update(float dt);
#define PROF_MAGIC 0x35465250u
#define SKIN_N 21
#define ACH_N 31
typedef struct {
    u32 magic, uid;                                  /* uid: the account this progress belongs to (0: nobody is signed in) */
    u32 earned;                                      /* чекушки earned so far; the balance is this minus the prices of the skins bought */
    u32 skins;                                       /* bit k: skin k is owned */
    u32 ach[2];                                      /* achievements done */
    u32 cn[CN_N];                                    /* counters the achievements look at */
    u32 day, week;                                   /* which daily and which weekly set this is */
    Mission dm[3], wm[4];
    u32 run_t[PER_BOX];                              /* weekly "a location in 10 minutes": when each of its levels was last won */
    u32 pub_id[4];                                   /* weekly "a level with N plays": the levels published this week */
    u32 best_plays;                                  /* the most plays any own level has */
    u32 rev;                                         /* the number of the save in the table that this copy has seen */
    u32 first_mask[2];                               /* levels ever won at the first attempt */
    u32 chat_last;                                   /* the newest message of the support chat that was read */
    u8 skin, dirty, chat, seen;                      /* dirty: changed since the last upload; chat: has written to the support; seen: the day the missions were last looked at */
    u32 r[8];
} Profile;
static Profile PF;
static u16 lv_hash16[MAXLV];
typedef struct { const char *name; int price; } SkinDef;
static const SkinDef skin_tab[SKIN_N] = { { "Чекушка", 0 }, { "Вода", 50 }, { "Сок", 80 }, { "Морс", 100 }, { "Квас", 120 }, { "Лимонад", 150 },
                                          { "Энергетик", 200 }, { "Пиво", 250 }, { "Вино", 300 }, { "Водка", 400 }, { "Золотая", 500 },
                                          /* V0.6: ten more drinks */
                                          { "Молоко", 60 }, { "Чай", 70 }, { "Компот", 90 }, { "Кисель", 110 }, { "Минералка", 130 },
                                          { "Какао", 160 }, { "Кофе", 180 }, { "Кола", 220 }, { "Капучино", 260 }, { "Горячий шоколад", 350 } };
static const u8 skin_order[SKIN_N] = { 0, 1, 11, 12, 2, 13, 3, 14, 4, 15, 5, 16, 17, 6, 18, 7, 19, 8, 20, 9, 10 };      /* the shop shows them by price */
static Image *I_skin[SKIN_N];
static int my_badge, sup_unread;
static int coins(void) { int c = (int)PF.earned + home_earned() - home_spent(); for (int i = 1; i < SKIN_N; i++) if ((PF.skins >> i) & 1u) c -= skin_tab[i].price; return c < 0 ? 0 : c; }
static int skins_owned(void) { int n = 0; for (int i = 1; i < SKIN_N; i++) n += (PF.skins >> i) & 1u; return n; }
static const Image *skin_img(void) { int k = PF.skin < SKIN_N ? PF.skin : 0; return k && I_skin[k] ? I_skin[k] : I_bottle; }
static const Image *skin_pic(int k) { return I_skin[k] ? I_skin[k] : I_bottle; }
static const char *plural(int n, const char *one, const char *few, const char *many) {      /* 1 уровень, 2 уровня, 5 уровней */
    int a = n % 100, b = n % 10; if (a >= 11 && a <= 14) return many; return b == 1 ? one : (b >= 2 && b <= 4 ? few : many);
}

/* what was just earned: shown one after another at the top of the screen */
static struct { int n; float t; struct { char text[128]; int coins; } q[8]; } RW;
static void rw_push(const char *text, int c) {
    if (RW.n >= 8) return;
    snprintf(RW.q[RW.n].text, sizeof(RW.q[0].text), "%s", text); RW.q[RW.n].coins = c; if (!RW.n) RW.t = 0; RW.n++;
}

static struct { int loaded, fresh, gen, sent_gen, soft, mine_asked, peeked; float t, retry, soft_t, out_t, lv_t; u32 save_uid, out_uid; char out_tok[48]; } PS;
static void prof_store(void) { plat_store("prof", &PF, (int)sizeof(PF)); PS.soft = 0; }
static void prof_dirty(void) { PF.dirty = 1; PS.gen++; if (PS.t <= 0 || PS.t > 3.0f) PS.t = 3.0f; prof_store(); }
static void prof_fresh(u32 uid) { memset(&PF, 0, sizeof(PF)); PF.magic = PROF_MAGIC; PF.uid = uid; PF.skins = 1; }

/* ---------------- achievements ---------------- */
enum { AV_LEVELS = 100, AV_STARS, AV_ARENA, AV_SKINS, AV_ACC, AV_PLAYS };
typedef struct { const char *name, *desc; int reward, src; u32 goal; } AchDef;
static const AchDef ach_tab[ACH_N] = {
    { "Первый глоток",       "Пройди первый уровень",                                        10, AV_LEVELS, 1 },
    { "Отличник",            "Пройди уровень на все звёзды",                                 10, CN_PERFECT, 1 },
    { "Десяточка",           "Пройди 10 уровней",                                            15, AV_LEVELS, 10 },
    { "Полпути",             "Пройди 30 уровней",                                            30, AV_LEVELS, 30 },
    { "До конца",            "Пройди все 60 уровней",                                        60, AV_LEVELS, 60 },
    { "Звездочёт",           "Собери 50 звёзд",                                              20, AV_STARS, 50 },
    { "Сотня",               "Собери 100 звёзд",                                             40, AV_STARS, 100 },
    { "Полтораста",          "Собери 150 звёзд",                                             60, AV_STARS, 150 },
    { "Все звёзды",          "Собери все 222 звезды",                                        150, AV_STARS, 222 },
    { "Экзамен сдан",        "Пройди все шесть уровней Арены",                               80, AV_ARENA, 6 },
    { "С первого раза",      "Пройди 10 разных уровней с первой попытки",                    25, CN_FIRST, 10 },
    { "Спидран",             "Пройди уровень на все звёзды быстрее полутора секунд",         30, CN_FAST, 1 },
    { "Рекордсмен",          "Побей свой рекорд времени 10 раз",                             30, CN_RECORDS, 10 },
    { "Как компьютер",       "Пройди уровень на все звёзды так же быстро, как TAS",          100, CN_TAS, 1 },
    { "Без единой ошибки",   "Пройди все уровни одной локации подряд с первой попытки",      50, CN_CLEAN, 1 },
    { "Ножницы",             "Перережь 500 верёвок",                                         30, CN_CUTS, 500 },
    { "Пузырь",              "Лопни 100 пузырей",                                            20, CN_POPS, 100 },
    { "Обжора",              "Накорми Мела 200 раз",                                         40, CN_WINS, 200 },
    { "Бой посуды",          "Разбей или потеряй 50 чекушек",                                15, CN_FAILS, 50 },
    { "Свой аккаунт",        "Создай аккаунт или войди в него",                              20, AV_ACC, 1 },
    { "Архитектор",          "Опубликуй свой уровень",                                       30, CN_PUB, 1 },
    { "Популярный автор",    "Твой уровень сыграли 10 раз",                                  50, AV_PLAYS, 10 },
    { "Знаменитость",        "Твой уровень сыграли 50 раз",                                  100, AV_PLAYS, 50 },
    { "В гостях",            "Пройди 5 уровней других игроков",                              25, CN_OTHERS, 5 },
    { "Зритель",             "Посмотри 10 записей других игроков",                           15, CN_WATCH, 10 },
    { "Первое место",        "Займи первое место в таблице любого уровня",                   100, CN_TOP1, 1 },
    { "Трудяга",             "Выполни 10 ежедневных заданий",                                40, CN_DAILY, 10 },
    { "Неделя за неделей",   "Выполни 5 еженедельных заданий",                               60, CN_WEEKLY, 5 },
    { "Модник",              "Купи 3 скина",                                                 20, AV_SKINS, 3 },
    { "Коллекционер",        "Купи 10 скинов",                                               150, AV_SKINS, 10 },
    { "Тык!",                "Ткни Мела в главном меню 10 раз",                              10, CN_POKE, 10 },
};
static u32 ach_value(int src) {
    if (src < 100) return PF.cn[src];
    switch (src) {
    case AV_LEVELS: { u32 n = 0; for (int i = 0; i < LEVEL_COUNT; i++) n += (u32)lvl_done(i); return n; }
    case AV_STARS: return (u32)total_stars();
    case AV_ARENA: { u32 n = 0; for (int i = (BOXES - 1) * PER_BOX; i < LEVEL_COUNT; i++) n += (u32)lvl_done(i); return n; }
    case AV_SKINS: return (u32)skins_owned();
    case AV_ACC: return (u32)(CFG.acc != 0);
    case AV_PLAYS: return PF.best_plays;
    }
    return 0;
}
static int ach_done(int i) { return (PF.ach[i >> 5] >> (i & 31)) & 1u; }
static void ach_check(void) {
    int n = 0, sum = 0, got[2] = { 0, 0 }; char b[120];
    for (int i = 0; i < ACH_N; i++) if (!ach_done(i) && ach_value(ach_tab[i].src) >= ach_tab[i].goal) { PF.ach[i >> 5] |= 1u << (i & 31); PF.earned += (u32)ach_tab[i].reward; if (n < 2) got[n] = i; n++; sum += ach_tab[i].reward; }
    if (!n) return;
    if (n <= 2) for (int k = 0; k < n; k++) { snprintf(b, sizeof(b), "Достижение: «%s»", ach_tab[got[k]].name); rw_push(b, ach_tab[got[k]].reward); }
    else { snprintf(b, sizeof(b), "Получено достижений: %d", n); rw_push(b, sum); }      /* (an old progress meets the achievements for the first time) */
    prof_dirty();
}

/* ---------------- missions ---------------- */
static int tasks_new;                                /* a new set has come and the player has not looked at it yet */
static u32 mhash(u32 a, u32 b) { u32 h = (a + 0x9E3779B9u) * 2654435761u ^ (b + 0x7F4A7C15u) * 2246822519u; h ^= h >> 15; h *= 2246822519u; h ^= h >> 13; h *= 3266489917u; h ^= h >> 16; return h; }
static int boxes_open(void) { int n = 0; for (int b = 0; b < BOXES; b++) if (box_open(b)) n = b + 1; return n < 1 ? 1 : n; }
static int levels_open(void) { int n = 0; for (int i = 0; i < LEVEL_COUNT; i++) n += lvl_open(i); return n; }
static void mis_set(Mission *m, int kind, int arg, int target, int reward) { memset(m, 0, sizeof(*m)); m->kind = (u8)kind; m->arg = (u8)arg; m->target = (u16)target; m->reward = (u16)reward; }
static void daily_make(u32 day) {
    static const u8 pool0[4] = { MK_WINS, MK_STARS, MK_BOX, MK_PERFECT }, pool1[5] = { MK_FIRST, MK_CUTS, MK_RECORD, MK_FAST, MK_POPS }, pool2[4] = { MK_TIME, MK_WATCH, MK_EDITOR, MK_OTHERS };
    int k0 = pool0[day % 4u], k1 = pool1[(day * 2u + 1u) % 5u], k2 = pool2[(day * 3u + 2u) % 4u], nb = boxes_open(); u32 h;
    if (k1 == MK_POPS && nb < 2) k1 = MK_CUTS;                                   /* no bubbles before the second location */
    if (k1 == MK_RECORD && total_stars() == 0) k1 = MK_FIRST;                    /* nothing to beat yet */
    if ((k2 == MK_WATCH || k2 == MK_OTHERS) && !(plat_caps() & 4)) k2 = MK_TIME; /* a build without the network */
    h = mhash(day, 1);
    if (k0 == MK_WINS) mis_set(&PF.dm[0], k0, 0, 4 + (int)(h % 3u), 10 + 2 * (int)(h % 3u));
    else if (k0 == MK_STARS) mis_set(&PF.dm[0], k0, 0, 10 + 2 * (int)(h % 4u), 12 + 2 * (int)(h % 4u));
    else if (k0 == MK_BOX) mis_set(&PF.dm[0], k0, (int)(h % (u32)nb), 3, 12);
    else mis_set(&PF.dm[0], k0, 0, 3 + (int)(h % 2u), 14 + 2 * (int)(h % 2u));
    h = mhash(day, 2);
    if (k1 == MK_FIRST) mis_set(&PF.dm[1], k1, 0, 2 + (int)(h % 2u), 14 + 2 * (int)(h % 2u));
    else if (k1 == MK_CUTS) mis_set(&PF.dm[1], k1, 0, 25 + 5 * (int)(h % 4u), 10);
    else if (k1 == MK_RECORD) mis_set(&PF.dm[1], k1, 0, 1, 15);
    else if (k1 == MK_FAST) mis_set(&PF.dm[1], k1, 6 + (int)(h % 3u), 2, 15);
    else mis_set(&PF.dm[1], k1, 0, 8 + 2 * (int)(h % 3u), 10);
    h = mhash(day, 3);
    if (k2 == MK_TIME) mis_set(&PF.dm[2], k2, 0, (5 + 2 * (int)(h % 3u)) * 60, 10);
    else if (k2 == MK_WATCH) mis_set(&PF.dm[2], k2, 0, 1, 10);
    else if (k2 == MK_EDITOR) mis_set(&PF.dm[2], k2, 0, 1, 15);
    else mis_set(&PF.dm[2], k2, 0, 1 + (int)(h % 2u), 14);
    PF.day = day; tasks_new = 1;
}
/* A set that is made in the middle of the week (the first start of the game, a player who comes back on a Friday) asks for less:
   the counting missions are cut down to the days that are left. */
static int week_part(int t, int left, int least) { int v = (t * left + 6) / 7; return v < least ? (least < t ? least : t) : v; }
static void weekly_make(u32 week) {
    int nb = boxes_open(), lo = levels_open(), box, t; u32 h = mhash(week, 11), now = now_s();
    int left = now && week_of(day_of(now)) == week ? 7 - (int)((day_of(now) + 3u) % 7u) : 7;      /* days of this week that are still to come, today included */
    if (week & 1u) { t = 30 + 5 * (int)(h % 3u); if (t > lo) t = lo < 8 ? 8 : lo; mis_set(&PF.wm[0], MK_WINS, 0, week_part(t, left, 8), 50); }
    else { t = 80 + 10 * (int)(h % 4u); if (t > lo * 3) t = lo * 3 < 20 ? 20 : lo * 3; mis_set(&PF.wm[0], MK_STARS, 0, week_part(t, left, 20), 50); }
    box = nb - 1 - (int)((week + 3u) % (u32)nb);                                 /* the hardest open location first, then down the list, week after week */
    mis_set(&PF.wm[1], MK_RUN, box, PER_BOX, 60 + 4 * box);
    if ((week & 1u) || !CFG.acc || !(plat_caps() & 4) || left < 4) mis_set(&PF.wm[2], (plat_caps() & 4) ? MK_OTHERS : MK_PERFECT, 0, (plat_caps() & 4) ? 3 : week_part(10, left, 3), 60);
    else mis_set(&PF.wm[2], MK_VIEWS, 0, 10, 100);                               /* only a signed-in player can publish a level; a level needs days to be played */
    if (week % 3u == 0) { t = 3 * left - 2; mis_set(&PF.wm[3], MK_DAILIES, 0, t > 10 ? 10 : (t < 1 ? 1 : t), 70); }      /* three daily missions a day: no more than the days left can give */
    else if (week % 3u == 1) mis_set(&PF.wm[3], MK_RECORD, 0, week_part(5, left, 2), 50);
    else mis_set(&PF.wm[3], MK_FIRST, 0, week_part(10, left, 4), 50);
    PF.week = week; memset(PF.run_t, 0, sizeof(PF.run_t)); memset(PF.pub_id, 0, sizeof(PF.pub_id)); tasks_new = 1;
}
/* A new day is believed only when the table's clock agrees (or the table cannot be asked): a device whose clock is set
   to tomorrow must not get tomorrow's missions today. */
static int t_sure; static float t_wait = 8.0f; static u32 t_seen;
static int clock_ok(void) { return t_sure || !(plat_caps() & 4) || NET.st == NS_OFF || t_wait <= 0; }
static void mis_refresh(void) {                      /* a new day, a new week: new sets (never back to an older one) */
    u32 t = now_s(), d = t ? day_of(t) : (PF.day ? PF.day : 1u), w = week_of(d); int ch = 0;
    if ((d > PF.day || w > PF.week || !PF.dm[0].kind || !PF.wm[0].kind) && !clock_ok()) return;
    if (d > PF.day || !PF.dm[0].kind) { daily_make(d > PF.day ? d : PF.day); ch = 1; }
    if (w > PF.week || !PF.wm[0].kind) { weekly_make(w > PF.week ? w : PF.week); ch = 1; }
    if (ch) prof_dirty();
}
static const char *mis_text(const Mission *m, char *b, int n) {
    int t = m->target;
    switch (m->kind) {
    case MK_WINS: snprintf(b, (size_t)n, "Пройди %d %s", t, plural(t, "разный уровень", "разных уровня", "разных уровней")); break;
    case MK_STARS: snprintf(b, (size_t)n, "Собери %d %s на разных уровнях", t, plural(t, "звезду", "звезды", "звёзд")); break;
    case MK_PERFECT: snprintf(b, (size_t)n, "Пройди %d %s на все звёзды", t, plural(t, "уровень", "уровня", "уровней")); break;
    case MK_BOX: snprintf(b, (size_t)n, "Пройди %d %s в локации «%s»", t, plural(t, "уровень", "уровня", "уровней"), box_name[m->arg % BOXES]); break;
    case MK_FIRST: snprintf(b, (size_t)n, "Пройди %d %s с первой попытки", t, plural(t, "уровень", "уровня", "уровней")); break;
    case MK_RECORD: if (t == 1) snprintf(b, (size_t)n, "Побей свой рекорд времени на любом уровне"); else snprintf(b, (size_t)n, "Побей свой рекорд времени на %d уровнях", t); break;
    case MK_FAST: snprintf(b, (size_t)n, "Пройди %d %s на все звёзды быстрее %d секунд", t, plural(t, "уровень", "уровня", "уровней"), (int)m->arg); break;
    case MK_CUTS: snprintf(b, (size_t)n, "Перережь %d %s", t, plural(t, "верёвку", "верёвки", "верёвок")); break;
    case MK_POPS: snprintf(b, (size_t)n, "Лопни %d %s", t, plural(t, "пузырь", "пузыря", "пузырей")); break;
    case MK_TIME: snprintf(b, (size_t)n, "Проведи в уровнях %d %s", t / 60, plural(t / 60, "минуту", "минуты", "минут")); break;
    case MK_WATCH: snprintf(b, (size_t)n, "Посмотри запись рекорда другого игрока"); break;
    case MK_OTHERS: snprintf(b, (size_t)n, "Пройди %d %s других игроков", t, plural(t, "уровень", "уровня", "уровней")); break;
    case MK_EDITOR: snprintf(b, (size_t)n, "Собери уровень в редакторе и пройди его"); break;
    case MK_RUN: snprintf(b, (size_t)n, "Перепройди локацию %d («%s») за 10 минут", (int)m->arg + 1, box_name[m->arg % BOXES]); break;
    case MK_VIEWS: snprintf(b, (size_t)n, "Создай уровень в редакторе, который наберёт %d просмотров", t); break;
    case MK_DAILIES: snprintf(b, (size_t)n, "Выполни %d %s", t, plural(t, "ежедневное задание", "ежедневных задания", "ежедневных заданий")); break;
    case MK_FEED: snprintf(b, (size_t)n, "Напои своего Мела %d %s", t, plural(t, "раз", "раза", "раз")); break;
    case MK_PLAY: snprintf(b, (size_t)n, "Поиграй со своим Мелом: погладь его или поговори с ним %d %s", t, plural(t, "раз", "раза", "раз")); break;
    case MK_PLACE: snprintf(b, (size_t)n, "Поставь или переставь дома %d %s", t, plural(t, "предмет", "предмета", "предметов")); break;
    case MK_VISIT: snprintf(b, (size_t)n, "Сходи в гости в %d %s в Городе Мелстроев", t, plural(t, "дом", "дома", "домов")); break;
    case MK_SLEEP: snprintf(b, (size_t)n, "Уложи своего Мела спать"); break;
    default: b[0] = 0;
    }
    return b;
}
static void mis_kind(int kind, int n);
static void mis_done(Mission *m) {
    if (m == month_cur()) { m->done = 1; m->prog = m->target; month_done(); return; }      /* V0.6: a monthly mission has its own prizes */
    int weekly = m >= PF.wm && m < PF.wm + 4;
    m->done = 1; m->prog = m->target; PF.earned += m->reward; PF.cn[weekly ? CN_WEEKLY : CN_DAILY]++;
    rw_push(weekly ? "Еженедельное задание выполнено!" : "Задание выполнено!", m->reward);
    sfx_p(S_WIN, 0.6f, 640, 1.26f);
    if (!weekly) mis_kind(MK_DAILIES, 1);
    prof_dirty(); ach_check();
}
static void mis_add(Mission *m, int n) {
    if (!m->kind || m->done || n <= 0) return;
    int p = m->prog + n; m->prog = (u16)(p > m->target ? m->target : p); PS.soft = 1;
    if (m->prog >= m->target) mis_done(m);
}
static void mis_kind(int kind, int n) {
    Mission *q = month_cur();
    for (int i = 0; i < 3; i++) if (PF.dm[i].kind == kind) mis_add(&PF.dm[i], n);
    for (int i = 0; i < 4; i++) if (PF.wm[i].kind == kind) mis_add(&PF.wm[i], n);
    if (q && q->kind == kind) mis_add(q, n);
}
static int run_count(const Mission *m, u32 now) { int c = 0; (void)m; for (int j = 0; j < PER_BOX; j++) if (PF.run_t[j] && now >= PF.run_t[j] && now - PF.run_t[j] <= 600u) c++; return c; }
static u32 mis_clock(void) { u32 t = now_s(); return t ? t : (u32)g_time + 1u; }
static void mis_level(Mission *m, int idx, int st, int mx, int first, int rec) {      /* a built-in level was won */
    if (!m->kind || m->done) return;
    u32 bit = 1u << (idx & 31), *w = &m->mask[(idx >> 5) & 1]; int fresh = !(*w & bit), add = 0;
    switch (m->kind) {
    case MK_WINS: add = fresh; break;
    case MK_STARS: add = fresh ? st : 0; break;
    case MK_PERFECT: add = fresh && st >= mx; break;
    case MK_BOX: add = fresh && idx / PER_BOX == m->arg; break;
    case MK_FIRST: add = fresh && first; break;
    case MK_RECORD: add = fresh && rec; break;
    case MK_FAST: add = fresh && st >= mx && L_ticks < (int)m->arg * SIM_HZ; break;
    case MK_RUN:
        if (idx / PER_BOX == m->arg) {
            u32 now = mis_clock(); PF.run_t[idx % PER_BOX] = now; int c = run_count(m, now); PS.soft = 1;
            m->prog = (u16)c; if (c >= PER_BOX) mis_done(m);
        }
        return;
    default: return;
    }
    if (add > 0) { *w |= bit; mis_add(m, add); }
}

/* ---------------- events from the game ---------------- */
static int clean_box = -1, clean_n;
static void meta_count(int what, int n) {
    if (what == MC_POKE) { PF.cn[CN_POKE] += (u32)n; PS.soft = 1; ach_check(); return; }
    if (scr != SC_PLAY || L_mode != LM_PLAY) return;                           /* only real runs count, not demos and recordings */
    if (what == MC_CUT) { PF.cn[CN_CUTS] += (u32)n; mis_kind(MK_CUTS, n); }
    else if (what == MC_POP) { PF.cn[CN_POPS] += (u32)n; mis_kind(MK_POPS, n); }
    else if (what == MC_FAIL) { PF.cn[CN_FAILS] += (u32)n; clean_n = 0; clean_box = -1; }
    PS.soft = 1;
}
static float play_acc;
static void meta_playtime(float dt) { play_acc += dt; while (play_acc >= 1.0f) { play_acc -= 1.0f; mis_kind(MK_TIME, 1); } }
static void meta_win(int st) {                       /* called after on_level_won(): CUR, L_ticks, V_attempt, win_first and L_newbest describe the run */
    int first = V_attempt == 1 && V_fails == 0;
    PF.cn[CN_WINS]++;
    if (CUR.kind == 0) {
        int i = CUR.idx, mx = CUR.maxst, rec = L_newbest && win_best_ticks > 0 && L_ticks < win_best_ticks;
        if (st >= mx && mx > 0) {
            PF.cn[CN_PERFECT]++;
            if (L_ticks < SIM_HZ * 3 / 2) PF.cn[CN_FAST]++;
            if (i < TAS_DATA_LEVELS && tas_runs[i].ticks && L_ticks <= (int)tas_runs[i].ticks) PF.cn[CN_TAS]++;
        }
        if (first && !((PF.first_mask[(i >> 5) & 1] >> (i & 31)) & 1u)) { PF.first_mask[(i >> 5) & 1] |= 1u << (i & 31); PF.cn[CN_FIRST]++; }
        if (rec) PF.cn[CN_RECORDS]++;
        if (first && i % PER_BOX == 0) { clean_box = i / PER_BOX; clean_n = 1; }
        else if (first && i / PER_BOX == clean_box && i % PER_BOX == clean_n) { if (++clean_n >= PER_BOX) { PF.cn[CN_CLEAN]++; clean_n = 0; clean_box = -1; } }
        else { clean_n = 0; clean_box = -1; }
        for (int k = 0; k < 3; k++) mis_level(&PF.dm[k], i, st, mx, first, rec);
        for (int k = 0; k < 4; k++) mis_level(&PF.wm[k], i, st, mx, first, rec);
        if (month_cur()) mis_level(month_cur(), i, st, mx, first, rec);
    } else if (CUR.kind == 2) {                        /* a level of another player: every such level counts once in a mission */
        if (!pub_own) {
            int id = atoi(CUR.key + 1); u32 bit = 1u << (id & 31); int w = (id >> 5) & 1;
            if (win_first) PF.cn[CN_OTHERS]++;
            for (int k = 0; k < 8; k++) { Mission *q = k < 3 ? &PF.dm[k] : (k < 7 ? &PF.wm[k - 3] : month_cur()); if (q && q->kind == MK_OTHERS && !q->done && !(q->mask[w] & bit)) { q->mask[w] |= bit; mis_add(q, 1); } }
        }
    } else mis_kind(MK_EDITOR, 1);
    home_level_won();
    ach_check(); prof_dirty();
}
static void meta_watch(void) { PF.cn[CN_WATCH]++; mis_kind(MK_WATCH, 1); ach_check(); prof_dirty(); }
static void meta_published(int id) {
    PF.cn[CN_PUB]++;
    for (int i = 0; i < 4; i++) if (!PF.pub_id[i]) { PF.pub_id[i] = (u32)id; break; }
    ach_check(); prof_dirty(); PS.lv_t = 0;
}
static void meta_rank(int rank) { if (rank == 1 && !PF.cn[CN_TOP1]) { PF.cn[CN_TOP1] = 1; ach_check(); prof_dirty(); } }

/* ---------------- the progress as one line of text (this is what the account keeps in the table) ---------------- */
typedef struct { Profile p; u8 best[MAXLV]; u32 ticks[MAXLV]; } Cloud;
#define AP(...) do { if (n < max - 1) { n += snprintf(o + n, (size_t)(max - n), __VA_ARGS__); if (n > max - 1) n = max - 1; } } while (0)
static int prof_encode(char *o, int max) {
    int n = 0, first = 1;
    AP("v5|e%u|s%x|k%u|a%x.%x|c", (unsigned)PF.earned, (unsigned)PF.skins, (unsigned)PF.skin, (unsigned)PF.ach[0], (unsigned)PF.ach[1]);
    for (int i = 0; i < CN_N; i++) AP(i ? ".%u" : "%u", (unsigned)PF.cn[i]);
    for (int s = 0; s < 2; s++) {
        const Mission *m = s ? PF.wm : PF.dm; int cnt = s ? 4 : 3;
        AP("|%c%u:", s ? 'w' : 'd', (unsigned)(s ? PF.week : PF.day));
        for (int i = 0; i < cnt; i++) AP("%s%u.%u.%u.%u.%u.%u.%x.%x", i ? "," : "", m[i].kind, m[i].arg, m[i].done, m[i].target, m[i].prog, m[i].reward, (unsigned)m[i].mask[0], (unsigned)m[i].mask[1]);
    }
    AP("|r"); for (int i = 0; i < PER_BOX; i++) AP(i ? ".%u" : "%u", (unsigned)PF.run_t[i]);
    AP("|p"); for (int i = 0; i < 4; i++) AP(i ? ".%u" : "%u", (unsigned)PF.pub_id[i]);
    AP("|b%u|h%u.%u|f%x.%x|l", (unsigned)PF.best_plays, (unsigned)PF.chat_last, (unsigned)PF.chat, (unsigned)PF.first_mask[0], (unsigned)PF.first_mask[1]);
    for (int i = 0; i < LEVEL_COUNT; i++) if (lvl_done(i)) { AP("%s%d.%04x.%d.%u", first ? "" : ",", i, (unsigned)lv_hash16[i], lvl_stars(i), (unsigned)SV.ticks[i]); first = 0; }
    return n;
}
#undef AP
static u32 rdn(const char **p, int base) {           /* a number, and one separator after it */
    char *e; u32 v = (u32)strtoul(*p, &e, base); *p = e; if (**p == '.' || **p == ',' || **p == ':') (*p)++; return v;
}
static int prof_decode(const char *s, Cloud *c) {
    memset(c, 0, sizeof(*c));
    if (strncmp(s, "v5|", 3)) return 0;
    const char *p = s + 3;
    while (*p) {
        char tag = *p++; const char *e = strchr(p, '|'), *q = p; if (!e) e = p + strlen(p);
        switch (tag) {
        case 'e': c->p.earned = rdn(&q, 10); break;
        case 's': c->p.skins = rdn(&q, 16); break;
        case 'k': c->p.skin = (u8)rdn(&q, 10); break;
        case 'a': c->p.ach[0] = rdn(&q, 16); c->p.ach[1] = rdn(&q, 16); break;
        case 'c': for (int i = 0; i < CN_N && q < e; i++) c->p.cn[i] = rdn(&q, 10); break;
        case 'd': case 'w': {
            Mission *m = tag == 'w' ? c->p.wm : c->p.dm; int cnt = tag == 'w' ? 4 : 3; u32 id = rdn(&q, 10);
            if (tag == 'w') c->p.week = id; else c->p.day = id;
            for (int i = 0; i < cnt && q < e; i++) {
                m[i].kind = (u8)rdn(&q, 10); m[i].arg = (u8)rdn(&q, 10); m[i].done = (u8)(rdn(&q, 10) != 0); m[i].target = (u16)rdn(&q, 10); m[i].prog = (u16)rdn(&q, 10); m[i].reward = (u16)rdn(&q, 10);
                m[i].mask[0] = rdn(&q, 16); m[i].mask[1] = rdn(&q, 16);
                if (m[i].kind >= MK_N || !m[i].target || m[i].reward > 500) memset(&m[i], 0, sizeof(m[i])); else if (m[i].prog > m[i].target) m[i].prog = m[i].target;
            }
        } break;
        case 'r': for (int i = 0; i < PER_BOX && q < e; i++) c->p.run_t[i] = rdn(&q, 10); break;
        case 'p': for (int i = 0; i < 4 && q < e; i++) c->p.pub_id[i] = rdn(&q, 10); break;
        case 'b': c->p.best_plays = rdn(&q, 10); break;
        case 'h': c->p.chat_last = rdn(&q, 10); c->p.chat = (u8)(rdn(&q, 10) != 0); break;
        case 'f': c->p.first_mask[0] = rdn(&q, 16); c->p.first_mask[1] = rdn(&q, 16); break;
        case 'l':
            while (q < e) {
                u32 i = rdn(&q, 10), h = rdn(&q, 16), st = rdn(&q, 10), tk = rdn(&q, 10);
                if (i < (u32)LEVEL_COUNT && h == lv_hash16[i] && st <= (u32)lv_max[i] && tk < (1u << 17)) { c->best[i] = (u8)(st + 1); c->ticks[i] = tk; }      /* a level that has changed since is not taken */
            }
            break;
        default: break;
        }
        p = e; if (*p == '|') p++;
    }
    if (c->p.earned > 5000000u) c->p.earned = 5000000u;
    c->p.skins = (c->p.skins & ((1u << SKIN_N) - 1u)) | 1u;
    if (c->p.skin >= SKIN_N || !((c->p.skins >> c->p.skin) & 1u)) c->p.skin = 0;
    c->p.ach[0] &= 0xFFFFFFFFu; c->p.ach[1] &= (ACH_N > 32 ? (1u << (ACH_N - 32)) - 1u : 0u); if (ACH_N < 32) c->p.ach[0] &= (1u << ACH_N) - 1u;
    return 1;
}
static void mis_merge(Mission *l, const Mission *c, int cnt, int newer) {
    for (int i = 0; i < cnt; i++) {
        if (newer) { l[i] = c[i]; continue; }
        if (l[i].kind != c[i].kind || l[i].target != c[i].target || l[i].arg != c[i].arg) continue;
        if (c[i].prog > l[i].prog) l[i].prog = c[i].prog;
        l[i].done |= c[i].done; l[i].mask[0] |= c[i].mask[0]; l[i].mask[1] |= c[i].mask[1];
        if (l[i].done) l[i].prog = l[i].target;
    }
}
/* what the table has and what this device has become one: the better result of every level, everything ever earned or bought */
static void prof_merge(const Cloud *c, int fresh) {
    for (int i = 0; i < LEVEL_COUNT; i++) {
        if (!c->best[i]) continue;
        int cs = c->best[i] - 1, ls = lvl_stars(i);
        if (!lvl_done(i) || cs > ls || (cs == ls && (SV.ticks[i] == 0 || (c->ticks[i] && c->ticks[i] < SV.ticks[i])))) {
            char rk[8]; own_key(i, rk); plat_store(rk, "", 0);                  /* the recording kept here belongs to a weaker run */
            SV.best[i] = c->best[i]; SV.ticks[i] = c->ticks[i]; SV.sent[i] = 1;
        } else if (cs == ls && c->ticks[i] == SV.ticks[i] && !SV.sent[i]) SV.sent[i] = 1;
    }
    if (c->p.earned > PF.earned) PF.earned = c->p.earned;
    PF.skins |= c->p.skins; PF.ach[0] |= c->p.ach[0]; PF.ach[1] |= c->p.ach[1];
    for (int i = 0; i < CN_N; i++) if (c->p.cn[i] > PF.cn[i]) PF.cn[i] = c->p.cn[i];
    if (c->p.best_plays > PF.best_plays) PF.best_plays = c->p.best_plays;
    PF.first_mask[0] |= c->p.first_mask[0]; PF.first_mask[1] |= c->p.first_mask[1];
    PF.chat |= c->p.chat; if (c->p.chat_last > PF.chat_last) PF.chat_last = c->p.chat_last;
    if (c->p.day >= PF.day && c->p.dm[0].kind) { mis_merge(PF.dm, c->p.dm, 3, c->p.day > PF.day || !PF.dm[0].kind); PF.day = c->p.day; }
    if (c->p.week >= PF.week && c->p.wm[0].kind) {
        int newer = c->p.week > PF.week || !PF.wm[0].kind;
        mis_merge(PF.wm, c->p.wm, 4, newer); PF.week = c->p.week;
        for (int i = 0; i < PER_BOX; i++) if (newer || c->p.run_t[i] > PF.run_t[i]) PF.run_t[i] = c->p.run_t[i];
        for (int i = 0; i < 4; i++) { u32 id = c->p.pub_id[i]; int has = 0; if (!id) continue; for (int k = 0; k < 4; k++) if (PF.pub_id[k] == id) has = 1; if (!has) for (int k = 0; k < 4; k++) if (!PF.pub_id[k]) { PF.pub_id[k] = id; break; } }
    }
    if (fresh) PF.skin = c->p.skin;
    if (PF.skin >= SKIN_N || !((PF.skins >> PF.skin) & 1u)) PF.skin = 0;
    save_store();
}

/* ---------------- whose progress is on the screen: a guest of this device, or an account ---------------- */
#define STASH_MAGIC 0x35485453u
typedef struct { u32 magic, uid; char nick[32]; u8 best[MAXLV]; u32 ticks[MAXLV]; Profile pf; } Stash;
static void stash_save(const char *key) {
    static Stash s; memset(&s, 0, sizeof(s)); s.magic = STASH_MAGIC; s.uid = SV.uid; memcpy(s.nick, SV.nick, sizeof(s.nick));
    memcpy(s.best, SV.best, sizeof(s.best)); memcpy(s.ticks, SV.ticks, sizeof(s.ticks)); s.pf = PF;
    plat_store(key, &s, (int)sizeof(s));
}
static int stash_load(const char *key, Stash *s) { return plat_fetch(key, s, (int)sizeof(*s)) == (int)sizeof(*s) && s->magic == STASH_MAGIC && s->pf.magic == PROF_MAGIC; }
static void prof_wipe(u32 uid) {                     /* an empty progress on the screen (what was there has been put away or belongs to the table) */
    memset(SV.best, 0, sizeof(SV.best)); memset(SV.ticks, 0, sizeof(SV.ticks)); memset(SV.sent, 0, sizeof(SV.sent));
    for (int i = 0; i < LEVEL_COUNT; i++) { char rk[8]; own_key(i, rk); plat_store(rk, "", 0); }
    prof_fresh(uid); pub_best_ok = 0; pub_best_sent = 0; pub_key[0] = 0; sub_level = -1; clean_n = 0; clean_box = -1; RW.n = 0; tasks_new = 0;
    memset(&PS, 0, sizeof(PS)); my_badge = 0; sup_unread = 0;
    home_switch(uid);                                  /* V0.6: the house goes with the account */
}
static void chat_reset(void);
static void prof_to_guest(void) {                    /* nobody is signed in any more: the guest of this device comes back (with his progress, if he had any) */
    static Stash s;
    prof_wipe(0); SV.nick[0] = 0; SV.uid = 0;
    if (stash_load("pg", &s) && s.uid) {
        SV.uid = s.uid; memcpy(SV.nick, s.nick, sizeof(SV.nick)); SV.nick[sizeof(SV.nick) - 1] = 0; memcpy(SV.best, s.best, sizeof(SV.best)); memcpy(SV.ticks, s.ticks, sizeof(SV.ticks));
        for (int i = 0; i < LEVEL_COUNT; i++) SV.sent[i] = lvl_done(i) ? 2 : 0;      /* the recordings of those runs are gone: nothing to send */
        PF = s.pf; PF.uid = 0; PF.dirty = 0; plat_store("pg", "", 0);
    }
    while (!SV.uid) SV.uid = plat_random() & 0x7FFFFFFFu;
    save_store(); mis_refresh(); ach_check(); prof_store(); chat_reset();
}
static void prof_on_login(u32 uid) {                 /* signed in to an existing account: its progress replaces what was on the screen */
    static Stash s;
    if (!CFG.acc && (total_stars() > 0 || PF.earned > 0 || PF.cn[CN_WINS] > 0)) stash_save("pg");      /* the guest's own progress waits for him */
    prof_wipe(uid);
    if (stash_load("pa", &s) && s.uid == uid) {       /* what this device knew about the account and could not send before */
        static Cloud c; memset(&c, 0, sizeof(c)); memcpy(c.best, s.best, sizeof(c.best)); memcpy(c.ticks, s.ticks, sizeof(c.ticks)); c.p = s.pf;
        PF = s.pf; PF.uid = uid; prof_merge(&c, 1); PF.dirty = 1; plat_store("pa", "", 0);
    }
    PS.fresh = 1; PS.loaded = 0; PS.retry = 0; chat_reset();
}
static void prof_on_register(void) { PF.uid = SV.uid; PF.rev = 0; PS.loaded = 1; PS.fresh = 0; plat_store("pg", "", 0); home_switch(SV.uid); ach_check(); prof_dirty(); chat_reset(); }
static void prof_leave(int kicked) {                 /* the account is left (by the player, or the table does not know this device any more) */
    if (PF.dirty || !PS.loaded || kicked) { PF.dirty = 1; stash_save("pa"); }      /* not everything has reached the table: keep it for the next sign-in */
    prof_to_guest();
}

/* ---------------- keeping the progress in the account ---------------- */
static char sync_buf[7000];
static void sync_send(void) {
    static char body[7400]; char u[16], base[16];
    prof_encode(sync_buf, 6000);
    snprintf(u, sizeof(u), "%u", (unsigned)SV.uid); snprintf(base, sizeof(base), "%u", (unsigned)PF.rev);
    snprintf(body, sizeof(body), "save\t%s\t%s\t%s\t%s\t%08x", u, CFG.token, base, sync_buf, (unsigned)net_sig("save", u, base, sync_buf, ""));
    PS.sent_gen = PS.gen; PS.save_uid = SV.uid; net_post(RQ_SAVE, body);
}
static int sync_on(void) { return CFG.acc && CFG.token[0] && NET.st == NS_ON && NET.proto >= 5 && !acc_banned; }
static void sync_update(float dt) {
    if (PS.out_uid && !NET.busy[RQ_SAVE] && !NET.busy[RQ_SAVE6]) { PS.out_t = 0; }
    if (PS.out_uid) {                                  /* the player has signed out: the table forgets the key of this device once the last save has gone */
        PS.out_t -= dt;
        if (PS.out_t <= 0) {
            static char body[160]; char u[16]; snprintf(u, sizeof(u), "%u", (unsigned)PS.out_uid);
            if (NET.st == NS_ON && NET.proto >= 4) { snprintf(body, sizeof(body), "out\t%s\t%s\t%08x", u, PS.out_tok, (unsigned)net_sig("out", u, "", "", "")); net_post(RQ_OUT, body); }
            PS.out_uid = 0; memset(PS.out_tok, 0, sizeof(PS.out_tok));
        }
    }
    if (PS.soft) { PS.soft_t += dt; if (PS.soft_t > 20.0f) { PS.soft_t = 0; prof_dirty(); } }
    if (!sync_on()) return;
    if (!PS.loaded) { PS.retry -= dt; if (PS.retry <= 0 && !NET.busy[RQ_LOAD]) { char q[120]; PS.retry = 20.0f; snprintf(q, sizeof(q), "a=load&u=%u&t=%s", (unsigned)SV.uid, CFG.token); net_get(RQ_LOAD, q); } return; }
    if (PF.dirty && !NET.busy[RQ_SAVE]) { PS.t -= dt; if (PS.t <= 0) { PS.t = 6.0f; sync_send(); } }
    if (PF.cn[CN_PUB] > 0 && !NET.busy[RQ_MYLV]) { PS.lv_t -= dt; if (PS.lv_t <= 0) { char q[120]; PS.lv_t = 180.0f; snprintf(q, sizeof(q), "a=mylv&u=%u&t=%s", (unsigned)SV.uid, CFG.token); net_get(RQ_MYLV, q); } }      /* how often were my levels played? */
}
static void acc_kicked(void) { if (!CFG.acc) return; acc_forget(); prof_leave(1); AC.note = 2; }      /* the table does not know the key of this device any more */
static void prof_logout(void) {                      /* the player signs out */
    char tok[48]; u32 uid = SV.uid; int out = acc_ready() && CFG.token[0]; snprintf(tok, sizeof(tok), "%s", CFG.token);
    if (PS.soft) prof_dirty();
    if (sync_on() && PS.loaded && PF.dirty && !NET.busy[RQ_SAVE]) sync_send();      /* what has not reached the table yet goes there now */
    home_flush();
    acc_forget(); prof_leave(0);
    if (out) { PS.out_uid = uid; snprintf(PS.out_tok, sizeof(PS.out_tok), "%s", tok); PS.out_t = 6.0f; }
}
static void sync_cloud(const char *data, u32 rev) {  /* a save has come from the table */
    static Cloud c; static char mine[7000];
    if (data && data[0] && prof_decode(data, &c)) prof_merge(&c, PS.fresh);
    PF.rev = rev; PS.loaded = 1; PS.fresh = 0;
    mis_refresh(); ach_check();
    prof_encode(mine, 6000);
    if (!data || strcmp(mine, data)) { PF.dirty = 1; PS.gen++; PS.t = 1.0f; } else PF.dirty = 0;      /* this device knows more than the table: send it */
    prof_store();
}

/* ---------------- the support chat ---------------- */
#define CHAT_MAX 80
typedef struct { u32 id, ts; int who; char text[620]; } ChatMsg;
static struct { int n, st, sending, stick; u32 since; float scroll, poll_t, drag_y0, scroll0; int drag; ChatMsg m[CHAT_MAX]; char draft[620]; } CH;      /* since: the table has been asked up to this message */
static void chat_reset(void) { memset(&CH, 0, sizeof(CH)); CH.stick = 1; }
static void chat_key(char *out, int max) {           /* what proves that this chat is ours: the key of the account, or a key this device has made up for itself */
    if (CFG.acc && CFG.token[0]) { snprintf(out, (size_t)max, "%s", CFG.token); return; }
    if (!CFG.r[0] && !CFG.r[1]) {
        char seed[96], hx[65]; snprintf(seed, sizeof(seed), "%u.%u.%u.%u.%u", (unsigned)plat_random(), (unsigned)plat_random(), (unsigned)SV.uid, (unsigned)plat_ctl(PC_TIME, NULL, 0, 0), (unsigned)rnd_u32());
        sha256_hex2("mel-nyam/gk/v1:", seed, hx);
        for (int i = 0; i < 4; i++) { char w[9]; memcpy(w, hx + i * 8, 8); w[8] = 0; CFG.r[i] = (u32)strtoul(w, NULL, 16); }
        if (!CFG.r[0]) CFG.r[0] = 1; cfg_store();
    }
    snprintf(out, (size_t)max, "%08x%08x%08x%08x", (unsigned)CFG.r[0], (unsigned)CFG.r[1], (unsigned)CFG.r[2], (unsigned)CFG.r[3]);
}
static int chat_ready(void) { return NET.st == NS_ON && NET.proto >= 5; }
static void chat_poll(int peek) {
    if (!chat_ready() || NET.busy[RQ_CHAT]) return;
    char q[200], k[48]; chat_key(k, (int)sizeof(k));
    snprintf(q, sizeof(q), "a=chat&u=%u&k=%s&after=%u%s", (unsigned)SV.uid, k, (unsigned)CH.since, peek ? "&peek=1" : "");
    net_get(RQ_CHAT, q); if (!CH.n && !peek) CH.st = 1; CH.poll_t = 0;
}
static void chat_clean(char *dst, int max, const char *src, int maxc) {      /* only what the font can draw; a very long word gets a space now and then, so that it can be wrapped */
    int n = 0, k = 0, run = 0; u32 c;
    while ((c = u8_next(&src)) != 0 && k < maxc && n + 6 < max) {
        if (!cp_allowed(c, 3)) c = '?';
        if (c == ' ') run = 0; else if (++run > 30) { dst[n++] = ' '; run = 1; }
        n += u8_put(dst + n, c); k++;
    }
    dst[n] = 0;
}
static void chat_add(u32 id, int who, u32 ts, const char *text) {      /* the messages stay in the order of their numbers (an answer may have come before the player's own last message) */
    int pos = CH.n;
    for (int i = 0; i < CH.n; i++) if (CH.m[i].id == id) return;
    while (pos > 0 && CH.m[pos - 1].id > id) pos--;
    if (CH.n >= CHAT_MAX) { if (!pos) return; memmove(&CH.m[0], &CH.m[1], sizeof(ChatMsg) * (CHAT_MAX - 1)); CH.n = CHAT_MAX - 1; pos--; }
    memmove(&CH.m[pos + 1], &CH.m[pos], sizeof(ChatMsg) * (size_t)(CH.n - pos)); CH.n++;
    ChatMsg *m = &CH.m[pos]; m->id = id; m->who = who; m->ts = ts; chat_clean(m->text, (int)sizeof(m->text), text, 300);
}
static void chat_send_done(const char *t) {
    static char body[1400]; char u[16], k[48];
    if (!chat_ready()) { gtoast("Нет связи с таблицей"); return; }
    if (NET.busy[RQ_MSG]) return;
    chat_clean(CH.draft, (int)sizeof(CH.draft), t, 300); chat_key(k, (int)sizeof(k)); snprintf(u, sizeof(u), "%u", (unsigned)SV.uid);
    snprintf(body, sizeof(body), "msg\t%s\t%s\t%s\t%d\t%08x", u, k, CH.draft, APP_VER, (unsigned)net_sig("msg", u, CH.draft, "", ""));
    net_post(RQ_MSG, body); CH.sending = 1;
}

/* ---------------- answers of the table ---------------- */
static void meta_http(int kind, int ok, int status, char *ln, char *p) {
    switch (kind) {
    case RQ_LOAD:
        if (!CFG.acc) break;
        if (ok) {
            u32 rev = (u32)strtoul(nfld(&ln), NULL, 10); const char *data = nfld(&ln);
            int empty = !data[0];
            sync_cloud(data, rev);
            if (empty && !PS.mine_asked && total_stars() == 0) { char q[140]; PS.mine_asked = 1; snprintf(q, sizeof(q), "a=mine&u=%u&t=%s", (unsigned)SV.uid, CFG.token); net_get(RQ_MINE, q); }      /* an account made by V0.4: its progress is only in the records */
            else if (g_toast_t > 0 && !strncmp(g_toast, "Вход выполнен", 25)) gtoast("Вход выполнен. Прогресс загружен");
        } else if (status == 200 && ln && !strcmp(ln, "auth")) acc_kicked();
        else if (status == 200 && ln && !strcmp(ln, "ban")) { if (!acc_banned) AC.note = 1; acc_banned = 1; }
        break;
    case RQ_SAVE:
        if (!CFG.acc || PS.save_uid != SV.uid) break;      /* an answer for the account that has just been left */
        if (ok) { PF.rev = (u32)strtoul(nfld(&ln), NULL, 10); if (PS.sent_gen == PS.gen) PF.dirty = 0; else PS.t = 2.0f; prof_store(); }
        else if (status == 200 && ln) {
            const char *code = nfld(&ln);
            if (!strcmp(code, "conflict")) { u32 rev = (u32)strtoul(nfld(&ln), NULL, 10); sync_cloud(nfld(&ln), rev); PS.t = 0.5f; }      /* another device was faster: both saves become one */
            else if (!strcmp(code, "auth")) acc_kicked();
            else if (!strcmp(code, "ban")) { if (!acc_banned) AC.note = 1; acc_banned = 1; }
            else PS.t = 90.0f;
        } else PS.t = 30.0f;
        break;
    case RQ_MYLV:
        if (ok) {
            u32 best = PF.best_plays, wk = 0; char *l2;
            while ((l2 = nline(&p)) != NULL) {
                if (!*l2) continue;
                u32 id = (u32)strtoul(nfld(&l2), NULL, 10), plays = (u32)strtoul(nfld(&l2), NULL, 10);
                if (plays > best) best = plays;
                for (int i = 0; i < 4; i++) if (PF.pub_id[i] && PF.pub_id[i] == id && plays > wk) wk = plays;
            }
            if (best != PF.best_plays) { PF.best_plays = best; ach_check(); prof_dirty(); }
            for (int i = 0; i < 4; i++) if (PF.wm[i].kind == MK_VIEWS && !PF.wm[i].done && wk > PF.wm[i].prog) { PF.wm[i].prog = 0; mis_add(&PF.wm[i], (int)wk); prof_dirty(); }
        }
        break;
    case RQ_CHAT: {
        int had = CH.n, fresh = 0; char *l2;
        if (!ok) { if (CH.st == 1) CH.st = 3; break; }
        while ((l2 = nline(&p)) != NULL) {
            if (!*l2) continue;
            u32 id = (u32)strtoul(nfld(&l2), NULL, 10); const char *w = nfld(&l2); u32 ts = (u32)strtoul(nfld(&l2), NULL, 10); const char *tx = nfld(&l2);
            if (!id) continue;
            if (id > CH.since) CH.since = id;
            if (w[0] == 'a' && id > PF.chat_last) fresh++;
            chat_add(id, w[0] == 'a' ? 1 : 0, ts, tx);
        }
        CH.st = 2;
        if (scr == SC_CHAT) { if (CH.n && CH.m[CH.n - 1].id > PF.chat_last) { PF.chat_last = CH.m[CH.n - 1].id; prof_dirty(); } sup_unread = 0; if (fresh && had) sfx(S_STAR1, 0.7f, 640); if (CH.n != had) CH.stick = 1; }
        else if (fresh) { if (!sup_unread) gtoast("Разработчик ответил тебе в поддержке"); sup_unread = fresh; }
    } break;
    case RQ_MSG:
        CH.sending = 0;
        if (ok) {
            u32 id = (u32)strtoul(nfld(&ln), NULL, 10); chat_add(id, 0, now_s(), CH.draft); CH.draft[0] = 0; CH.stick = 1; CH.st = 2;
            if (id > PF.chat_last) PF.chat_last = id;
            if (!PF.chat) PF.chat = 1;
            prof_dirty(); sfx(S_WHOOSH, 0.5f, 640);
        } else {
            const char *code = status == 200 && ln ? nfld(&ln) : "";
            msg_open("Не отправилось", !strcmp(code, "slow") ? "Слишком много сообщений подряд. Подожди минуту и отправь ещё раз." : !strcmp(code, "ban") ? "Этот аккаунт заблокирован." :
                     !strcmp(code, "unknown") ? "Таблица рекордов ещё не обновлена: поддержка появится чуть позже." : status == 200 ? "Таблица не приняла сообщение. Попробуй ещё раз чуть позже." : "Нет связи с таблицей. Проверь интернет и попробуй ещё раз.");
        }
        break;
    default: break;
    }
}
static void hb_extra(char *ln) {                     /* the rest of the answer to "I am here": the table's clock, new answers of the support, the badge of this player */
    int dev = plat_ctl(PC_TIME, NULL, 0, 0); long long srv = strtoll(nfld(&ln), NULL, 10);
    if (dev > 0 && srv > 1500000000LL) { long long d = srv - dev; t_off = (d > 90 || d < -90) ? (int)d : 0; }
    int unread = atoi(nfld(&ln)), badge = atoi(nfld(&ln));
    t_sure = 1; my_badge = CFG.acc ? badge : 0;
    if (unread > 0 && scr != SC_CHAT) { if (!sup_unread) gtoast("Разработчик ответил тебе в поддержке"); sup_unread = unread; }
}

/* ---------------- the music: one tune for the menus, one for every location ---------------- */
static Sound *mus_slot[2]; static int mus_track[2] = { -1, -1 }, mus_cur = -1, mus_goal = -1, mus_render = -1, mus_into; static float mus_hold;
static void mus_want(int track) { mus_goal = track < 0 ? -1 : track % MUSIC_TRACKS; }
static void mus_update(float dt) {
    if (mus_hold > 0) mus_hold -= dt;
    if (mus_render >= 0) {                             /* a tune is being played into its buffer, a slice a frame; what was playing goes on meanwhile */
        if (music_step()) return;
        mus_track[mus_into] = mus_render; snd_changed(mus_slot[mus_into]); mus_render = -1;
    }
    if (mus_goal == mus_cur) return;
    if (mus_goal < 0) { snd_music(SND[S_MUSIC]); mus_cur = -1; mus_hold = 0.7f; return; }
    for (int k = 0; k < 2; k++) if (mus_track[k] == mus_goal) { snd_music(mus_slot[k]); mus_cur = mus_goal; mus_hold = 0.7f; return; }
    if (!SV.music || !CFG.vol_music || mus_hold > 0 || !mus_slot[0] || !mus_slot[1]) return;      /* nobody would hear it / the tune that has just been switched off is still fading */
    mus_into = (mus_cur >= 0 && mus_track[0] == mus_cur) ? 1 : 0;
    mus_track[mus_into] = -1; mus_render = mus_goal; music_begin(mus_goal, mus_slot[mus_into]);
}

/* ---------------- start-up and per-frame work ---------------- */
static void meta_init(void) {
    for (int i = 0; i < LEVEL_COUNT && i < MAXLV; i++) lv_hash16[i] = (u16)(objs_hash(g_levels[i].objs) & 0xFFFFu);
    for (int i = 0; i < SKIN_N; i++) { char nm[16]; snprintf(nm, sizeof(nm), "skin%d", i); I_skin[i] = img_load(nm); }
    static Profile p; int n = plat_fetch("prof", &p, (int)sizeof(p));
    if (n == (int)sizeof(p) && p.magic == PROF_MAGIC && (p.uid == (CFG.acc ? SV.uid : 0u))) PF = p; else prof_fresh(CFG.acc ? SV.uid : 0u);      /* (a game of V0.4: the progress on the device becomes the first profile) */
    PF.skins |= 1u; if (PF.skin >= SKIN_N || !((PF.skins >> PF.skin) & 1u)) PF.skin = 0;
    memset(&PS, 0, sizeof(PS)); chat_reset();
    home_init();
    mis_refresh(); ach_check();
    if (PF.dirty) PS.t = 2.0f;
    mus_slot[0] = snd_new(music_max(), MUSIC_RATE); mus_slot[1] = snd_new(music_max(), MUSIC_RATE);
    if (mus_slot[0]) mus_slot[0]->n = 2; if (mus_slot[1]) mus_slot[1]->n = 2;
}
static float meta_sec;
static void meta_update(float dt) {
    if (t_wait > 0) t_wait -= dt;
    meta_sec += dt;
    if (meta_sec >= 1.0f) {
        u32 t = now_s(); meta_sec = 0;
        if (t_seen && (t > t_seen + 180u || t + 180u < t_seen)) { t_sure = 0; t_wait = 8.0f; AC.hb_t = 100.0f; }      /* the clock has jumped: ask the table what time it is */
        t_seen = t; mis_refresh();
    }
    sync_update(dt); home_update(dt); mus_update(dt);
    if (PF.chat && !PS.peeked && chat_ready() && scr != SC_CHAT && g_time > 3.0f) { PS.peeked = 1; chat_poll(1); }      /* has the developer answered while the game was closed? */
    if (RW.n) { RW.t += dt; if (RW.t > 2.6f) { RW.n--; memmove(&RW.q[0], &RW.q[1], sizeof(RW.q[0]) * (size_t)RW.n); RW.t = 0; } }
}

/* ============================== what the player sees ============================== */
static void badge_icon(int b, float x, float y, float s) {      /* 1 the maker of the game, 2 a moderator, 3 a friend of the game */
    if (b == 1) icon(IC_CROWN, x, y, s, C_GOLD); else if (b == 2) icon(IC_SHIELD, x, y, s, C_CYAN); else if (b == 3) icon(IC_HEART, x, y, s * 0.8f, C_PINK);
}
static const char *badge_name(int b) { return b == 1 ? "Создатель игры" : (b == 2 ? "Модератор" : (b == 3 ? "Друг игры" : "")); }
static void coin_icon(float x, float y, float h) { float s = h / 72.0f; gfx_image_ex(I_bottle, x, y, s, s, 0.22f, 1); }
static void coin_badge(float xr, float y) {           /* the balance, right-aligned at xr */
    char b[24]; snprintf(b, sizeof(b), "%d", coins()); float tw = gfx_text_w(&F_ui, b, 30);
    gfx_rrect(xr - tw - 76, y - 25, tw + 76, 50, 25, 0x0E0A2EA0u); coin_icon(xr - tw - 48, y, 42); gfx_text(&F_ui, b, xr - 18, y + 1, 30, C_GOLD, AL_RIGHT);
}
static void reward_tag(float x, float y, int c, float size) {      /* "+15" and the bottle, centred at x */
    char b[24]; snprintf(b, sizeof(b), "+%d", c); float tw = gfx_text_w(&F_ui, b, size), w = tw + size * 0.95f;
    gfx_text(&F_ui, b, x - w * 0.5f, y, size, C_GOLD, AL_LEFT); coin_icon(x + w * 0.5f - size * 0.36f, y - 1, size * 1.25f);
}
static void meta_overlay(void) {                      /* what was just earned */
    if (!RW.n) return;
    float t = RW.t, k = ease_out_back(clampf(t / 0.28f, 0, 1)) * clampf((2.6f - t) / 0.25f, 0, 1), y = 104 - 70 * (1.0f - clampf(k, 0, 1)); char b[24];
    const char *tx = RW.q[0].text; int c = RW.q[0].coins; snprintf(b, sizeof(b), "+%d", c);
    float tw = gfx_text_w(&F_ui, tx, 25), cw = c > 0 ? gfx_text_w(&F_ui, b, 27) + 58 : 0, w = tw + cw + 64;
    gfx_rrect(640 - w * 0.5f - 3, y - 27, w + 6, 60, 30, 0x00000070u); gfx_rrect(640 - w * 0.5f, y - 30, w, 60, 30, C_GOLD); gfx_rrect(640 - w * 0.5f + 4, y - 26, w - 8, 52, 26, 0x2A1A70FFu);
    gfx_text(&F_ui, tx, 640 - w * 0.5f + 30, y, 25, WHITE, AL_LEFT);
    if (c > 0) { gfx_text(&F_ui, b, 640 + w * 0.5f - 62, y, 27, C_GOLD, AL_RIGHT); coin_icon(640 + w * 0.5f - 38, y - 1, 40); }
}

/* a question with two answers */
static struct { int on, arg; char title[80], text[520], yes[40]; void (*fn)(int); } ASK;
static int ask_on(void) { return ASK.on; }
static void ask_open(const char *title, const char *text, const char *yes, void (*fn)(int), int arg) {
    ASK.on = 1; ASK.fn = fn; ASK.arg = arg; snprintf(ASK.title, sizeof(ASK.title), "%s", title); snprintf(ASK.text, sizeof(ASK.text), "%s", text); snprintf(ASK.yes, sizeof(ASK.yes), "%s", yes);
}
static void ask_draw(void) {
    gfx_fade(0x0A0626C8u);
    panel(300, 190, 680, 340);
    title_text(ASK.title, 640, 246, 38);
    gfx_text_wrap(&F_txt, ASK.text, 640, 304, 23, 600, 31, 0xE8E0FFFFu, AL_CENTER, 1);
    if (wbtn(890, 492, 470, 280, 66, ASK.yes, C_GREEN1, C_GREEN2, 27, IC_NONE, 1)) { ASK.on = 0; if (ASK.fn) ASK.fn(ASK.arg); }
    if (wbtn(891, 792, 470, 280, 66, "Отмена", C_VIO1, C_VIO2, 27, IC_NONE, 1)) ASK.on = 0;
}

/* ---------------- missions ---------------- */
static struct { int tab; } TK;
static void tasks_enter(int a) { TK.tab = a == 1; mis_refresh(); tasks_new = 0; if (PF.seen != (u8)PF.day) { PF.seen = (u8)PF.day; PS.soft = 1; } PS.lv_t = 0; }
static const char *fmt_left(u32 s, char *b, int n) {  /* "5 ч 12 мин" */
    if (s >= 86400u) snprintf(b, (size_t)n, "%u д %u ч", (unsigned)(s / 86400u), (unsigned)(s % 86400u / 3600u));
    else if (s >= 3600u) snprintf(b, (size_t)n, "%u ч %02u мин", (unsigned)(s / 3600u), (unsigned)(s % 3600u / 60u));
    else snprintf(b, (size_t)n, "%u мин %02u с", (unsigned)(s / 60u), (unsigned)(s % 60u));
    return b;
}
static int mis_icon(int kind) {
    switch (kind) {
    case MK_STARS: case MK_PERFECT: return IC_CUP; case MK_TIME: case MK_FAST: case MK_RUN: return IC_CLOCK; case MK_WATCH: return IC_EYE; case MK_OTHERS: return IC_GLOBE;
    case MK_EDITOR: case MK_VIEWS: return IC_EDIT; case MK_RECORD: return IC_UP; case MK_DAILIES: return IC_TASKS; case MK_CUTS: return IC_CUT;
    case MK_FEED: case MK_PLAY: case MK_SLEEP: return IC_HEART; case MK_PLACE: case MK_VISIT: return IC_HOME; default: return IC_PLAY;
    }
}
static void mission_row(const Mission *m, float x, float y, float w, float h, int weekly) {
    char b[200], pb[40]; int prog = m->prog, tg = m->target;
    if (m->kind == MK_RUN && !m->done) prog = run_count(m, mis_clock());
    gfx_rrect(x, y, w, h, 22, m->done ? 0x8CF04E2Au : 0xFFFFFF12u);
    gfx_circle(x + 54, y + h * 0.5f, 31, m->done ? C_GREEN2 : (weekly ? 0xB8257FFFu : C_VIO2)); icon(m->done ? IC_OK : mis_icon(m->kind), x + 54, y + h * 0.5f, m->done ? 17 : 15, WHITE);
    text_fit(&F_ui, mis_text(m, b, (int)sizeof(b)), x + 104, y + h * 0.5f - 17, 23, w - 104 - 150, m->done ? 0xD8FFC0FFu : WHITE, AL_LEFT);
    float bx = x + 104, bw = w - 104 - 250, by = y + h * 0.5f + 12, k = tg ? clampf((float)prog / (float)tg, 0, 1) : 0;
    gfx_rrect(bx - 3, by - 3, bw + 6, 22, 11, 0x0E0A2EC0u); gfx_rrect(bx, by, bw, 16, 8, 0xFFFFFF28u);
    if (k > 0.01f) gfx_rrect(bx, by, maxf(16, bw * k), 16, 8, m->done ? C_GREEN1 : C_GOLD);
    if (m->kind == MK_TIME) snprintf(pb, sizeof(pb), "%d / %d мин", prog / 60, tg / 60); else snprintf(pb, sizeof(pb), "%d / %d", prog, tg);
    gfx_text(&F_ui, pb, bx + bw + 14, by + 8, 19, 0xE8E0FFFFu, AL_LEFT);
    if (m->done) gfx_text(&F_ui, "Выполнено", x + w - 78, y + h * 0.5f - 14, 19, 0x9CF04EFFu, AL_CENTER);
    reward_tag(x + w - 78, y + h * 0.5f + (m->done ? 14 : 0), m->reward, m->done ? 22 : 30);
}
static void scr_tasks(void) {
    char b[220], tb[40]; u32 t = now_s();
    bg_draw(0, 0.4f, DECO_NONE, 0, 0, 0);
    title_text("Задания", 640, 62, 50); back_button(SC_MENU, 0); coin_badge(1250, 62);
    if (wbtn(800, 304, 148, 316, 58, "Ежедневные", TK.tab == 0 ? C_GREEN1 : C_VIO1, TK.tab == 0 ? C_GREEN2 : C_VIO2, 26, IC_NONE, 1)) TK.tab = 0;
    if (wbtn(801, 640, 148, 316, 58, "Еженедельные", TK.tab == 1 ? C_GREEN1 : C_VIO1, TK.tab == 1 ? C_GREEN2 : C_VIO2, 26, IC_NONE, 1)) TK.tab = 1;
    if (wbtn(802, 976, 148, 316, 58, "Задания месяца", C_PINK, 0xB8257FFFu, 25, IC_HOME, 1)) go(SC_MONTH, 0, 0);      /* V0.6: one for every day of the month, with furniture for prizes */
    if (tasks_new6) gfx_circle(976 + 150, 148 - 24, 9, C_RED1);
    panel(140, 192, 1000, 500);
    if (t) snprintf(b, sizeof(b), TK.tab ? "Новые задания на неделю — через %s" : "Новые задания на день — через %s", fmt_left(TK.tab ? week_left(t) : day_left(t), tb, (int)sizeof(tb)));
    else snprintf(b, sizeof(b), "Часы устройства недоступны: задания сменятся при следующем запуске");
    float tw = gfx_text_w(&F_ui, b, 22); icon(IC_CLOCK, 640 - tw * 0.5f - 22, 238, 12, C_GOLD); gfx_text(&F_ui, b, 640 + 8, 238, 22, C_GOLD, AL_CENTER);
    if (!PF.dm[0].kind || !PF.wm[0].kind) gfx_text(&F_txt, "Сверяю часы с таблицей рекордов...", 640, 430, 24, 0xFFFFFFC0u, AL_CENTER);      /* the very first seconds of a new profile */
    else if (TK.tab == 0) for (int i = 0; i < 3; i++) mission_row(&PF.dm[i], 170, 272 + (float)i * 132, 940, 118, 0);
    else for (int i = 0; i < 4; i++) mission_row(&PF.wm[i], 170, 268 + (float)i * 102, 940, 92, 1);
    if (TK.tab == 0) gfx_text(&F_txt, "Новый день в игре начинается в полночь по Москве. За каждое задание дают чекушки: их тратят в магазине.", 640, 672, 17, 0xFFFFFFA0u, AL_CENTER);
}

/* ---------------- achievements ---------------- */
static struct { float scroll, drag_y0, scroll0; int drag; } AH;
static void ach_enter(int a) { (void)a; AH.scroll = 0; AH.drag = 0; ach_check(); PS.lv_t = 0; }
static int ach6_n(void); static const AchDef *ach6_get(int i); static int ach6_done(int i); static u32 ach6_now(int i);
static void scr_ach(void) {
    char b[96]; int got = 0, all = ACH_N + ach6_n(); for (int i = 0; i < ACH_N; i++) got += ach_done(i); for (int i = 0; i < ach6_n(); i++) got += ach6_done(i);
    bg_draw(0, 0.4f, DECO_NONE, 0, 0, 0);
    title_text("Достижения", 640, 62, 50); back_button(SC_MENU, 0); coin_badge(1250, 62);
    float lx = 140, ly = 112, lw = 1000, lh = 576, top = ly + 64, vis = lh - 64 - 16, rowh = 78, content = (float)all * rowh, maxs = maxf(0, content - vis);
    panel(lx, ly, lw, lh);
    snprintf(b, sizeof(b), "Получено: %d из %d", got, all); gfx_text(&F_ui, b, lx + 34, ly + 38, 25, C_GOLD, AL_LEFT);
    gfx_text(&F_txt, "Чем труднее достижение, тем больше чекушек за него дают", lx + lw - 80, ly + 38, 18, 0xFFFFFFB0u, AL_RIGHT);
    if (P.pressed && !ui_block && P.downx > lx && P.downx < lx + lw - 70 && P.downy > top && P.downy < top + vis) { AH.drag = 1; AH.drag_y0 = P.downy; AH.scroll0 = AH.scroll; }
    if (AH.drag) { if (!P.down) AH.drag = 0; else AH.scroll = AH.scroll0 - (P.y - AH.drag_y0); }
    AH.scroll = clampf(AH.scroll, 0, maxs);
    gfx_clip(lx + 8, top, lw - 16, vis);
    for (int i = 0; i < all; i++) {
        int v6 = i >= ACH_N; const AchDef *a = v6 ? ach6_get(i - ACH_N) : &ach_tab[i]; float y = top + (float)i * rowh - AH.scroll + rowh * 0.5f; if (y < top - rowh || y > top + vis + rowh) continue;
        int done = v6 ? ach6_done(i - ACH_N) : ach_done(i); u32 v = v6 ? ach6_now(i - ACH_N) : ach_value(a->src); if (v > a->goal) v = a->goal;
        gfx_rrect(lx + 18, y - rowh * 0.5f + 4, lw - 86, rowh - 8, 18, done ? 0xFFD23F26u : (i & 1 ? 0xFFFFFF10u : 0xFFFFFF08u));
        gfx_circle(lx + 62, y, 26, done ? 0xE0A21AFFu : 0x4A4470FFu); icon(v6 ? IC_HOME : IC_MEDAL, lx + 62, y, 15, done ? WHITE : 0xFFFFFF80u);
        gfx_text(&F_ui, a->name, lx + 104, y - 13, 24, done ? C_GOLD : WHITE, AL_LEFT);
        text_fit(&F_txt, a->desc, lx + 104, y + 15, 18, lw - 104 - 330, done ? 0xE8E0FFFFu : 0xD8CCFFC0u, AL_LEFT);
        if (done) { icon(IC_OK, lx + lw - 286, y, 13, 0x9CF04EFFu); gfx_text(&F_ui, "получено", lx + lw - 266, y, 19, 0x9CF04EFFu, AL_LEFT); }
        else if (a->goal > 1) { snprintf(b, sizeof(b), "%u / %u", (unsigned)v, (unsigned)a->goal); gfx_text(&F_ui, b, lx + lw - 226, y, 21, 0xE8E0FFFFu, AL_CENTER); }
        reward_tag(lx + lw - 122, y, a->reward, 26);
    }
    gfx_clip_reset();
    if (maxs > 0) {
        float bx = lx + lw - 40, t0 = top + 52, th = vis - 104, bh = maxf(40, th * vis / content), by = t0 + (th - bh) * (AH.scroll / maxs);
        gfx_rrect(bx - 4, t0, 8, th, 4, 0xFFFFFF20u); gfx_rrect(bx - 4, by, 8, bh, 4, 0xFFFFFFA0u);
        if (rbtn(860, bx, top + 22, 20, IC_UP, C_VIO1, C_VIO2, AH.scroll > 0)) AH.scroll -= rowh * 4;
        if (rbtn(861, bx, top + vis - 22, 20, IC_DOWN, C_VIO1, C_VIO2, AH.scroll < maxs)) AH.scroll += rowh * 4;
    }
}

/* ---------------- the shop ---------------- */
static void shop_enter(int a) { (void)a; }
static void shop_buy(int k) {
    if (k <= 0 || k >= SKIN_N || ((PF.skins >> k) & 1u) || coins() < skin_tab[k].price) return;
    PF.skins |= 1u << k; PF.skin = (u8)k; sfx_p(S_WIN, 0.7f, 640, 1.12f); fx_confetti(200, 1080, -10, 60);
    char b[100]; snprintf(b, sizeof(b), "Куплено: «%s»", skin_tab[k].name); gtoast(b);
    ach_check(); prof_dirty();
}
static void scr_shop(void) {
    char b[200];
    bg_draw(0, 0.4f, DECO_NONE, 0, 0, 0);
    title_text("Магазин", 640, 62, 50); back_button(SC_MENU, 0); coin_badge(1250, 62);
    gfx_text(&F_txt, "Скины для чекушки: 20 напитков и золотая. Они меняют только её вид: уровни проходятся так же.", 640, 108, 19, 0xFFFFFFC0u, AL_CENTER);
    for (int q = 0; q < SKIN_N; q++) {                   /* by price: seven in a row */
        int k = skin_order[q]; float cw = 166, chh = 184, x = 43 + (float)(q % 7) * 172, y = 132 + (float)(q / 7) * 192, cx = x + cw * 0.5f;
        int own = (PF.skins >> k) & 1u, sel = PF.skin == k, price = skin_tab[k].price, can = coins() >= price;
        gfx_rrect(x - 3, y + 5, cw + 6, chh + 4, 24, 0x00000050u); gfx_rrect(x, y, cw, chh, 22, sel ? C_GOLD : C_EDGE); gfx_rrect_grad(x + 4, y + 4, cw - 8, chh - 8, 18, sel ? 0x5A3FB8FFu : C_PANEL1, C_PANEL2);
        float bob = sel ? sinf(g_time * 3.0f) * 3.0f : 0;
        gfx_circle(cx, y + 56, 44, 0xFFFFFF14u);
        gfx_image_ex(skin_pic(k), cx, y + 56 + bob, 1.5f, 1.5f, sel ? sinf(g_time * 2.0f) * 0.08f : 0, own ? 1.0f : 0.92f);
        text_fit(&F_ui, skin_tab[k].name, cx, y + 116, 19, cw - 14, WHITE, AL_CENTER);
        if (sel) { gfx_rrect(cx - 68, y + 132, 136, 40, 18, 0x2FAE3AFFu); icon(IC_OK, cx - 44, y + 152, 9, WHITE); gfx_text(&F_ui, "Надето", cx + 10, y + 152, 19, WHITE, AL_CENTER); }
        else if (own) { if (wbtn(830 + k, cx, y + 152, 136, 40, "Надеть", C_BLUE1, C_BLUE2, 20, IC_NONE, 1)) { PF.skin = (u8)k; prof_dirty(); } }
        else {
            snprintf(b, sizeof(b), "%d", price);
            if (wbtn(830 + k, cx - 12, y + 152, 112, 40, b, can ? C_ORG1 : 0x8A84A8FFu, can ? C_ORG2 : 0x5A5478FFu, 22, IC_NONE, 1)) {
                if (can) { snprintf(b, sizeof(b), "«%s» за %d %s. После покупки останется %d.", skin_tab[k].name, price, plural(price, "чекушку", "чекушки", "чекушек"), coins() - price); ask_open("Купить скин?", b, "Купить", shop_buy, k); }
                else { char t[150]; snprintf(t, sizeof(t), "Не хватает %d %s. Их дают за задания и достижения.", price - coins(), plural(price - coins(), "чекушки", "чекушек", "чекушек")); gtoast(t); }
            }
            coin_icon(cx + 60, y + 151, 30);
        }
    }
    parts_draw();
}

/* ---------------- the support chat ---------------- */
static void chat_enter(int a) { (void)a; sup_unread = 0; CH.stick = 1; CH.drag = 0; if (chat_ready()) { if (CH.n && CH.m[CH.n - 1].id > PF.chat_last) { PF.chat_last = CH.m[CH.n - 1].id; prof_dirty(); } chat_poll(0); } else if (NET.st == NS_ERR || NET.st == NS_NONE) net_cfg(); }
static void chat_write(void) { kb_open("Сообщение разработчику", CH.draft, 200, 3, chat_send_done); }
static void scr_chat(void) {
    float lx = 140, ly = 108, lw = 1000, lh = 492, top = ly + 18, vis = lh - 36, y = 0, maxw = 600; int ready = chat_ready();
    bg_draw(0, 0.4f, DECO_NONE, 0, 0, 0);
    title_text("Тех. поддержка", 640, 62, 50); back_button(SC_SETTINGS, 0);
    panel(lx, ly, lw, lh);
    if (ready && scr_next < 0) { CH.poll_t += g_dt; if (CH.poll_t > 8.0f) chat_poll(0); }      /* a new answer shows up by itself */
    static float hh[CHAT_MAX]; float content = 0;
    for (int i = 0; i < CH.n; i++) { int lines = gfx_text_wrap(&F_txt, CH.m[i].text, 0, 0, 21, maxw, 28, 0, AL_LEFT, 0); hh[i] = (float)lines * 28 + 18 + (CH.m[i].who ? 28 : 0); content += hh[i] + 12; }
    float maxs = maxf(0, content - vis);
    if (P.pressed && !ui_block && P.downx > lx && P.downx < lx + lw - 60 && P.downy > top && P.downy < top + vis) { CH.drag = 1; CH.drag_y0 = P.downy; CH.scroll0 = CH.scroll; CH.stick = 0; }
    if (CH.drag) { if (!P.down) CH.drag = 0; else CH.scroll = CH.scroll0 - (P.y - CH.drag_y0); }
    if (CH.stick) CH.scroll = maxs;
    CH.scroll = clampf(CH.scroll, 0, maxs); if (CH.scroll >= maxs - 1) CH.stick = 1;
    gfx_clip(lx + 8, top, lw - 16, vis);
    y = top - CH.scroll + (content < vis ? vis - content : 0);
    for (int i = 0; i < CH.n; i++) {
        const ChatMsg *m = &CH.m[i]; float h = hh[i];
        if (y + h > top - 10 && y < top + vis + 10) {
            float tw = 0; { const char *s = m->text; float w1 = gfx_text_w(&F_txt, s, 21); tw = w1 > maxw ? maxw : w1; }
            if (m->who) { float lw2 = gfx_text_w(&F_ui, "Разработчик", 18) + 34; if (tw < lw2) tw = lw2; }
            float bw = tw + 40, bx = m->who ? lx + 36 : lx + lw - 70 - bw;
            gfx_rrect(bx, y, bw, h, 20, m->who ? 0x6A4A10FFu : 0x4B2FB0FFu); gfx_rrect(bx + 2, y + 2, bw - 4, h - 4, 18, m->who ? 0x8A6418FFu : 0x6038D8FFu);
            if (m->who) { icon(IC_CROWN, bx + 28, y + 19, 9, C_GOLD); gfx_text(&F_ui, "Разработчик", bx + 44, y + 20, 18, C_GOLD, AL_LEFT); }
            gfx_text_wrap(&F_txt, m->text, bx + 20, y + 23 + (m->who ? 28 : 0), 21, maxw, 28, WHITE, AL_LEFT, 1);
        }
        y += h + 12;
    }
    gfx_clip_reset();
    if (!CH.n) {
        const char *t = !ready ? (NET.st == NS_ON && NET.proto && NET.proto < 5 ? "Поддержка появится, когда автор игры обновит таблицу рекордов." : (NET.st == NS_ON || NET.st == NS_CFG || NET.st == NS_NONE ? "Подключаюсь..." : "Нет связи с интернетом. Написать в поддержку можно, когда связь появится."))
                      : (CH.st == 1 ? "Загружаю переписку..." : (CH.st == 3 ? "Таблица не ответила. Нажми кнопку со стрелкой, чтобы попробовать ещё раз." : "Здесь можно написать разработчику игры: вопрос, ошибка, идея. Ответ появится в этом же окне."));
        gfx_text_wrap(&F_txt, t, 640, top + vis * 0.4f, 24, 760, 34, 0xFFFFFFC0u, AL_CENTER, 1);
    }
    if (maxs > 0) {
        float bx = lx + lw - 38, t0 = top + 52, th = vis - 104, bh = maxf(40, th * vis / content), by = t0 + (th - bh) * (CH.scroll / maxs);
        gfx_rrect(bx - 4, t0, 8, th, 4, 0xFFFFFF20u); gfx_rrect(bx - 4, by, 8, bh, 4, 0xFFFFFFA0u);
        if (rbtn(870, bx, top + 22, 20, IC_UP, C_VIO1, C_VIO2, CH.scroll > 0)) { CH.scroll -= 200; CH.stick = 0; }
        if (rbtn(871, bx, top + vis - 22, 20, IC_DOWN, C_VIO1, C_VIO2, CH.scroll < maxs)) CH.scroll += 200;
    }
    if (wbtn(872, 590, 650, 560, 64, CH.sending ? "Отправляю..." : "Написать сообщение", C_GREEN1, C_GREEN2, 28, IC_CHAT, ready && !CH.sending)) chat_write();
    if (rbtn(873, 928, 650, 28, IC_RESTART, C_BLUE1, C_BLUE2, ready && !NET.busy[RQ_CHAT])) { chat_poll(0); CH.stick = 1; }
    gfx_text_wrap(&F_txt, CFG.acc ? "Переписка хранится в твоём аккаунте." : "Без аккаунта переписка видна только на этом устройстве.", 1070, 632, 16, 190, 22, 0xFFFFFFA0u, AL_CENTER, 1);
}

/* ---------------- keys ---------------- */
static int meta_key(int key) {
    if (ASK.on) { if (key == KEY_ESC) ASK.on = 0; else if (key == KEY_ENTER) { ASK.on = 0; if (ASK.fn) ASK.fn(ASK.arg); } return 1; }
    if (scr == SC_CHAT) {
        if (key == KEY_ESC) { go(SC_SETTINGS, 0, 0); return 1; }
        if (key == KEY_ENTER && chat_ready() && !CH.sending) { chat_write(); return 1; }
        if (key == KEY_UP || key == KEY_WHEEL_UP) { CH.scroll -= 90; CH.stick = 0; return 1; } if (key == KEY_DOWN || key == KEY_WHEEL_DOWN) { CH.scroll += 90; return 1; }
        return 0;
    }
    if (scr == SC_ACH) { if (key == KEY_UP || key == KEY_WHEEL_UP) { AH.scroll -= 78; return 1; } if (key == KEY_DOWN || key == KEY_WHEEL_DOWN) { AH.scroll += 78; return 1; } return 0; }
    if (scr == SC_TASKS) { if (key == KEY_LEFT) { TK.tab = 0; return 1; } if (key == KEY_RIGHT) { TK.tab = 1; return 1; } return 0; }
    if (scr == SC_SETTINGS) { if (key == KEY_WHEEL_UP) { STG.scroll -= 108; return 1; } if (key == KEY_WHEEL_DOWN) { STG.scroll += 108; return 1; } return 0; }
    if (scr == SC_RECORDS) { if (key == KEY_WHEEL_UP) { RS.scroll -= 132; return 1; } if (key == KEY_WHEEL_DOWN) { RS.scroll += 132; return 1; } return 0; }
    return 0;
}

/* ---------------- test hooks of V0.5 (180..229) ---------------- */
static int v05_debug(int cmd, int arg) {
    switch (cmd) {
    case 180: return coins();
    case 181: return (int)PF.earned;
    case 182: return (int)PF.skins;
    case 183: return PF.skin;
    case 184: { int before = (int)PF.skins; shop_buy(arg); return (int)PF.skins != before; }
    case 185: if (arg >= 0 && arg < SKIN_N && ((PF.skins >> arg) & 1u)) { PF.skin = (u8)arg; prof_dirty(); return 1; } return 0;
    case 186: { int slot = arg & 255, f = arg >> 8; const Mission *m = slot < 3 ? &PF.dm[slot] : (slot >= 4 && slot < 8 ? &PF.wm[slot - 4] : NULL); if (!m) return -1;
                return f == 0 ? m->kind : f == 1 ? m->target : f == 2 ? (m->kind == MK_RUN && !m->done ? run_count(m, mis_clock()) : m->prog) : f == 3 ? m->done : f == 4 ? m->reward : m->arg; }
    case 187: return (int)PF.day;
    case 188: return (int)PF.week;
    case 189: return (int)PF.ach[0];
    case 190: { int n = 0; for (int i = 0; i < ACH_N; i++) n += ach_done(i); return n; }
    case 191: scr_next = -1; enter(SC_TASKS, arg, 0); g_fade = 0; return 0;
    case 192: scr_next = -1; enter(SC_SHOP, 0, 0); g_fade = 0; return 0;
    case 193: scr_next = -1; enter(SC_ACH, 0, 0); g_fade = 0; AH.scroll = (float)arg; return 0;
    case 194: scr_next = -1; enter(SC_CHAT, 0, 0); g_fade = 0; return 0;
    case 195: return arg >= 0 && arg < CN_N ? (int)PF.cn[arg] : -1;
    case 196: { u32 t = now_s(); return t ? (int)(arg ? week_left(t) : day_left(t)) : -1; }
    case 197: return PS.loaded | (PF.dirty << 1) | (NET.busy[RQ_SAVE] << 2) | (NET.busy[RQ_LOAD] << 3) | ((int)(PF.rev & 0xFFFFu) << 8);
    case 198: return CH.n | (CH.st << 8) | (sup_unread << 12) | (CH.sending << 20);
    case 200: return arg >= 0 && arg < CH.n ? (CH.m[arg].who | ((int)strlen(CH.m[arg].text) << 4)) : -1;
    case 201: mis_refresh(); return 0;
    case 202: PF.earned += (u32)arg; prof_dirty(); return coins();
    case 203: return (mus_cur & 15) | ((mus_render >= 0) << 4) | ((mus_goal & 15) << 8);
    case 204: return my_badge;
    case 205: return RW.n;
    case 206: return tasks_new;
    case 207: PS.t = 0; PS.retry = 0; PS.lv_t = 0; if (PS.soft) prof_dirty(); return 0;
    case 208: if (CFG.acc) acc_logout(); return CFG.acc;
    case 209: return (int)(PF.uid & 0x7FFFFFFFu);
    case 210: return (int)ach_value(AV_LEVELS);
    case 211: if (arg >= 0 && arg < LEVEL_COUNT && SV.ticks[arg]) { SV.ticks[arg] += 240; SV.sent[arg] = 1; } return 0;      /* tests: pretend the old record of this level was two seconds slower */
    case 212: return (int)ach_value(arg);
    case 213: return ach_done(arg);
    case 214: return (int)(now_s() & 0x7FFFFFFFu);
    case 215: return (int)PF.best_plays;
    case 216: return boxes_open() | (levels_open() << 8);
    case 217: return (int)(day_of(now_s()));
    case 218: memset(SV.best, 4, (size_t)LEVEL_COUNT); for (int i = (BOXES - 1) * PER_BOX; i < LEVEL_COUNT; i++) SV.best[i] = 11; for (int i = 0; i < LEVEL_COUNT; i++) if (!SV.ticks[i]) SV.ticks[i] = 1200; ach_check(); return total_stars();      /* tests: everything is open */
    case 219: return (int)strlen(sync_buf);
    default: return 0;
    }
}
