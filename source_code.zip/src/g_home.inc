/* ============================================================================
   «МЕЛ-НЯМ» V0.6 — what an account owns besides its progress:
     a house in the city of Melstroy (bigger for 300 чекушек), the furniture in it (given by the monthly missions),
     the little talking Mel who lives there (his needs, his age, his clothes, the drinks in his fridge).
   All of it is one more line of text in the account ("v6|..."), next to the progress of V0.5 and apart from it:
   a game of V0.5 on another device of the same player never sees this line and so cannot lose it.
   Included by game.c after g_meta.inc. The screens are in g_house.inc (the room), g_pet.inc (Mel) and g_city.inc (the map).
   ============================================================================ */

/* ---------------- the catalogues ---------------- */
enum { IK_FLOOR, IK_WALL, IK_CEIL, IK_RUG };         /* where a piece of furniture goes: stands on the floor / hangs on the wall / hangs from the ceiling / lies on the floor */
typedef struct { const char *name; u8 kind; i16 w, h; } ItemDef;      /* w, h: design units at scale 1 */
#define ITEM_N 36
#define ITEM_START 6                                 /* the first six come with the house; the rest are prizes of the monthly missions, five a month */
static const ItemDef item_tab[ITEM_N] = {
    { "Кровать", IK_FLOOR, 230, 112 }, { "Стол", IK_FLOOR, 150, 92 }, { "Стул", IK_FLOOR, 72, 112 }, { "Коврик", IK_RUG, 210, 34 }, { "Лампочка", IK_CEIL, 60, 96 }, { "Постер", IK_WALL, 92, 122 },
    { "Диван", IK_FLOOR, 236, 112 }, { "Телевизор", IK_FLOOR, 176, 150 }, { "Фикус", IK_FLOOR, 86, 156 }, { "Картина", IK_WALL, 132, 96 }, { "Игровое кресло", IK_FLOOR, 96, 152 },
    { "Ёлка", IK_FLOOR, 160, 236 }, { "Камин", IK_FLOOR, 190, 172 }, { "Гирлянда", IK_WALL, 300, 56 }, { "Снеговик", IK_FLOOR, 96, 136 }, { "Кресло-качалка", IK_FLOOR, 126, 134 },
    { "Стол стримера", IK_FLOOR, 226, 156 }, { "Микрофон", IK_FLOOR, 56, 156 }, { "Вывеска LIVE", IK_WALL, 156, 72 }, { "Колонка", IK_FLOOR, 76, 136 }, { "Кольцевая лампа", IK_FLOOR, 76, 196 },
    { "Аквариум", IK_FLOOR, 156, 156 }, { "Книжный шкаф", IK_FLOOR, 146, 236 }, { "Часы", IK_WALL, 76, 76 }, { "Торшер", IK_FLOOR, 76, 216 }, { "Кот", IK_FLOOR, 76, 72 },
    { "Холодильник", IK_FLOOR, 116, 226 }, { "Пальма", IK_FLOOR, 136, 246 }, { "Гитара", IK_FLOOR, 66, 146 }, { "Кубок", IK_FLOOR, 76, 156 }, { "Диско-шар", IK_CEIL, 86, 116 },
    { "Джакузи", IK_FLOOR, 226, 112 }, { "Сейф", IK_FLOOR, 116, 126 }, { "Золотой Мел", IK_FLOOR, 96, 206 }, { "Телескоп", IK_FLOOR, 106, 166 }, { "Люстра", IK_CEIL, 166, 116 },
};

enum { SL_HAT, SL_EYES, SL_TOP, SL_LEGS, SL_FEET, SL_ACC, SL_N };
typedef struct { const char *name; u8 slot, style; u32 c1, c2; i16 price; } ClothDef;
#define CLOTH_N 40
static const char *const slot_name[SL_N] = { "Шапки", "Очки", "Верх", "Низ", "Обувь", "Разное" };
static const ClothDef cloth_tab[CLOTH_N] = {
    { "Кепка", SL_HAT, 0, 0xE5484DFFu, 0xB32B32FFu, 30 }, { "Кепка назад", SL_HAT, 1, 0xF4F4F8FFu, 0xB9BCCBFFu, 40 }, { "Шапка с помпоном", SL_HAT, 2, 0x3D7BE8FFu, 0xFFFFFFFFu, 35 },
    { "Наушники", SL_HAT, 3, 0x2B2B3AFFu, 0xFF4FB8FFu, 60 }, { "Цилиндр", SL_HAT, 4, 0x24212EFFu, 0xC8323CFFu, 80 }, { "Колпак", SL_HAT, 5, 0xFFC93CFFu, 0xFF4FB8FFu, 25 },
    { "Шляпа ковбоя", SL_HAT, 6, 0xA9703FFFu, 0x6E4525FFu, 70 }, { "Корона", SL_HAT, 7, 0xFFD23FFFu, 0xE5484DFFu, 250 },
    { "Тёмные очки", SL_EYES, 0, 0x1A1A24FFu, 0x3B3B4CFFu, 40 }, { "Круглые очки", SL_EYES, 1, 0x2B2B3AFFu, 0xCDEBFFA0u, 30 }, { "Очки-звёзды", SL_EYES, 2, 0xFFD23FFFu, 0xFF8A1EFFu, 55 },
    { "VR-шлем", SL_EYES, 3, 0x30303EFFu, 0x46E6FFFFu, 120 }, { "Розовые очки", SL_EYES, 4, 0xFF6FC2FFu, 0xFFB3E0C0u, 45 },
    { "Белая футболка", SL_TOP, 0, 0xF4F4F8FFu, 0xC9CBD9FFu, 20 }, { "Футболка MEL", SL_TOP, 1, 0x7C4DFFFFu, 0xFFD23FFFu, 35 }, { "Тельняшка", SL_TOP, 2, 0xF4F4F8FFu, 0x2B4FB8FFu, 30 },
    { "Худи", SL_TOP, 3, 0x8A8FA6FFu, 0x6B7089FFu, 60 }, { "Спортивная куртка", SL_TOP, 4, 0xE5484DFFu, 0xFFFFFFFFu, 70 }, { "Свитер с ёлочкой", SL_TOP, 5, 0x2F9E55FFu, 0xF4F4F8FFu, 65 },
    { "Пиджак", SL_TOP, 6, 0x262633FFu, 0xC8323CFFu, 150 }, { "Майка", SL_TOP, 7, 0xFF8A1EFFu, 0xD96A0AFFu, 15 }, { "Гавайская рубашка", SL_TOP, 8, 0x29B6C8FFu, 0xFFD23FFFu, 55 },
    { "Золотая куртка", SL_TOP, 9, 0xFFD23FFFu, 0xE39A12FFu, 300 },
    { "Джинсы", SL_LEGS, 0, 0x3F6FC4FFu, 0x2B4F94FFu, 30 }, { "Шорты", SL_LEGS, 1, 0x2FAE6AFFu, 0x1F7F4BFFu, 20 }, { "Спортивные штаны", SL_LEGS, 2, 0x2B2B3AFFu, 0xFFFFFFFFu, 40 },
    { "Брюки", SL_LEGS, 3, 0x3A3A4AFFu, 0x262633FFu, 70 }, { "Пижамные штаны", SL_LEGS, 4, 0x9AD4FFFFu, 0xFFFFFFFFu, 35 }, { "Золотые штаны", SL_LEGS, 5, 0xFFD23FFFu, 0xE39A12FFu, 200 },
    { "Кеды", SL_FEET, 0, 0xE5484DFFu, 0xFFFFFFFFu, 25 }, { "Кроссовки", SL_FEET, 1, 0xF4F4F8FFu, 0x46E6FFFFu, 50 }, { "Тапочки-зайцы", SL_FEET, 2, 0xFFB3D9FFu, 0xFFFFFFFFu, 30 },
    { "Ботинки", SL_FEET, 3, 0x7A4A28FFu, 0x4E2E18FFu, 60 }, { "Золотые кроссовки", SL_FEET, 4, 0xFFD23FFFu, 0xFFFFFFFFu, 180 },
    { "Золотая цепь", SL_ACC, 0, 0xFFD23FFFu, 0xE39A12FFu, 90 }, { "Шарф", SL_ACC, 1, 0xE5484DFFu, 0xFFFFFFFFu, 30 }, { "Бабочка", SL_ACC, 2, 0xC8323CFFu, 0x8E1F27FFu, 35 },
    { "Медаль", SL_ACC, 3, 0xFFD23FFFu, 0x3D7BE8FFu, 50 }, { "Часы", SL_ACC, 4, 0x30303EFFu, 0xFFD23FFFu, 70 }, { "Рюкзак", SL_ACC, 5, 0x3D7BE8FFu, 0xFFC93CFFu, 45 },
};

/* The drinks of the little Mel are the twenty drinks of the shop (every skin but the golden bottle), bought one by one and drunk once.
   What a drink does: thirst, energy, health, joy (points out of 100). The spirits are for a grown-up Mel only. */
enum { ND_THIRST, ND_ENERGY, ND_HEALTH, ND_JOY, ND_N };
typedef struct { i8 fx[ND_N]; u8 price, alc; } DrinkDef;
#define DRINK_N 20
#define HOUSE_PRICE 300
#define ADULT_AGE 18
static const DrinkDef drink_tab[DRINK_N] = {
    { { 10, -25, -15, 30 }, 12, 1 },  /* чекушка */   { { 35, 0, 2, 0 }, 0, 0 },      /* вода: из-под крана, бесплатно */
    { { 30, 5, 6, 5 }, 3, 0 },        /* сок */       { { 30, 0, 10, 4 }, 4, 0 },     /* морс */
    { { 28, 6, 2, 8 }, 4, 0 },        /* квас */      { { 40, 4, -2, 12 }, 5, 0 },    /* лимонад */
    { { 10, 45, -8, 5 }, 8, 0 },      /* энергетик */ { { 15, -18, -10, 22 }, 9, 1 }, /* пиво */
    { { 8, -22, -12, 26 }, 10, 1 },   /* вино */      { { 2, -35, -22, 35 }, 12, 1 }, /* водка */
    { { 25, 5, 12, 3 }, 3, 0 },       /* молоко */    { { 25, 12, 4, 4 }, 2, 0 },     /* чай */
    { { 32, 3, 7, 6 }, 3, 0 },        /* компот */    { { 22, -4, 9, 7 }, 4, 0 },     /* кисель */
    { { 38, 2, 6, 0 }, 2, 0 },        /* минералка */ { { 18, -10, 4, 16 }, 5, 0 },   /* какао */
    { { 8, 35, -4, 6 }, 6, 0 },       /* кофе */      { { 25, 18, -6, 15 }, 6, 0 },   /* кола */
    { { 12, 28, -2, 12 }, 8, 0 },     /* капучино */  { { 15, 8, 0, 28 }, 9, 0 },     /* горячий шоколад */
};
static int drink_skin(int d) { return d < 10 ? d : d + 1; }
static const char *drink_name(int d) { return skin_tab[drink_skin(d)].name; }

/* ---------------- the house of an account ---------------- */
enum { C6_VISITS, C6_FEEDS, C6_WORDS, C6_PLAYS, C6_MONTHS, C6_TALKS, C6_SLEEPS, C6_MOVES, C6_N = 12 };
#define PLACED_MAX 44
#define HOME_MAGIC 0x36454D48u
typedef struct { u8 id, x, y, fl; } Placed;          /* id: item + 1 (0: free); x: design x / 6; y: design y / 4 (wall things only); fl: bit 0 upstairs, bit 1 mirrored */
typedef struct {
    u32 magic, uid, rev, plot;                       /* rev: the save of the table this copy has seen; plot: where the house stands in the city (given by the table) */
    u32 earned;                                      /* чекушки earned by what V0.6 added (monthly missions, the new achievements) */
    u32 skins, ach;                                  /* a copy of the skins owned; the achievements of V0.6 */
    u32 cn[C6_N];
    u32 items[2], cloth[2];                          /* furniture and clothes owned (bits) */
    u32 pl_rev, wear_rev;                            /* how many times the furniture was moved / the clothes were changed: the newer state wins when two devices differ */
    Placed pl[PLACED_MAX];
    u32 month; u16 m_idx, r0; Mission mm;            /* the monthly missions: which month, how many are done, the one that is open */
    u32 xp, pet_t;                                   /* Mel: all his experience (his age follows from it); when his needs were last counted */
    u16 need[ND_N];                                  /* 0..10000 */
    u16 bought[DRINK_N], used[DRINK_N];
    u32 xp_day; u16 xp_cnt[4];                       /* what was already rewarded today */
    u8 wear[SL_N];                                   /* cloth + 1 in every slot */
    u8 big, asleep, dirty, seen_age;                 /* seen_age: the age the player has seen him jump to */
    u32 guests;                                      /* how many visitors the house had (told by the table) */
    u32 xp_wins;                                     /* level wins that have already made him grow today */
    u32 r[7];
} Home;
static Home HM;
static struct { int loaded, gen, sent_gen, got; float t, retry, sec; u32 save_uid; u32 seen[8]; int seen_n;
    u32 mseen[8], mseen_key; int mseen_n;            /* the houses visited for the open mission of the month (mseen_key says for which one) */
} HS;
static int home_on(void) { return CFG.acc && HM.magic == HOME_MAGIC && HM.uid && HM.uid == SV.uid; }       /* a signed-in player has a house */
static void home_store(void) { if (HM.magic == HOME_MAGIC) plat_store("home", &HM, (int)sizeof(HM)); }
static void home_dirty(void) { if (!home_on()) return; HM.dirty = 1; HS.gen++; if (HS.t <= 0 || HS.t > 3.0f) HS.t = 3.0f; home_store(); }
static int item_has(const Home *h, int i) { return (h->items[i >> 5] >> (i & 31)) & 1u; }
static int cloth_has(const Home *h, int i) { return (h->cloth[i >> 5] >> (i & 31)) & 1u; }
static int items_owned(const Home *h) { int n = 0; for (int i = 0; i < ITEM_N; i++) n += item_has(h, i); return n; }
static int items_placed(const Home *h) { int n = 0; for (int i = 0; i < PLACED_MAX; i++) n += h->pl[i].id != 0; return n; }
static int cloth_owned(const Home *h) { int n = 0; for (int i = 0; i < CLOTH_N; i++) n += cloth_has(h, i); return n; }
static int drink_left(int d) { int n = (int)HM.bought[d] - (int)HM.used[d]; return n < 0 ? 0 : n; }
/* чекушки: what V0.6 has given and what it has taken */
static int home_earned(void) { return home_on() ? (int)HM.earned : 0; }
static int home_spent(void) {
    int c = 0; if (!home_on()) return 0;
    if (HM.big) c += HOUSE_PRICE;
    for (int i = 0; i < CLOTH_N; i++) if (cloth_has(&HM, i)) c += cloth_tab[i].price;
    for (int d = 0; d < DRINK_N; d++) c += (int)HM.bought[d] * drink_tab[d].price;
    return c;
}

/* ---------------- the age of Mel ---------------- */
static int pet_need(int age) { return age < 20 ? 20 + 10 * age : 250; }      /* experience from this birthday to the next: slowly to twenty (2300 in all), then steadily on */
static int pet_age_of(u32 xp, int *into, int *need) {
    int a = 0, x = (int)(xp > 4000000u ? 4000000u : xp);
    while (a < 199 && x >= pet_need(a)) { x -= pet_need(a); a++; }
    if (into) *into = x; if (need) *need = pet_need(a);
    return a;
}
static int pet_age(void) { return pet_age_of(HM.xp, NULL, NULL); }
static const char *pet_stage(int age) { return age < 3 ? "Малыш" : (age < 7 ? "Дошкольник" : (age < 13 ? "Школьник" : (age < 18 ? "Подросток" : (age < 30 ? "Взрослый" : (age < 60 ? "Солидный дядя" : "Дедушка Мел"))))); }
static float pet_pitch(int age) {                    /* the younger, the higher the voice; an old Mel speaks low */
    if (age < 18) return 1.9f - 0.9f * (float)age / 18.0f;
    return clampf(1.0f - (float)(age - 18) * 0.006f, 0.72f, 1.0f);
}

/* ---------------- the first state ---------------- */
static void home_place(Home *h, int item, int x, int y, int fl) {
    for (int i = 0; i < PLACED_MAX; i++) if (!h->pl[i].id) { h->pl[i].id = (u8)(item + 1); h->pl[i].x = (u8)(x / 6); h->pl[i].y = (u8)(y / 4); h->pl[i].fl = (u8)fl; return; }
}
static void home_starter(Home *h) {                  /* what every new house has: six things in their places, a newborn Mel who is fed and rested */
    for (int i = 0; i < ITEM_START; i++) h->items[0] |= 1u << i;
    if (!items_placed(h) && !h->pl_rev) { home_place(h, 3, 540, 0, 0); home_place(h, 0, 262, 0, 0); home_place(h, 1, 786, 0, 0); home_place(h, 2, 894, 0, 2); home_place(h, 4, 450, 0, 0); home_place(h, 5, 430, 252, 0); }      /* (a small house is 960 wide: see g_house.inc) */
    if (!h->pet_t && !h->xp) for (int k = 0; k < ND_N; k++) h->need[k] = 8000;
}
static void home_fresh(u32 uid) { memset(&HM, 0, sizeof(HM)); if (!uid) return; HM.magic = HOME_MAGIC; HM.uid = uid; home_starter(&HM); }

/* ---------------- the house as one line of text ---------------- */
#define AP(...) do { if (n < max - 1) { n += snprintf(o + n, (size_t)(max - n), __VA_ARGS__); if (n > max - 1) n = max - 1; } } while (0)
static int home_encode(const Home *h, char *o, int max) {
    int n = 0, first = 1; const Mission *m = &h->mm;
    AP("v6|e%u|s%x|a%x|c", (unsigned)h->earned, (unsigned)h->skins, (unsigned)h->ach);
    for (int i = 0; i < C6_N; i++) AP(i ? ".%u" : "%u", (unsigned)h->cn[i]);
    AP("|h%u.%u.%u|i%x.%x|k%x.%x|w", (unsigned)h->big, (unsigned)h->pl_rev, (unsigned)h->wear_rev, (unsigned)h->items[0], (unsigned)h->items[1], (unsigned)h->cloth[0], (unsigned)h->cloth[1]);
    for (int i = 0; i < SL_N; i++) AP(i ? ".%u" : "%u", (unsigned)h->wear[i]);
    AP("|p"); for (int i = 0; i < PLACED_MAX; i++) if (h->pl[i].id) { AP("%s%u.%u.%u.%u", first ? "" : ",", h->pl[i].id, h->pl[i].x, h->pl[i].y, h->pl[i].fl); first = 0; }
    AP("|m%u:%u:%u.%u.%u.%u.%u.%u.%x.%x", (unsigned)h->month, (unsigned)h->m_idx, m->kind, m->arg, m->done, m->target, m->prog, m->reward, (unsigned)m->mask[0], (unsigned)m->mask[1]);
    AP("|x%u.%u|n%u.%u", (unsigned)h->xp, (unsigned)h->seen_age, (unsigned)h->pet_t, (unsigned)h->asleep); for (int i = 0; i < ND_N; i++) AP(".%u", (unsigned)h->need[i]);
    AP("|b"); for (int i = 0; i < DRINK_N; i++) AP(i ? ".%u" : "%u", (unsigned)h->bought[i]);
    AP("|u"); for (int i = 0; i < DRINK_N; i++) AP(i ? ".%u" : "%u", (unsigned)h->used[i]);
    AP("|q%u", (unsigned)h->xp_day); for (int i = 0; i < 4; i++) AP(".%u", (unsigned)h->xp_cnt[i]); AP(".%u", (unsigned)h->xp_wins);
    return n;
}
#undef AP
static int home_decode(const char *s, Home *h) {
    memset(h, 0, sizeof(*h));
    if (strncmp(s, "v6|", 3)) return 0;
    const char *p = s + 3; int np = 0;
    while (*p) {
        char tag = *p++; const char *e = strchr(p, '|'), *q = p; if (!e) e = p + strlen(p);
        switch (tag) {
        case 'e': h->earned = rdn(&q, 10); break;
        case 's': h->skins = rdn(&q, 16); break;
        case 'a': h->ach = rdn(&q, 16); break;
        case 'c': for (int i = 0; i < C6_N && q < e; i++) h->cn[i] = rdn(&q, 10); break;
        case 'h': h->big = (u8)(rdn(&q, 10) != 0); h->pl_rev = rdn(&q, 10); h->wear_rev = rdn(&q, 10); break;
        case 'i': h->items[0] = rdn(&q, 16); h->items[1] = rdn(&q, 16); break;
        case 'k': h->cloth[0] = rdn(&q, 16); h->cloth[1] = rdn(&q, 16); break;
        case 'w': for (int i = 0; i < SL_N && q < e; i++) h->wear[i] = (u8)rdn(&q, 10); break;
        case 'p': while (q < e && np < PLACED_MAX) { u32 id = rdn(&q, 10), x = rdn(&q, 10), y = rdn(&q, 10), fl = rdn(&q, 10); if (id >= 1 && id <= ITEM_N) { Placed *pl = &h->pl[np++]; pl->id = (u8)id; pl->x = (u8)(x > 255 ? 255 : x); pl->y = (u8)(y > 255 ? 255 : y); pl->fl = (u8)(fl & 3u); } } break;
        case 'm': {
            Mission *m = &h->mm; h->month = rdn(&q, 10); h->m_idx = (u16)rdn(&q, 10);
            m->kind = (u8)rdn(&q, 10); m->arg = (u8)rdn(&q, 10); m->done = (u8)(rdn(&q, 10) != 0); m->target = (u16)rdn(&q, 10); m->prog = (u16)rdn(&q, 10); m->reward = (u16)rdn(&q, 10); m->mask[0] = rdn(&q, 16); m->mask[1] = rdn(&q, 16);
            if (m->kind >= MK_N || !m->target || m->reward > 500) memset(m, 0, sizeof(*m)); else if (m->prog > m->target) m->prog = m->target;
            if (h->m_idx > 31) h->m_idx = 31; if (h->month > 60000u) h->month = 0;
        } break;
        case 'x': h->xp = rdn(&q, 10); h->seen_age = (u8)rdn(&q, 10); break;
        case 'n': h->pet_t = rdn(&q, 10); h->asleep = (u8)(rdn(&q, 10) != 0); for (int i = 0; i < ND_N && q < e; i++) { u32 v = rdn(&q, 10); h->need[i] = (u16)(v > 10000u ? 10000u : v); } break;
        case 'b': for (int i = 0; i < DRINK_N && q < e; i++) { u32 v = rdn(&q, 10); h->bought[i] = (u16)(v > 60000u ? 60000u : v); } break;
        case 'u': for (int i = 0; i < DRINK_N && q < e; i++) { u32 v = rdn(&q, 10); h->used[i] = (u16)(v > 60000u ? 60000u : v); } break;
        case 'q': h->xp_day = rdn(&q, 10); for (int i = 0; i < 4 && q < e; i++) h->xp_cnt[i] = (u16)rdn(&q, 10); if (q < e) h->xp_wins = rdn(&q, 10); break;
        default: break;
        }
        p = e; if (*p == '|') p++;
    }
    if (h->earned > 5000000u) h->earned = 5000000u; if (h->xp > 4000000u) h->xp = 4000000u;
    h->skins &= (1u << SKIN_N) - 1u; h->items[1] &= (1u << (ITEM_N - 32)) - 1u; h->cloth[1] &= (1u << (CLOTH_N - 32)) - 1u;
    for (int i = 0; i < SL_N; i++) { int c = h->wear[i] - 1; if (c < 0 || c >= CLOTH_N || cloth_tab[c].slot != i || !cloth_has(h, c)) h->wear[i] = 0; }
    for (int i = 0; i < PLACED_MAX; i++) if (h->pl[i].id && !item_has(h, h->pl[i].id - 1)) h->pl[i].id = 0;      /* nothing stands in a house that the house does not own, and nothing stands there twice */
    for (int i = 0; i < PLACED_MAX; i++) for (int k = 0; k < i; k++) if (h->pl[i].id && h->pl[k].id == h->pl[i].id) h->pl[i].id = 0;
    for (int d = 0; d < DRINK_N; d++) if (h->used[d] > h->bought[d] && drink_tab[d].price) h->used[d] = h->bought[d];
    h->magic = HOME_MAGIC;
    return 1;
}
/* What the table has and what this device has become one house: everything ever earned, bought or given stays;
   of two different arrangements the one that was changed more often wins; Mel is as he was seen last. */
static void home_merge(const Home *c, int fresh) {
    if (c->earned > HM.earned) HM.earned = c->earned;
    HM.skins |= c->skins; HM.ach |= c->ach; HM.big |= c->big;
    for (int i = 0; i < C6_N; i++) if (c->cn[i] > HM.cn[i]) HM.cn[i] = c->cn[i];
    for (int i = 0; i < 2; i++) { HM.items[i] |= c->items[i]; HM.cloth[i] |= c->cloth[i]; }
    if (fresh || c->pl_rev > HM.pl_rev) { memcpy(HM.pl, c->pl, sizeof(HM.pl)); HM.pl_rev = c->pl_rev; }
    if (fresh || c->wear_rev > HM.wear_rev) { memcpy(HM.wear, c->wear, sizeof(HM.wear)); HM.wear_rev = c->wear_rev; }
    if (c->month > HM.month || (c->month == HM.month && c->m_idx > HM.m_idx) || (fresh && c->month)) { HM.month = c->month; HM.m_idx = c->m_idx; HM.mm = c->mm; }
    else if (c->month == HM.month && c->m_idx == HM.m_idx && c->mm.kind == HM.mm.kind && c->mm.target == HM.mm.target) { if (c->mm.prog > HM.mm.prog) HM.mm.prog = c->mm.prog; HM.mm.mask[0] |= c->mm.mask[0]; HM.mm.mask[1] |= c->mm.mask[1]; }
    if (c->xp > HM.xp) HM.xp = c->xp;
    if (c->seen_age > HM.seen_age) HM.seen_age = c->seen_age;
    if (fresh || c->pet_t > HM.pet_t) { HM.pet_t = c->pet_t; HM.asleep = c->asleep; memcpy(HM.need, c->need, sizeof(HM.need)); }
    for (int d = 0; d < DRINK_N; d++) { if (c->bought[d] > HM.bought[d]) HM.bought[d] = c->bought[d]; if (c->used[d] > HM.used[d]) HM.used[d] = c->used[d]; }
    if (c->xp_day > HM.xp_day) { HM.xp_day = c->xp_day; memcpy(HM.xp_cnt, c->xp_cnt, sizeof(HM.xp_cnt)); HM.xp_wins = c->xp_wins; }
    else if (c->xp_day == HM.xp_day) { for (int i = 0; i < 4; i++) if (c->xp_cnt[i] > HM.xp_cnt[i]) HM.xp_cnt[i] = c->xp_cnt[i]; if (c->xp_wins > HM.xp_wins) HM.xp_wins = c->xp_wins; }
    PF.skins |= HM.skins & ((1u << SKIN_N) - 1u);
}

/* ---------------- whose house this is ---------------- */
typedef struct { u32 magic; Home h; } HomeStash;
static void month_refresh(void); static void ach6_check(void); static void pet_reset_view(void);
static void home_switch(u32 uid) {                   /* another player (or nobody) is signed in on this device now */
    static HomeStash st;
    if (HM.magic == HOME_MAGIC && HM.uid && HM.uid != uid && HM.dirty) { st.magic = HOME_MAGIC; st.h = HM; plat_store("hx", &st, (int)sizeof(st)); }      /* what could not be sent waits for its owner */
    memset(&HS, 0, sizeof(HS)); pet_reset_view();
    if (!uid) { memset(&HM, 0, sizeof(HM)); plat_store("home", "", 0); return; }
    if (HM.magic == HOME_MAGIC && HM.uid == uid) return;
    if (plat_fetch("hx", &st, (int)sizeof(st)) == (int)sizeof(st) && st.magic == HOME_MAGIC && st.h.magic == HOME_MAGIC && st.h.uid == uid) { HM = st.h; HM.dirty = 1; plat_store("hx", "", 0); }
    else home_fresh(uid);
    home_store();
}
static void home_init(void) {
    static Home h; int n = plat_fetch("home", &h, (int)sizeof(h));
    memset(&HS, 0, sizeof(HS));
    if (CFG.acc && SV.uid) { if (n == (int)sizeof(h) && h.magic == HOME_MAGIC && h.uid == SV.uid) HM = h; else home_fresh(SV.uid); }
    else memset(&HM, 0, sizeof(HM));
    if (home_on()) { PF.skins |= HM.skins & ((1u << SKIN_N) - 1u); if (HM.dirty) HS.t = 2.0f; }
}

/* ---------------- keeping the house in the account ---------------- */
static int home_look(void) { int a = pet_age(); return (HM.big ? 1 : 0) | ((a > 199 ? 199 : a) << 1); }      /* what the map of the city shows of this house */
static int home_sync_on(void) { return sync_on() && NET.proto >= 6 && home_on(); }
static void home_send(void) {
    static char body[3600], data[3100]; char u[16], base[16], look[12];
    HM.skins = PF.skins;
    home_encode(&HM, data, 3000);
    snprintf(u, sizeof(u), "%u", (unsigned)SV.uid); snprintf(base, sizeof(base), "%u", (unsigned)HM.rev); snprintf(look, sizeof(look), "%d", home_look());
    snprintf(body, sizeof(body), "save6\t%s\t%s\t%s\t%s\t%s\t%08x", u, CFG.token, base, look, data, (unsigned)net_sig("save6", u, base, look, data));
    HS.sent_gen = HS.gen; HS.save_uid = SV.uid; net_post(RQ_SAVE6, body);
}
static void home_cloud(const char *data, u32 rev) {  /* the house has come from the table */
    static Home c; static char mine[3100]; int fresh = !HS.loaded && !HM.dirty;
    if (data && data[0] && home_decode(data, &c)) home_merge(&c, fresh);
    else if (rev > HM.rev && HM.rev) { u32 uid = HM.uid, plot = HM.plot, guests = HM.guests; home_fresh(uid); HM.plot = plot; HM.guests = guests; }      /* the owner of the game has emptied this house */
    HM.rev = rev; HS.loaded = 1;
    home_starter(&HM); month_refresh(); ach6_check();
    HM.skins = PF.skins; home_encode(&HM, mine, 3000);
    if (!data || strcmp(mine, data)) { HM.dirty = 1; HS.gen++; HS.t = 1.0f; } else HM.dirty = 0;
    home_store();
}
static void home_flush(void) { if (home_sync_on() && HS.loaded && HM.dirty && !NET.busy[RQ_SAVE6]) home_send(); }      /* before the player signs out */
static void city_http(int kind, int ok, int status, char *ln, char *p);
static void home_http(int kind, int ok, int status, char *ln, char *p) {
    switch (kind) {
    case RQ_LOAD6:
        if (!home_on()) break;
        if (ok) { u32 rev = (u32)strtoul(nfld(&ln), NULL, 10), plot = (u32)strtoul(nfld(&ln), NULL, 10), guests = (u32)strtoul(nfld(&ln), NULL, 10); HM.plot = plot; HM.guests = guests; home_cloud(nfld(&ln), rev); }
        else if (status == 200 && ln && !strcmp(ln, "auth")) acc_kicked();
        break;
    case RQ_SAVE6:
        if (!home_on() || HS.save_uid != SV.uid) break;
        if (ok) { HM.rev = (u32)strtoul(nfld(&ln), NULL, 10); if (HS.sent_gen == HS.gen) HM.dirty = 0; home_store(); }
        else if (status == 200 && ln) {
            const char *why = nfld(&ln);
            if (!strcmp(why, "conflict")) { u32 rev = (u32)strtoul(nfld(&ln), NULL, 10); HS.loaded = 1; home_cloud(nfld(&ln), rev); HM.dirty = 1; HS.t = 0.5f; }      /* another device was first: both become one, and that goes back */
            else if (!strcmp(why, "auth")) acc_kicked();
            else HS.t = 60.0f;
        }
        break;
    default: city_http(kind, ok, status, ln, p); break;
    }
}

/* ---------------- the calendar ---------------- */
static void civil(u32 days, int *y, int *m, int *d) {      /* days since 1970-01-01 -> the date */
    int z = (int)days + 719468, era = z / 146097, doe = z - era * 146097, yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365, yy = yoe + era * 400;
    int doy = doe - (365 * yoe + yoe / 4 - yoe / 100), mp = (5 * doy + 2) / 153;
    *d = doy - (153 * mp + 2) / 5 + 1; *m = mp < 10 ? mp + 3 : mp - 9; *y = yy + (*m <= 2);
}
static int month_days(u32 id) { int y = (int)(id / 12u), m = (int)(id % 12u) + 1; static const u8 dm[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }; return m == 2 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0) ? 29 : dm[m - 1]; }
static u32 month_of(u32 t, int *dom) { int y, m, d; civil(day_of(t), &y, &m, &d); if (dom) *dom = d; return (u32)(y * 12 + m - 1); }
static const char *month_name(u32 id) { static const char *const nm[12] = { "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь" }; return nm[id % 12u]; }
static u32 month_left(u32 t) { int dom; u32 id = month_of(t, &dom); return (u32)(month_days(id) - dom) * 86400u + day_left(t); }

/* ---------------- the monthly missions: one for every day of the month, done in order ---------------- */
#define MONTH_BASE (2026u * 12u + 10u)               /* November 2026: the first month there was */
static const u8 month_prize_day[4] = { 3, 8, 15, 22 };      /* these missions and the last one give a thing for the house; the others give чекушки */
static int month_prize(u32 month, int idx) {         /* the thing mission number idx (from 0) gives, or -1 */
    int n = month_days(month), j = -1; u32 k = month >= MONTH_BASE ? month - MONTH_BASE : 0;
    for (int i = 0; i < 4; i++) if (idx + 1 == month_prize_day[i]) j = i;
    if (idx + 1 == n) j = 4;
    return j < 0 ? -1 : ITEM_START + (int)((k * 5u + (u32)j) % (u32)(ITEM_N - ITEM_START));
}
static int city_others(void); static int city_known(void);
/* Every mission of this list can be done at any hour and all of them on one day: none waits for a new day, for other players' levels
   or for anything else the player cannot bring about himself. (Visits need neighbours: see below.) */
static void month_make(void) {                       /* open mission number HM.m_idx of the month HM.month */
    static const u8 plan[31][2] = {
        { MK_FEED, 2 }, { MK_WINS, 3 }, { MK_PLAY, 5 }, { MK_STARS, 8 }, { MK_CUTS, 30 }, { MK_PLACE, 3 }, { MK_PERFECT, 2 }, { MK_VISIT, 2 },
        { MK_FIRST, 2 }, { MK_FEED, 5 }, { MK_TIME, 8 }, { MK_PERFECT, 3 }, { MK_WINS, 6 }, { MK_SLEEP, 1 }, { MK_STARS, 15 }, { MK_POPS, 12 },
        { MK_VISIT, 3 }, { MK_PLACE, 4 }, { MK_PLAY, 10 }, { MK_BOX, 3 }, { MK_FIRST, 4 }, { MK_WINS, 8 }, { MK_FEED, 8 }, { MK_PERFECT, 5 },
        { MK_PLAY, 8 }, { MK_CUTS, 60 }, { MK_SLEEP, 1 }, { MK_STARS, 20 }, { MK_WINS, 10 }, { MK_FIRST, 5 }, { MK_TIME, 15 } };
    int idx = HM.m_idx, n = month_days(HM.month), kind, t, arg = 0, net = (plat_caps() & 4) != 0; u32 h = mhash(HM.month, 100u + (u32)idx);
    memset(&HM.mm, 0, sizeof(HM.mm));
    if (idx >= n) return;
    kind = plan[idx % 31][0]; t = plan[idx % 31][1];
    if (idx == n - 1) { if (idx > 0 && plan[(idx - 1) % 31][0] == MK_STARS) { kind = MK_WINS; t = 12; } else { kind = MK_STARS; t = 25; } }      /* the last one of the month */
    else if (kind != MK_SLEEP && kind != MK_BOX && kind != MK_VISIT) t += (int)(h % (u32)(t / 4 + 1));      /* a little different every month */
    if (kind == MK_POPS && boxes_open() < 2) { kind = MK_CUTS; t = 30; }
    if (kind == MK_VISIT) {                                                      /* as many houses as there are to visit; none (or no network): play with Mel instead */
        int others = city_known() ? city_others() : (int)HM.plot - 1;            /* (before the map was looked at: the plots that were given out before this one) */
        if (!net || NET.st != NS_ON || NET.proto < 6 || others < 1) { kind = MK_PLAY; t = 6; } else if (t > others) t = others;
    }
    if (kind == MK_BOX) arg = (int)(h % (u32)boxes_open());
    if (kind == MK_TIME) t *= 60;
    mis_set(&HM.mm, kind, arg, t, month_prize(HM.month, idx) >= 0 ? 0 : (idx % 7 == 6 ? 25 : 6 + 2 * (int)(h % 5u)));
}
static Mission *month_cur(void) { return home_on() && HM.mm.kind && !HM.mm.done ? &HM.mm : NULL; }
static int month_all_done(void) { return home_on() && HM.month && HM.m_idx >= month_days(HM.month); }
static int tasks_new6;                               /* a new month has begun and the player has not looked yet */
static void month_refresh(void) {
    if (!home_on()) return;
    u32 t = now_s(); if (!t || !clock_ok()) return;
    u32 id = month_of(t, NULL);
    if (id > HM.month) { HM.month = id; HM.m_idx = 0; month_make(); tasks_new6 = 1; home_dirty(); }      /* never back to an older month */
    else if (!HM.mm.kind && HM.m_idx < month_days(HM.month)) { month_make(); home_dirty(); }
}
static void item_got(int item);
static void month_done(void);
static void month_visit_fix(void) {                 /* the map of the city has come: a mission must not ask for more visits than there are houses */
    Mission *m = month_cur(); int others = city_others();
    if (!m || m->kind != MK_VISIT) return;
    if (others < 1) { mis_set(m, MK_PLAY, 0, 6, m->reward); home_dirty(); }
    else if (m->target > others) { m->target = (u16)others; home_dirty(); if (m->prog >= m->target) { m->done = 1; m->prog = m->target; month_done(); } }
}
static void month_done(void) {                       /* the open mission is done: its prize, then the next one */
    int idx = HM.m_idx, item = month_prize(HM.month, idx), c = HM.mm.reward; char b[120];
    if (item >= 0 && item_has(&HM, item)) { item = -1; c = 60; }                  /* (the catalogue has come round: this thing is there already) */
    if (item >= 0) { HM.items[item >> 5] |= 1u << (item & 31); snprintf(b, sizeof(b), "Задание месяца: в дом привезли «%s»!", item_tab[item].name); rw_push(b, 0); item_got(item); }
    else { HM.earned += (u32)c; snprintf(b, sizeof(b), "Задание месяца %d выполнено!", idx + 1); rw_push(b, c); }
    sfx_p(S_WIN, 0.6f, 640, 1.34f);
    HM.m_idx = (u16)(idx + 1);
    if (HM.m_idx >= month_days(HM.month)) { memset(&HM.mm, 0, sizeof(HM.mm)); HM.cn[C6_MONTHS]++; rw_push("Все задания месяца выполнены!", 0); }
    else month_make();
    home_dirty(); ach6_check();
}

/* ---------------- the achievements of V0.6 ---------------- */
#define ACH6_N 10
enum { A6_HOUSE = 200, A6_BIG, A6_PLACED, A6_AGE, A6_CLOTH };
static const AchDef ach6_tab[ACH6_N] = {
    { "Новосёл",          "Получи дом в Городе Мелстроев: для этого нужен аккаунт",       20, A6_HOUSE, 1 },
    { "Особняк",          "Перестрой свой дом в большой",                                 50, A6_BIG, 1 },
    { "Дизайнер",         "Расставь в доме 10 предметов",                                 30, A6_PLACED, 10 },
    { "В гости",          "Побывай в домах 5 других игроков",                             25, 100 + C6_VISITS, 5 },
    { "Нянька",           "Напои маленького Мела 50 раз",                                 40, 100 + C6_FEEDS, 50 },
    { "Попугай",          "Научи Мела говорить 5 слов",                                   40, 100 + C6_WORDS, 5 },
    { "Первоклассник",    "Вырасти Мела до 7 лет",                                        50, A6_AGE, 7 },
    { "Совершеннолетний", "Вырасти Мела до 18 лет",                                       150, A6_AGE, 18 },
    { "Стиляга",          "Купи 10 вещей в магазине одежды",                              40, A6_CLOTH, 10 },
    { "Месяц закрыт",     "Выполни все задания одного месяца",                            100, 100 + C6_MONTHS, 1 },
};
static u32 ach6_value(int src) {
    if (!home_on()) return 0;
    if (src >= 100 && src < 100 + C6_N) return HM.cn[src - 100];
    switch (src) { case A6_HOUSE: return 1; case A6_BIG: return HM.big; case A6_PLACED: return (u32)items_placed(&HM); case A6_AGE: return (u32)pet_age(); case A6_CLOTH: return (u32)cloth_owned(&HM); }
    return 0;
}
static int ach6_done(int i) { return home_on() && ((HM.ach >> i) & 1u); }
static int ach6_n(void) { return ACH6_N; }
static const AchDef *ach6_get(int i) { return &ach6_tab[i]; }
static u32 ach6_now(int i) { return ach6_value(ach6_tab[i].src); }
static void ach6_check(void) {
    if (!home_on()) return;
    for (int i = 0; i < ACH6_N; i++) if (!((HM.ach >> i) & 1u) && ach6_value(ach6_tab[i].src) >= ach6_tab[i].goal) {
        char b[120]; HM.ach |= 1u << i; HM.earned += (u32)ach6_tab[i].reward; snprintf(b, sizeof(b), "Достижение: «%s»", ach6_tab[i].name); rw_push(b, ach6_tab[i].reward); home_dirty();
    }
}

/* ---------------- Mel's needs run with the clock ---------------- */
static void pet_minutes(u32 mins, int away) {        /* away: the game was closed meanwhile (nobody could look after him: he is not left to starve) */
    float nd[ND_N], lo[ND_N] = { 1500, 1500, 3000, 1500 }, old[ND_N];
    for (int k = 0; k < ND_N; k++) old[k] = nd[k] = (float)HM.need[k];
    if (mins > 20160u) mins = 20160u;                                              /* (two weeks are as bad as it gets) */
    for (u32 i = 0; i < mins; i++) {
        nd[ND_THIRST] -= 27.8f;                                                    /* a full glass lasts six hours */
        if (HM.asleep) { nd[ND_ENERGY] += 111.0f; if (nd[ND_ENERGY] >= 10000.0f) HM.asleep = 0; }      /* an hour and a half of sleep and he is rested */
        else { nd[ND_ENERGY] -= 11.9f; nd[ND_JOY] -= 16.7f; }                      /* awake for fourteen hours, merry for ten */
        for (int k = 0; k < ND_N; k++) nd[k] = clampf(nd[k], 0, 10000);
        if (nd[ND_THIRST] <= 0 || nd[ND_ENERGY] <= 0 || nd[ND_JOY] <= 0) nd[ND_HEALTH] -= 10.0f;
        else if (nd[ND_THIRST] > 5000 && nd[ND_ENERGY] > 5000 && nd[ND_JOY] > 5000) nd[ND_HEALTH] += 10.0f;
    }
    for (int k = 0; k < ND_N; k++) { float v = clampf(nd[k], 0, 10000); if (away && v < lo[k]) v = minf(old[k], lo[k]); HM.need[k] = (u16)v; }
}
static void pet_clock(void) {
    u32 now = now_s(); if (!home_on() || !now) return;
    if (!HM.pet_t || now < HM.pet_t) { HM.pet_t = now; return; }
    u32 mins = (now - HM.pet_t) / 60u; if (!mins) return;
    pet_minutes(mins, mins > 10u); HM.pet_t += mins * 60u; home_store();
    if (mins > 10u) home_dirty();
}
static void pet_add(int k, int pts) { int v = (int)HM.need[k] + pts * 100; HM.need[k] = (u16)(v < 0 ? 0 : (v > 10000 ? 10000 : v)); }
static int pet_pct(int k) { return (HM.need[k] + 50) / 100; }
/* experience: what was done for him, with a limit a day for the things that can be repeated without end */
enum { XD_DRINK, XD_PLAY, XD_TALK, XD_WORD, XD_WIN };
static void pet_xp(int pts, int daily, int limit) {
    if (!home_on() || pts <= 0) return;
    u32 day = now_s() ? day_of(now_s()) : HM.xp_day;
    if (day > HM.xp_day) { HM.xp_day = day; memset(HM.xp_cnt, 0, sizeof(HM.xp_cnt)); HM.xp_wins = 0; }
    if (daily == XD_WIN) { if (HM.xp_wins >= (u32)limit) return; HM.xp_wins++; }
    else if (daily >= 0) { if (HM.xp_cnt[daily] >= limit) return; HM.xp_cnt[daily]++; }
    HM.xp += (u32)pts; ach6_check(); home_dirty();
}
static void home_level_won(void) { if (home_on()) { pet_xp(4, XD_WIN, 12); pet_add(ND_JOY, 3); } }      /* the player's own wins make Mel grow too: the first twelve of a day */

/* something in the house waits for the player: a new month of missions, a Mel who needs him, a birthday not yet seen */
static int home_alert(void) {
    if (!home_on()) return 0;
    if (tasks_new6 || pet_age() > HM.seen_age) return 1;
    if (!HM.asleep) for (int k = 0; k < ND_N; k++) if (HM.need[k] < 2500) return 1;
    return 0;
}
static float home_tick;
static void home_update(float dt) {
    if (!home_on()) return;
    home_tick += dt;
    if (home_tick >= 1.0f) {
        u32 mask = (1u << SKIN_N) - 1u; home_tick = 0; pet_clock(); month_refresh();
        if ((PF.skins | HM.skins) != PF.skins) PF.skins |= HM.skins & mask;             /* a skin is never lost: a game of V0.5 on another device saves only the first eleven, the house keeps them all */
        if (HM.skins != (PF.skins & mask)) { HM.skins = PF.skins & mask; home_dirty(); }
    }
    if (!home_sync_on()) return;
    if (!HS.loaded) { HS.retry -= dt; if (HS.retry <= 0 && !NET.busy[RQ_LOAD6]) { char q[120]; HS.retry = 20.0f; snprintf(q, sizeof(q), "a=load6&u=%u&t=%s", (unsigned)SV.uid, CFG.token); net_get(RQ_LOAD6, q); } return; }
    if (HM.dirty && !NET.busy[RQ_SAVE6]) { HS.t -= dt; if (HS.t <= 0) { HS.t = 6.0f; home_send(); } }
}
