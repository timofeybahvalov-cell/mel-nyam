/* ============================================================================
   «Мел-Ням» — WebAssembly platform layer. The module is freestanding (wasi-libc
   only for malloc/math/string); the HTML shell (web/shell.html) provides the
   canvas, WebAudio, input and storage and hands the asset pack over.
   ============================================================================ */
#include "engine.h"
#include <stdlib.h>
#include <string.h>

#define EXPORT(n) __attribute__((export_name(#n)))
#define IMPORT(n) __attribute__((import_module("env"), import_name(#n)))

IMPORT(js_save) void js_save(const void *p, int n);
IMPORT(js_load) int js_load(void *p, int max);
IMPORT(js_fullscreen) void js_fullscreen(void);
IMPORT(js_caps) int js_caps(void);
IMPORT(js_log) void js_log(const char *p, int n);
IMPORT(js_store) void js_store(const char *key, int klen, const void *p, int n);
IMPORT(js_fetch) int js_fetch(const char *key, int klen, void *p, int max);
IMPORT(js_http) void js_http(int id, const char *url, int ulen, const char *body, int blen);      /* blen < 0: GET */
IMPORT(js_random) u32 js_random(void);
IMPORT(js_snd) void js_snd(int op, int idx, int id, float a, float b, float c);                    /* the page plays the sounds with the browser's own audio nodes */
IMPORT(js_ctl) int js_ctl(int what, const char *s, int slen, int a, int b);

static u32 *g_fb;
static i16 g_audio[4096 * 2];

void plat_audio_lock(void) {}
void plat_audio_unlock(void) {}
void plat_save(const void *d, int n) { js_save(d, n); }
int plat_load(void *d, int max) { return js_load(d, max); }
void plat_quit(void) {}
void plat_fullscreen(void) { js_fullscreen(); }
int plat_caps(void) { return js_caps(); }
void plat_log(const char *s) { js_log(s, (int)strlen(s)); }
void plat_store(const char *key, const void *d, int n) { js_store(key, (int)strlen(key), d, n); }
int plat_fetch(const char *key, void *d, int max) { return js_fetch(key, (int)strlen(key), d, max); }
void plat_http(int id, const char *url, const char *body, int body_len) { js_http(id, url, (int)strlen(url), body, body ? body_len : -1); }
u32 plat_random(void) { return js_random(); }
void plat_snd(int op, int idx, int id, float a, float b, float c) { js_snd(op, idx, id, a, b, c); }
int plat_ctl(int what, const char *s, int a, int b) { return js_ctl(what, s ? s : "", s ? (int)strlen(s) : 0, a, b); }

EXPORT(web_alloc) void *web_alloc(int n) { return malloc((size_t)n); }
EXPORT(web_init) void web_init(const u8 *pack, int size, int rate) { app_init(pack, size, rate); }
EXPORT(web_resize) u32 *web_resize(int w, int h) {
    free(g_fb); g_fb = (u32 *)calloc((size_t)w * h + 16, 4);
    app_resize(g_fb, w, h);
    return g_fb;
}
EXPORT(web_frame) void web_frame(float dt) { app_frame(dt); }
EXPORT(web_pointer) void web_pointer(int type, float x, float y) { app_pointer(type, x, y); }
EXPORT(web_key) void web_key(int key, int down) { app_key(key, down); }
EXPORT(web_audio) i16 *web_audio(int frames) { if (frames > 4096) frames = 4096; audio_mix(g_audio, frames); return g_audio; }
EXPORT(web_debug) int web_debug(int cmd, int arg) { return app_debug(cmd, arg); }
/* audio played by the page: call web_audio_ext(1) before web_init; the page then fetches each sound once (16-bit mono) */
EXPORT(web_audio_ext) void web_audio_ext(int on) { audio_external(on); }
EXPORT(web_snd_pcm) const i16 *web_snd_pcm(int i) { const Sound *s = snd_by_index(i); return s ? s->pcm : NULL; }
EXPORT(web_snd_len) int web_snd_len(int i) { const Sound *s = snd_by_index(i); return s ? s->n : 0; }
EXPORT(web_snd_rate) int web_snd_rate(int i) { const Sound *s = snd_by_index(i); return s ? s->rate : 0; }
EXPORT(web_free) void web_free(void *p) { free(p); }
EXPORT(web_char) void web_char(u32 cp) { app_char(cp); }
EXPORT(web_http) void web_http(int id, int status, const char *data, int size) { app_http(id, status, data, size); }
EXPORT(web_text) void web_text(int kind, const char *s) { app_text(kind, s); }
