/* ============================================================================
   «Мел-Ням» — WebAssembly platform layer. The module is freestanding (wasi-libc
   only for malloc/math/string); the HTML shell (web/shell.html) provides the
   canvas, WebAudio, input and storage and hands the asset pack over.
   ============================================================================ */
#include "engine.h"
#include <stdlib.h>
#include <string.h>

#define EXPORT(n) __attribute__((export_name(#n)))
#define IMPORT(n) __attribute__((import_module("env"), import_name(#n)))

IMPORT(js_save) void js_save(const void *p, int n);
IMPORT(js_load) int js_load(void *p, int max);
IMPORT(js_fullscreen) void js_fullscreen(void);
IMPORT(js_caps) int js_caps(void);
IMPORT(js_log) void js_log(const char *p, int n);

static u32 *g_fb;
static i16 g_audio[4096 * 2];

void plat_audio_lock(void) {}
void plat_audio_unlock(void) {}
void plat_save(const void *d, int n) { js_save(d, n); }
int plat_load(void *d, int max) { return js_load(d, max); }
void plat_quit(void) {}
void plat_fullscreen(void) { js_fullscreen(); }
int plat_caps(void) { return js_caps(); }
void plat_log(const char *s) { js_log(s, (int)strlen(s)); }

EXPORT(web_alloc) void *web_alloc(int n) { return malloc((size_t)n); }
EXPORT(web_init) void web_init(const u8 *pack, int size, int rate) { app_init(pack, size, rate); }
EXPORT(web_resize) u32 *web_resize(int w, int h) {
    free(g_fb); g_fb = (u32 *)calloc((size_t)w * h + 16, 4);
    app_resize(g_fb, w, h);
    return g_fb;
}
EXPORT(web_frame) void web_frame(float dt) { app_frame(dt); }
EXPORT(web_pointer) void web_pointer(int type, float x, float y) { app_pointer(type, x, y); }
EXPORT(web_key) void web_key(int key, int down) { app_key(key, down); }
EXPORT(web_audio) i16 *web_audio(int frames) { if (frames > 4096) frames = 4096; audio_mix(g_audio, frames); return g_audio; }
EXPORT(web_debug) int web_debug(int cmd, int arg) { return app_debug(cmd, arg); }
