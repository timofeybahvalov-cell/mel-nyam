/* Game simulation (physics + rules) of «Мел-Ням». No rendering here:
   the same code drives the game, the level generator, the replays and the editor.
   The simulation is bit-exact on every platform (integer ticks, own sin/cos, no libm in the physics),
   so a recorded list of actions always replays to the same result. */
#ifndef MN_SIM_H
#define MN_SIM_H
#include "engine.h"

#define SIM_VERSION 2          /* stored with every replay: bump when the physics change */

enum { O_END = 0, O_CANDY, O_PIN, O_AUTOPIN, O_STAR, O_BUBBLE, O_BLOWER, O_SPIKES, O_MEL,
       O_BOUNCER, O_PORTAL, O_GRAV, O_LASER, O_RAIL, O_TYPES };
/* O_CANDY   x,y
   O_PIN     x,y  a = rope length (0: exactly the distance to the bottle), b = thief speed px/s (0: none), c = thief start delay s
   O_AUTOPIN x,y  a = catch radius, b = thief speed (starts when the rope attaches)
   O_STAR    x,y
   O_BUBBLE  x,y
   O_BLOWER  x,y  a = direction in degrees (0 = blows right, 90 = down, 180 = left, 270 = up)
   O_SPIKES  x,y  a,b = second end point
   O_MEL     x,y  (mouth position), a = 1: he hangs upside down (only the picture; the physics ignore it)
   O_BOUNCER x,y  a = tilt in degrees (0 = flat), b = half length (0: 60)
   O_PORTAL  x,y  a = exit direction in degrees (-1: keep the direction), b = pair number (0..2)
   O_GRAV    x,y  gravity switch button
   O_LASER   x,y  a,b = second end point, c = seconds on, d = seconds off (0: always on), e = phase shift s
   O_RAIL    x,y  a,b = other end of the rail, c = start position 0..1, d = rope length (0: distance; d < 0: a sticky pin with catch radius -d), e = thief speed */
typedef struct { int type; float x, y, a, b, c, d, e; } LObj;

enum { ACT_END = 0, ACT_CUT, ACT_POP, ACT_BLOW, ACT_GRAV, ACT_SLIDE };
/* arg:  ACT_CUT   pin | (link + 1) << 4     (link + 1 == 0: the middle of the rope)
         ACT_BLOW  blower #     ACT_GRAV  button #
         ACT_SLIDE pin | q << 4              (q = 0..255: target position on the rail) */
typedef struct { float t; int act, arg; } Step;

typedef struct {
    const char *name, *hint;
    int box;
    const LObj *objs;
    const Step *demo;          /* a known full-star solution */
} LevelDef;

#define SIM_HZ 120
#define SIM_DT (1.0f / 120.0f)
#define MAX_ROPES 10
#define ROPE_NODES 52
#define MAX_PINS 10
#define MAX_STARS 10
#define MAX_BUBBLES 6
#define MAX_BLOWERS 6
#define MAX_SPIKES 10
#define MAX_BOUNCERS 6
#define MAX_PORTALS 6
#define MAX_GRAVS 3
#define MAX_LASERS 6

#define CANDY_R 24.0f
#define BUBBLE_VIS_R 46.0f
#define MOUTH_R 46.0f
#define MOUTH_NEAR 175.0f
#define PORTAL_R 30.0f

typedef struct { float x, y, px, py; } Pt;
typedef struct { int active, cut, pin, n, cut_at; float seg, len, fade; Pt p[ROPE_NODES];
                 int thief; float thief_s, thief_v, thief_t0, tx, ty, tvy; } Rope;      /* thief: 0 none, 1 on the rope, 2 falling */
typedef struct { float x, y, r; int autopin, used, rope; float pulse;
                 int rail; float x0, y0, x1, y1, u, ut, uv, thief_v, thief_d; } Pin;
typedef struct { float x, y; int got; float t; } Star;
typedef struct { float x, y; int used; } Bubble;
typedef struct { float x, y, dx, dy, ang, squeeze; } Blower;
typedef struct { float x0, y0, x1, y1; } Spikes;
typedef struct { float x, y, dx, dy, nx, ny, hl, ang, pulse; } Bouncer;
typedef struct { float x, y, dx, dy, ang; int pair, link, lock, keep; float pulse; } Portal;
typedef struct { float x, y, pulse; } GravBtn;
typedef struct { float x0, y0, x1, y1; int on_t, off_t, ph_t; } Laser;

enum { EV_CUT = 1, EV_STAR = 2, EV_BUBBLE_IN = 4, EV_BUBBLE_POP = 8, EV_BLOW = 16, EV_ATTACH = 32,
       EV_EAT = 64, EV_LOST = 128, EV_BREAK = 256, EV_BOUNCE = 512, EV_PORTAL = 1024, EV_GRAV = 2048,
       EV_STOLEN = 4096, EV_THIEF_FALL = 8192, EV_BURN = 16384 };
enum { ST_PLAY = 0, ST_EATEN, ST_LOST, ST_BROKEN, ST_STOLEN };

typedef struct {
    Pt c; float rot, rotv; int in_bubble; float bubble_t;
    Rope rope[MAX_ROPES];
    Pin pin[MAX_PINS]; int npins;
    Star star[MAX_STARS]; int nstars;
    Bubble bubble[MAX_BUBBLES]; int nbubbles;
    Blower blower[MAX_BLOWERS]; int nblowers;
    Spikes spikes[MAX_SPIKES]; int nspikes;
    Bouncer bouncer[MAX_BOUNCERS]; int nbouncers;
    Portal portal[MAX_PORTALS]; int nportals;
    GravBtn grav[MAX_GRAVS]; int ngravs;
    Laser laser[MAX_LASERS]; int nlasers;
    float mx, my; int has_mel;
    int state; float time, state_t; int stars; int tick;
    int gdir;                                   /* +1 normal gravity, -1 upside down */
    u32 events; float ev_x, ev_y; int ev_star, ev_blower, ev_bouncer, ev_portal, ev_portal2, ev_grav; float cut_x, cut_y;
    float pop_x, pop_y, thief_x, thief_y;
    int ncut; struct { int pin, link; } cutlog[MAX_ROPES];      /* filled by sim_cut(): what the swipe has cut */
    float mouth_dist, mouth_min;                /* mouth_min: closest approach to Mel's mouth during this attempt */
} Sim;

void sim_load(Sim *s, const LObj *objs);
void sim_step(Sim *s);                                           /* advance one tick (SIM_DT) */
int  sim_cut(Sim *s, float x0, float y0, float x1, float y1);    /* swipe segment; returns ropes cut (see cutlog) */
int  sim_pick(const Sim *s, float x, float y, int *act, int *arg);   /* what would a tap at x,y do? (bubble / blower / gravity button) */
int  sim_act(Sim *s, int act, int arg);                          /* apply one action; returns 1 if it had an effect */
int  sim_do(Sim *s, const Step *st);                             /* run one scripted action */
int  sim_ropes_left(const Sim *s);
int  sim_laser_on(const Sim *s, int i);
float sim_laser_wait(const Sim *s, int i);                       /* seconds until it switches (on->off or off->on) */
int  sim_thief_pos(const Sim *s, int rope, float *x, float *y);  /* 1 if this rope carries a thief */
int  sim_rail_pick(const Sim *s, float x, float y);              /* rail pin under the pointer or -1 */
int  sim_rail_q(const Sim *s, int pin, float x, float y);        /* pointer -> target position 0..255 on that rail */
void sim_sincos(float deg, float *sn, float *cs);
int  sim_max_stars(const LObj *objs);
extern int sim_skip_visual;      /* tools only: do not simulate the rope nodes (they never influence the bottle) */

#endif
