/* ============================================================================
   «МЕЛ-НЯМ» — the settings screen: volumes, switches, Mel's reactions one by one.
   Included by game.c (one translation unit), after g_online.inc and g_tas.inc.
   ============================================================================ */
typedef struct { const char *name, *desc; int clip, voice, fb; const char *line; } Emo;
static const Emo emo_tab[EM_N] = {
    [EM_HELLO]  = { "Приветствие в меню",   "«Hello! I'm Mellstroy!» при запуске игры",   CL_SMILE,  V_HELLO,   -1,       "Hello! I'm Mellstroy!" },
    [EM_GREET]  = { "Привет чату",          "на первом уровне после запуска",             CL_SMILE,  V_HI,      -1,       "Ребята, всем привет! Это я, блогер Меллстрой!" },
    [EM_GIVE]   = { "«Дай его!»",           "чекушка уже рядом со ртом",                  CL_AM,     V_GIVE,    V_AM1,    "Дай его!" },
    [EM_HURRY]  = { "«Быстрее! Быстрее!»",  "если долго думать над уровнем",              CL_FASTER, V_FASTER,  -1,       "Быстрее! Быстрее!!!" },
    [EM_BORED]  = { "Скучает",              "зевает, пока ты думаешь",                    CL_BORED,  -1,        -1,       NULL },
    [EM_STARS]  = { "«У-у-у-у!»",           "собраны все звёзды уровня",                  CL_OMG,    V_UUU,     -1,       "У-у-у-у!" },
    [EM_WOW]    = { "«О май гад!»",         "идеально с первой попытки",                  CL_LAUGH,  V_OMG,     -1,       "О май гад!" },
    [EM_BRAVO]  = { "«Браво, босс!»",       "уровень пройден на все звёзды",              CL_LAUGH,  V_BRAVO,   -1,       "Браво, босс!" },
    [EM_BEST]   = { "«Кто лучший?»",        "победа после того, как он торопил",          CL_BEST,   V_BEST,    V_LAUGH,  "Кто лучший? Ахаха!" },
    [EM_SOSO]   = { "«Ещё посидим!»",       "победа, но звёзд не хватает",                CL_SMILE,  V_POSIDIM, -1,       "Не, ещё посидим!" },
    [EM_SORRY]  = { "«Обидно, да...»",      "чекушка улетела с экрана",                   CL_SAD,    V_OBIDNO,  -1,       "Обидно, да..." },
    [EM_STOP]   = { "«Стоп-стоп-стоп!»",    "чекушку разбили или украли",                 CL_SAD,    V_STOP,    -1,       "Стоп-стоп-стоп!" },
    [EM_SCREAM] = { "Крик «А-А-А-А!»",      "чекушки бьются одна за другой",              CL_ANGRY,  V_SCREAM,  -1,       "А-А-А-А!" },
    [EM_RED]    = { "Краснеет от злости",   "«Я уже красный!» после четырёх разбитых",    CL_ANGRY,  V_RED,     V_SCREAM, "Я уже красный! Культурно уже не получится!" },
    [EM_RAGE]   = { "Ярость",               "вскакивает и орёт после шести неудач",       CL_RAGE,   V_RAGE,    V_SCREAM, "А-А-А-А! Эх ты, #@$%&!!!" },
    [EM_LUDO]   = { "Лудо-приключение",     "три неудачи подряд",                         CL_SMILE,  V_LUDO,    V_LAUGH,  "Начинаем наше лудо-приключение! Да-да, нет-нет, да будет свет..." },
    [EM_POKE]   = { "Тычок в Мела",         "нажатие на Мела в главном меню",             CL_LAUGH,  V_LAUGH,   -1,       "Ха-ха-ха!" },
};
#define EM_ALL ((1u << EM_N) - 1u)
static struct { float scroll, drag_y0, scroll0; int drag; } STG;
static void settings_enter(int a) { (void)a; STG.scroll = 0; STG.drag = 0; mel_set(CL_IDLE, 1); M.dy = 0; M.red = M.red_to = 0; M.say_t = 0; }
static void emo_preview(int e) {                     /* Mel shows the reaction in his little window, even when it is switched off */
    const Emo *m = &emo_tab[e];
    M.say_t = 0; M.voice_t = 0;
    if (m->voice >= 0) say2(m->voice, m->fb, m->line);
    if (M.say_t > 0) M.say_size = 21.0f;             /* a smaller bubble: there is little room next to his window */
    mel_set(m->clip, 1); M.react = maxf(2.2f, M.voice_t + 0.4f);
    M.red = M.red_to = (e == EM_RED) ? 1.0f : 0.0f;
}
static void scr_settings(void) {
    char buf[64];
    bg_draw(0, 0.4f, DECO_NONE, 0, 0, 0);
    title_text("Настройки", 640, 62, 50);
    back_button(SC_MENU, 0);
    if (M.react <= 0) M.red_to = 0;
    /* ---- left: volumes, switches, Mel ---- */
    panel(36, 112, 560, 572);
    gfx_text(&F_ui, "Громкость", 66, 150, 25, C_GOLD, AL_LEFT);
    static const char *const vn[3] = { "Звуки", "Музыка", "Речь" }; u8 *vp[3] = { &CFG.vol_sfx, &CFG.vol_music, &CFG.vol_voice };
    for (int i = 0; i < 3; i++) {
        float y = 198 + (float)i * 46.0f, v = (float)*vp[i] / 100.0f;
        gfx_text(&F_ui, vn[i], 66, y, 22, WHITE, AL_LEFT);
        int r = slider(700 + i, 196, y, 290, &v, i == 0 ? C_CYAN : (i == 1 ? C_PINK : C_ORG1));
        if (r) {
            int nv = (int)(v * 20.0f + 0.5f) * 5;
            if (nv != *vp[i]) { *vp[i] = (u8)nv; if (i == 1 && !SV.music) { SV.music = 1; save_store(); } if (i != 1 && !SV.sound) { SV.sound = 1; save_store(); } apply_volumes(); }
        }
        if (r == 2) {                                 /* let go: remember it and let the player hear the new volume */
            cfg_store();
            if (i == 0) sfx(S_STAR1, 0.8f, 640); else if (i == 2 && speech_on()) snd_play_voice(SND[V_AM1], 1.0f);
        }
        snprintf(buf, sizeof(buf), "%d%%", (int)*vp[i]); gfx_text(&F_ui, buf, 572, y, 22, *vp[i] ? WHITE : C_RED1, AL_RIGHT);
    }
    gfx_rrect(60, 326, 512, 2, 1, 0xFFFFFF30u);
    static const char *const tn[6] = { "Речь Мела", "Облачко с текстом", "Подсказки", "Тряска и вспышки", "Искры и конфетти", "Таймер уровня" };
    u8 *tp[6] = { &CFG.speech, &CFG.bubbles, &CFG.hints, &CFG.shake, &CFG.sparks, &CFG.timer };
    for (int i = 0; i < 6; i++) {
        float lx = 64 + (float)(i & 1) * 264.0f, y = 362 + (float)(i / 2) * 46.0f;
        gfx_text(&F_txt, tn[i], lx, y, 19, *tp[i] ? WHITE : 0xFFFFFFA0u, AL_LEFT);
        if (tgl(710 + i, lx + 214, y, *tp[i], 1)) { *tp[i] = !*tp[i]; cfg_store(); apply_volumes(); }
    }
    gfx_rrect(60, 490, 512, 2, 1, 0xFFFFFF30u);
    float cx = 62, cy = 504, cw = 206, ch = 162;
    draw_mel_cam_k(cx, cy, cw, ch, 0.9f);
    if (M.say_t <= 0) gfx_text_wrap(&F_txt, "Нажми на кнопку справа в списке — Мел покажет эту реакцию.", 430, 524, 18, 280, 25, 0xFFFFFFB0u, AL_CENTER, 1);
    if (wbtn(762, 430, 640, 290, 46, acc_label(), C_VIO1, C_VIO2, 21, IC_USER, 1)) acc_open();
    /* ---- right: Mel's reactions ---- */
    float lx = 616, ly = 112, lw = 628, lh = 572, top = ly + 70, vis = lh - 70 - 14, rowh = 54, content = (float)EM_N * rowh, maxs = maxf(0, content - vis);
    panel(lx, ly, lw, lh);
    gfx_text(&F_ui, "Эмоции Мела", lx + 30, ly + 38, 25, C_GOLD, AL_LEFT);
    if (wbtn(760, lx + lw - 228, ly + 38, 132, 40, "Все вкл.", C_GREEN1, C_GREEN2, 19, IC_NONE, (CFG.emo_off & EM_ALL) != 0)) { CFG.emo_off = 0; cfg_store(); }
    if (wbtn(761, lx + lw - 86, ly + 38, 138, 40, "Все выкл.", C_RED1, C_RED2, 19, IC_NONE, (CFG.emo_off & EM_ALL) != EM_ALL)) { CFG.emo_off = EM_ALL; cfg_store(); }
    if (P.pressed && !ui_block && P.downx > lx + 104 && P.downx < lx + lw - 124 && P.downy > top && P.downy < top + vis) { STG.drag = 1; STG.drag_y0 = P.downy; STG.scroll0 = STG.scroll; }
    if (STG.drag) { if (!P.down) STG.drag = 0; else STG.scroll = STG.scroll0 - (P.y - STG.drag_y0); }
    STG.scroll = clampf(STG.scroll, 0, maxs);
    gfx_clip(lx + 8, top, lw - 16, vis);
    for (int i = 0; i < EM_N; i++) {
        const Emo *m = &emo_tab[i]; float y = top + (float)i * rowh - STG.scroll + rowh * 0.5f; if (y < top - rowh || y > top + vis + rowh) continue;
        int on = emo_on(i), inview = y - 19 > top && y + 19 < top + vis;
        gfx_rrect(lx + 18, y - rowh * 0.5f + 3, lw - 82, rowh - 6, 14, i & 1 ? 0xFFFFFF10u : 0xFFFFFF08u);
        if (tgl(720 + i, lx + 62, y, on, inview)) { CFG.emo_off ^= 1u << i; cfg_store(); if (i == EM_RED) M.red_to = 0; }
        gfx_text(&F_ui, m->name, lx + 110, y - 10, 21, on ? WHITE : 0xFFFFFF90u, AL_LEFT);
        text_fit(&F_txt, m->desc, lx + 110, y + 13, 15, lw - 110 - 150, on ? 0xD8CCFFE0u : 0xD8CCFF80u, AL_LEFT);
        if (rbtn(740 + i, lx + lw - 100, y, 17, IC_PLAY, C_GREEN1, C_GREEN2, inview)) emo_preview(i);
    }
    gfx_clip_reset();
    if (maxs > 0) {
        float bx = lx + lw - 38, t0 = top + 50, th = vis - 100, bh = maxf(40, th * vis / content), by = t0 + (th - bh) * (STG.scroll / maxs);
        gfx_rrect(bx - 4, t0, 8, th, 4, 0xFFFFFF20u); gfx_rrect(bx - 4, by, 8, bh, 4, 0xFFFFFFA0u);
        if (rbtn(763, bx, top + 22, 20, IC_UP, C_VIO1, C_VIO2, STG.scroll > 0)) STG.scroll -= rowh * 4;
        if (rbtn(764, bx, top + vis - 22, 20, IC_DOWN, C_VIO1, C_VIO2, STG.scroll < maxs)) STG.scroll += rowh * 4;
    }
    /* Mel's bubble, over everything else */
    { float k = mel_cam_k(ch, 0.9f); draw_say(cx + cw * 0.5f, cy + ch - CLP[M.clip].avail * k, 266.0f, 6.0f, 1.0f); }
}

/* ---------------- test hooks of V0.4 (140..179) ---------------- */
static int v04_debug(int cmd, int arg) {
    switch (cmd) {
    case 140: scr_next = -1; enter(SC_SETTINGS, 0, 0); g_fade = 0; return 0;
    case 141: { u8 *f[9] = { &CFG.vol_sfx, &CFG.vol_music, &CFG.vol_voice, &CFG.speech, &CFG.bubbles, &CFG.hints, &CFG.shake, &CFG.sparks, &CFG.timer }; int k = arg >> 8; if (k < 0 || k > 8) return -1; *f[k] = (u8)(arg & 255); cfg_store(); apply_volumes(); return 0; }
    case 142: { u8 *f[9] = { &CFG.vol_sfx, &CFG.vol_music, &CFG.vol_voice, &CFG.speech, &CFG.bubbles, &CFG.hints, &CFG.shake, &CFG.sparks, &CFG.timer }; return arg >= 0 && arg <= 8 ? *f[arg] : -1; }
    case 143: if (arg >= 0 && arg < EM_N) emo_preview(arg); return 0;
    case 144: CFG.emo_off = (u32)arg & EM_ALL; cfg_store(); return 0;
    case 145: return (int)CFG.emo_off;
    case 146: if (arg > 0) rp_speed = clampf((float)arg / 10.0f, 0.1f, 5.0f); return (int)(rp_speed * 10.0f + 0.5f);
    case 147: STG.scroll = (float)arg; return 0;
    case 150: if (arg == 1) acc_open(); else if (arg == 2) donate_open(); else if (arg == 3) upd_open(); else if (arg == 4) acc_logout(); else wn_close(); return WN.kind;
    case 151: return WN.kind | (AC.busy << 4) | (CFG.acc << 5) | (acc_banned << 6) | (KB.on << 7) | (MSGB.on << 8) | (NET.proto << 12);
    case 152: return donate_has();
    case 153: return upd_pending() ? UP.ver : 0;
    case 154: return plat_ctl(PC_UPDATE_STATE, NULL, 0, 0);
    case 155: if (upd_pending()) upd_start(); return upd_pending();
    case 156: return (int)strlen(CFG.token);
    case 157: return arg >= 0 && arg < LEVEL_COUNT ? (SV.best[arg] | (SV.sent[arg] << 8)) : -1;
    case 158: acc_start(arg); return KB.on;
    case 159: hb_send(); return 0;
    case 160: return arg >= 0 && arg < (int)strlen(SV.nick) ? (u8)SV.nick[arg] : 0;
    case 161: return pw_rules(KB.buf);
    case 162: return UP.pf | (UP.asked << 4);
    default: return 0;
    }
}
