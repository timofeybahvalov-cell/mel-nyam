/* The version of the game: the update check compares APP_VER with the "ver" of online.json on the site.
   0.4 -> 400, a fix of it -> 401, 0.5 -> 500. android/build_apk.sh and tools/make_github.py read these two lines. */
#ifndef APP_VER
#define APP_VER 400
#endif
#ifndef APP_VER_NAME
#define APP_VER_NAME "0.4"
#endif
