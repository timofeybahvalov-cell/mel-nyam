/* ============================================================================
   «МЕЛ-НЯМ» V0.6 — what the city, the houses and the little Mel look like.
   Everything here is drawn by code from circles, capsules and triangles: it takes no room in the pack,
   it scales to any size, and the little Mel can grow smoothly from a baby to an old man.
   Included by game.c after g_home.inc.
   ============================================================================ */

/* ---------------- drawing in the frame of one thing: its own origin, scale and mirror ---------------- */
#define OLC 0x1B1840FFu                              /* the dark outline of everything */
static struct { float x, y, s, f, ow; } DX = { 0, 0, 1, 1, 3 };
static void d_at(float x, float y, float s, int flip) { DX.x = x; DX.y = y; DX.s = s; DX.f = flip ? -1.0f : 1.0f; DX.ow = 3.0f; }
#define LX(v) (DX.x + (v) * DX.s * DX.f)
#define LY(v) (DX.y + (v) * DX.s)
static void d_rect(float x, float y, float w, float h, float r, u32 c) {
    float X = DX.f > 0 ? LX(x) : LX(x + w);
    if (r > 0) gfx_rrect(X, LY(y), w * DX.s, h * DX.s, r * DX.s, c); else gfx_rect(X, LY(y), w * DX.s, h * DX.s, c);
}
static void d_grad(float x, float y, float w, float h, float r, u32 c0, u32 c1) { float X = DX.f > 0 ? LX(x) : LX(x + w); gfx_rrect_grad(X, LY(y), w * DX.s, h * DX.s, r * DX.s, c0, c1); }
static void d_circ(float x, float y, float r, u32 c) { gfx_circle(LX(x), LY(y), r * DX.s, c); }
static void d_ell(float x, float y, float rx, float ry, u32 c) { gfx_ellipse(LX(x), LY(y), rx * DX.s, ry * DX.s, c); }
static void d_ring(float x, float y, float r, float th, u32 c) { gfx_ring(LX(x), LY(y), r * DX.s, th * DX.s, c); }
static void d_line(float x0, float y0, float x1, float y1, float r, u32 c) { gfx_capsule(LX(x0), LY(y0), LX(x1), LY(y1), r * DX.s, c); }
static void d_line2(float x0, float y0, float x1, float y1, float r0, float r1, u32 c) { gfx_capsule2(LX(x0), LY(y0), LX(x1), LY(y1), r0 * DX.s, r1 * DX.s, c); }
static void d_tri(float x0, float y0, float x1, float y1, float x2, float y2, u32 c) { gfx_tri(LX(x0), LY(y0), LX(x1), LY(y1), LX(x2), LY(y2), c); }
static void d_quad(float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3, u32 c) {      /* corners in order; the two halves overlap a little so that no seam shows */
    float mx = (x0 + x1 + x2 + x3) * 0.25f, my = (y0 + y1 + y2 + y3) * 0.25f, k = 0.04f;
    d_tri(x0, y0, x1, y1, x2 + (x2 - mx) * k, y2 + (y2 - my) * k, c); d_tri(x0 + (x0 - mx) * k, y0 + (y0 - my) * k, x2, y2, x3, y3, c);
    d_line(x0, y0, x2, y2, 0.6f, c);
}
static void d_curve(float x0, float y0, float cx, float cy, float x1, float y1, float r, u32 c) {      /* a bent line: from, the point it bends towards, to */
    float px = x0, py = y0;
    for (int i = 1; i <= 8; i++) { float t = (float)i / 8.0f, u = 1.0f - t, x = u * u * x0 + 2 * u * t * cx + t * t * x1, y = u * u * y0 + 2 * u * t * cy + t * t * y1; d_line(px, py, x, y, r, c); px = x; py = y; }
}
static void d_text(const Font *f, const char *s, float x, float y, float size, u32 c) { gfx_text(f, s, LX(x), LY(y), size * DX.s, c, AL_CENTER); }
/* the same shapes with the dark outline around them */
static void o_rect(float x, float y, float w, float h, float r, u32 c) { float o = DX.ow; d_rect(x - o, y - o, w + 2 * o, h + 2 * o, r + o, OLC); d_rect(x, y, w, h, r, c); }
static void o_grad(float x, float y, float w, float h, float r, u32 c0, u32 c1) { float o = DX.ow; d_rect(x - o, y - o, w + 2 * o, h + 2 * o, r + o, OLC); d_grad(x, y, w, h, r, c0, c1); }
static void o_circ(float x, float y, float r, u32 c) { d_circ(x, y, r + DX.ow, OLC); d_circ(x, y, r, c); }
static void o_ell(float x, float y, float rx, float ry, u32 c) { d_ell(x, y, rx + DX.ow, ry + DX.ow, OLC); d_ell(x, y, rx, ry, c); }
static void o_line(float x0, float y0, float x1, float y1, float r, u32 c) { d_line(x0, y0, x1, y1, r + DX.ow, OLC); d_line(x0, y0, x1, y1, r, c); }
static void o_line2(float x0, float y0, float x1, float y1, float r0, float r1, u32 c) { d_line2(x0, y0, x1, y1, r0 + DX.ow, r1 + DX.ow, OLC); d_line2(x0, y0, x1, y1, r0, r1, c); }
static void o_tri(float x0, float y0, float x1, float y1, float x2, float y2, u32 c) {
    float o = DX.ow * 0.5f; d_line(x0, y0, x1, y1, o * 2, OLC); d_line(x1, y1, x2, y2, o * 2, OLC); d_line(x2, y2, x0, y0, o * 2, OLC); d_tri(x0, y0, x1, y1, x2, y2, c); d_line(x0, y0, x1, y1, 0.5f, c); d_line(x1, y1, x2, y2, 0.5f, c); d_line(x2, y2, x0, y0, 0.5f, c);
}
static void o_quad(float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3, u32 c) {
    float o = DX.ow; d_line(x0, y0, x1, y1, o, OLC); d_line(x1, y1, x2, y2, o, OLC); d_line(x2, y2, x3, y3, o, OLC); d_line(x3, y3, x0, y0, o, OLC); d_quad(x0, y0, x1, y1, x2, y2, x3, y3, c);
}
static void d_star(float x, float y, float r, u32 c) {      /* a five-pointed star */
    float px[10], py[10];
    for (int i = 0; i < 10; i++) { float a = -PI * 0.5f + (float)i * PI / 5.0f, rr = (i & 1) ? r * 0.45f : r; px[i] = x + cosf(a) * rr; py[i] = y + sinf(a) * rr; }
    for (int i = 0; i < 10; i += 2) d_tri(px[i], py[i], px[(i + 1) % 10], py[(i + 1) % 10], px[(i + 9) % 10], py[(i + 9) % 10], c);
    d_circ(x, y, r * 0.47f, c);
}
static void d_glow(float x, float y, float r, u32 c) { for (int i = 3; i >= 1; i--) d_circ(x, y, r * (float)i / 3.0f, color_alpha(c, 0.16f)); }
static u32 shade(u32 c, float k) { return color_lerp(c, k < 0 ? 0x000000FFu : 0xFFFFFFFFu, k < 0 ? -k : k); }      /* darker (k < 0) or lighter */

/* ============================== the little Mel ============================== */
enum { KS_ASLEEP = 1, KS_SICK = 2, KS_TIPSY = 4, KS_THIRSTY = 8, KS_TIRED = 16 };
typedef struct {
    float age;                                       /* years (fractions while he grows before the eyes) */
    u8 wear[SL_N];                                   /* cloth + 1 */
    float t;                                         /* a clock for his little motions */
    float mouth, smile, blink;                       /* 0..1 open; -1 sad..1 merry; 0..1 shut */
    float lookx, looky;                              /* where the eyes look, -1..1 */
    float arm[2], fore[2];                           /* each arm: 0 hangs down, PI/2 points sideways, PI up; fore: how much the forearm bends further */
    float tilt, lean;                                /* the head to one side; the whole body */
    int state;
    int drink; float sip;                            /* a bottle (skin number) at his mouth, 0..1 */
} Kid;
static float agef(float a, float v0, float v3, float v7, float v13, float v18) {      /* a size that changes with the years */
    if (a <= 0) return v0; if (a < 3) return v0 + (v3 - v0) * a / 3.0f; if (a < 7) return v3 + (v7 - v3) * (a - 3) / 4.0f;
    if (a < 13) return v7 + (v13 - v7) * (a - 7) / 6.0f; if (a < 18) return v13 + (v18 - v13) * (a - 13) / 5.0f; return v18;
}
static float kid_height(float age) { return agef(age, 22, 44, 72, 104, 128) + agef(age, 46, 62, 82, 108, 128) + agef(age, 52, 54, 55, 55, 54) * 1.78f; }
static struct { float hx, hy, R, mouthx, mouthy, handx[2], handy[2], top; } KG;      /* where the last drawn Mel has his head, mouth and hands (design units) */
#define SKIN1 0xFFD9B8FFu
#define SKIN2 0xF2BE98FFu
static void kid_arm(int side, float sx, float sy, float len, float r, float a, float fore, u32 sleeve, float sleeve_k, u32 cuff) {
    float sg = side ? 1.0f : -1.0f, l1 = len * 0.5f, ex = sx + sg * sinf(a) * l1, ey = sy + cosf(a) * l1, a2 = a + fore, hx = ex + sg * sinf(a2) * l1, hy = ey + cosf(a2) * l1;
    d_line(sx, sy, ex, ey, r + DX.ow, OLC); d_line(ex, ey, hx, hy, r + DX.ow, OLC); d_circ(hx, hy, r * 1.22f + DX.ow, OLC);
    d_line(sx, sy, ex, ey, r, SKIN1); d_line(ex, ey, hx, hy, r, SKIN1);
    if (sleeve_k > 0) {
        if (sleeve_k <= 0.5f) d_line(sx, sy, sx + (ex - sx) * sleeve_k * 2, sy + (ey - sy) * sleeve_k * 2, r + 1.5f, sleeve);
        else { float k = (sleeve_k - 0.5f) * 2; d_line(sx, sy, ex, ey, r + 1.5f, sleeve); d_line(ex, ey, ex + (hx - ex) * k, ey + (hy - ey) * k, r + 1.5f, sleeve); if (cuff) d_line(ex + (hx - ex) * (k - 0.12f), ey + (hy - ey) * (k - 0.12f), ex + (hx - ex) * k, ey + (hy - ey) * k, r + 2.0f, cuff); }
    }
    d_circ(hx, hy, r * 1.22f, SKIN1);
    KG.handx[side] = LX(hx); KG.handy[side] = LY(hy);
}
/* (x, y): the point of the floor between his feet; s: scale (1: design units) */
static void kid_draw(float x, float y, float s, const Kid *k) {
    float a = k->age, L = agef(a, 22, 44, 72, 104, 128), T = agef(a, 46, 62, 82, 108, 128), R = agef(a, 52, 54, 55, 55, 54), W = agef(a, 62, 66, 72, 84, 100);
    float AL_ = agef(a, 34, 48, 66, 90, 108), ar = agef(a, 10, 10.5f, 11, 12, 13), lr = agef(a, 12, 12.5f, 13, 14.5f, 16);
    float breathe = (k->state & KS_ASLEEP) ? sinf(k->t * 1.4f) * 1.6f : sinf(k->t * 2.4f) * 1.0f;
    const ClothDef *top = k->wear[SL_TOP] ? &cloth_tab[k->wear[SL_TOP] - 1] : NULL, *legs = k->wear[SL_LEGS] ? &cloth_tab[k->wear[SL_LEGS] - 1] : NULL, *feet = k->wear[SL_FEET] ? &cloth_tab[k->wear[SL_FEET] - 1] : NULL;
    const ClothDef *hat = k->wear[SL_HAT] ? &cloth_tab[k->wear[SL_HAT] - 1] : NULL, *eyes = k->wear[SL_EYES] ? &cloth_tab[k->wear[SL_EYES] - 1] : NULL, *acc = k->wear[SL_ACC] ? &cloth_tab[k->wear[SL_ACC] - 1] : NULL;
    int baby = a < 3.0f;
    u32 ctop = top ? top->c1 : (baby ? 0xFFE27AFFu : 0x8FD0FFFFu), ctop2 = top ? top->c2 : (baby ? 0xF2C84BFFu : 0x5FA8E6FFu);
    u32 cleg = legs ? legs->c1 : (baby ? 0xFFE27AFFu : 0x4C5FA8FFu), cleg2 = legs ? legs->c2 : 0x38488AFFu;
    int tstyle = top ? top->style : -1, lstyle = legs ? legs->style : -1, fstyle = feet ? feet->style : -1;
    float sleeve = tstyle < 0 ? 0.3f : (tstyle == 7 ? 0.0f : ((tstyle == 3 || tstyle == 4 || tstyle == 5 || tstyle == 6 || tstyle == 9) ? 1.0f : 0.32f));
    float legk = lstyle < 0 ? (baby ? 0.55f : 0.42f) : (lstyle == 1 ? 0.42f : 1.0f);
    u32 hair = a >= 60 ? 0xE9E9F2FFu : (a >= 45 ? color_lerp(0xD9B45AFFu, 0xE9E9F2FFu, (a - 45) / 15.0f) : color_lerp(0xF2D680FFu, 0xD9B45AFFu, clampf(a / 18.0f, 0, 1))), hair2 = shade(hair, -0.16f);
    float hipY = -L - breathe * 0.3f, shY = hipY - T, hy = shY - R * 0.78f - breathe * 0.4f, hx = sinf(k->tilt) * R * 0.5f + k->lean * (L + T) * 0.3f, bx = k->lean * (L + T) * 0.12f;
    float lx = W * 0.24f, shoe = fstyle >= 0 ? lr * 0.9f : 0;
    d_at(x, y, s, 0); DX.ow = 3.0f;
    d_ell(0, 2, W * 0.75f, 9, 0x00000038u);                                             /* his shadow on the floor */
    if (acc && acc->style == 5) { o_rect(bx - W * 0.62f, shY + T * 0.08f, W * 1.24f, T * 0.8f, 12, acc->c1); d_rect(bx - W * 0.62f, shY + T * 0.5f, W * 1.24f, T * 0.12f, 0, acc->c2); }      /* a backpack shows from behind him */
    if (tstyle == 3) o_ell(hx * 0.5f, shY + 4, W * 0.56f, R * 0.36f, ctop2);          /* the hood of a hoodie lies on the shoulders */
    /* legs and feet */
    for (int i = 0; i < 2; i++) {
        float sg = i ? 1.0f : -1.0f, fx = sg * (lx + 2), fy = -lr - shoe * 0.6f;
        o_line(bx + sg * lx, hipY, fx, fy, lr, SKIN1);
        if (legk >= 1.0f) { d_line(bx + sg * lx, hipY, fx, fy, lr + 1.5f, cleg); if (lstyle == 2) d_line(bx + sg * (lx + lr * 0.7f), hipY + 4, fx + sg * lr * 0.7f, fy, 1.6f, cleg2); if (lstyle == 4) for (int q = 0; q < 3; q++) d_circ(bx * (1 - (q + 0.5f) / 3) + sg * lx + (fx - sg * lx) * (q + 0.5f) / 3, hipY + (fy - hipY) * (q + 0.5f) / 3, 2.4f, cleg2); }
        else d_line(bx + sg * lx, hipY, bx + sg * lx + (fx - bx - sg * lx) * legk, hipY + (fy - hipY) * legk, lr + 1.5f, cleg);
        if (fstyle < 0) o_ell(fx + sg * 3, -lr * 0.62f, lr * 1.25f, lr * 0.62f, SKIN1);
        else if (fstyle == 3) { o_rect(fx - lr * 1.1f, -lr * 2.4f, lr * 2.2f, lr * 2.4f, 5, feet->c1); o_ell(fx + sg * 5, -lr * 0.7f, lr * 1.55f, lr * 0.7f, feet->c1); d_rect(fx - lr * 1.1f, -4, lr * 2.2f + 5, 4, 0, feet->c2); }
        else {
            o_ell(fx + sg * 5, -lr * 0.75f, lr * 1.6f, lr * 0.75f, feet->c1);
            if (fstyle == 0) d_ell(fx + sg * (lr * 1.15f + 5), -lr * 0.62f, lr * 0.5f, lr * 0.5f, feet->c2);
            if (fstyle == 1 || fstyle == 4) d_line(fx - sg * 4, -lr * 0.9f, fx + sg * 12, -lr * 0.5f, 2.0f, fstyle == 1 ? feet->c2 : 0xFFFFFFFFu);
            if (fstyle == 2) { o_ell(fx + sg * 2, -lr * 1.9f, 3.5f, lr * 0.8f, feet->c1); o_ell(fx + sg * 11, -lr * 1.8f, 3.5f, lr * 0.8f, feet->c1); d_circ(fx + sg * (lr * 1.3f + 5), -lr * 0.8f, 2.2f, OLC); }
        }
    }
    /* body */
    o_rect(bx - W * 0.5f, shY, W, T + lr * 0.4f, W * 0.3f, ctop);
    if (tstyle < 0 && !baby) d_rect(bx - W * 0.5f + 5, shY + T * 0.3f, W - 10, 5, 2, ctop2);
    if (tstyle == 2) for (float q = shY + T * 0.22f; q < hipY - 8; q += 13) d_rect(bx - W * 0.5f + 1, q, W - 2, 5.5f, 0, ctop2);
    if (tstyle == 1) d_text(&F_ui, "MEL", bx, shY + T * 0.5f, W * 0.3f, ctop2);
    if (tstyle == 3) { o_rect(bx - W * 0.26f, shY + T * 0.56f, W * 0.52f, T * 0.26f, 6, ctop2); d_line(bx - 7, shY + 6, bx - 8, shY + T * 0.32f, 1.5f, 0xFFFFFFE0u); d_line(bx + 7, shY + 6, bx + 8, shY + T * 0.32f, 1.5f, 0xFFFFFFE0u); }
    if (tstyle == 4) { d_line(bx, shY + 4, bx, hipY, 1.6f, ctop2); d_rect(bx - W * 0.5f + 1, shY + T * 0.72f, W - 2, 5, 0, ctop2); }
    if (tstyle == 5) { d_tri(bx, shY + T * 0.2f, bx - W * 0.2f, shY + T * 0.62f, bx + W * 0.2f, shY + T * 0.62f, ctop2); d_rect(bx - 3, shY + T * 0.62f, 6, T * 0.1f, 0, 0x8A5A2BFFu); d_circ(bx, shY + T * 0.2f, 3, 0xFFD23FFFu); }
    if (tstyle == 6) { d_tri(bx - W * 0.2f, shY + 1, bx + W * 0.2f, shY + 1, bx, shY + T * 0.62f, 0xFFFFFFFFu); d_quad(bx - 4, shY + 4, bx + 4, shY + 4, bx + 5, shY + T * 0.5f, bx - 5, shY + T * 0.5f, ctop2); d_circ(bx, shY + T * 0.76f, 2.6f, 0xD8D8E6FFu); }
    if (tstyle == 8) { for (int q = 0; q < 6; q++) d_star(bx - W * 0.3f + (float)(q % 3) * W * 0.3f + (q > 2 ? 6 : -4), shY + T * (q > 2 ? 0.7f : 0.36f), 6.5f, ctop2); d_tri(bx - 9, shY + 1, bx + 9, shY + 1, bx, shY + T * 0.24f, SKIN1); }
    if (tstyle == 9) { d_rect(bx - W * 0.5f + 6, shY + 8, W * 0.2f, T * 0.5f, 6, 0xFFFFFF70u); d_line(bx, shY + 4, bx, hipY, 1.6f, ctop2); }
    if (tstyle == 7) { d_circ(bx - W * 0.5f + 3, shY + 9, 9, SKIN1); d_circ(bx + W * 0.5f - 3, shY + 9, 9, SKIN1); }
    if (legs || !baby) { o_rect(bx - W * 0.5f, hipY - T * 0.2f, W, T * 0.2f + lr * 0.7f, 8, cleg); if (lstyle == 0 || lstyle == 3) d_rect(bx - W * 0.5f + 2, hipY - T * 0.2f + 1, W - 4, 4, 0, cleg2); }
    if (acc && acc->style == 5) { d_line(bx - W * 0.3f, shY + 3, bx - W * 0.36f, hipY - T * 0.24f, 3.2f, acc->c2); d_line(bx + W * 0.3f, shY + 3, bx + W * 0.36f, hipY - T * 0.24f, 3.2f, acc->c2); }
    if (acc && acc->style == 3) { d_line(bx - 9, shY + 3, bx, shY + T * 0.4f, 2.2f, acc->c2); d_line(bx + 9, shY + 3, bx, shY + T * 0.4f, 2.2f, acc->c2); o_circ(bx, shY + T * 0.46f, 9, acc->c1); d_star(bx, shY + T * 0.46f, 5, 0xFFF3B0FFu); }
    if (acc && acc->style == 0) { d_curve(bx - W * 0.3f, shY + 2, bx, shY + T * 0.5f, bx + W * 0.3f, shY + 2, 3.0f, OLC); d_curve(bx - W * 0.3f, shY + 2, bx, shY + T * 0.5f, bx + W * 0.3f, shY + 2, 1.9f, acc->c1); o_circ(bx, shY + T * 0.28f, 5.5f, acc->c1); }
    /* arms */
    float shx = W * 0.5f - ar * 0.5f, shy = shY + ar * 1.25f;
    u32 cuff = (tstyle == 4 || tstyle == 3) ? ctop2 : ((tstyle == 6) ? 0xFFFFFFFFu : 0);
    kid_arm(0, bx - shx, shy, AL_, ar, k->arm[0], k->fore[0], ctop, sleeve, cuff);
    kid_arm(1, bx + shx, shy, AL_, ar, k->arm[1], k->fore[1], ctop, sleeve, cuff);
    if (acc && acc->style == 4) { float wx = (KG.handx[0] - DX.x) / DX.s, wy = (KG.handy[0] - DX.y) / DX.s; o_circ(wx + 2, wy - ar * 1.5f, 5.2f, acc->c1); d_circ(wx + 2, wy - ar * 1.5f, 3.2f, acc->c2); }
    /* head */
    float fy = hy + R * 0.06f;                                                           /* the middle of the face */
    d_ell(hx, hy, R * 1.05f + DX.ow, R * 0.97f + DX.ow, OLC);
    if (a >= 1.0f) d_ell(hx, hy - R * 0.2f, R * 1.1f + DX.ow, R * 0.88f + DX.ow, OLC);
    o_circ(hx - R * 1.0f, fy + R * 0.12f, R * 0.19f, SKIN1); o_circ(hx + R * 1.0f, fy + R * 0.12f, R * 0.19f, SKIN1);
    d_circ(hx - R * 1.0f, fy + R * 0.12f, R * 0.09f, SKIN2); d_circ(hx + R * 1.0f, fy + R * 0.12f, R * 0.09f, SKIN2);
    if (a >= 1.0f) d_ell(hx, hy - R * 0.2f, R * 1.1f, R * 0.88f, hair);                 /* the hair behind the face */
    d_ell(hx, hy + R * 0.05f, R * 1.02f, R * 0.92f, (k->state & KS_SICK) ? 0xE6E2B4FFu : SKIN1);
    if (a >= 25.0f) d_ell(hx, fy + R * 0.62f, R * 0.7f, R * 0.33f, color_alpha(a >= 60 ? 0xF4F4FAFFu : shade(hair, -0.3f), a >= 60 ? 0.95f : clampf((a - 25) / 20.0f, 0.18f, 0.5f)));      /* stubble, later a beard */
    if (a >= 1.0f) {                                                                     /* the fringe */
        float fr = hy - R * 0.52f;
        d_ell(hx - R * 0.5f, fr, R * 0.58f, R * 0.4f, hair); d_ell(hx + R * 0.36f, fr - R * 0.06f, R * 0.7f, R * 0.4f, hair); d_ell(hx - R * 0.02f, fr + R * 0.04f, R * 0.36f, R * 0.34f, hair2);
        d_ell(hx + R * 0.36f, fr - R * 0.1f, R * 0.5f, R * 0.22f, shade(hair, 0.22f));
    } else { d_curve(hx - 4, hy - R * 0.92f, hx + 2, hy - R * 1.22f, hx + 12, hy - R * 1.06f, 2.6f, hair2); d_curve(hx + 2, hy - R * 0.92f, hx - 6, hy - R * 1.16f, hx - 14, hy - R * 1.0f, 2.2f, hair2); }
    /* face */
    float ex = R * 0.41f, ey = fy + R * 0.08f, shut = k->blink; if (k->state & KS_ASLEEP) shut = 1; else if ((k->state & KS_TIRED) && shut < 0.45f) shut = 0.45f;
    for (int i = 0; i < 2; i++) {
        float cx = hx + (i ? ex : -ex), open = 1.0f - shut;
        if (open < 0.25f) d_curve(cx - R * 0.17f, ey + R * 0.02f, cx, ey + R * 0.13f, cx + R * 0.17f, ey + R * 0.02f, 1.9f, OLC);
        else {
            d_ell(cx, ey, R * 0.2f + 1.6f, R * 0.25f * open + 1.6f, OLC); d_ell(cx, ey, R * 0.2f, R * 0.25f * open, 0xFFFFFFFFu);
            float px = cx + k->lookx * R * 0.07f, py = ey + k->looky * R * 0.06f * open;
            d_ell(px, py, R * 0.135f, minf(R * 0.135f, R * 0.24f * open), 0x3F7CC0FFu); d_ell(px, py, R * 0.075f, minf(R * 0.075f, R * 0.2f * open), 0x15152AFFu); d_circ(px - R * 0.045f, py - R * 0.06f * open, R * 0.04f, 0xFFFFFFFFu);
        }
        float br = k->smile < -0.3f ? (i ? -1.0f : 1.0f) * R * 0.07f : 0;                 /* the brows of a sad one go up in the middle */
        if (!eyes || eyes->style == 1) d_line(cx - R * 0.17f, ey - R * 0.36f - br, cx + R * 0.17f, ey - R * 0.36f + br, 2.0f, shade(hair, -0.45f));
    }
    d_ell(hx - R * 0.64f, fy + R * 0.42f, R * 0.16f, R * 0.09f, (k->state & KS_TIPSY) ? 0xFF6F8CC0u : 0xFF9FA860u); d_ell(hx + R * 0.64f, fy + R * 0.42f, R * 0.16f, R * 0.09f, (k->state & KS_TIPSY) ? 0xFF6F8CC0u : 0xFF9FA860u);
    d_ell(hx, fy + R * 0.3f, R * 0.07f, R * 0.05f, (k->state & KS_TIPSY) ? 0xF08A8AFFu : SKIN2);
    float my = fy + R * 0.55f, mo = k->mouth;
    if (a >= 40.0f) d_curve(hx - R * 0.26f, my - R * 0.1f, hx, my - R * 0.2f, hx + R * 0.26f, my - R * 0.1f, 3.0f, a >= 60 ? 0xF4F4FAFFu : shade(hair, -0.35f));      /* a moustache */
    if (mo > 0.08f) { d_ell(hx, my, R * 0.2f + 1.6f, R * (0.05f + 0.2f * mo) + 1.6f, OLC); d_ell(hx, my, R * 0.2f, R * (0.05f + 0.2f * mo), 0x7A1F2EFFu); if (mo > 0.3f) d_ell(hx, my + R * 0.12f * mo, R * 0.12f, R * 0.08f * mo, 0xFF7A8EFFu); }
    else d_curve(hx - R * 0.22f, my - R * 0.04f * k->smile, hx, my + R * 0.2f * k->smile, hx + R * 0.22f, my - R * 0.04f * k->smile, 1.9f, 0x7A2A2AFFu);
    if (k->state & KS_THIRSTY) { d_ell(hx + R * 0.86f, fy - R * 0.2f, 4.2f, 6.2f, 0x7FD4FFFFu); d_tri(hx + R * 0.86f - 3.6f, fy - R * 0.2f - 3, hx + R * 0.86f + 3.6f, fy - R * 0.2f - 3, hx + R * 0.86f, fy - R * 0.2f - 13, 0x7FD4FFFFu); }
    /* what he wears on the head and the face */
    if (eyes) {
        int st = eyes->style; float gy = ey, gr = R * 0.25f;
        if (st == 3) { o_rect(hx - R * 0.86f, gy - R * 0.3f, R * 1.72f, R * 0.6f, 9, eyes->c1); d_rect(hx - R * 0.7f, gy - R * 0.14f, R * 1.4f, R * 0.14f, 4, eyes->c2); d_line(hx - R * 0.86f, gy, hx - R * 1.04f, gy - R * 0.05f, 3.0f, OLC); d_line(hx + R * 0.86f, gy, hx + R * 1.04f, gy - R * 0.05f, 3.0f, OLC); }
        else {
            d_line(hx - ex + gr, gy - 1, hx + ex - gr, gy - 1, 2.0f, st == 1 ? eyes->c1 : OLC); d_line(hx - ex - gr, gy - 2, hx - R * 1.0f, gy - R * 0.08f, 1.8f, OLC); d_line(hx + ex + gr, gy - 2, hx + R * 1.0f, gy - R * 0.08f, 1.8f, OLC);
            for (int i = 0; i < 2; i++) {
                float cx = hx + (i ? ex : -ex);
                if (st == 1) { d_ring(cx, gy, gr, 3.2f, eyes->c1); d_circ(cx, gy, gr - 1.5f, 0xCDEBFF40u); }
                else if (st == 2) { d_star(cx, gy, gr * 1.5f, OLC); d_star(cx, gy, gr * 1.22f, eyes->c1); d_star(cx, gy, gr * 0.7f, eyes->c2); }
                else { o_rect(cx - gr * 1.06f, gy - gr * 0.8f, gr * 2.12f, gr * 1.6f, gr * 0.7f, eyes->c1); d_rect(cx - gr * 0.7f, gy - gr * 0.52f, gr * 0.8f, gr * 0.36f, 3, st == 0 ? 0xFFFFFF50u : 0xFFFFFFA0u); }
            }
        }
    }
    if (hat) {
        int st = hat->style; float ty = hy - R * 0.5f;                                    /* the line where a hat sits */
        if (st == 0 || st == 1) {
            float sg = st == 1 ? -1.0f : 1.0f;
            if (st == 0) o_ell(hx + R * 0.72f, ty + R * 0.06f, R * 0.62f, R * 0.13f, hat->c2);
            d_ell(hx, ty - R * 0.2f, R * 1.06f + DX.ow, R * 0.42f + DX.ow, OLC); d_ell(hx, ty - R * 0.2f, R * 1.06f, R * 0.42f, hat->c1);      /* (the dome ends at the band: the eyes stay free) */
            d_rect(hx - R * 1.04f, ty + R * 0.02f, R * 2.08f, R * 0.2f, R * 0.09f, hat->c2);
            if (st == 1) { o_rect(hx - R * 0.3f, ty - R * 0.02f, R * 0.6f, R * 0.26f, R * 0.12f, shade(hat->c1, -0.06f)); d_rect(hx - R * 0.2f, ty + R * 0.05f, R * 0.4f, R * 0.1f, 3, hair); }
            d_circ(hx, ty - R * 0.6f, R * 0.07f, hat->c2); (void)sg;
        } else if (st == 2) {
            d_ell(hx, ty - R * 0.25f, R * 1.06f + DX.ow, R * 0.52f + DX.ow, OLC); d_ell(hx, ty - R * 0.25f, R * 1.06f, R * 0.52f, hat->c1);
            o_rect(hx - R * 1.08f, ty - R * 0.02f, R * 2.16f, R * 0.3f, R * 0.14f, hat->c2); o_circ(hx, ty - R * 0.82f, R * 0.2f, hat->c2);
        } else if (st == 3) {
            for (int q = 0; q < 2; q++) { float rr = q ? 2.6f : 5.2f; u32 cc = q ? hat->c1 : OLC;      /* the band over the head */
                d_curve(hx - R * 1.12f, fy, hx - R * 1.12f, hy - R * 1.14f, hx, hy - R * 1.14f, rr, cc); d_curve(hx + R * 1.12f, fy, hx + R * 1.12f, hy - R * 1.14f, hx, hy - R * 1.14f, rr, cc); }
            o_rect(hx - R * 1.3f, fy - R * 0.2f, R * 0.36f, R * 0.66f, R * 0.16f, hat->c1); o_rect(hx + R * 0.94f, fy - R * 0.2f, R * 0.36f, R * 0.66f, R * 0.16f, hat->c1);
            d_rect(hx - R * 1.3f, fy - R * 0.02f, R * 0.12f, R * 0.3f, 3, hat->c2); d_rect(hx + R * 1.18f, fy - R * 0.02f, R * 0.12f, R * 0.3f, 3, hat->c2);
        } else if (st == 4) {
            o_rect(hx - R * 0.62f, ty - R * 1.16f, R * 1.24f, R * 1.2f, 6, hat->c1); d_rect(hx - R * 0.62f, ty - R * 0.3f, R * 1.24f, R * 0.2f, 0, hat->c2); o_rect(hx - R * 1.06f, ty - R * 0.06f, R * 2.12f, R * 0.18f, R * 0.09f, hat->c1);
        } else if (st == 5) {
            o_tri(hx - R * 0.42f, ty - R * 0.1f, hx + R * 0.42f, ty - R * 0.1f, hx + R * 0.06f, ty - R * 1.3f, hat->c1);
            d_line(hx - R * 0.2f, ty - R * 0.5f, hx + R * 0.28f, ty - R * 0.44f, 2.4f, hat->c2); d_line(hx - R * 0.06f, ty - R * 0.86f, hx + R * 0.16f, ty - R * 0.82f, 2.2f, hat->c2); o_circ(hx + R * 0.06f, ty - R * 1.3f, R * 0.11f, hat->c2);
        } else if (st == 6) {
            o_ell(hx, ty + R * 0.02f, R * 1.56f, R * 0.2f, hat->c1); o_rect(hx - R * 0.68f, ty - R * 0.74f, R * 1.36f, R * 0.8f, R * 0.3f, hat->c1); d_ell(hx, ty - R * 0.72f, R * 0.3f, R * 0.1f, hat->c2); d_rect(hx - R * 0.68f, ty - R * 0.2f, R * 1.36f, R * 0.14f, 0, hat->c2);
        } else {
            float cw = R * 0.72f, cy = ty - R * 0.12f;
            for (int i = 0; i < 3; i++) { float qx = hx + ((float)i - 1) * cw * 0.72f; o_tri(qx - cw * 0.36f, cy - R * 0.1f, qx + cw * 0.36f, cy - R * 0.1f, qx, cy - R * 0.66f, hat->c1); }
            o_rect(hx - cw, cy - R * 0.2f, cw * 2, R * 0.32f, 4, hat->c1); for (int i = 0; i < 3; i++) d_circ(hx + ((float)i - 1) * cw * 0.6f, cy - R * 0.04f, R * 0.07f, i == 1 ? 0x46E6FFFFu : hat->c2);
        }
    }
    if (acc && acc->style == 1) { o_rect(hx * 0.5f + bx * 0.5f - W * 0.46f, shY - 4, W * 0.92f, 15, 7, acc->c1); o_rect(bx + W * 0.12f, shY + 4, 14, T * 0.42f, 5, acc->c1); d_rect(bx + W * 0.12f, shY + T * 0.34f, 14, 4, 0, acc->c2); }
    if (acc && acc->style == 2) { o_tri(bx, shY + 6, bx - 15, shY - 3, bx - 15, shY + 15, acc->c1); o_tri(bx, shY + 6, bx + 15, shY - 3, bx + 15, shY + 15, acc->c1); o_circ(bx, shY + 6, 4.5f, acc->c2); }
    KG.hx = LX(hx); KG.hy = LY(hy); KG.R = R * s; KG.mouthx = LX(hx); KG.mouthy = LY(my); KG.top = LY(hy - R * (hat ? 1.5f : 1.1f));
    if (k->sip > 0.01f && k->drink >= 0) {                                               /* a bottle at the mouth */
        const Image *im = skin_pic(drink_skin(k->drink)); float bs = s * 1.5f * agef(a, 0.62f, 0.72f, 0.86f, 1.0f, 1.0f), u = 0.25f + 0.3f * k->sip;      /* the neck goes to the mouth as he lifts it */
        gfx_image_ex(im, KG.handx[1] + (KG.mouthx - KG.handx[1]) * u + 10 * s, KG.handy[1] + (KG.mouthy - KG.handy[1]) * u - 26 * s * k->sip, bs, bs, -0.35f - 1.1f * k->sip, 1.0f);
    }
    if (k->state & KS_ASLEEP) for (int i = 0; i < 3; i++) { float p = fmodf(k->t * 0.5f + (float)i * 0.33f, 1.0f); gfx_text(&F_ui, "z", LX(hx + R * 0.9f + p * 46), LY(hy - R * 0.8f - p * 70), (14 + p * 20) * s, color_alpha(0xCFE6FFFFu, 1.0f - p), AL_CENTER); }
}
/* a still Mel for lists and the map: only how old he is and what he wears */
static void kid_simple(Kid *k, float age, const u8 *wear, float t) {
    memset(k, 0, sizeof(*k)); k->age = age; if (wear) memcpy(k->wear, wear, SL_N); k->t = t; k->smile = 0.8f; k->drink = -1;
    k->arm[0] = 0.22f; k->arm[1] = 0.22f; k->fore[0] = -0.1f; k->fore[1] = -0.1f;
    float b = fmodf(t + age * 0.37f, 3.6f); k->blink = b > 3.45f ? 1.0f : 0.0f;
}

/* ============================== furniture ============================== */
/* Floor things and rugs: (x, y) is the middle of the bottom edge. Wall things: the centre. Ceiling things: the middle of the top edge. */
#define WOOD1 0xC98B4FFFu
#define WOOD2 0x8E5A2CFFu
static void item_draw(int id, float x, float y, float s, int flip) {
    float t = g_time; d_at(x, y, s, flip);
    switch (id) {
    case 0:  /* bed */
        o_rect(-115, -112, 24, 104, 8, WOOD2); o_rect(96, -70, 19, 62, 7, WOOD2); o_rect(-104, -52, 212, 38, 6, WOOD1); d_rect(-104, -22, 212, 8, 0, WOOD2);
        o_rect(-96, -70, 198, 24, 9, 0xF4F4FAFFu); o_rect(-90, -88, 62, 26, 11, 0xCFE6FFFFu); o_rect(-22, -74, 124, 36, 9, 0x8E6BE8FFu); d_rect(-22, -74, 124, 9, 4, 0xB79CFFFFu);
        d_rect(-104, -14, 10, 14, 0, WOOD2); d_rect(94, -14, 10, 14, 0, WOOD2); break;
    case 1:  /* table */
        o_rect(-64, -80, 12, 80, 3, WOOD2); o_rect(52, -80, 12, 80, 3, WOOD2); o_rect(-44, -80, 88, 24, 4, WOOD1); d_circ(0, -68, 3.5f, 0xFFD23FFFu); o_rect(-75, -92, 150, 14, 5, WOOD1); d_rect(-71, -90, 142, 4, 2, 0xE2AC72FFu); break;
    case 2:  /* chair */
        o_rect(-30, -112, 10, 112, 3, WOOD2); o_rect(22, -48, 9, 48, 3, WOOD2); o_rect(-30, -106, 12, 44, 5, WOOD1); o_rect(-32, -58, 66, 12, 5, WOOD1); break;
    case 3:  /* rug */
        o_ell(0, -12, 104, 15, 0xD9463EFFu); d_ell(0, -12, 86, 11, 0xFFB648FFu); d_ell(0, -12, 62, 7.5f, 0xD9463EFFu); d_ell(0, -12, 30, 3.6f, 0xFFE6A0FFu); break;
    case 4:  /* bulb */
        d_line(0, 0, 0, 52, 1.6f, OLC); o_rect(-8, 48, 16, 14, 3, 0x8A8FA6FFu); d_glow(0, 74, 52, 0xFFE680FFu); o_circ(0, 74, 17, 0xFFE680FFu); d_circ(-5, 69, 5, 0xFFFFFFC0u); break;
    case 5:  /* poster */
        o_rect(-46, -61, 92, 122, 4, 0xF4F4FAFFu); d_grad(-40, -55, 80, 110, 2, 0x8E6BE8FFu, 0x3A2A8CFFu); d_star(-22, -34, 9, 0xFFD23FFFu); d_star(24, -20, 6, 0xFFD23FFFu);
        d_rect(-9, -14, 18, 34, 6, 0xDFF3FFFFu); d_rect(-5, -26, 10, 14, 2, 0xDFF3FFFFu); d_rect(-9, -2, 18, 10, 0, 0xE5484DFFu); d_text(&F_ui, "MEL", 0, 38, 22, 0xFFFFFFFFu); break;
    case 6:  /* sofa */
        d_rect(-100, -12, 12, 12, 0, WOOD2); d_rect(88, -12, 12, 12, 0, WOOD2); o_rect(-108, -106, 216, 70, 16, 0x2FA89AFFu); o_rect(-118, -52, 236, 42, 10, 0x25857AFFu);
        o_rect(-98, -66, 94, 26, 9, 0x4CC9BAFFu); o_rect(4, -66, 94, 26, 9, 0x4CC9BAFFu); o_rect(-120, -80, 32, 70, 12, 0x2FA89AFFu); o_rect(88, -80, 32, 70, 12, 0x2FA89AFFu); o_rect(-70, -98, 40, 30, 8, 0xFFD23FFFu); break;
    case 7:  /* TV on a stand */
        o_rect(-72, -46, 144, 46, 5, 0x5A3A22FFu); d_rect(-64, -38, 60, 30, 3, 0x7A5232FFu); d_rect(4, -38, 60, 30, 3, 0x7A5232FFu); d_rect(-10, -56, 20, 12, 0, OLC);
        o_rect(-88, -152, 176, 98, 7, 0x22222EFFu); d_grad(-80, -144, 160, 82, 3, 0x4FB6FFFFu, 0x2B4FB8FFu); d_tri(-80, -144, -30, -144, -80, -94, 0xFFFFFF30u);
        d_circ(-28 + sinf(t * 1.3f) * 22, -104, 11, 0xFFD23FFFu); d_rect(-80, -76, 160, 14, 0, 0x2FAE6AFFu); d_circ(74, -58, 2.2f, 0xFF4040FFu); break;
    case 8:  /* ficus */
        d_line(0, -40, -4, -104, 3.4f, 0x7A5232FFu); o_ell(-24, -96, 20, 13, 0x3FAE56FFu); o_ell(22, -108, 22, 14, 0x2F9E55FFu); o_ell(-8, -128, 22, 15, 0x4FC468FFu); o_ell(16, -140, 17, 12, 0x3FAE56FFu); o_ell(-22, -118, 14, 10, 0x2F9E55FFu);
        o_quad(-28, -44, 28, -44, 21, 0, -21, 0, 0xD9794AFFu); o_rect(-31, -50, 62, 11, 4, 0xE8946AFFu); break;
    case 9:  /* painting */
        o_rect(-66, -48, 132, 96, 4, 0xE0B040FFu); d_grad(-57, -39, 114, 78, 0, 0x9AD4FFFFu, 0xE6F4FFFFu); d_circ(30, -16, 11, 0xFFE06AFFu); d_ell(-18, -20, 16, 6, 0xFFFFFFE0u); d_ell(-8, -24, 10, 6, 0xFFFFFFE0u);
        d_rect(-57, 24, 114, 15, 0, 0x4FC468FFu); d_ell(-27, 25, 29, 13, 0x4FC468FFu); d_ell(28, 27, 28, 11, 0x2F9E55FFu); d_rect(0, 30, 57, 9, 0, 0x2F9E55FFu); d_tri(-40, 14, -34, 14, -37, 2, 0x2F9E55FFu); break;
    case 10: /* gaming chair */
        d_line(0, -30, 0, -52, 4.5f, OLC); d_line(-32, -6, 32, -6, 4.0f, OLC); d_circ(-32, -5, 5.5f, 0x30303EFFu); d_circ(32, -5, 5.5f, 0x30303EFFu); d_line(0, -30, 0, -8, 3.5f, 0x8A8FA6FFu);
        o_rect(-34, -152, 60, 104, 16, 0x26262FFFu); d_rect(-26, -140, 9, 84, 4, 0xE5484DFFu); d_rect(9, -140, 9, 84, 4, 0xE5484DFFu); o_rect(-20, -150, 32, 22, 9, 0xE5484DFFu);
        o_rect(-36, -62, 76, 18, 8, 0x26262FFFu); d_rect(-30, -58, 64, 5, 2, 0xE5484DFFu); o_rect(24, -84, 16, 9, 4, 0x30303EFFu); break;
    case 11: /* fir tree */
        o_rect(-9, -30, 18, 30, 3, 0x7A5232FFu); o_tri(-80, -28, 80, -28, 0, -116, 0x1F8F4BFFu); o_tri(-62, -86, 62, -86, 0, -168, 0x27A558FFu); o_tri(-44, -140, 44, -140, 0, -212, 0x33B866FFu);
        { static const i16 b[9][2] = { { -44, -44 }, { 6, -58 }, { 42, -40 }, { -24, -100 }, { 22, -106 }, { -4, -76 }, { -12, -156 }, { 14, -162 }, { 0, -132 } }; static const u32 bc[3] = { 0xFF5A5AFFu, 0xFFD23FFFu, 0x5CC3FFFFu };
          for (int i = 0; i < 9; i++) { int on = ((int)(t * 2.0f) + i) % 3 != 0; d_circ(b[i][0], b[i][1], 6.2f, OLC); d_circ(b[i][0], b[i][1], 4.6f, on ? bc[i % 3] : shade(bc[i % 3], -0.45f)); } }
        d_star(0, -220, 17, OLC); d_star(0, -220, 13, 0xFFD23FFFu); break;
    case 12: /* fireplace */
        o_rect(-95, -150, 190, 150, 5, 0xB5553CFFu); for (int r = 0; r < 6; r++) for (int c = 0; c < 5; c++) d_rect(-93 + (float)c * 38 + ((r & 1) ? 0 : 18), -146 + (float)r * 25, 2.5f, 23, 0, 0x8E3F2CFFu);
        for (int r = 1; r < 6; r++) d_rect(-95, -150 + (float)r * 25, 190, 2.5f, 0, 0x8E3F2CFFu);
        o_rect(-52, -104, 104, 104, 10, 0x1A1420FFu); d_rect(-52, -8, 104, 8, 0, 0x1A1420FFu);
        for (int i = 0; i < 5; i++) { float fx = -30 + (float)i * 15, fh = 38 + sinf(t * 7.0f + (float)i * 1.9f) * 12 + (i == 2 ? 20 : 0); d_tri(fx - 13, -10, fx + 13, -10, fx + sinf(t * 5 + (float)i) * 5, -10 - fh, 0xFF8A1EFFu); d_tri(fx - 7, -10, fx + 7, -10, fx, -10 - fh * 0.55f, 0xFFE06AFFu); }
        o_line(-34, -8, 30, -12, 6, 0x7A5232FFu); o_line(-26, -14, 36, -7, 6, 0x8E5A2CFFu); o_rect(-106, -172, 212, 24, 5, 0xE8D8C0FFu); d_rect(-106, -154, 212, 6, 0, 0xC9B79AFFu); break;
    case 13: /* garland of lamps */
        d_curve(-150, -22, -75, 30, 0, -14, 1.6f, OLC); d_curve(0, -14, 75, 30, 150, -22, 1.6f, OLC);
        for (int i = 0; i < 10; i++) { float q = ((float)i + 0.5f) / 10.0f, half = q < 0.5f ? q * 2 : (q - 0.5f) * 2, u = 1.0f - half, bx = (q < 0.5f ? -150 : 0) + half * 150, by = u * u * (q < 0.5f ? -22.0f : -14.0f) + 2 * u * half * 30.0f + half * half * (q < 0.5f ? -14.0f : -22.0f);
            static const u32 gc[5] = { 0xFF5A5AFFu, 0xFFD23FFFu, 0x5CE06AFFu, 0x5CC3FFFFu, 0xFF6FC2FFu }; int on = ((int)(t * 2.5f) + i) % 4 != 0;
            if (on) d_glow(bx, by + 9, 16, gc[i % 5]); d_ell(bx, by + 9, 6.5f, 8.5f, OLC); d_ell(bx, by + 9, 5, 7, on ? gc[i % 5] : shade(gc[i % 5], -0.5f)); } break;
    case 14: /* snowman */
        o_circ(0, -34, 36, 0xF6FAFFFFu); o_circ(0, -84, 26, 0xF6FAFFFFu); o_circ(0, -120, 19, 0xF6FAFFFFu); d_line(-24, -88, -46, -106, 2.2f, 0x7A5232FFu); d_line(24, -88, 46, -106, 2.2f, 0x7A5232FFu);
        o_rect(-22, -106, 44, 9, 4, 0xE5484DFFu); o_rect(8, -102, 9, 24, 4, 0xE5484DFFu); d_circ(-7, -124, 2.6f, OLC); d_circ(7, -124, 2.6f, OLC); o_tri(0, -120, 0, -113, 20, -115, 0xFF8A1EFFu);
        o_quad(-13, -152, 13, -152, 17, -134, -17, -134, 0x8A8FA6FFu); d_circ(0, -84, 3, OLC); d_circ(0, -70, 3, OLC); d_circ(0, -40, 3, OLC); break;
    case 15: /* rocking chair */
        d_curve(-62, -16, 0, 12, 62, -16, 5.4f, OLC); d_curve(-62, -16, 0, 12, 62, -16, 3.2f, WOOD1); o_line(-32, -6, -36, -58, 4, WOOD2); o_line(32, -6, 36, -58, 4, WOOD2);
        o_line2(-40, -60, -54, -130, 8, 6, WOOD1); o_line2(-36, -72, -46, -122, 6.5f, 5, 0xE5484DFFu); o_rect(-46, -68, 90, 13, 6, WOOD1); o_rect(-38, -76, 74, 10, 5, 0xE5484DFFu);
        o_line(-46, -96, 38, -92, 4, WOOD2); o_line(38, -92, 38, -62, 4, WOOD2); break;
    case 16: /* streamer's desk */
        o_rect(-110, -70, 14, 70, 3, 0x22222EFFu); o_rect(96, -70, 14, 70, 3, 0x22222EFFu); o_rect(56, -64, 36, 60, 5, 0x30303EFFu); for (int i = 0; i < 3; i++) d_rect(62, -56 + (float)i * 16, 24, 5, 2, color_lerp(0xFF4FB8FFu, 0x46E6FFFFu, 0.5f + 0.5f * sinf(t * 2 + (float)i)));
        o_rect(-113, -80, 226, 13, 5, 0x30303EFFu); d_rect(-113, -70, 226, 3, 0, 0xA98BFFFFu);
        d_rect(-30, -92, 12, 12, 0, OLC); o_rect(-78, -156, 108, 66, 5, 0x22222EFFu); d_grad(-72, -150, 96, 54, 2, 0x8E6BE8FFu, 0x3A2A8CFFu); d_tri(-36, -136, -36, -110, -12, -123, 0xFFFFFFE0u);
        o_rect(-70, -86, 80, 7, 3, 0x4A4A5AFFu); for (int i = 0; i < 6; i++) d_rect(-66 + (float)i * 12.5f, -85, 9, 3, 1, i % 2 ? 0xFF4FB8FFu : 0x46E6FFFFu); o_ell(30, -84, 9, 5, 0x4A4A5AFFu);
        o_rect(48, -116, 22, 36, 5, 0xE5484DFFu); d_rect(52, -108, 14, 9, 2, 0xFFFFFFE0u); break;
    case 17: /* microphone */
        d_line(0, -10, -22, 0, 3.4f, OLC); d_line(0, -10, 22, 0, 3.4f, OLC); d_line(0, -10, 0, -112, 3.4f, OLC); d_line(0, -10, 0, -112, 1.6f, 0x8A8FA6FFu); o_line(0, -112, 12, -126, 3, 0x4A4A5AFFu);
        o_rect(4, -158, 24, 40, 11, 0x4A4A5AFFu); for (int i = 0; i < 4; i++) d_rect(7, -152 + (float)i * 7, 18, 2.4f, 1, 0x9A9FB6FFu); d_ring(-10, -140, 15, 2.8f, OLC); d_circ(-10, -140, 13, 0x30303E60u); break;
    case 18: /* the LIVE sign */
        d_glow(0, 0, 100, 0xFF4040FFu); o_rect(-78, -36, 156, 72, 16, 0xD9363EFFu); d_rect(-70, -28, 140, 56, 11, (fmodf(t, 1.6f) < 1.2f) ? 0xFF5A5AFFu : 0xE04848FFu); d_circ(-46, 0, 9, 0xFFFFFFFFu); d_text(&F_ui, "LIVE", 16, 1, 36, 0xFFFFFFFFu); break;
    case 19: /* speaker */
        o_rect(-38, -136, 76, 136, 8, 0x26262FFFu); o_circ(0, -98, 16, 0x4A4A5AFFu); d_circ(0, -98, 6, 0x15151CFFu); o_circ(0, -42, 27 + sinf(t * 9.0f) * 0.8f, 0x4A4A5AFFu); d_ring(0, -42, 17, 3, 0x30303EFFu); d_circ(0, -42, 8, 0x15151CFFu); d_circ(28, -128, 2.2f, 0x5CE06AFFu); break;
    case 20: /* ring lamp */
        d_line(0, -12, -24, 0, 3.4f, OLC); d_line(0, -12, 24, 0, 3.4f, OLC); d_line(0, -12, 0, -124, 3.4f, OLC); d_line(0, -12, 0, -124, 1.6f, 0x8A8FA6FFu);
        d_glow(0, -160, 60, 0xFFFFFFFFu); d_ring(0, -160, 30, 15, OLC); d_ring(0, -160, 30, 9.5f, 0xFFFBE6FFu); o_rect(-7, -131, 14, 10, 3, 0x4A4A5AFFu); break;
    case 21: /* aquarium */
        o_rect(-70, -56, 140, 56, 5, 0x5A3A22FFu); d_rect(-62, -48, 124, 40, 3, 0x7A5232FFu); o_rect(-78, -156, 156, 100, 5, 0x9ADFFFFFu); d_grad(-74, -142, 148, 82, 2, 0x5CC3FFFFu, 0x2B7FD8FFu); d_rect(-74, -64, 148, 6, 0, 0xE8D090FFu);
        d_curve(-50, -60, -58, -84, -46, -104, 2.6f, 0x2FAE6AFFu); d_curve(-40, -60, -34, -80, -42, -94, 2.4f, 0x4FC468FFu); d_curve(52, -60, 58, -78, 48, -98, 2.6f, 0x2FAE6AFFu);
        for (int i = 0; i < 2; i++) { float ph = t * (i ? 0.5f : 0.36f) + (float)i * 2.0f, fx = sinf(ph) * 44, fyy = -112 + (float)i * 24 + sinf(ph * 2.3f) * 5, dir = cosf(ph) > 0 ? 1.0f : -1.0f; u32 fc = i ? 0xFFD23FFFu : 0xFF8A1EFFu;
            d_tri(fx - dir * 9, fyy, fx - dir * 20, fyy - 8, fx - dir * 20, fyy + 8, fc); d_ell(fx, fyy, 12, 7.5f, fc); d_circ(fx + dir * 6, fyy - 2, 1.8f, OLC); }
        for (int i = 0; i < 3; i++) { float p = fmodf(t * 0.4f + (float)i * 0.37f, 1.0f); d_ring(20 + (float)i * 9, -66 - p * 70, 3.2f, 1.2f, 0xFFFFFFB0u); }
        d_tri(-74, -142, -40, -142, -74, -100, 0xFFFFFF28u); d_rect(-78, -156, 156, 9, 3, 0x30303EFFu); break;
    case 22: /* bookcase */
        o_rect(-73, -236, 146, 236, 5, WOOD2); for (int r = 0; r < 4; r++) { float sy = -228 + (float)r * 57; d_rect(-65, sy, 130, 49, 2, 0x5A3A22FFu);
            float bx = -63; for (int i = 0; i < 9 && bx < 52; i++) { u32 h = mhash((u32)(r * 16 + i), 77); float bw = 9 + (float)(h % 7u), bh = 30 + (float)((h >> 4) % 15u); static const u32 bc[6] = { 0xE5484DFFu, 0x3D7BE8FFu, 0x2FAE6AFFu, 0xFFC93CFFu, 0x8E6BE8FFu, 0xF4F4F8FFu };
                if (r == 2 && i == 4) { d_circ(bx + 12, sy + 49 - 13, 12, 0xFFD23FFFu); bx += 28; continue; } d_rect(bx, sy + 49 - bh, bw, bh, 1.5f, bc[(h >> 8) % 6u]); d_rect(bx + 2, sy + 49 - bh + 6, bw - 4, 2.5f, 0, 0xFFFFFF70u); bx += bw + 1.5f; } } break;
    case 23: { /* clock: shows the time of Moscow */
        u32 now = now_s(), sec = now ? (now + MSK) % 86400u : (u32)(t * 60.0f) % 86400u; float hh = (float)(sec % 43200u) / 43200.0f * TAU, mm = (float)(sec % 3600u) / 3600.0f * TAU;
        o_circ(0, 0, 37, 0xE5484DFFu); d_circ(0, 0, 30, 0xFFFDF4FFu); for (int i = 0; i < 12; i++) { float a = (float)i * TAU / 12; d_circ(sinf(a) * 25, -cosf(a) * 25, i % 3 ? 1.3f : 2.4f, OLC); }
        d_line(0, 0, sinf(hh) * 14 * DX.f, -cosf(hh) * 14, 2.6f, OLC); d_line(0, 0, sinf(mm) * 22 * DX.f, -cosf(mm) * 22, 1.8f, OLC); d_circ(0, 0, 3.2f, 0xE5484DFFu); } break;
    case 24: /* floor lamp */
        o_ell(0, -6, 26, 7, 0x4A4A5AFFu); d_line(0, -8, 0, -160, 4.0f, OLC); d_line(0, -8, 0, -160, 2.0f, 0xC9A650FFu); d_glow(0, -176, 70, 0xFFE680FFu); o_quad(-22, -216, 22, -216, 37, -158, -37, -158, 0xFFE9A8FFu); d_quad(-12, -210, -4, -210, -8, -164, -26, -164, 0xFFFFFF60u); break;
    case 25: { /* cat */
        float wag = sinf(t * 2.2f) * 12, bl = fmodf(t, 4.2f) > 4.05f;
        d_curve(22, -10, 46, -14 + wag * 0.3f, 40, -44 + wag, 6.5f, OLC); d_curve(22, -10, 46, -14 + wag * 0.3f, 40, -44 + wag, 4.2f, 0xF09A3EFFu);
        o_ell(4, -22, 26, 22, 0xF09A3EFFu); d_ell(4, -12, 14, 12, 0xFFE2C0FFu); o_tri(-31, -52, -28, -74, -13, -62, 0xF09A3EFFu); o_tri(-11, -63, 3, -75, 6, -53, 0xF09A3EFFu); o_circ(-13, -46, 19, 0xF09A3EFFu); d_tri(-28, -56, -26, -68, -19, -61, 0xFFB0B8FFu); d_tri(-4, -62, 2, -69, 3, -57, 0xFFB0B8FFu);
        if (bl) { d_line(-23, -48, -17, -48, 1.4f, OLC); d_line(-9, -48, -3, -48, 1.4f, OLC); } else { d_ell(-20, -48, 3.2f, 4.2f, 0x2FAE3AFFu); d_ell(-6, -48, 3.2f, 4.2f, 0x2FAE3AFFu); d_ell(-20, -48, 1.2f, 3.6f, OLC); d_ell(-6, -48, 1.2f, 3.6f, OLC); }
        d_tri(-15.5f, -42, -10.5f, -42, -13, -39, 0xFF7A8EFFu); d_line(-20, -40, -34, -42, 0.8f, OLC); d_line(-6, -40, 8, -42, 0.8f, OLC); d_ell(-6, -3, 7, 4, 0xFFE2C0FFu); d_ell(12, -3, 7, 4, 0xFFE2C0FFu); } break;
    case 26: /* fridge */
        o_rect(-58, -226, 116, 226, 10, 0xEDF2F8FFu); d_rect(-58, -150, 116, 4, 0, 0xB9C4D4FFu); o_rect(36, -206, 8, 42, 4, 0xB9C4D4FFu); o_rect(36, -134, 8, 60, 4, 0xB9C4D4FFu);
        d_rect(-44, -120, 22, 26, 3, 0xFFD23FFFu); d_circ(-8, -106, 8, 0xE5484DFFu); d_star(-30, -70, 9, 0x5CC3FFFFu); d_rect(-52, -220, 8, 190, 4, 0xFFFFFFA0u); d_rect(-58, -6, 116, 6, 0, 0xB9C4D4FFu); break;
    case 27: /* palm */
        o_line2(4, -40, -8, -176, 11, 7, 0xB98A4AFFu); for (int i = 0; i < 5; i++) d_line(-8 + (float)i * 1.2f, -62 - (float)i * 24, 10 - (float)i * 1.4f, -66 - (float)i * 24, 1.6f, 0x8E6A32FFu);
        { static const i16 lf[6][2] = { { -66, -168 }, { 62, -172 }, { -54, -214 }, { 48, -220 }, { -4, -246 }, { 68, -130 } }; for (int i = 0; i < 6; i++) { o_line2(-8, -178, lf[i][0], lf[i][1], 12, 3.0f, i & 1 ? 0x2F9E55FFu : 0x3FB866FFu); d_line(-8, -178, lf[i][0] * 0.8f - 1.6f, lf[i][1] * 0.8f - 35.6f, 1.2f, 0x1F7F4BFFu); } }
        o_circ(-8, -178, 8, 0x8E6A32FFu); o_quad(-30, -46, 30, -46, 23, 0, -23, 0, 0x5C8FD9FFu); o_rect(-33, -52, 66, 11, 4, 0x7FB0F0FFu); break;
    case 28: /* guitar on a stand */
        d_line(-22, 0, 0, -30, 3, OLC); d_line(22, 0, 0, -30, 3, OLC); o_rect(-5, -146, 10, 84, 3, 0x5A3A22FFu); o_rect(-9, -150, 18, 20, 4, 0x30303EFFu);
        o_ell(0, -34, 27, 24, 0xE08A3CFFu); o_ell(0, -66, 20, 17, 0xE08A3CFFu); d_ell(0, -50, 20, 14, 0xE08A3CFFu); d_circ(0, -50, 8.5f, 0x3A2416FFu); d_rect(-9, -26, 18, 5, 2, 0x3A2416FFu);
        for (int i = 0; i < 3; i++) d_line(-2.4f + (float)i * 2.4f, -140, -2.4f + (float)i * 2.4f, -24, 0.5f, 0xF4F4F8FFu); break;
    case 29: /* cup on a column */
        o_rect(-30, -70, 60, 70, 4, 0xE8D8C0FFu); o_rect(-36, -78, 72, 12, 4, 0xF6EBD8FFu); o_rect(-36, -10, 72, 10, 3, 0xF6EBD8FFu); d_rect(-20, -62, 5, 48, 2, 0xC9B79AFFu); d_rect(15, -62, 5, 48, 2, 0xC9B79AFFu);
        d_ring(-25, -128, 11, 6.5f, OLC); d_ring(25, -128, 11, 6.5f, OLC); d_ring(-25, -128, 11, 3, 0xFFD23FFFu); d_ring(25, -128, 11, 3, 0xFFD23FFFu);
        o_rect(-14, -88, 28, 9, 3, 0xE39A12FFu); o_rect(-4, -106, 8, 20, 2, 0xFFD23FFFu); o_quad(-26, -152, 26, -152, 15, -104, -15, -104, 0xFFD23FFFu); o_ell(0, -152, 26, 6, 0xFFE680FFu); d_quad(-17, -146, -10, -146, -8, -112, -11, -112, 0xFFFFFF90u); d_star(4, -128, 8, 0xE39A12FFu); break;
    case 30: /* disco ball */
        d_line(0, 0, 0, 44, 1.6f, OLC);
        for (int i = 0; i < 6; i++) { float a = t * 0.6f + (float)i * TAU / 6; d_tri(0, 74, cosf(a) * 150, 74 + fabsf(sinf(a)) * 120 + 30, cosf(a + 0.14f) * 150, 74 + fabsf(sinf(a + 0.14f)) * 120 + 30, color_alpha((i & 1) ? 0xFF6FC2FFu : 0x5CC3FFFFu, 0.2f)); }
        o_circ(0, 74, 32, 0xC8CEDEFFu); for (int i = -2; i <= 2; i++) { float yy = (float)i * 11.5f, hw = sqrtf(32.0f * 32.0f - yy * yy) - 2; d_line(-hw, 74 + yy, hw, 74 + yy, 0.7f, 0x8A90A6FFu); }
        d_curve(0, 43, -44, 74, 0, 105, 0.7f, 0x8A90A6FFu); d_curve(0, 43, 44, 74, 0, 105, 0.7f, 0x8A90A6FFu); d_line(0, 43, 0, 105, 0.7f, 0x8A90A6FFu); d_circ(-10, 62, 9, 0xFFFFFF70u);
        for (int i = 0; i < 7; i++) { float a = t * 1.1f + (float)i * 0.9f, px = cosf(a) * 20 * cosf((float)i), py = 74 + sinf((float)i * 2.1f) * 22; if (sinf(a * 2 + (float)i) > 0.2f) d_star(px, py, 5.5f, 0xFFFFFFFFu); } break;
    case 31: /* jacuzzi */
        o_rect(-113, -70, 226, 70, 16, 0xF4F4FAFFu); d_rect(-113, -22, 226, 8, 0, 0xC9D4E4FFu); o_ell(0, -70, 100, 15, 0x5CC3FFFFu); d_ell(0, -70, 84, 10, 0x9ADFFFFFu);
        for (int i = 0; i < 7; i++) { float p = fmodf(t * 0.7f + (float)i * 0.31f, 1.0f), bx = -70 + (float)i * 23 + sinf(t + (float)i) * 4; d_ring(bx, -72 - p * 34, 3 + p * 3.5f, 1.3f, color_alpha(0xFFFFFFFFu, 1.0f - p)); }
        o_line(84, -78, 84, -102, 3.5f, 0xC9D4E4FFu); o_line(84, -102, 66, -102, 3.5f, 0xC9D4E4FFu); d_rect(-90, -52, 180, 6, 3, 0x5CC3FF80u); d_circ(-86, -36, 4.5f, 0x5CC3FFFFu); d_circ(-70, -36, 4.5f, 0xE5484DFFu); break;
    case 32: /* safe */
        o_rect(-58, -126, 116, 120, 9, 0x5A6072FFu); o_rect(-46, -114, 92, 96, 6, 0x767D92FFu); d_ring(-8, -66, 21, 5.5f, OLC); d_ring(-8, -66, 21, 2.6f, 0xD8DCE8FFu); for (int i = 0; i < 4; i++) { float a = t * 0.25f + (float)i * PI / 2; d_line(-8, -66, -8 + cosf(a) * 28, -66 + sinf(a) * 28, 2.4f, OLC); d_circ(-8 + cosf(a) * 28, -66 + sinf(a) * 28, 4.2f, 0xD8DCE8FFu); }
        d_circ(-8, -66, 6, 0xD8DCE8FFu); o_rect(22, -96, 18, 24, 3, 0x30303EFFu); d_rect(25, -93, 12, 6, 1, 0x5CE06AFFu); d_rect(-52, -106, 5, 16, 2, 0x30303EFFu); d_rect(-52, -42, 5, 16, 2, 0x30303EFFu);
        o_rect(-50, -8, 16, 8, 2, 0x30303EFFu); o_rect(34, -8, 16, 8, 2, 0x30303EFFu); o_ell(42, -5, 11, 4.5f, 0xFFD23FFFu); o_ell(46, -11, 11, 4.5f, 0xFFD23FFFu); o_ell(41, -17, 11, 4.5f, 0xFFE680FFu); break;
    case 33: /* the golden Mel */
        o_rect(-42, -30, 84, 30, 4, 0xE8D8C0FFu); o_rect(-48, -40, 96, 12, 4, 0xF6EBD8FFu); d_text(&F_ui, "MEL", 0, -15, 15, 0xA08A60FFu);
        o_line(-12, -44, -13, -84, 9, 0xFFD23FFFu); o_line(12, -44, 13, -84, 9, 0xFFD23FFFu); o_rect(-24, -134, 48, 56, 14, 0xFFD23FFFu); o_line(-26, -124, -40, -96, 7.5f, 0xFFD23FFFu); o_line(26, -126, 44, -160, 7.5f, 0xFFD23FFFu);
        o_rect(38, -190, 14, 30, 5, 0xFFE680FFu); d_rect(42, -198, 6, 10, 2, 0xFFE680FFu); o_circ(0, -160, 27, 0xFFD23FFFu); d_ell(-2, -180, 26, 11, 0xE39A12FFu); d_circ(-9, -158, 3, 0xA86A08FFu); d_circ(9, -158, 3, 0xA86A08FFu);
        d_curve(-9, -148, 0, -141, 9, -148, 1.6f, 0xA86A08FFu); d_ell(-12, -122, 5, 16, 0xFFFFFF80u); if (fmodf(t, 2.4f) < 0.5f) d_star(28, -178, 9 * sinf(fmodf(t, 2.4f) * TAU), 0xFFFFFFFFu); break;
    case 34: /* telescope */
        d_line(0, -84, -34, 0, 3.6f, OLC); d_line(0, -84, 34, 0, 3.6f, OLC); d_line(0, -84, 4, 0, 3.6f, OLC); d_line(0, -84, -34, 0, 1.7f, 0xC9A650FFu); d_line(0, -84, 34, 0, 1.7f, 0xC9A650FFu); d_line(0, -84, 4, 0, 1.7f, 0xC9A650FFu);
        o_line2(-40, -66, 42, -150, 9, 15, 0x3D7BE8FFu); d_line(-26, -86, -8, -104, 10.5f, 0xFFD23FFFu); o_line(-40, -66, -52, -54, 5, 0x30303EFFu); o_circ(46, -154, 15, 0x9ADFFFFFu); d_circ(42, -158, 5, 0xFFFFFFC0u); o_circ(0, -86, 7, 0x30303EFFu); break;
    case 35: /* chandelier */
        d_line(0, 0, 0, 36, 2.6f, OLC); d_line(0, 0, 0, 36, 1.2f, 0xFFD23FFFu); o_ell(0, 44, 15, 9, 0xFFD23FFFu);
        for (int i = 0; i < 5; i++) { float ax = ((float)i - 2) * 36; d_curve(0, 50, ax * 0.6f, 96, ax, 76, 4.0f, OLC); d_curve(0, 50, ax * 0.6f, 96, ax, 76, 2.0f, 0xFFD23FFFu); }
        for (int i = 0; i < 5; i++) { float ax = ((float)i - 2) * 36; d_glow(ax, 54, 34, 0xFFE680FFu); o_rect(ax - 4, 60, 8, 18, 2, 0xFFFDF4FFu); d_ell(ax, 54, 4.5f, 8 + sinf(t * 8 + (float)i * 2) * 1.2f, 0xFFB648FFu); d_ell(ax, 56, 2.2f, 4.5f, 0xFFF3B0FFu); o_tri(ax - 4.5f, 84, ax + 4.5f, 84, ax, 100, 0xBFE9FFFFu); }
        o_tri(-7, 96, 7, 96, 0, 114, 0xBFE9FFFFu); break;
    }
}
/* a small picture of a thing inside a box of this size (lists, prizes) */
static void item_icon(int id, float cx, float cy, float box) {
    const ItemDef *d = &item_tab[id]; float s = minf(box / (float)d->w, box / (float)d->h), y = cy + (float)d->h * s * 0.5f;
    if (d->kind == IK_WALL) y = cy; else if (d->kind == IK_CEIL) y = cy - (float)d->h * s * 0.5f; else if (d->kind == IK_RUG) y = cy + (float)d->h * s * 0.5f;
    item_draw(id, cx, y, s, 0);
}
