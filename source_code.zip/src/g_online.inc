/* ============================================================================
   «МЕЛ-НЯМ» — replays, personal records, the online table (Google Sheet behind an
   Apps Script web app), text input, the level editor and levels made by players.
   Included by game.c (one translation unit).
   ============================================================================ */
#ifndef ONLINE_CFG_URL
#define ONLINE_CFG_URL "https://timofeybahvalov-cell.github.io/mel-nyam/online.json"
#endif
#define NET_SALT "mel-nyam/v2/4eKywka"
#include "sha256.h"

/* ============================== small text helpers ============================== */
static u32 u8_next(const char **ps) {
    const unsigned char *s = (const unsigned char *)*ps; u32 c = *s; if (!c) return 0; s++;
    if (c >= 0xF0 && s[0] && s[1] && s[2]) { c = (c & 7u) << 18 | (s[0] & 63u) << 12 | (s[1] & 63u) << 6 | (s[2] & 63u); s += 3; }
    else if (c >= 0xE0 && s[0] && s[1]) { c = (c & 15u) << 12 | (s[0] & 63u) << 6 | (s[1] & 63u); s += 2; }
    else if (c >= 0xC0 && s[0]) { c = (c & 31u) << 6 | (s[0] & 63u); s += 1; }
    *ps = (const char *)s; return c;
}
static int u8_put(char *o, u32 c) {
    if (c < 0x80) { o[0] = (char)c; return 1; }
    if (c < 0x800) { o[0] = (char)(0xC0 | (c >> 6)); o[1] = (char)(0x80 | (c & 63)); return 2; }
    if (c < 0x10000) { o[0] = (char)(0xE0 | (c >> 12)); o[1] = (char)(0x80 | ((c >> 6) & 63)); o[2] = (char)(0x80 | (c & 63)); return 3; }
    o[0] = (char)(0xF0 | (c >> 18)); o[1] = (char)(0x80 | ((c >> 12) & 63)); o[2] = (char)(0x80 | ((c >> 6) & 63)); o[3] = (char)(0x80 | (c & 63)); return 4;
}
static int u8_len(const char *s) { int n = 0; while (u8_next(&s)) n++; return n; }
static void u8_pop(char *s) { int n = (int)strlen(s); if (!n) return; n--; while (n > 0 && ((unsigned char)s[n] & 0xC0) == 0x80) n--; s[n] = 0; }
/* characters a nick (kind 0), a level name (kind 1), a password (kind 2) or a message (kind 3) may contain: the font has exactly these */
static int cp_allowed(u32 c, int kind) {
    if (kind == 3) return (c >= 32 && c <= 126) || (c >= 0x410 && c <= 0x44F) || c == 0x401 || c == 0x451 || c == 0xAB || c == 0xBB || c == 0x2014 || c == 0x2013 || c == 0x2026 || c == 0x2116;
    if (kind == 2) return (c >= 33 && c <= 126) || (c >= 0x410 && c <= 0x44F) || c == 0x401 || c == 0x451;
    if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= 0x410 && c <= 0x44F) || c == 0x401 || c == 0x451 || c == '_' || c == '-') return 1;
    return kind == 1 && (c == ' ' || c == '!' || c == '?' || c == '.' || c == ',');
}
static void text_clean(char *dst, int max, const char *src, int maxc) {        /* whatever comes from the network is reduced to the allowed characters */
    int n = 0, k = 0; u32 c;
    while ((c = u8_next(&src)) != 0 && k < maxc && n + 5 < max) { if (!cp_allowed(c, 1)) c = '?'; n += u8_put(dst + n, c); k++; }
    dst[n] = 0;
}
/* what a new password must have: 1 eight characters or more, 2 a capital letter, 4 a small letter, 8 a digit, 16 a sign (31 = everything) */
static int pw_rules(const char *s) {
    int r = 0, n = 0; u32 c;
    while ((c = u8_next(&s)) != 0) {
        n++;
        if ((c >= 'A' && c <= 'Z') || (c >= 0x410 && c <= 0x42F) || c == 0x401) r |= 2;
        else if ((c >= 'a' && c <= 'z') || (c >= 0x430 && c <= 0x44F) || c == 0x451) r |= 4;
        else if (c >= '0' && c <= '9') r |= 8;
        else r |= 16;
    }
    return r | (n >= 8 ? 1 : 0);
}
static u32 fnv_str(u32 h, const char *s) { while (*s) { h = (h ^ (u8)*s++) * 16777619u; } return h; }
static u32 fnv_mem(u32 h, const void *p, int n) { const u8 *b = (const u8 *)p; for (int i = 0; i < n; i++) h = (h ^ b[i]) * 16777619u; return h; }

/* ============================== replays ============================== */
static u32 objs_hash(const LObj *o) {
    u32 h = 2166136261u ^ (u32)SIM_VERSION;
    for (; o->type != O_END; o++) { int v[8] = { o->type, (int)(o->x * 10), (int)(o->y * 10), (int)(o->a * 10), (int)(o->b * 10), (int)(o->c * 100), (int)(o->d * 100), (int)(o->e * 100) }; h = fnv_mem(h, v, (int)sizeof(v)); }
    return h;
}
/* the online key of a built-in level: its number plus a hash of its layout, so records of a changed level start from scratch */
static void level_key(int idx, char *out, int n) { snprintf(out, (size_t)n, "b%02d-%04x", idx, (unsigned)(objs_hash(g_levels[idx].objs) & 0xFFFFu)); }
static int replay_encode(const Replay *r, char *out, int max) {              /* "ticks_stars_hex..." (nothing a spreadsheet could mistake for a number or a date) */
    int n = snprintf(out, (size_t)max, "%d_%d_", r->ticks, r->stars);
    for (int i = 0; i < r->n && n + 9 < max; i++) n += snprintf(out + n, (size_t)(max - n), "%08x", (unsigned)r->a[i]);
    return n;
}
static int replay_decode(const char *s, Replay *r) {
    int t = 0, st = 0, pos = 0; memset(r, 0, sizeof(*r));
    if (sscanf(s, "%d_%d_%n", &t, &st, &pos) < 2 || pos == 0 || t < 1 || t >= (1 << 17) || st < 0 || st > MAX_STARS) return 0;
    r->ticks = t; r->stars = st; s += pos;
    while (r->n < REC_MAX) {
        u32 v = 0; int k;
        for (k = 0; k < 8; k++) { char c = s[k]; int d = (c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10 : -1; if (d < 0) break; v = v << 4 | (u32)d; }
        if (k < 8) break;
        r->a[r->n++] = v; s += 8;
    }
    return 1;
}
/* run a recording through the bare simulation: does it really end in Mel's mouth with that many stars at that tick? */
static int replay_check(const LObj *objs, const Replay *r) {
    static Sim T; int i = 0; sim_load(&T, objs);
    for (int n = 0; n <= r->ticks + 2 && T.state == ST_PLAY; n++) {
        while (i < r->n && (int)(r->a[i] >> 15) <= T.tick) { sim_act(&T, (int)((r->a[i] >> 12) & 7u), (int)(r->a[i] & 4095u)); i++; }
        sim_step(&T);
    }
    return T.state == ST_EATEN && T.tick == r->ticks && T.stars == r->stars;
}
#define REPLAY_MAGIC 0x52504C4Du
static void replay_save(const char *key, const Replay *r, u32 lhash) {
    static u32 buf[5 + REC_MAX];
    buf[0] = REPLAY_MAGIC; buf[1] = lhash; buf[2] = (u32)r->ticks; buf[3] = (u32)r->stars; buf[4] = (u32)r->n; memcpy(buf + 5, r->a, sizeof(u32) * (size_t)r->n);
    plat_store(key, buf, (int)(sizeof(u32) * (size_t)(5 + r->n)));
}
static int replay_load(const char *key, Replay *r, u32 lhash) {
    static u32 buf[5 + REC_MAX]; int n = plat_fetch(key, buf, (int)sizeof(buf));
    memset(r, 0, sizeof(*r));
    if (n < 20 || buf[0] != REPLAY_MAGIC || buf[1] != lhash || buf[4] > REC_MAX || n < (int)(sizeof(u32) * (5 + buf[4]))) return 0;
    r->ticks = (int)buf[2]; r->stars = (int)buf[3]; r->n = (int)buf[4]; memcpy(r->a, buf + 5, sizeof(u32) * (size_t)r->n);
    return 1;
}
static void own_key(int idx, char *k) { snprintf(k, 8, "r%02d", idx); }

/* ============================== modal: text input, messages, toast ============================== */
static struct { int on, kind, maxc, lang, shift, show, rules; char title[120], buf[640], err[120]; void (*done)(const char *); } KB;      /* kind 2: a password (rules: it is a new one, so it must be strong); kind 3: a message */
static struct { int on; char title[96], text[640]; } MSGB;
static char g_toast[160]; static float g_toast_t;
static void gtoast(const char *s) { snprintf(g_toast, sizeof(g_toast), "%s", s); g_toast_t = 3.0f; }
static void msg_open(const char *title, const char *text) { MSGB.on = 1; snprintf(MSGB.title, sizeof(MSGB.title), "%s", title); snprintf(MSGB.text, sizeof(MSGB.text), "%s", text); }
static void kb_open(const char *title, const char *init, int maxc, int kind, void (*done)(const char *)) {
    memset(&KB, 0, sizeof(KB)); KB.on = 1; KB.kind = kind; KB.maxc = maxc; KB.done = done;
    snprintf(KB.title, sizeof(KB.title), "%s", title);
    if (init && kind == 3) snprintf(KB.buf, sizeof(KB.buf), "%s", init); else if (init && kind != 2) text_clean(KB.buf, (int)sizeof(KB.buf), init, maxc);
    if (kind == 2) KB.lang = 1;                          /* passwords: Latin letters first */
}
static void kb_open_pw(const char *title, int rules, void (*done)(const char *)) { kb_open(title, NULL, 32, 2, done); KB.rules = rules; }
static void kb_put(u32 c) {
    int n = (int)strlen(KB.buf);
    if (!cp_allowed(c, KB.kind) || u8_len(KB.buf) >= KB.maxc || n + 5 >= (int)sizeof(KB.buf)) return;
    if (c == ' ' && (n == 0 || KB.buf[n - 1] == ' ')) return;
    KB.buf[n + u8_put(KB.buf + n, c)] = 0; KB.err[0] = 0; sfx(S_TICK, 0.5f, 640);
}
static void kb_ok(void) {
    int n = (int)strlen(KB.buf); while (n > 0 && KB.buf[n - 1] == ' ') KB.buf[--n] = 0;
    if (KB.kind == 2) {
        int r = KB.rules ? pw_rules(KB.buf) : 31;
        if (!KB.buf[0]) { snprintf(KB.err, sizeof(KB.err), "Введи пароль"); sfx(S_TICK, 0.8f, 640); return; }
        if (r != 31) {
            snprintf(KB.err, sizeof(KB.err), "Не хватает: %s", !(r & 1) ? "длины, нужно 8 символов или больше" : !(r & 2) ? "заглавной буквы" : !(r & 4) ? "строчной буквы" : !(r & 8) ? "цифры" : "знака, например ! ? # _");
            sfx(S_TICK, 0.8f, 640); return;
        }
    } else if (KB.kind == 3) { if (!KB.buf[0]) { snprintf(KB.err, sizeof(KB.err), "Напиши хотя бы одно слово"); sfx(S_TICK, 0.8f, 640); return; } }
    else if (u8_len(KB.buf) < 2) { snprintf(KB.err, sizeof(KB.err), "Нужно хотя бы 2 символа"); sfx(S_TICK, 0.8f, 640); return; }
    KB.on = 0; if (KB.done) { static char t[640]; snprintf(t, sizeof(t), "%s", KB.buf); if (KB.kind == 2) memset(KB.buf, 0, sizeof(KB.buf)); KB.done(t); memset(t, 0, sizeof(t)); }
}
static u32 cp_upper(u32 c) { if (c >= 'a' && c <= 'z') return c - 32; if (c >= 0x430 && c <= 0x44F) return c - 0x20; if (c == 0x451) return 0x401; return c; }
static void kb_draw(void) {
    static const char *const rows[3][3] = { { "йцукенгшщзхъ", "фывапролджэ", "ячсмитьбюё" }, { "qwertyuiop", "asdfghjkl", "zxcvbnm" }, { "!@#$%^&*()+=", ".,:;?'\"/\\|", "<>[]{}~`" } };
    static const char *const lang_name[3] = { "РУС", "ENG", "#+=" };
    gfx_fade(0x0A0626C8u);
    panel(160, 56, 960, 608);
    title_text(KB.title, 640, 104, 34);
    gfx_rrect(300, 136, 680, 64, 22, 0x0E0A2EFFu); gfx_rrect(303, 139, 674, 58, 19, 0x2A1F6CFFu);
    static char shown[200]; const char *txt = KB.buf;
    if (KB.kind == 2 && !KB.show) { int n = u8_len(KB.buf), k = 0; for (int i = 0; i < n && k + 4 < (int)sizeof(shown); i++) k += u8_put(shown + k, 0x2022); shown[k] = 0; txt = shown; }      /* dots instead of the password */
    if (KB.kind == 3) {                                  /* a message: the last two lines of it are in view */
        const char *s = KB.buf; static char tail[660];
        for (;;) { snprintf(tail, sizeof(tail), "%s%s", s, fmodf(g_time, 1.0f) < 0.55f ? "|" : " "); if (gfx_text_wrap(&F_txt, tail, 640, 0, 21, 640, 26, 0, AL_CENTER, 0) <= 2 || !*s) break; for (int k = 0; k < 6 && *s; k++) u8_next(&s); }
        gfx_text_wrap(&F_txt, tail, 640, 143, 21, 640, 26, WHITE, AL_CENTER, 1);
    } else {
    float tsz = 36, tw = gfx_text_w(&F_ui, txt, tsz); if (tw > 560) { tsz *= 560 / tw; tw = 560; }
    gfx_text(&F_ui, txt, 640, 168, tsz, WHITE, AL_CENTER);
    if (fmodf(g_time, 1.0f) < 0.55f) gfx_rrect(640 + tw * 0.5f + 4, 150, 4, 36, 2, C_GOLD);
    }
    if (KB.kind == 2 && rbtn(376, 1022, 168, 26, KB.show ? IC_EYE : IC_EYE_OFF, C_BLUE1, C_BLUE2, 1)) KB.show = !KB.show;
    if (KB.err[0]) gfx_text(&F_txt, KB.err, 640, 218, 19, C_RED1, AL_CENTER);
    else if (KB.kind == 2 && KB.rules) {                 /* what a new password needs; a part turns green once it is there */
        static const char *const rn[5] = { "8+ символов", "Заглавная", "строчная", "цифра", "знак" }; int r = pw_rules(KB.buf); float x = 0, w[5], all = 0;
        for (int i = 0; i < 5; i++) { w[i] = gfx_text_w(&F_ui, rn[i], 18) + 44; all += w[i]; }
        x = 640 - all * 0.5f;
        for (int i = 0; i < 5; i++) { int ok = (r >> i) & 1; icon(ok ? IC_OK : IC_MINUS, x + 12, 218, 8, ok ? 0x9CF04EFFu : 0xFFFFFF70u); gfx_text(&F_ui, rn[i], x + 26, 218, 18, ok ? 0x9CF04EFFu : 0xFFFFFFB0u, AL_LEFT); x += w[i]; }
    }
    else { char cnt[32]; snprintf(cnt, sizeof(cnt), "%d / %d", u8_len(KB.buf), KB.maxc); gfx_text(&F_txt, cnt, 640, 218, 18, 0xFFFFFFA0u, AL_CENTER); }
    for (int r = 0; r < 4; r++) {
        const char *row = r == 0 ? "1234567890_-" : rows[KB.lang][r - 1]; int n = u8_len(row); float x = 640 - (n - 1) * 36.0f, y = 268 + r * 68.0f;
        for (int i = 0; i < n; i++, x += 72.0f) {
            u32 c = u8_next(&row); if (KB.shift) c = cp_upper(c);
            char lab[8]; lab[u8_put(lab, c)] = 0;
            if (wbtn(300 + r * 16 + i, x, y, 64, 58, lab, C_VIO1, C_VIO2, 32, IC_NONE, 1)) kb_put(c);
        }
    }
    float y = 268 + 4 * 68.0f + 4;
    /* capital letters: the key shows what the letter keys type now, in the alphabet of the layout; the key next to it shows the layout it switches to */
    int nlang = KB.kind >= 2 ? 3 : 2, next = (KB.lang + 1) % nlang;
    if (wbtn(370, 250, y, 110, 60, KB.lang == 1 ? (KB.shift ? "ABC" : "abc") : (KB.shift ? "АБВ" : "абв"), KB.shift ? C_ORG1 : C_BLUE1, KB.shift ? C_ORG2 : C_BLUE2, 26, IC_NONE, KB.lang != 2)) KB.shift = !KB.shift;
    if (wbtn(371, 372, y, 110, 60, lang_name[next], C_BLUE1, C_BLUE2, 26, IC_NONE, 1)) KB.lang = next;
    if (wbtn(372, 548, y, 218, 60, "пробел", C_VIO1, C_VIO2, 24, IC_NONE, KB.kind == 1 || KB.kind == 3)) kb_put(' ');
    if (wbtn(373, 730, y, 122, 60, "Стереть", C_RED1, C_RED2, 22, IC_NONE, 1)) { u8_pop(KB.buf); KB.err[0] = 0; }
    if (wbtn(374, 878, y, 150, 60, "Отмена", C_VIO1, C_VIO2, 24, IC_NONE, 1)) KB.on = 0;
    if (wbtn(375, 1030, y, 126, 60, "OK", C_GREEN1, C_GREEN2, 30, IC_NONE, 1)) kb_ok();
}
static void msg_draw(void) {
    gfx_fade(0x0A0626C8u);
    panel(300, 190, 680, 340);
    title_text(MSGB.title, 640, 246, 38);
    gfx_text_wrap(&F_txt, MSGB.text, 640, 310, 23, 600, 31, 0xE8E0FFFFu, AL_CENTER, 1);
    if (wbtn(400, 640, 470, 220, 68, "Понятно", C_GREEN1, C_GREEN2, 30, IC_NONE, 1)) MSGB.on = 0;
}
static int tas_modal_on(void); static void tas_modal_draw(void); static int tas_modal_key(int key);      /* the TAS search window (g_tas.inc) */
static int wn_on(void); static void wn_draw(void); static int wn_key(int key);                            /* the account, update and support windows (further below) */
static int modal_on(void) { return KB.on || MSGB.on || wn_on() || tas_modal_on() || ask_on(); }
static void modal_draw(void) {
    int was = ui_block; ui_block = (scr_next >= 0);
    if (KB.on) kb_draw(); else if (MSGB.on) msg_draw(); else if (ask_on()) ask_draw(); else if (wn_on()) wn_draw(); else if (tas_modal_on()) tas_modal_draw();
    ui_block = was;
    if (g_toast_t > 0) {
        g_toast_t -= g_dt; float a = clampf(g_toast_t / 0.3f, 0, 1), w = gfx_text_w(&F_ui, g_toast, 24) + 56;
        gfx_rrect(640 - w * 0.5f, 652, w, 46, 23, RGBA(14, 10, 46, (int)(225 * a))); gfx_text(&F_ui, g_toast, 640, 675, 24, RGBA(255, 255, 255, (int)(255 * a)), AL_CENTER);
    }
}
static void ui_char(u32 cp) { if (KB.on) kb_put(cp); }

/* ============================== network ============================== */
enum { NS_NONE, NS_CFG, NS_ON, NS_OFF, NS_ERR };      /* not asked yet / asking for the address / the table is reachable / no table configured / no connection */
enum { RQ_CFG = 1, RQ_TOP, RQ_SUB, RQ_REP, RQ_LIST, RQ_LEVEL, RQ_PUB, RQ_PING, RQ_ACC, RQ_OUT, RQ_MINE, RQ_HB,
       RQ_LOAD, RQ_SAVE, RQ_MSG, RQ_CHAT, RQ_MYLV, RQ_ADM, RQ_N };      /* V0.5: the progress in the account, the support chat, my levels; the owner's tool */
/* proto: what the table can do (the third field of its answer to a=ping): 0 not asked yet, 2 records and levels (V0.2, V0.3), 4 accounts as well,
   5 keeps the progress of an account, has the support chat and badges (V0.5) */
static struct { int st, forced, proto; char api[512], cfg[300]; float retry; int seq[RQ_N], busy[RQ_N]; } NET;
#ifdef MN_ADMIN
static char nbuf[1 << 19];                           /* the owner's tool reads the whole list of players at once */
#else
static char nbuf[1 << 16];
#endif
static int dbg_http_on, dbg_http_status, dbg_http_n; static char dbg_http_buf[4096];
static void url_enc(char *out, int max, const char *s) {
    int n = 0; for (; *s && n + 4 < max; s++) { unsigned char c = (unsigned char)*s;
        if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '-' || c == '_' || c == '.') out[n++] = (char)c; else n += snprintf(out + n, 4, "%%%02X", c); }
    out[n] = 0;
}
static void net_get(int kind, const char *query) {
    static char url[1400]; snprintf(url, sizeof(url), "%s%c%s", NET.api, strchr(NET.api, '?') ? '&' : '?', query);
    NET.busy[kind] = 1; plat_http(kind | (++NET.seq[kind] << 8), url, NULL, 0);
}
static void net_post(int kind, const char *body) { NET.busy[kind] = 1; plat_http(kind | (++NET.seq[kind] << 8), NET.api, body, (int)strlen(body)); }
static void net_cfg(void) {
    if (NET.forced || !(plat_caps() & 4)) { if (!NET.forced) NET.st = NS_OFF; return; }
    NET.st = NS_CFG; NET.busy[RQ_CFG] = 1; plat_http(RQ_CFG | (++NET.seq[RQ_CFG] << 8), NET.cfg[0] ? NET.cfg : ONLINE_CFG_URL, NULL, 0);
}
static char *nline(char **p) { char *s = *p; if (!s || !*s) return NULL; char *e = strchr(s, '\n'); if (e) { *e = 0; if (e > s && e[-1] == '\r') e[-1] = 0; *p = e + 1; } else *p = s + strlen(s); return s; }
static char *nfld(char **p) { char *s = *p; if (!s) return (char *)""; char *e = strchr(s, '\t'); if (e) { *e = 0; *p = e + 1; } else *p = NULL; return s; }
static u32 net_sig(const char *a, const char *b, const char *c, const char *d, const char *e) {
    u32 h = fnv_str(2166136261u, NET_SALT); const char *f[5] = { a, b, c, d, e };
    for (int i = 0; i < 5; i++) { h = fnv_str(h, "|"); h = fnv_str(h, f[i] ? f[i] : ""); }
    return h;
}
static void own_p(const char *key, char *out) { char u[16]; snprintf(u, sizeof(u), "%u", (unsigned)SV.uid); snprintf(out, 12, "%08x", (unsigned)net_sig("p", u, key, "", "")); }

/* ---------- submitting records ---------- */
static int sub_level = -1;                           /* built-in level whose record is on its way (-2: the player level below) */
static Replay pub_best; static int pub_best_ok, pub_best_sent; static char pub_key[24];      /* this session's best run on the player level played last */
static int nick_pending, nick_asked, pub_own;
static void submit_record(const char *key, const Replay *r) {
    static char body[14000], rep[12400]; char u[16], st[8], tk[12];
    replay_encode(r, rep, (int)sizeof(rep));
    snprintf(u, sizeof(u), "%u", (unsigned)SV.uid); snprintf(st, sizeof(st), "%d", r->stars); snprintf(tk, sizeof(tk), "%d", r->ticks);
    if (NET.proto >= 4) snprintf(body, sizeof(body), "sub2\t%s\t%s\t%s\t%s\t%s\t%s\t%08x", key, u, CFG.token, st, tk, rep, (unsigned)net_sig("sub2", key, u, rep, ""));     /* the nick comes from the account */
    else snprintf(body, sizeof(body), "sub\t%s\t%s\t%s\t%s\t%s\t%s\t%08x", key, u, SV.nick, st, tk, rep, (unsigned)net_sig(key, u, SV.nick, rep, ""));
    net_post(RQ_SUB, body);
}
static int acc_banned;
static int can_submit(void) {                        /* a table with accounts takes records only from a signed-in player; an old one wants just a nick */
    if (NET.st != NS_ON || !NET.proto) return 0;
    return NET.proto >= 4 ? (CFG.acc && CFG.token[0] && !acc_banned) : (SV.nick[0] != 0);
}
static int need_identity(void) { return NET.st == NS_ON && NET.proto && !acc_banned && (NET.proto >= 4 ? !CFG.acc : !SV.nick[0]); }
static void online_flush(void) {                     /* send the personal bests that the table has not seen yet, one at a time */
    if (!can_submit() || NET.busy[RQ_SUB]) return;
    for (int i = 0; i < LEVEL_COUNT; i++) if (lvl_done(i) && !SV.sent[i] && SV.ticks[i]) {
        static Replay r; char k[8], key[24]; own_key(i, k);
        if (!replay_load(k, &r, objs_hash(g_levels[i].objs)) || r.ticks != (int)SV.ticks[i]) { SV.sent[i] = 2; continue; }      /* no recording of that run (2 = nothing to send) */
        level_key(i, key, (int)sizeof(key)); sub_level = i; submit_record(key, &r); return;
    }
    if (pub_best_ok && !pub_best_sent && pub_key[0]) { sub_level = -2; submit_record(pub_key, &pub_best); }
}
static void nick_done(const char *t) {
    snprintf(SV.nick, sizeof(SV.nick), "%s", t);
    for (int i = 0; i < LEVEL_COUNT; i++) if (SV.sent[i] == 1) SV.sent[i] = 0;        /* the table gets the new name */
    save_store(); online_flush(); gtoast("Ник сохранён");
}
static void acc_open(void);
static void ask_nick(void) {                         /* "who are you?": the account window, or just a nick when the table is an old one */
    nick_asked = 1;
    if (NET.st == NS_ON && NET.proto && NET.proto < 4) kb_open("Твой ник для таблицы рекордов", SV.nick, 12, 0, nick_done); else acc_open();
}

/* ---------- what happens when a level is won ---------- */
static int win_best_ticks, win_first;
static void editor_solved(int st);
static void on_level_won(int st) {
    win_first = 0; win_best_ticks = 0;
    if (CUR.kind == 0) {
        int i = CUR.idx, had = lvl_done(i), old = lvl_stars(i);
        win_first = !had; win_best_ticks = (int)SV.ticks[i];
        if (!had || st > old || (st == old && (SV.ticks[i] == 0 || (u32)L_ticks < SV.ticks[i]))) {
            L_newbest = had; SV.best[i] = (u8)(st + 1); SV.ticks[i] = (u32)L_ticks; SV.sent[i] = 0;
            if (!REC.over) { char k[8]; own_key(i, k); replay_save(k, &REC, objs_hash(CUR.objs)); } else SV.sent[i] = 2;
            save_store();
        }
        online_flush();
        if (need_identity() && !nick_asked) nick_pending = 1;      /* the table is there but it does not know how to call this player yet */
    } else if (CUR.kind == 1) editor_solved(st);
    else {                                             /* a level made by another player: the best run of this session goes to its table */
        win_first = !pub_best_ok; win_best_ticks = pub_best_ok ? pub_best.ticks : 0;
        if (!REC.over && (!pub_best_ok || st > pub_best.stars || (st == pub_best.stars && L_ticks < pub_best.ticks))) {
            L_newbest = pub_best_ok; pub_best = REC; pub_best_ok = 1; pub_best_sent = 0; snprintf(pub_key, sizeof(pub_key), "%s", CUR.key);
            online_flush();
            if (need_identity() && !nick_asked) nick_pending = 1;
        }
    }
}

/* ============================== levels made in the editor ============================== */
#define SLOTS 8
#define ED_MAXO 48
#define ED_MAGIC 0x3156454Cu
typedef struct { u32 magic; char name[64]; int bg, n, solved, pub_id; LObj o[ED_MAXO + 1]; } EdLevel;
static EdLevel ED, PUBLV; static int ed_slot;
static const int obj_limit[O_TYPES] = { 0, 1, MAX_PINS, MAX_PINS, MAX_STARS, MAX_BUBBLES, MAX_BLOWERS, MAX_SPIKES, 1, MAX_BOUNCERS, MAX_PORTALS, MAX_GRAVS, MAX_LASERS, MAX_PINS };
static int ed_count(const EdLevel *e, int type) { int n = 0; for (int i = 0; i < e->n; i++) if (e->o[i].type == type) n++; return n; }
static int ed_pins(const EdLevel *e) { return ed_count(e, O_PIN) + ed_count(e, O_AUTOPIN) + ed_count(e, O_RAIL); }
/* "1;bg;type,x,y,a,b,c,d,e;..." — x,y,a,b in tenths, c,d,e in hundredths; trailing zeros are dropped */
static int level_encode(const EdLevel *e, char *out, int max) {
    int n = snprintf(out, (size_t)max, "1;%d", e->bg);
    for (int i = 0; i < e->n && n + 80 < max; i++) {
        const LObj *o = &e->o[i]; int v[8] = { o->type, (int)floorf(o->x * 10 + 0.5f), (int)floorf(o->y * 10 + 0.5f), (int)floorf(o->a * 10 + 0.5f), (int)floorf(o->b * 10 + 0.5f), (int)floorf(o->c * 100 + 0.5f), (int)floorf(o->d * 100 + 0.5f), (int)floorf(o->e * 100 + 0.5f) };
        int k = 8; while (k > 3 && v[k - 1] == 0) k--;
        out[n++] = ';'; for (int q = 0; q < k; q++) n += snprintf(out + n, (size_t)(max - n), q ? ",%d" : "%d", v[q]);
    }
    out[n] = 0; return n;
}
static int level_decode(const char *s, EdLevel *e) {
    int ver = 0, bg = 0, pos = 0; memset(e, 0, sizeof(*e)); e->magic = ED_MAGIC;
    if (sscanf(s, "%d;%d%n", &ver, &bg, &pos) < 2 || ver != 1) return 0;
    e->bg = bg < 0 ? 0 : bg % BOXES; s += pos;
    while (*s == ';') {
        int v[8] = { 0 }, k = 0; s++;
        while (k < 8) { char *end; long t = strtol(s, &end, 10); if (end == s) break; v[k++] = (int)t; s = end; if (*s == ',') s++; else break; }
        if (k < 3 || v[0] <= O_END || v[0] >= O_TYPES || e->n >= ED_MAXO) return 0;
        LObj *o = &e->o[e->n]; o->type = v[0]; o->x = clampf(v[1] * 0.1f, -100, 1380); o->y = clampf(v[2] * 0.1f, -100, 820);
        o->a = clampf(v[3] * 0.1f, -2000, 2000); o->b = clampf(v[4] * 0.1f, -2000, 2000); o->c = clampf(v[5] * 0.01f, -100, 100); o->d = clampf(v[6] * 0.01f, -2000, 2000); o->e = clampf(v[7] * 0.01f, 0, 1000);
        if (o->type == O_PIN || o->type == O_AUTOPIN || o->type == O_RAIL) { if (ed_pins(e) >= MAX_PINS) return 0; }
        else if (ed_count(e, o->type) >= obj_limit[o->type]) return 0;
        e->n++;
    }
    e->o[e->n].type = O_END;
    return ed_count(e, O_CANDY) == 1 && ed_count(e, O_MEL) == 1;
}
static void slot_key(int slot, char *k, int proof) { snprintf(k, 8, proof ? "lp%d" : "lv%d", slot); }
static int slot_load(int slot, EdLevel *e) {
    char k[8]; slot_key(slot, k, 0); memset(e, 0, sizeof(*e));
    if (plat_fetch(k, e, (int)sizeof(*e)) != (int)sizeof(*e) || e->magic != ED_MAGIC || e->n < 0 || e->n > ED_MAXO) { memset(e, 0, sizeof(*e)); return 0; }
    e->name[sizeof(e->name) - 1] = 0; e->o[e->n].type = O_END; e->bg = (e->bg % BOXES + BOXES) % BOXES;
    return 1;
}
static void slot_save(int slot, const EdLevel *e) { char k[8]; slot_key(slot, k, 0); plat_store(k, e, (int)sizeof(*e)); }
/* make a level the current one: kind 1 = test from the editor, 2 = published by a player */
static void play_custom(const EdLevel *e, int kind, const char *key) {
    static LObj objs[ED_MAXO + 1]; static char name[64];
    memcpy(objs, e->o, sizeof(LObj) * (size_t)e->n); objs[e->n].type = O_END; snprintf(name, sizeof(name), "%s", e->name);
    memset(&CUR, 0, sizeof(CUR)); CUR.kind = kind; CUR.name = name; CUR.hint = ""; CUR.box = e->bg; CUR.objs = objs; CUR.idx = -1; CUR.maxst = sim_max_stars(objs);
    for (const LObj *o = objs; o->type != O_END; o++) if (o->type == O_MEL && o->a > 0.5f) CUR.flip = 1;
    snprintf(CUR.key, sizeof(CUR.key), "%s", key);
}

/* ============================== records screen ============================== */
static void text_fit(const Font *f, const char *s, float x, float y, float size, float maxw, u32 col, int align);
typedef struct { int rank, stars, ticks, badge; char nick[56], p[12]; } TopRow;
static struct { int level, n, st, own_ok, mine; char key[24]; TopRow row[100]; float scroll, drag_y0, scroll0; int drag; Replay own; char want_nick[56]; } RS;
static void records_load(void) {
    RS.n = 0; RS.st = 0; RS.scroll = 0; RS.own_ok = 0; RS.mine = -1;
    if (RS.level >= 0) { char k[8]; level_key(RS.level, RS.key, (int)sizeof(RS.key)); own_key(RS.level, k); RS.own_ok = replay_load(k, &RS.own, objs_hash(g_levels[RS.level].objs)); }
    else { snprintf(RS.key, sizeof(RS.key), "%s", CUR.key); RS.own_ok = pub_best_ok; if (pub_best_ok) RS.own = pub_best; }
    if (NET.st == NS_ON) { char q[80]; snprintf(q, sizeof(q), "a=top&l=%s", RS.key); net_get(RQ_TOP, q); RS.st = 1; }
    else if (NET.st == NS_ERR || NET.st == NS_NONE) net_cfg();
}
static void records_enter(int a) {
    if (a >= 0 && a < LEVEL_COUNT) RS.level = a; else if (a == -2) RS.level = -2; else if (RS.level < 0) RS.level = 0;
    if (need_identity() && !nick_asked) nick_pending = 1;
    records_load();
}
static void play_replay(const Replay *r, const char *who) {
    PLAYB = *r; playb_tas = 0; snprintf(playb_who, sizeof(playb_who), "%s", who ? who : ""); g_toast_t = 0;
    if (RS.level >= 0) cur_builtin(RS.level);
    play_back = SC_RECORDS; play_back_arg = RS.level >= 0 ? RS.level : -2;
    go(SC_PLAY, -1, LM_REPLAY);
}
static int rep_mine;                                 /* the recording that is being fetched is the player's own */
static int records_unlocked(void) { return RS.level >= 0 ? lvl_done(RS.level) : pub_best_ok; }     /* a recording may be watched only after beating the level yourself */
static void watch_row(int i) {
    if (!records_unlocked()) { gtoast("Сначала пройди этот уровень сам!"); sfx(S_TICK, 0.8f, 640); return; }
    if (i == RS.mine && RS.own_ok && RS.own.ticks == RS.row[i].ticks) { play_replay(&RS.own, RS.row[i].nick); return; }
    if (NET.st != NS_ON || NET.busy[RQ_REP]) return;
    rep_mine = (i == RS.mine);
    char q[120]; snprintf(q, sizeof(q), "a=rep&l=%s&p=%s", RS.key, RS.row[i].p); snprintf(RS.want_nick, sizeof(RS.want_nick), "%s", RS.row[i].nick);
    net_get(RQ_REP, q); gtoast("Загружаю запись...");
}
static const char *net_status(void) {
    switch (NET.st) {
    case NS_ON: return "Онлайн-таблица подключена";
    case NS_CFG: return "Подключаюсь к таблице...";
    case NS_OFF: return "Онлайн-таблица пока не подключена: видны только твои рекорды";
    case NS_ERR: return "Нет связи с интернетом: видны только твои рекорды";
    }
    return "";
}
static void stars_small(float x, float y, int st, int mx, float sz) { for (int k = 0; k < mx; k++) star_icon(x + (k - (mx - 1) * 0.5f) * sz * 0.92f, y, sz, k < st, 1); }
static void scr_records(void) {
    char buf[96], tb[24]; int lv = RS.level, b = lv >= 0 ? lv / PER_BOX : CUR.box, mx = lv >= 0 ? lv_max[lv] : CUR.maxst;
    bg_draw(b, 0.4f, DECO_NONE, 0, 0, 0);
    title_text("Рекорды", 640, 62, 50);
    if (rbtn(6, 62, 62, 32, IC_BACK, C_VIO1, C_VIO2, 1)) { if (lv >= 0) go(SC_MENU, 0, 0); else go(SC_HUB, 1, 0); }
    /* ---- left: which level, and my own result ---- */
    panel(36, 112, 372, 572);
    if (lv >= 0) {
        if (rbtn(100, 78, 162, 24, IC_BACK, C_VIO1, C_VIO2, 1)) { RS.level = (lv + LEVEL_COUNT - PER_BOX) % LEVEL_COUNT; records_load(); }
        if (rbtn(101, 366, 162, 24, IC_NEXT, C_VIO1, C_VIO2, 1)) { RS.level = (lv + PER_BOX) % LEVEL_COUNT; records_load(); }
        snprintf(buf, sizeof(buf), "%d. %s", b + 1, box_name[b]); gfx_text(&F_ui, buf, 222, 162, 27, WHITE, AL_CENTER);
        for (int i = 0; i < PER_BOX; i++) {
            int li = b * PER_BOX + i; float x = 114 + (i % 3) * 108.0f, y = 236 + (i / 3) * 86.0f; char nb[8]; snprintf(nb, sizeof(nb), "%d", i + 1);
            if (wbtn(102 + i, x, y, 92, 70, nb, li == lv ? C_GREEN1 : box_c1[b], li == lv ? C_GREEN2 : box_c2[b], 38, IC_NONE, 1) && li != lv) { RS.level = li; records_load(); }
        }
        gfx_text(&F_txt, g_levels[lv].name, 222, 384, 22, 0xE4DCFFFFu, AL_CENTER);
    } else {
        gfx_text(&F_txt, "Уровень игрока", 222, 162, 20, 0xD8CCFFFFu, AL_CENTER);
        gfx_text(&F_ui, CUR.name ? CUR.name : "", 222, 220, 30, WHITE, AL_CENTER);
    }
    gfx_rrect(60, 412, 324, 2, 1, 0xFFFFFF30u);
    gfx_text(&F_ui, "Мой результат", 222, 440, 24, C_GOLD, AL_CENTER);
    int done = lv >= 0 ? lvl_done(lv) : pub_best_ok, st = lv >= 0 ? lvl_stars(lv) : pub_best.stars, tk = lv >= 0 ? (int)SV.ticks[lv] : pub_best.ticks;
    if (done) {
        stars_small(222, 480, st, mx, mx > 3 ? 27.0f : 40.0f);
        gfx_text(&F_ui, tk ? fmt_time(tk, tb, (int)sizeof(tb)) : "без времени", 222, 520, 28, WHITE, AL_CENTER);
    } else gfx_text_wrap(&F_txt, "Уровень ещё не пройден. Записи других игроков откроются после прохождения.", 222, 480, 19, 300, 26, 0xFFFFFFC0u, AL_CENTER, 1);
    if (wbtn(108, 222, 580, 300, 54, "Моя запись", C_BLUE1, C_BLUE2, 25, IC_PLAY, done && (RS.own_ok || RS.mine >= 0))) { if (RS.own_ok) play_replay(&RS.own, SV.nick[0] ? SV.nick : "Я"); else watch_row(RS.mine); }      /* after signing in on a new device the recording is only in the table */
    snprintf(buf, sizeof(buf), "%s", SV.nick[0] ? SV.nick : "Аккаунт");
    if (wbtn(109, 222, 644, 300, 50, buf, C_VIO1, C_VIO2, 23, IC_USER, 1)) ask_nick();
    /* ---- right: the table ---- */
    float lx = 432, ly = 112, lw = 812, lh = 572, top = ly + 62, vis = lh - 62 - 46, rowh = 44, rw = lw - 96;
    float cx_st = lx + 430, cx_tm = lx + 566, cx_w = lx + 668;
    panel(lx, ly, lw, lh);
    gfx_text(&F_ui, "#", lx + 54, ly + 36, 22, 0xD8CCFFFFu, AL_CENTER); gfx_text(&F_ui, "Игрок", lx + 100, ly + 36, 22, 0xD8CCFFFFu, AL_LEFT);
    gfx_text(&F_ui, "Звёзды", cx_st, ly + 36, 22, 0xD8CCFFFFu, AL_CENTER); gfx_text(&F_ui, "Время", cx_tm, ly + 36, 22, 0xD8CCFFFFu, AL_CENTER);
    gfx_text(&F_ui, "Запись", cx_w, ly + 36, 22, 0xD8CCFFFFu, AL_CENTER);
    float content = RS.n * rowh, maxs = maxf(0, content - vis);
    if (P.pressed && !ui_block && P.downx > lx && P.downx < lx + rw - 80 && P.downy > top && P.downy < top + vis) { RS.drag = 1; RS.drag_y0 = P.downy; RS.scroll0 = RS.scroll; }
    if (RS.drag) { if (!P.down) RS.drag = 0; else RS.scroll = RS.scroll0 - (P.y - RS.drag_y0); }
    RS.scroll = clampf(RS.scroll, 0, maxs);
    gfx_clip(lx + 8, top, lw - 16, vis);
    int unlocked = records_unlocked();
    for (int i = 0; i < RS.n; i++) {
        const TopRow *r = &RS.row[i]; float y = top + i * rowh - RS.scroll + rowh * 0.5f; if (y < top - rowh || y > top + vis + rowh) continue;
        int me = (i == RS.mine);
        gfx_rrect(lx + 18, y - rowh * 0.5f + 3, rw, rowh - 6, 14, me ? 0xFFD23F38u : (i & 1 ? 0xFFFFFF10u : 0xFFFFFF08u));
        snprintf(buf, sizeof(buf), "%d", r->rank); gfx_text(&F_ui, buf, lx + 54, y, r->rank <= 3 ? 26 : 22, r->rank == 1 ? C_GOLD : (r->rank == 2 ? 0xDCE5F7FFu : (r->rank == 3 ? 0xF0A060FFu : WHITE)), AL_CENTER);
        text_fit(&F_ui, r->nick, lx + 100, y, 24, 240, me ? C_GOLD : WHITE, AL_LEFT);
        if (r->badge) badge_icon(r->badge, lx + 100 + minf(240, gfx_text_w(&F_ui, r->nick, 24)) + 20, y - 1, 11);
        if (mx > 3) { snprintf(buf, sizeof(buf), "%d", r->stars); gfx_text(&F_ui, buf, cx_st + 4, y, 24, WHITE, AL_RIGHT); star_icon(cx_st + 22, y - 1, 26, 1, 1); } else stars_small(cx_st, y - 1, r->stars, mx, 26);
        gfx_text(&F_ui, fmt_time(r->ticks, tb, (int)sizeof(tb)), cx_tm, y, 24, WHITE, AL_CENTER);
        int inview = y - 17 > top && y + 17 < top + vis;
        if (unlocked) { if (rbtn(110 + (i % 40), cx_w, y, 17, IC_PLAY, C_GREEN1, C_GREEN2, inview)) watch_row(i); }
        else { icon(IC_LOCK, cx_w, y, 15, 0xFFFFFFA0u); if (inview && P.released && !ui_block && in_box(P.upx, P.upy, cx_w, y, 60, rowh) && in_box(P.downx, P.downy, cx_w, y, 60, rowh)) watch_row(i); }
    }
    gfx_clip_reset();
    if (RS.n == 0) {
        const char *t = RS.st == 1 ? "Загружаю таблицу..." : (RS.st == 3 ? "Таблица не ответила. Попробуй ещё раз." : (NET.st == NS_ON ? "Здесь пока пусто. Стань первым!" : "Онлайн-таблица недоступна."));
        gfx_text(&F_txt, t, lx + lw * 0.5f, top + vis * 0.45f, 24, 0xFFFFFFC0u, AL_CENTER);
    }
    if (maxs > 0) {
        float bx = lx + lw - 42, t0 = top + 52, th = vis - 104, bh = maxf(40, th * vis / content), by = t0 + (th - bh) * (RS.scroll / maxs);
        gfx_rrect(bx - 4, t0, 8, th, 4, 0xFFFFFF20u); gfx_rrect(bx - 4, by, 8, bh, 4, 0xFFFFFFA0u);
        if (rbtn(150, bx, top + 22, 20, IC_UP, C_VIO1, C_VIO2, RS.scroll > 0)) RS.scroll -= rowh * 5;
        if (rbtn(151, bx, top + vis - 22, 20, IC_DOWN, C_VIO1, C_VIO2, RS.scroll < maxs)) RS.scroll += rowh * 5;
    }
    gfx_text(&F_txt, net_status(), lx + 30, ly + lh - 24, 18, NET.st == NS_ON ? 0x9CF04EFFu : 0xFFFFFFB0u, AL_LEFT);
    if (rbtn(152, lx + lw - 40, ly + lh - 26, 17, IC_RESTART, C_BLUE1, C_BLUE2, RS.st != 1)) { if (NET.st != NS_ON) net_cfg(); records_load(); }
}

/* ============================== hub: my levels / levels of other players ============================== */
#define HUB_PAGE 8
typedef struct { int id, stars, plays, bg, badge; char name[64], author[56]; } HubItem;
static struct { int tab, sort, off, total, n, st, del; float del_t; HubItem it[HUB_PAGE]; EdLevel slot[SLOTS]; int has[SLOTS]; } HB;
static void text_fit(const Font *f, const char *s, float x, float y, float size, float maxw, u32 col, int align) {
    float w = gfx_text_w(f, s, size); if (w > maxw) size *= maxw / w;
    gfx_text(f, s, x, y, size, col, align);
}
static void hub_request(void) {
    HB.n = 0; HB.st = 0;
    if (NET.st == NS_ON) { char q[80]; snprintf(q, sizeof(q), "a=list&s=%s&o=%d", HB.sort ? "top" : "new", HB.off); net_get(RQ_LIST, q); HB.st = 1; }
    else if (NET.st == NS_ERR || NET.st == NS_NONE) net_cfg();
}
static void hub_enter(int a) {
    HB.tab = a ? 1 : 0; HB.del = -1;
    if (HB.tab == 0) { for (int i = 0; i < SLOTS; i++) HB.has[i] = slot_load(i, &HB.slot[i]); }
    else hub_request();
}
static void hub_play(int i) {
    if (NET.st != NS_ON || NET.busy[RQ_LEVEL]) return;
    char q[64]; snprintf(q, sizeof(q), "a=lvl&id=%d", HB.it[i].id); net_get(RQ_LEVEL, q); gtoast("Загружаю уровень...");
}
static const u32 obj_col[O_TYPES] = { 0, 0xFFA63CFFu, 0xE8E8F4FFu, 0xC6F25CFFu, 0xFFD23FFFu, 0x8FE6FFFFu, 0xFFB45AFFu, 0xFF5A5AFFu, 0xFF7AC8FFu, 0x7CF06AFFu, 0x46E6FFFFu, 0xC08CFFFFu, 0xFF4040FFu, 0xB9C4DCFFu };
static void mini_level(const EdLevel *e, float x, float y, float w, float h) {          /* a tiny schematic of a level */
    float k = w / 1280.0f;
    gfx_rrect(x, y, w, h, 12, color_lerp(box_c2[e->bg % BOXES], 0x100A30FFu, 0.55f));
    for (int i = 0; i < e->n; i++) {
        const LObj *o = &e->o[i]; float px = x + o->x * k, py = y + o->y * k; u32 c = obj_col[o->type];
        if (px < x + 4 || px > x + w - 4 || py < y + 4 || py > y + h - 4) continue;
        if (o->type == O_SPIKES || o->type == O_LASER || o->type == O_RAIL) gfx_capsule(px, py, clampf(x + o->a * k, x + 4, x + w - 4), clampf(y + o->b * k, y + 4, y + h - 4), 1.6f, c);
        else if (o->type == O_MEL) gfx_circle(px, py, 8, c);
        else if (o->type == O_CANDY) gfx_rrect(px - 3, py - 6, 6, 12, 2, c);
        else gfx_circle(px, py, o->type == O_STAR ? 4.0f : 3.2f, c);
    }
}
static void scr_hub(void) {
    char buf[160];
    bg_draw(0, 0.4f, DECO_NONE, 0, 0, 0);
    if (rbtn(6, 62, 62, 32, IC_BACK, C_VIO1, C_VIO2, 1)) go(HB.tab ? SC_CHAPTERS : SC_MENU, 0, 0);
    if (wbtn(200, 480, 62, 310, 62, "Мои уровни", HB.tab == 0 ? C_GREEN1 : C_VIO1, HB.tab == 0 ? C_GREEN2 : C_VIO2, 27, IC_EDIT, 1) && HB.tab != 0) hub_enter(0);
    if (wbtn(201, 830, 62, 350, 62, "Уровни игроков", HB.tab == 1 ? C_GREEN1 : C_VIO1, HB.tab == 1 ? C_GREEN2 : C_VIO2, 27, IC_GLOBE, 1) && HB.tab != 1) hub_enter(1);
    if (HB.tab == 0) {
        if (HB.del >= 0) { HB.del_t -= g_dt; if (HB.del_t <= 0) HB.del = -1; }
        for (int i = 0; i < SLOTS; i++) {
            float x = 190 + (i % 4) * 300.0f, y = 250 + (i / 4) * 274.0f; const EdLevel *e = &HB.slot[i];
            gfx_rrect(x - 140, y - 126 + 6, 280, 256, 30, 0x00000060u); gfx_rrect(x - 138, y - 130, 276, 256, 28, HB.has[i] ? C_EDGE : 0x7C7896FFu);
            gfx_rrect_grad(x - 134, y - 126, 268, 248, 24, C_PANEL1, C_PANEL2);
            if (HB.has[i]) {
                mini_level(e, x - 120, y - 114, 240, 135);
                text_fit(&F_ui, e->name, x, y + 40, 24, 250, WHITE, AL_CENTER);
                if (HB.del == i) snprintf(buf, sizeof(buf), "Нажми ещё раз — удалю");
                else if (e->pub_id) snprintf(buf, sizeof(buf), "Опубликован, № %d", e->pub_id);
                else snprintf(buf, sizeof(buf), "%s", e->solved ? "Пройден: можно публиковать" : "Ещё не пройден");
                gfx_text(&F_txt, buf, x, y + 64, 17, HB.del == i ? C_RED1 : (e->pub_id ? 0x9CF04EFFu : 0xD8CCFFFFu), AL_CENTER);
                if (wbtn(210 + i, x - 30, y + 96, 180, 44, "Открыть", C_GREEN1, C_GREEN2, 23, IC_EDIT, 1)) go(SC_EDITOR, i, 0);
                if (rbtn(220 + i, x + 98, y + 96, 22, IC_TRASH, C_RED1, C_RED2, 1)) {
                    if (HB.del == i) { char k[8]; slot_key(i, k, 0); plat_store(k, "", 0); slot_key(i, k, 1); plat_store(k, "", 0); HB.has[i] = 0; HB.del = -1; gtoast("Уровень удалён"); }
                    else { HB.del = i; HB.del_t = 3.0f; }
                }
            } else {
                icon(IC_PLUS, x, y - 50, 54, 0xFFFFFF50u);
                gfx_text(&F_txt, "Свободное место", x, y + 22, 19, 0xFFFFFFA0u, AL_CENTER);
                if (wbtn(210 + i, x, y + 80, 200, 54, "Создать", C_BLUE1, C_BLUE2, 25, IC_PLUS, 1)) go(SC_EDITOR, i, 0);
            }
        }
        gfx_text(&F_txt, "Собери свой уровень, пройди его сам и опубликуй — его увидят все игроки.", 640, 690, 20, 0xFFFFFFC0u, AL_CENTER);
    } else {
        panel(120, 112, 1040, 572);
        if (wbtn(202, 250, 152, 170, 46, "Новые", HB.sort == 0 ? C_ORG1 : C_VIO1, HB.sort == 0 ? C_ORG2 : C_VIO2, 22, IC_NONE, 1) && HB.sort != 0) { HB.sort = 0; HB.off = 0; hub_request(); }
        if (wbtn(203, 440, 152, 190, 46, "Популярные", HB.sort == 1 ? C_ORG1 : C_VIO1, HB.sort == 1 ? C_ORG2 : C_VIO2, 22, IC_NONE, 1) && HB.sort != 1) { HB.sort = 1; HB.off = 0; hub_request(); }
        gfx_text(&F_txt, "Автор", 700, 152, 18, 0xD8CCFFFFu, AL_CENTER); gfx_text(&F_txt, "Звёзд", 880, 152, 18, 0xD8CCFFFFu, AL_CENTER); gfx_text(&F_txt, "Сыграно", 980, 152, 18, 0xD8CCFFFFu, AL_CENTER);
        for (int i = 0; i < HB.n; i++) {
            const HubItem *it = &HB.it[i]; float y = 212 + i * 52.0f;
            gfx_rrect(140, y - 23, 1000, 46, 16, i & 1 ? 0xFFFFFF10u : 0xFFFFFF08u);
            gfx_circle(170, y, 11, box_c1[it->bg % BOXES]);
            text_fit(&F_ui, it->name, 196, y, 25, 380, WHITE, AL_LEFT);
            text_fit(&F_ui, it->author, 700, y, 22, 210, 0xE4DCFFFFu, AL_CENTER);
            if (it->badge) badge_icon(it->badge, 700 + minf(210, gfx_text_w(&F_ui, it->author, 22)) * 0.5f + 18, y - 1, 10);
            snprintf(buf, sizeof(buf), "%d", it->stars); gfx_text(&F_ui, buf, 878, y, 23, WHITE, AL_RIGHT); star_icon(896, y - 1, 26, 1, 1);
            snprintf(buf, sizeof(buf), "%d", it->plays); gfx_text(&F_ui, buf, 980, y, 23, WHITE, AL_CENTER);
            if (wbtn(230 + i, 1078, y, 104, 40, "Играть", C_GREEN1, C_GREEN2, 20, IC_NONE, !NET.busy[RQ_LEVEL])) hub_play(i);
        }
        if (HB.n == 0) {
            const char *t = HB.st == 1 ? "Загружаю список..." : (HB.st == 3 ? "Таблица не ответила. Попробуй ещё раз." : (NET.st == NS_ON ? "Пока никто не опубликовал уровень. Стань первым: «Мои уровни» — «Создать»!" : (NET.st == NS_OFF ? "Онлайн-таблица пока не подключена: уровни игроков появятся позже" : NET.st == NS_ERR ? "Нет связи с интернетом: уровни игроков сейчас не видны" : net_status())));
            gfx_text_wrap(&F_txt, t, 640, 380, 24, 820, 32, 0xFFFFFFC8u, AL_CENTER, 1);
        }
        int last = HB.off + HB.n;
        if (rbtn(204, 540, 648, 22, IC_BACK, C_VIO1, C_VIO2, HB.off > 0 && HB.st != 1)) { HB.off = HB.off >= HUB_PAGE ? HB.off - HUB_PAGE : 0; hub_request(); }
        if (HB.total > 0) snprintf(buf, sizeof(buf), "%d–%d из %d", HB.off + 1, last, HB.total); else buf[0] = 0;
        gfx_text(&F_ui, buf, 640, 648, 22, WHITE, AL_CENTER);
        if (rbtn(205, 740, 648, 22, IC_NEXT, C_VIO1, C_VIO2, last < HB.total && HB.st != 1)) { HB.off += HUB_PAGE; hub_request(); }
        if (rbtn(206, 1112, 648, 20, IC_RESTART, C_BLUE1, C_BLUE2, HB.st != 1)) hub_request();
    }
}

/* ============================== the level editor ============================== */
#define ED_K 0.75f               /* the level is shown at this scale ... */
#define ED_X 10.0f               /* ... with its top left corner here */
#define ED_Y 88.0f
#define ED_W (1280.0f * ED_K)
#define ED_H (720.0f * ED_K)
typedef struct { const char *label, *zero; int f, kind; float step, lo, hi; int dec; } EdProp;      /* f: 0 a, 1 b, 2 c, 3 d, 4 e;  kind: 0 number, 1 angle 0..345, 2 portal exit, 3 rope length, 4 yes/no */
static const EdProp ed_props[O_TYPES][3] = {
    [O_PIN]     = { { "Длина верёвки", "по чекушке", 0, 3, 20, 0, 700, 0 }, { "Воришка: скорость", "нет", 1, 0, 20, 0, 200, 0 }, { "Воришка: старт, с", NULL, 2, 0, 0.5f, 0, 10, 1 } },
    [O_AUTOPIN] = { { "Радиус захвата", NULL, 0, 0, 10, 60, 300, 0 }, { "Воришка: скорость", "нет", 1, 0, 20, 0, 200, 0 } },
    [O_BLOWER]  = { { "Куда дует, градусы", NULL, 0, 1, 15, 0, 345, 0 } },
    [O_MEL]     = { { "Висит вверх ногами", "нет", 0, 4, 1, 0, 1, 0 } },
    [O_BOUNCER] = { { "Наклон, градусы", NULL, 0, 0, 5, -85, 85, 0 }, { "Половина длины", NULL, 1, 0, 10, 30, 160, 0 } },
    [O_PORTAL]  = { { "Куда выбрасывает", "как влетел", 0, 2, 15, 0, 345, 0 } },
    [O_LASER]   = { { "Горит, с", NULL, 2, 0, 0.25f, 0.25f, 6, 2 }, { "Пауза, с", "всегда горит", 3, 0, 0.25f, 0, 6, 2 }, { "Сдвиг, с", NULL, 4, 0, 0.25f, 0, 12, 2 } },
    [O_RAIL]    = { { "Старт на рельсе", NULL, 2, 0, 0.125f, 0, 1, 2 }, { "Длина верёвки", "по чекушке", 3, 3, 20, 0, 700, 0 }, { "Воришка: скорость", "нет", 4, 0, 20, 0, 200, 0 } },
};
static const char *const obj_name[O_TYPES] = { "", "Чекушка", "Гвоздь", "Липучка", "Звезда", "Пузырь", "Груша", "Шипы", "Мел", "Батут", "Портал", "Гравитация", "Лазер", "Рельс" };
static const int ed_palette[11] = { O_PIN, O_AUTOPIN, O_STAR, O_BUBBLE, O_BLOWER, O_SPIKES, O_BOUNCER, O_PORTAL, O_GRAV, O_LASER, O_RAIL };
static struct { int sel, grab, drag, moved, dirty, clear; float gdx, gdy, clear_t; } EU;
static Replay ed_proof; static int ed_proof_ok;
static int ed_two(int type) { return type == O_SPIKES || type == O_LASER || type == O_RAIL; }
static int ed_find(int type) { for (int i = 0; i < ED.n; i++) if (ED.o[i].type == type) return i; return -1; }
/* The game always plays the level exactly as it is written in the published text: the proof run recorded here must replay on every other machine. */
static void ed_canonical(const EdLevel *src, EdLevel *dst) {
    static char txt[4096]; level_encode(src, txt, (int)sizeof(txt));
    if (!level_decode(txt, dst)) { *dst = *src; dst->o[dst->n].type = O_END; }
    snprintf(dst->name, sizeof(dst->name), "%s", src->name); dst->solved = src->solved; dst->pub_id = src->pub_id;
}
static void ed_refresh(void) {
    static EdLevel c; ED.o[ED.n].type = O_END; ed_canonical(&ED, &c);
    play_custom(&c, 1, ""); sim_load(&S, CUR.objs);
    memset(spill, 0, sizeof(spill)); memset(slash, 0, sizeof(slash)); memset(fly, 0, sizeof(fly)); trail_n = 0; tapfx_t = 0; steal_rope = -1; rail_drag = -1;
}
static void ed_commit(void) {                         /* the layout has changed: the old proof run is worthless */
    char k[8]; ED.solved = 0; ED.pub_id = 0; ed_proof_ok = 0; slot_key(ed_slot, k, 1); plat_store(k, "", 0);
    slot_save(ed_slot, &ED); ed_refresh(); EU.dirty = 0;
}
static void ed_new(void) {
    static const LObj init[] = { { O_CANDY, 640, 250, 0, 0, 0, 0, 0 }, { O_PIN, 640, 90, 0, 0, 0, 0, 0 }, { O_STAR, 640, 350, 0, 0, 0, 0, 0 }, { O_STAR, 640, 420, 0, 0, 0, 0, 0 }, { O_STAR, 640, 490, 0, 0, 0, 0, 0 }, { O_MEL, 640, 590, 0, 0, 0, 0, 0 } };
    memset(&ED, 0, sizeof(ED)); ED.magic = ED_MAGIC; ED.n = 6; memcpy(ED.o, init, sizeof(init)); ED.bg = ed_slot % 3;
    snprintf(ED.name, sizeof(ED.name), "Мой уровень %d", ed_slot + 1);
}
static void editor_enter(int a) {
    if (a >= 0) {
        ed_slot = a % SLOTS; ed_proof_ok = 0;
        if (!slot_load(ed_slot, &ED)) { ed_new(); slot_save(ed_slot, &ED); }
    }
    EU.sel = -1; EU.drag = 0; EU.dirty = 0; EU.clear = 0;
    nparts = 0; mel_set(CL_IDLE, 1); M.dy = 0; M.red = M.red_to = 0; M.say_t = 0;
    ed_refresh();
    if (ED.solved) { char k[8]; slot_key(ed_slot, k, 1); ed_proof_ok = replay_load(k, &ed_proof, objs_hash(CUR.objs)) && replay_check(CUR.objs, &ed_proof); if (!ed_proof_ok) { ED.solved = 0; slot_save(ed_slot, &ED); } }
}
static void editor_solved(int st) {                   /* the author has just beaten his own level in a test run */
    win_first = 1;
    if (REC.over) return;
    if (ed_proof_ok && (st < ed_proof.stars || (st == ed_proof.stars && L_ticks >= ed_proof.ticks))) return;
    char k[8]; ed_proof = REC; ed_proof_ok = 1; ED.solved = st + 1; slot_key(ed_slot, k, 1); replay_save(k, &REC, objs_hash(CUR.objs)); slot_save(ed_slot, &ED);
}
static void ed_test(void) {
    if (EU.dirty) ed_commit();
    ed_refresh(); play_back = SC_EDITOR; play_back_arg = -1; go(SC_PLAY, -1, LM_PLAY);
}
static void ed_publish(void) {
    static char body[20000], data[4096], rep[12400]; static EdLevel c; char u[16];
    if (EU.dirty) ed_commit();
    if (ED.pub_id) { msg_open("Уже опубликован", "Этот уровень уже лежит в разделе «Уровни игроков». Измени его, пройди ещё раз — и можно публиковать как новый."); return; }
    if (!ED.solved || !ed_proof_ok) { msg_open("Сначала пройди сам", "Публиковать можно только уровень, который ты сам прошёл. Нажми «Проба» и накорми Мела чекушкой."); return; }
    if (NET.st != NS_ON) { msg_open("Нет онлайн-таблицы", NET.st == NS_OFF ? "Онлайн-таблица пока не подключена. Уровень сохранён на устройстве: опубликуешь его позже." : NET.st == NS_ERR ? "Нет связи с интернетом. Уровень сохранён на устройстве: опубликуешь его позже." : net_status()); if (NET.st != NS_CFG) net_cfg(); return; }
    if (!can_submit()) { if (acc_banned) msg_open("Аккаунт заблокирован", "С этого аккаунта нельзя публиковать уровни."); else ask_nick(); return; }
    if (NET.busy[RQ_PUB]) return;
    ed_canonical(&ED, &c); level_encode(&c, data, (int)sizeof(data)); replay_encode(&ed_proof, rep, (int)sizeof(rep));
    snprintf(u, sizeof(u), "%u", (unsigned)SV.uid);
    if (NET.proto >= 4) snprintf(body, sizeof(body), "pub2\t%s\t%s\t%s\t%s\t%s\t%08x", u, CFG.token, ED.name, data, rep, (unsigned)net_sig("pub2", u, ED.name, data, rep));
    else snprintf(body, sizeof(body), "pub\t%s\t%s\t%s\t%s\t%s\t%08x", u, SV.nick, ED.name, data, rep, (unsigned)net_sig("pub", u, ED.name, data, rep));
    net_post(RQ_PUB, body); gtoast("Отправляю уровень...");
}
static void ed_name_done(const char *t) { snprintf(ED.name, sizeof(ED.name), "%s", t); slot_save(ed_slot, &ED); }
static void ed_remove(int i) {
    if (i < 0 || i >= ED.n || ED.o[i].type == O_CANDY || ED.o[i].type == O_MEL) return;
    int pair = ED.o[i].type == O_PORTAL ? (int)ED.o[i].b : -1;
    memmove(&ED.o[i], &ED.o[i + 1], sizeof(LObj) * (size_t)(ED.n - i - 1)); ED.n--;
    if (pair >= 0) for (int k = 0; k < ED.n; k++) if (ED.o[k].type == O_PORTAL && (int)ED.o[k].b == pair) { memmove(&ED.o[k], &ED.o[k + 1], sizeof(LObj) * (size_t)(ED.n - k - 1)); ED.n--; break; }
    EU.sel = -1; ed_commit();
}
static int ed_can_add(int type) {
    if (ED.n >= ED_MAXO) return 0;
    if (type == O_PIN || type == O_AUTOPIN || type == O_RAIL) return ed_pins(&ED) < MAX_PINS;
    if (type == O_PORTAL) return ED.n + 2 <= ED_MAXO && ed_count(&ED, O_PORTAL) + 2 <= MAX_PORTALS;
    return ed_count(&ED, type) < obj_limit[type];
}
static float ed_dist(const LObj *o, float px, float py) {      /* from a point to an object (two-point objects are segments) */
    if (!ed_two(o->type)) return hypotf(o->x - px, o->y - py);
    float dx = o->a - o->x, dy = o->b - o->y, l2 = dx * dx + dy * dy, t = l2 > 1.0f ? clampf(((px - o->x) * dx + (py - o->y) * dy) / l2, 0, 1) : 0;
    return hypotf(o->x + dx * t - px, o->y + dy * t - py);
}
static void ed_spot(float half, float *x, float *y) {  /* a free place near the middle for a new object that is 2 * half wide */
    static const float xs[7] = { 640, 480, 800, 320, 960, 160, 1120 }, ys[5] = { 300, 400, 200, 500, 120 };
    for (int r = 0; r < 5; r++) for (int c = 0; c < 7; c++) {
        int busy = 0;
        for (int i = 0; i < ED.n && !busy; i++) for (int k = -2; k <= 2; k++) if (ed_dist(&ED.o[i], xs[c] + half * 0.5f * (float)k, ys[r]) < (ED.o[i].type == O_MEL ? 120.0f : 78.0f)) { busy = 1; break; }
        if (!busy) { *x = xs[c]; *y = ys[r]; return; }
    }
    *x = 640; *y = 360;
}
static void ed_add(int type) {
    if (!ed_can_add(type)) return;
    float x, y; ed_spot(type == O_SPIKES ? 80.0f : (type == O_LASER ? 100.0f : (type == O_RAIL ? 120.0f : (type == O_PORTAL ? 70.0f : 0.0f))), &x, &y);
    LObj *o = &ED.o[ED.n]; memset(o, 0, sizeof(*o)); o->type = type; o->x = x; o->y = y;
    switch (type) {
    case O_AUTOPIN: o->a = 120; break;
    case O_SPIKES: o->x = x - 80; o->a = x + 80; o->b = y; break;
    case O_BOUNCER: o->b = 60; break;
    case O_LASER: o->x = x - 100; o->a = x + 100; o->b = y; o->c = 1; o->d = 1; break;
    case O_RAIL: o->x = x - 120; o->a = x + 120; o->b = y; break;
    case O_PORTAL: {
        int pair = 0; for (;;) { int used = 0; for (int i = 0; i < ED.n; i++) if (ED.o[i].type == O_PORTAL && (int)ED.o[i].b == pair) used = 1; if (!used) break; pair++; }
        o->x = x - 70; o->a = -1; o->b = (float)pair; ED.n++;
        LObj *o2 = &ED.o[ED.n]; *o2 = *o; o2->x = x + 70;
    } break;
    default: break;
    }
    EU.sel = ED.n; ED.n++; ed_commit();
}
static void ed_copy(int i) {
    if (i < 0 || i >= ED.n) return; int type = ED.o[i].type;
    if (type == O_CANDY || type == O_MEL || type == O_PORTAL || !ed_can_add(type)) return;
    LObj *o = &ED.o[ED.n]; *o = ED.o[i]; float d = o->y < 600 ? 50.0f : -50.0f; o->y += d; if (ed_two(type)) o->b += d;
    EU.sel = ED.n; ED.n++; ed_commit();
}
static float *ed_field(LObj *o, int f) { return f == 0 ? &o->a : (f == 1 ? &o->b : (f == 2 ? &o->c : (f == 3 ? &o->d : &o->e))); }
static void ed_step(LObj *o, const EdProp *p, int dir) {
    float *v = ed_field(o, p->f), nv = *v + (float)dir * p->step;
    if (p->kind == 1) nv = fmodf(nv + 360.0f, 360.0f);
    else if (p->kind == 2) { if (*v < 0) nv = dir > 0 ? 0.0f : 345.0f; else if (nv < 0 || nv >= 360.0f) nv = -1.0f; }
    else if (p->kind == 3) {
        int ci = ed_find(O_CANDY); float px = o->x, py = o->y; if (o->type == O_RAIL) { px = o->x + (o->a - o->x) * o->c; py = o->y + (o->b - o->y) * o->c; }
        float dist = ci >= 0 ? hypotf(ED.o[ci].x - px, ED.o[ci].y - py) : 0, lo = ceilf((dist + 10.0f) / 20.0f) * 20.0f;
        if (*v <= 0) nv = dir > 0 ? lo : 0.0f; else if (nv < lo) nv = 0.0f; else nv = minf(nv, p->hi);
    }
    else if (p->kind == 4) nv = *v > 0.5f ? 0.0f : 1.0f;
    else nv = clampf(nv, p->lo, p->hi);
    *v = nv;
}
static void ed_value(const LObj *o, const EdProp *p, char *buf, int n) {
    float v = *ed_field((LObj *)o, p->f);
    if (p->kind == 4) snprintf(buf, (size_t)n, "%s", v > 0.5f ? "да" : "нет");
    else if (p->zero && (p->kind == 2 ? v < 0 : v <= 0.0001f)) snprintf(buf, (size_t)n, "%s", p->zero);
    else if (p->dec == 2) snprintf(buf, (size_t)n, "%.2f", (double)v);
    else if (p->dec == 1) snprintf(buf, (size_t)n, "%.1f", (double)v);
    else snprintf(buf, (size_t)n, "%d", (int)floorf(v + 0.5f));
}
static void ed_handle(const LObj *o, int h, float *x, float *y) {
    if (h == 2) { *x = o->a; *y = o->b; } else if (h == 3) { *x = (o->x + o->a) * 0.5f; *y = (o->y + o->b) * 0.5f; } else { *x = o->x; *y = o->y; }
}
static int ed_pick(float lx, float ly, int *handle) {
    float best = 64.0f; int bi = -1, bh = 0;
    for (int i = 0; i < ED.n; i++) {
        const LObj *o = &ED.o[i]; int two = ed_two(o->type);
        for (int h = two ? 1 : 0; h <= (two ? 3 : 0); h++) {
            float x, y; ed_handle(o, h, &x, &y); float d = hypotf(lx - x, ly - y);
            if (i == EU.sel) d *= 0.6f; if (h == 3) d *= 1.3f;
            if (d < best) { best = d; bi = i; bh = h; }
        }
    }
    *handle = bh; return bi;
}
static float snap10(float v) { return floorf(v / 10.0f + 0.5f) * 10.0f; }
static void ed_drag_to(float lx, float ly) {
    LObj *o = &ED.o[EU.sel]; float x = clampf(snap10(lx + EU.gdx), 30, 1250), y = clampf(snap10(ly + EU.gdy), 30, 690), ox = o->x, oy = o->y, oa = o->a, ob = o->b;
    if (EU.grab == 2) { o->a = x; o->b = y; }
    else if (EU.grab == 3) {
        float cx = (o->x + o->a) * 0.5f, cy = (o->y + o->b) * 0.5f, dx = snap10(x - cx), dy = snap10(y - cy);
        dx = clampf(dx, 30 - minf(o->x, o->a), 1250 - maxf(o->x, o->a)); dy = clampf(dy, 30 - minf(o->y, o->b), 690 - maxf(o->y, o->b));
        o->x += dx; o->a += dx; o->y += dy; o->b += dy;
    }
    else { o->x = x; o->y = y; }
    if (ed_two(o->type) && hypotf(o->a - o->x, o->b - o->y) < 40.0f) { o->x = ox; o->y = oy; o->a = oa; o->b = ob; }      /* too short */
    if (o->x != ox || o->y != oy || o->a != oa || o->b != ob) { EU.dirty = 1; ed_refresh(); }
}
static void editor_backdrop(int which) {               /* called while the background cache is the render target: the level's picture at editor scale */
    int W = bgc->w, H = bgc->h; float rs = (float)H / DESIGN_H;
    int fx = (int)(ED_X * rs + 0.5f), fy = (int)(ED_Y * rs + 0.5f), fw = (int)(ED_W * rs + 0.5f), fh = (int)(ED_H * rs + 0.5f);
    if (fx + fw > W) fw = W - fx; if (fy + fh > H) fh = H - fy; if (fw < 8 || fh < 8) return;
    Image *t = img_new(fw, fh, 1); if (!t || !t->px) return;
    gfx_set_target(t); gfx_cover(I_bg[which], 1.0f); gfx_set_target(bgc);
    for (int y = 0; y < fh; y++) memcpy(bgc->px + (size_t)(fy + y) * (size_t)W + fx, t->px + (size_t)y * (size_t)fw, (size_t)fw * 4);
    img_free(t);
}
static void scr_editor(void) {
    char buf[160]; const u32 frame = 0x140D3AFFu;
    bg_draw(ED.bg, 0.3f, DECO_EDIT, 0, 0, 0);
    /* ---- pointer: pick, drag, drop ---- */
    float lx = (P.x - ED_X) / ED_K, ly = (P.y - ED_Y) / ED_K;
    if (P.pressed && !ui_block && P.downx >= ED_X && P.downx <= ED_X + ED_W && P.downy >= ED_Y && P.downy <= ED_Y + ED_H) {
        float dx = (P.downx - ED_X) / ED_K, dy = (P.downy - ED_Y) / ED_K; int h, i = ed_pick(dx, dy, &h);
        EU.sel = i; EU.drag = (i >= 0); EU.grab = h; EU.moved = 0;
        if (i >= 0) { float hx, hy; ed_handle(&ED.o[i], h, &hx, &hy); EU.gdx = hx - dx; EU.gdy = hy - dy; sfx(S_TICK, 0.4f, P.downx); }
    }
    if (EU.drag) {
        if (EU.sel < 0 || EU.sel >= ED.n) EU.drag = 0;
        else if (P.down && !ui_block) { if (!EU.moved && hypotf(P.x - P.downx, P.y - P.downy) > 5.0f) EU.moved = 1; if (EU.moved) ed_drag_to(lx, ly); }
        else { EU.drag = 0; if (EU.dirty) ed_commit(); }
    }
    /* ---- the level ---- */
    gfx_zoom(ED_K); gfx_offset(ED_X / ED_K, ED_Y / ED_K);
    draw_scene();
    for (int i = 0; i < ED.n; i++) {                    /* what cannot be seen in the picture itself */
        const LObj *o = &ED.o[i];
        if (o->type == O_PORTAL && o->a >= 0) { float sn, cs; sim_sincos(o->a, &sn, &cs); gfx_capsule(o->x + cs * 38, o->y + sn * 38, o->x + cs * 72, o->y + sn * 72, 4, 0xFFFFFFD0u); gfx_circle(o->x + cs * 76, o->y + sn * 76, 8, 0xFFFFFFE6u); }
        if (o->type == O_PORTAL) { snprintf(buf, sizeof(buf), "%d", (int)o->b + 1); gfx_text(&F_ui, buf, o->x, o->y - 50, 24, WHITE, AL_CENTER); }
        if (o->type == O_BLOWER) { float sn, cs; sim_sincos(o->a, &sn, &cs); gfx_capsule(o->x + cs * 60, o->y + sn * 60, o->x + cs * 110, o->y + sn * 110, 3, 0xFFFFFF90u); gfx_circle(o->x + cs * 114, o->y + sn * 114, 7, 0xFFFFFFB0u); }
    }
    if (EU.sel >= 0 && EU.sel < ED.n) {
        const LObj *o = &ED.o[EU.sel];
        if (ed_two(o->type)) {
            for (int h = 1; h <= 3; h++) { float x, y; ed_handle(o, h, &x, &y); gfx_circle(x, y, h == 3 ? 15 : 19, 0x140D3AC0u); gfx_circle(x, y, h == 3 ? 11 : 15, h == EU.grab && EU.drag ? WHITE : C_GOLD); if (h == 3) { gfx_rect(x - 7, y - 1.5f, 14, 3, 0x140D3AFFu); gfx_rect(x - 1.5f, y - 7, 3, 14, 0x140D3AFFu); } }
        } else dashed_circle(o->x, o->y, o->type == O_MEL ? 78.0f : 46.0f, g_time * 0.6f, 5.0f, C_GOLD);
    }
    gfx_zoom(1.0f); gfx_offset(0, 0); gfx_clip_reset();
    /* ---- frame around the level ---- */
    gfx_rect(0, 0, DESIGN_W, ED_Y, frame); gfx_rect(0, ED_Y + ED_H, DESIGN_W, DESIGN_H - ED_Y - ED_H, frame); gfx_rect(0, ED_Y, ED_X, ED_H, frame); gfx_rect(ED_X + ED_W, ED_Y, DESIGN_W - ED_X - ED_W, ED_H, frame);
    gfx_rect(ED_X - 3, ED_Y - 3, ED_W + 6, 3, C_EDGE); gfx_rect(ED_X - 3, ED_Y + ED_H, ED_W + 6, 3, C_EDGE); gfx_rect(ED_X - 3, ED_Y, 3, ED_H, C_EDGE); gfx_rect(ED_X + ED_W, ED_Y, 3, ED_H, C_EDGE);
    /* ---- top bar ---- */
    if (rbtn(6, 46, 43, 29, IC_BACK, C_VIO1, C_VIO2, 1)) { if (EU.dirty) ed_commit(); go(SC_HUB, 0, 0); }
    if (wbtn(500, 262, 43, 340, 56, ED.name, C_VIO1, C_VIO2, gfx_text_w(&F_ui, ED.name, 24) > 250 ? 24 * 250 / gfx_text_w(&F_ui, ED.name, 24) : 24, IC_EDIT, 1)) kb_open("Название уровня", ED.name, 20, 1, ed_name_done);
    snprintf(buf, sizeof(buf), "Фон: %s", box_name[ED.bg]);
    if (wbtn(501, 566, 43, 244, 56, buf, C_BLUE1, C_BLUE2, 20, IC_NONE, 1)) { ED.bg = (ED.bg + 1) % BOXES; slot_save(ed_slot, &ED); ed_refresh(); }
    if (wbtn(502, 786, 43, 172, 56, "Проба", C_GREEN1, C_GREEN2, 26, IC_PLAY, 1)) ed_test();
    if (wbtn(503, 1022, 43, 276, 56, ED.pub_id ? "Опубликован" : "Опубликовать", C_ORG1, C_ORG2, 23, IC_GLOBE, !NET.busy[RQ_PUB])) ed_publish();
    if (EU.clear) { EU.clear_t -= g_dt; if (EU.clear_t <= 0) EU.clear = 0; }
    if (rbtn(504, 1226, 43, 27, IC_TRASH, EU.clear ? C_ORG1 : C_RED1, EU.clear ? C_ORG2 : C_RED2, 1)) {
        if (EU.clear) { EU.clear = 0; ed_new(); EU.sel = -1; ed_commit(); gtoast("Уровень очищен"); } else { EU.clear = 1; EU.clear_t = 3.0f; gtoast("Нажми ещё раз — сотру всё"); }
    }
    /* ---- palette ---- */
    float px = ED_X + ED_W + 12, pw = DESIGN_W - px - 8;
    gfx_text(&F_ui, "Добавить", px + pw * 0.5f, 106, 23, C_GOLD, AL_CENTER);
    for (int i = 0; i < 11; i++) {
        int t = ed_palette[i]; float x = px + pw * 0.25f + (i % 2) * pw * 0.5f, y = 150 + (i / 2) * 55.0f;
        if (wbtn(510 + i, x, y, pw * 0.5f - 8, 46, obj_name[t], C_VIO1, C_VIO2, t == O_GRAV ? 16.5f : 20, IC_NONE, ed_can_add(t))) ed_add(t);
    }
    int stars = ed_count(&ED, O_STAR);
    snprintf(buf, sizeof(buf), "Объектов: %d из %d", ED.n, ED_MAXO); gfx_text(&F_txt, buf, px + pw * 0.5f, 492, 18, 0xE4DCFFFFu, AL_CENTER);
    snprintf(buf, sizeof(buf), "Звёзд: %d", stars); gfx_text(&F_txt, buf, px + pw * 0.5f, 516, 18, 0xE4DCFFFFu, AL_CENTER);
    const char *stt = ED.pub_id ? "Опубликован" : (ED.solved ? "Пройден: можно публиковать" : "Не пройден: нажми «Проба»");
    gfx_text_wrap(&F_txt, stt, px + pw * 0.5f, 548, 18, pw - 10, 22, ED.solved || ED.pub_id ? 0x9CF04EFFu : C_ORG1, AL_CENTER, 1);
    if (ED.pub_id) { snprintf(buf, sizeof(buf), "Номер уровня: %d", ED.pub_id); gfx_text(&F_txt, buf, px + pw * 0.5f, 574, 18, 0x9CF04EFFu, AL_CENTER); }
    gfx_text_wrap(&F_txt, "Тащи объекты мышкой или пальцем. Жёлтые кружки меняют длину и наклон.", px + pw * 0.5f, 612, 16, pw - 10, 20, 0xFFFFFF90u, AL_CENTER, 1);
    /* ---- the selected object ---- */
    float by = ED_Y + ED_H + 46;
    if (EU.sel >= 0 && EU.sel < ED.n) {
        LObj *o = &ED.o[EU.sel]; int fixed = (o->type == O_CANDY || o->type == O_MEL);
        gfx_text(&F_ui, obj_name[o->type], 22, by - 12, 25, C_GOLD, AL_LEFT);
        snprintf(buf, sizeof(buf), "x %d  y %d", (int)o->x, (int)o->y); gfx_text(&F_txt, buf, 22, by + 16, 16, 0xFFFFFFA0u, AL_LEFT);
        for (int k = 0; k < 3; k++) {
            const EdProp *p = &ed_props[o->type][k]; if (!p->label) break;
            float x = 290 + k * 214.0f; char val[40]; ed_value(o, p, val, (int)sizeof(val));
            gfx_text(&F_txt, p->label, x, by - 24, 16, 0xD8CCFFFFu, AL_CENTER);
            if (rbtn(530 + k * 2, x - 78, by + 10, 20, IC_MINUS, C_VIO1, C_VIO2, 1)) { ed_step(o, p, -1); ed_commit(); }
            text_fit(&F_ui, val, x, by + 10, 22, 108, WHITE, AL_CENTER);
            if (rbtn(531 + k * 2, x + 78, by + 10, 20, IC_PLUS, C_VIO1, C_VIO2, 1)) { ed_step(o, p, 1); ed_commit(); }
        }
        if (rbtn(540, ED_X + ED_W - 86, by, 25, IC_COPY, C_BLUE1, C_BLUE2, !fixed && o->type != O_PORTAL && ed_can_add(o->type))) ed_copy(EU.sel);
        if (rbtn(541, ED_X + ED_W - 28, by, 25, IC_TRASH, C_RED1, C_RED2, !fixed)) ed_remove(EU.sel);
    } else gfx_text(&F_txt, "Нажми на объект, чтобы выбрать его. Кнопки справа добавляют новые объекты.", 22, by, 19, 0xFFFFFFB0u, AL_LEFT);
}

/* ============================== V0.4: the account, who is online, the update, the support window ============================== */
/* An account = a nick + a password. The password never leaves the device as it was typed: the table gets its SHA-256.
   For a correct nick and password the table hands out the player's number and a key; the key signs every record sent later. */
enum { WN_NONE, WN_ACC, WN_DONATE, WN_UPDATE };
enum { AO_NONE, AO_REG, AO_LOGIN, AO_REN, AO_PW };
static struct { int kind, out_ask; float out_t; } WN;
static struct { int op, busy, note; char nick[40], ph[68], ph_old[68], hb_w[16]; float hb_t, ping_t; } AC;      /* note: something to tell the player back in the menu (1 banned, 2 signed out) */
static char don_url[256];                            /* the support page: from online.json, so it can be changed or removed without a new build */
static struct { int ver, size, pf, asked; char name[16], file[80], sha[72], site[300]; } UP;      /* the newest version, as online.json describes it */

static int wn_on(void) { return WN.kind != WN_NONE; }
static void wn_close(void) { WN.kind = WN_NONE; }
static int acc_ready(void) { return NET.st == NS_ON && NET.proto >= 4; }
static const char *acc_label(void) { return SV.nick[0] ? SV.nick : "Аккаунт"; }
static void acc_open(void) { WN.kind = WN_ACC; WN.out_ask = 0; if (NET.st == NS_ERR || NET.st == NS_NONE) net_cfg(); }
static void acc_hash(const char *pw, char *out) { sha256_hex2("mel-nyam/pw/v1:", pw, out); }
static void acc_send(void) {
    static char body[700]; char u[16]; snprintf(u, sizeof(u), "%u", (unsigned)SV.uid); body[0] = 0;
    if (AC.op == AO_REG) snprintf(body, sizeof(body), "reg\t%s\t%s\t%s\t%d\t%08x", u, AC.nick, AC.ph, APP_VER, (unsigned)net_sig("reg", u, AC.nick, AC.ph, ""));
    else if (AC.op == AO_LOGIN) snprintf(body, sizeof(body), "login\t%s\t%s\t%d\t%08x", AC.nick, AC.ph, APP_VER, (unsigned)net_sig("login", AC.nick, AC.ph, "", ""));
    else if (AC.op == AO_REN) snprintf(body, sizeof(body), "ren\t%s\t%s\t%s\t%08x", u, CFG.token, AC.nick, (unsigned)net_sig("ren", u, AC.nick, "", ""));
    else if (AC.op == AO_PW) snprintf(body, sizeof(body), "pw\t%s\t%s\t%s\t%s\t%08x", u, CFG.token, AC.ph_old, AC.ph, (unsigned)net_sig("pw", u, AC.ph_old, AC.ph, ""));
    if (!body[0]) return;
    if (!acc_ready()) { AC.op = AO_NONE; msg_open("Нет связи", "Таблица рекордов сейчас недоступна. Проверь интернет и попробуй ещё раз."); return; }
    AC.busy = 1; net_post(RQ_ACC, body);
}
static void acc_pw_done(const char *t);
static void acc_pw2_done(const char *t) {            /* the password typed a second time: it has to be the same */
    char h[68]; acc_hash(t, h);
    if (strcmp(h, AC.ph)) { kb_open_pw(AC.op == AO_PW ? "Новый пароль" : "Придумай пароль", 1, acc_pw_done); snprintf(KB.err, sizeof(KB.err), "Пароли не совпали. Введи пароль заново."); return; }
    acc_send();
}
static void acc_pw_done(const char *t) {
    acc_hash(t, AC.ph);
    if (AC.op == AO_LOGIN) acc_send(); else kb_open_pw("Повтори пароль ещё раз", 0, acc_pw2_done);
}
static void acc_oldpw_done(const char *t) { acc_hash(t, AC.ph_old); kb_open_pw("Новый пароль", 1, acc_pw_done); }
static void acc_nick_done(const char *t) {
    snprintf(AC.nick, sizeof(AC.nick), "%s", t);
    if (AC.op == AO_REN) acc_send(); else kb_open_pw(AC.op == AO_LOGIN ? "Пароль от аккаунта" : "Придумай пароль", AC.op == AO_REG, acc_pw_done);
}
static void acc_start(int op) {
    if (AC.busy) return;
    AC.op = op;
    if (op == AO_REG) kb_open("Придумай ник: 2–12 букв или цифр", SV.nick, 12, 0, acc_nick_done);
    else if (op == AO_LOGIN) kb_open("Ник твоего аккаунта", SV.nick, 12, 0, acc_nick_done);
    else if (op == AO_REN) kb_open("Новый ник", SV.nick, 12, 0, acc_nick_done);
    else if (op == AO_PW) kb_open_pw("Старый пароль", 0, acc_oldpw_done);
}
static void acc_forget(void) {                       /* this device is not signed in any more */
    CFG.acc = 0; memset(CFG.token, 0, sizeof(CFG.token)); cfg_store();
}
/* V0.5: the progress belongs to the account, not to the device. Signing out puts the last changes into the table and leaves
   the device with the progress of its own guest (an empty one, or what he had before he signed in). See g_meta.inc. */
static void acc_logout(void) {
    prof_logout();
    acc_banned = 0; AC.hb_w[0] = 0;
    gtoast("Ты вышел из аккаунта"); if (scr == SC_RECORDS) records_load();
}
static const char *acc_err(const char *code, int status, int op) {
    if (status != 200) return "Нет связи с таблицей рекордов. Проверь интернет и попробуй ещё раз.";
    if (!strcmp(code, "taken")) return "Этот ник уже занят другим игроком. Придумай другой.";
    if (!strcmp(code, "badnick")) return "Такой ник не подходит. Нужны 2–12 букв или цифр, без ругательств.";
    if (!strcmp(code, "auth")) return op == AO_LOGIN ? "Неверный ник или пароль." : (op == AO_PW ? "Старый пароль введён неверно." : "Вход в аккаунт устарел. Выйди из аккаунта и войди заново.");
    if (!strcmp(code, "wait")) return "Слишком много неудачных попыток. Подожди 10 минут и попробуй снова.";
    if (!strcmp(code, "ban")) return "Этот аккаунт заблокирован.";
    if (!strcmp(code, "exists")) return "С этого устройства аккаунт уже создавали. Нажми «Войти» и введи его ник и пароль.";
    if (!strcmp(code, "limit")) return "Сегодня создано слишком много аккаунтов. Попробуй завтра.";
    if (!strcmp(code, "unknown")) return "Таблица рекордов ещё не обновлена и пока не умеет работать с аккаунтами.";
    return "Таблица не приняла запрос. Попробуй ещё раз чуть позже.";
}
static void acc_answer(int ok, int status, char *ln) {
    int op = AC.op; AC.busy = 0; AC.op = AO_NONE;
    if (!ok) { msg_open("Не получилось", acc_err(ln ? nfld(&ln) : "", status, op)); }
    else if (op == AO_REG || op == AO_LOGIN) {
        char *uid = nfld(&ln), *nick = nfld(&ln), *tok = nfld(&ln); u32 u = (u32)strtoul(uid, NULL, 10);
        if (!u || strlen(tok) < 16 || strlen(tok) >= sizeof(CFG.token)) msg_open("Не получилось", "Таблица ответила непонятно. Попробуй ещё раз чуть позже.");
        else {
            if (op == AO_LOGIN) prof_on_login(u);         /* the progress of the account replaces what was on the screen; the guest's own is put away until he signs out */
            SV.uid = u;
            text_clean(SV.nick, (int)sizeof(SV.nick), nick, 12); snprintf(CFG.token, sizeof(CFG.token), "%s", tok); CFG.acc = 1; acc_banned = 0;
            if (op == AO_REG) prof_on_register();         /* a new account: what this player has done so far becomes its progress */
            save_store(); cfg_store(); AC.hb_w[0] = 0; wn_close();
            if (op == AO_LOGIN) {
                if (NET.proto < 5) { char q[140]; snprintf(q, sizeof(q), "a=mine&u=%u&t=%s", (unsigned)SV.uid, CFG.token); net_get(RQ_MINE, q); }      /* an old table keeps only the records */
                gtoast("Вход выполнен. Загружаю прогресс...");
            } else { gtoast("Аккаунт создан!"); online_flush(); }
            if (scr == SC_RECORDS) records_load();
        }
    } else if (op == AO_REN) { text_clean(SV.nick, (int)sizeof(SV.nick), nfld(&ln), 12); save_store(); gtoast("Ник изменён"); if (scr == SC_RECORDS) records_load(); }
    else if (op == AO_PW) { char *tok = nfld(&ln); if (strlen(tok) >= 16 && strlen(tok) < sizeof(CFG.token)) { snprintf(CFG.token, sizeof(CFG.token), "%s", tok); cfg_store(); } gtoast("Пароль изменён"); }
    memset(AC.ph, 0, sizeof(AC.ph)); memset(AC.ph_old, 0, sizeof(AC.ph_old));
}
/* the progress kept by the table (after signing in on another device): every level takes the better of the two results */
static void acc_mine(int ok, char *p) {
    int n = 0; char *ln; char m[96];
    while (ok && (ln = nline(&p)) != NULL) {
        if (!*ln) continue;
        char *key = nfld(&ln); int st = atoi(nfld(&ln)), tk = atoi(nfld(&ln));
        for (int i = 0; i < LEVEL_COUNT; i++) {
            char k[24]; level_key(i, k, (int)sizeof(k)); if (strcmp(k, key)) continue;
            if (st < 0 || st > lv_max[i] || tk < 1 || tk >= (1 << 17)) break;
            int old = lvl_stars(i);
            if (!lvl_done(i) || st > old || (st == old && (SV.ticks[i] == 0 || (u32)tk < SV.ticks[i]))) {
                char rk[8]; own_key(i, rk); plat_store(rk, "", 0);            /* the recording kept here belongs to a weaker run; the better one is in the table */
                SV.best[i] = (u8)(st + 1); SV.ticks[i] = (u32)tk; SV.sent[i] = 1; n++;
            } else if (st == old && (u32)tk == SV.ticks[i]) SV.sent[i] = 1;
            break;
        }
    }
    save_store();
    if (!ok) snprintf(m, sizeof(m), "Вход выполнен. Прогресс загрузить не удалось");
    else if (n) snprintf(m, sizeof(m), "Вход выполнен. Загружено уровней: %d", n); else snprintf(m, sizeof(m), "Вход выполнен");
    gtoast(m); online_flush(); ach_check(); prof_dirty();
}
/* who is online: now and again the game tells the table where the player is (only the owner of the table sees it, in the admin tool) */
static void where_code(char *o, int n) {
    const char *s = "m";
    switch (scr) {
    case SC_PLAY:
        if (CUR.kind == 0) { snprintf(o, (size_t)n, "%c%d", L_replay ? 'w' : 'l', CUR.idx + 1); return; }
        if (CUR.kind == 2) { snprintf(o, (size_t)n, "p%.9s", CUR.key[0] == 'u' ? CUR.key + 1 : ""); return; }
        s = "e"; break;
    case SC_CHAPTERS: case SC_BOXES: case SC_LEVELS: s = "c"; break;
    case SC_RECORDS: s = "r"; break; case SC_HUB: s = "h"; break; case SC_EDITOR: s = "e"; break;
    case SC_TAS: s = "t"; break; case SC_SETTINGS: s = "s"; break; case SC_FINAL: s = "f"; break;
    case SC_TASKS: s = "q"; break; case SC_SHOP: s = "k"; break; case SC_ACH: s = "a"; break; case SC_CHAT: s = "u"; break; case SC_ADMIN: s = "z"; break;
    default: break;
    }
    snprintf(o, (size_t)n, "%s", s);
}
static void hb_send(void) {
    char q[220], w[16]; where_code(w, (int)sizeof(w)); snprintf(AC.hb_w, sizeof(AC.hb_w), "%s", w);
    int k = snprintf(q, sizeof(q), "a=hb&u=%u&w=%s&v=%d&p=%d", (unsigned)SV.uid, w, APP_VER, plat_ctl(PC_PLATFORM, NULL, 0, 0));
    if (CFG.acc && CFG.token[0]) snprintf(q + k, sizeof(q) - (size_t)k, "&t=%s", CFG.token);
    net_get(RQ_HB, q); AC.hb_t = 0;
}
static void hb_answer(int ok, int status, char *ln) {
    if (ok) { hb_extra(ln); return; }
    if (status != 200) return;
    const char *c = ln ? nfld(&ln) : "";
    if (!strcmp(c, "ban")) { if (!acc_banned) AC.note = 1; acc_banned = 1; }
    else if (!strcmp(c, "auth") && CFG.acc) acc_kicked();                          /* the key is not valid any more: the password was changed on another device, or the account is gone */
}

/* ---------- the update ---------- */
#ifdef MN_ADMIN
static int upd_pending(void) { return 0; }           /* the owner's tool must not replace itself with the published game */
#else
static int upd_pending(void) { return UP.ver > APP_VER && UP.pf != PF_OTHER && UP.name[0]; }
#endif
static const char *upd_label(void) { static char b[64]; snprintf(b, sizeof(b), "Обновить до %s", UP.name); return b; }
static void upd_open(void) { WN.kind = WN_UPDATE; UP.asked = 1; }
static void upd_start(void) {
    static char arg[480];
    if (UP.pf == PF_SITE) snprintf(arg, sizeof(arg), "%s", UP.site); else snprintf(arg, sizeof(arg), "%s%s\n%s", UP.site, UP.file, UP.sha);
    plat_ctl(PC_UPDATE_RESET, NULL, 0, 0);
    if (!plat_ctl(PC_UPDATE, arg, UP.size, UP.ver)) gtoast("Обновление не запустилось");
}
static void upd_draw(void) {
    static char buf[700]; int st = plat_ctl(PC_UPDATE_STATE, NULL, 0, 0), pf = UP.pf;
    panel(270, 150, 740, 420);
    title_text(st < 0 ? "Не получилось обновить" : "Вышло обновление!", 640, 208, 40);
    if (st == 0) {
        const char *how = pf == PF_WIN ? "Игра сама скачает её, заменит свой файл и запустится заново." :
                          pf == PF_APK ? "Игра скачает её и откроет установщик Android: нажми в нём «Обновить» или «Установить». Если Android спросит разрешение на установку, разреши его для игры." :
                          pf == PF_SITE ? "Страница загрузится заново, уже с новой версией." :
                                          "Ты играешь в сохранённый файл: сам себя он заменить не может. Открой сайт игры — там всегда свежая версия, и файл можно скачать заново.";
        snprintf(buf, sizeof(buf), "Новая версия игры — %s (у тебя %s). %s%s", UP.name, APP_VER_NAME, how, pf == PF_FILE ? "" : " Прогресс и аккаунт останутся на месте.");
        gfx_text_wrap(&F_txt, buf, 640, 262, 23, 640, 32, 0xE8E0FFFFu, AL_CENTER, 1);
        if (pf == PF_FILE) { if (wbtn(784, 500, 500, 300, 66, "Открыть сайт", C_GREEN1, C_GREEN2, 28, IC_GLOBE, 1)) plat_ctl(PC_OPEN_URL, UP.site, 0, 0); }
        else if (wbtn(784, 500, 500, 300, 66, "Обновить", C_GREEN1, C_GREEN2, 30, IC_GET, 1)) upd_start();
        if (wbtn(785, 810, 500, 220, 66, "Позже", C_VIO1, C_VIO2, 28, IC_NONE, 1)) wn_close();
    } else if (st > 0 && st <= 100) {
        snprintf(buf, sizeof(buf), "Скачиваю новую версию: %d %%", st); gfx_text(&F_ui, buf, 640, 300, 28, WHITE, AL_CENTER);
        gfx_rrect(360, 350, 560, 30, 15, 0x0E0A2EFFu); gfx_rrect(364, 354, 552.0f * (float)st / 100.0f, 22, 11, C_GREEN1);
        gfx_text(&F_txt, "Не закрывай игру.", 640, 430, 21, 0xFFFFFFB0u, AL_CENTER);
    } else if (st > 100) {
        gfx_text_wrap(&F_txt, pf == PF_APK ? "Новая версия скачана и проверена. Сейчас откроется установщик Android: нажми «Обновить» или «Установить». Игра закроется — потом запусти её снова." :
                              pf == PF_WIN ? "Новая версия скачана и проверена. Перезапускаю игру..." : "Загружаю страницу заново...",
                      640, 286, 24, 620, 34, 0xE8E0FFFFu, AL_CENTER, 1);
        if (pf == PF_APK && wbtn(785, 640, 500, 240, 66, "Закрыть", C_VIO1, C_VIO2, 28, IC_NONE, 1)) wn_close();
    } else {
        const char *why = st == UPD_NET ? "Не удалось скачать новую версию: нет связи с сайтом игры. Попробуй ещё раз позже." :
                          st == UPD_BAD ? "Скачанный файл не прошёл проверку, и игра его не тронула. Попробуй ещё раз чуть позже." :
                          st == UPD_WRITE ? "Не удалось заменить файл игры: папка, где он лежит, закрыта для записи. Скачай новую версию с сайта." :
                          (pf == PF_APK ? "Установка не состоялась. Если Android не разрешил её, включи для игры «Установку неизвестных приложений» и попробуй ещё раз." : "Обновление отменено.");
        gfx_text_wrap(&F_txt, why, 640, 270, 23, 640, 32, 0xE8E0FFFFu, AL_CENTER, 1);
        if (wbtn(784, 430, 500, 230, 62, "Ещё раз", C_GREEN1, C_GREEN2, 26, IC_RESTART, 1)) upd_start();
        if (wbtn(786, 668, 500, 230, 62, "На сайт", C_BLUE1, C_BLUE2, 26, IC_GLOBE, 1)) plat_ctl(PC_OPEN_URL, UP.site, 0, 0);
        if (wbtn(785, 880, 500, 170, 62, "Позже", C_VIO1, C_VIO2, 26, IC_NONE, 1)) { plat_ctl(PC_UPDATE_RESET, NULL, 0, 0); wn_close(); }
    }
}

/* ---------- the support window ---------- */
static int donate_has(void) { return don_url[0] != 0; }
static void donate_open(void) { WN.kind = WN_DONATE; }
static void donate_draw(void) {
    panel(240, 104, 800, 512);
    icon(IC_HEART, 640 - gfx_text_w(&F_ui, "Поддержать игру", 40) * 0.5f - 34, 162, 19, C_PINK); title_text("Поддержать игру", 640 + 16, 162, 40);
    gfx_text_wrap(&F_txt, "«Мел-Ням» — бесплатная фан-игра, и такой она останется. Если она тебе нравится, автору можно сказать «спасибо» добровольным переводом.", 640, 214, 22, 700, 31, 0xE8E0FFFFu, AL_CENTER, 1);
    gfx_rrect(300, 318, 680, 2, 1, 0xFFFFFF30u);
    gfx_text_wrap(&F_txt, "За перевод в игре ничего не даётся. Получатель перевода — отец автора игры. Меллстрой с игрой не связан и денег не получает.", 640, 338, 21, 700, 30, 0xD8CCFFFFu, AL_CENTER, 1);
    gfx_text(&F_ui, "Младше 18? Сначала спроси родителей.", 640, 446, 25, C_GOLD, AL_CENTER);
    if (wbtn(780, 516, 528, 340, 66, "Открыть страницу", C_PINK, 0xB8257FFFu, 27, IC_NONE, 1)) { if (plat_ctl(PC_OPEN_URL, don_url, 0, 0)) gtoast("Страница открывается в браузере"); else gtoast("Не получилось открыть браузер"); }
    if (wbtn(781, 836, 528, 220, 66, "Закрыть", C_VIO1, C_VIO2, 27, IC_NONE, 1)) wn_close();
    {   /* say where the button leads: the name of the site from the address */
        static char line[160]; const char *h = strstr(don_url, "://"); h = h ? h + 3 : don_url; int n = (int)strcspn(h, "/?#");
        snprintf(line, sizeof(line), "Страница откроется в браузере: %.*s", n > 60 ? 60 : n, h);
        gfx_text(&F_txt, line, 640, 590, 17, 0xFFFFFF90u, AL_CENTER);
    }
}

/* ---------- the account window ---------- */
static void acc_draw(void) {
    static char buf[500]; int ready = acc_ready();
    panel(280, 120, 720, 480);
    title_text("Аккаунт", 640, 176, 42);
    if (AC.busy) {
        for (int i = 0; i < 3; i++) gfx_circle(606 + i * 34.0f, 330, 8.0f + 4.0f * sinf(g_time * 6.0f - (float)i * 0.9f), C_GOLD);
        gfx_text(&F_txt, "Связываюсь с таблицей рекордов...", 640, 384, 23, 0xE8E0FFFFu, AL_CENTER);
    } else if (CFG.acc) {
        gfx_text(&F_txt, "Ты вошёл как", 640, 232, 22, 0xD8CCFFFFu, AL_CENTER);
        text_fit(&F_ui, SV.nick, 640, 276, 44, 560, C_GOLD, AL_CENTER);
        gfx_text_wrap(&F_txt, acc_banned ? "Этот аккаунт заблокирован: рекорды и уровни с него не принимаются." : "Прогресс, чекушки и скины хранятся в аккаунте. Войди в него на другом устройстве — и всё будет там же. После выхода на этом устройстве останется пустой профиль гостя.", 640, 320, 20, 620, 28, acc_banned ? C_RED1 : 0xE8E0FFFFu, AL_CENTER, 1);
        if (wbtn(770, 474, 432, 316, 58, "Сменить ник", C_BLUE1, C_BLUE2, 24, IC_EDIT, ready)) acc_start(AO_REN);
        if (wbtn(771, 806, 432, 316, 58, "Сменить пароль", C_BLUE1, C_BLUE2, 24, IC_LOCK, ready)) acc_start(AO_PW);
        if (WN.out_ask) { WN.out_t -= g_dt; if (WN.out_t <= 0) WN.out_ask = 0; }
        if (wbtn(772, 474, 512, 316, 58, WN.out_ask ? "Точно выйти?" : "Выйти", C_RED1, C_RED2, 24, IC_NONE, 1)) { if (WN.out_ask) { WN.out_ask = 0; acc_logout(); } else { WN.out_ask = 1; WN.out_t = 3.0f; } }
        if (wbtn(773, 806, 512, 316, 58, "Закрыть", C_VIO1, C_VIO2, 24, IC_NONE, 1)) wn_close();
    } else {
        int old = NET.st == NS_ON && NET.proto && NET.proto < 4;
        if (ready && SV.nick[0]) snprintf(buf, sizeof(buf), "Ник «%s» пока без пароля. Придумай пароль — и в аккаунт можно будет войти на другом устройстве: ник, рекорды и прогресс сохранятся.", SV.nick);
        else if (ready) snprintf(buf, sizeof(buf), "Аккаунт — это ник и пароль. С ним твои рекорды и прогресс не пропадут: войти можно на телефоне, на компьютере и в браузере.");
        else if (old) snprintf(buf, sizeof(buf), "Таблица рекордов ещё не обновлена: аккаунты с паролем появятся чуть позже. Пока можно просто выбрать ник.");
        else if (NET.st == NS_ON || NET.st == NS_CFG || NET.st == NS_NONE) snprintf(buf, sizeof(buf), "Подключаюсь к таблице рекордов...");
        else snprintf(buf, sizeof(buf), "%s", NET.st == NS_OFF ? "Онлайн-таблица пока не подключена: аккаунты появятся позже." : "Нет связи с интернетом. Аккаунт можно создать, когда связь появится.");
        gfx_text_wrap(&F_txt, buf, 640, 236, 22, 620, 31, 0xE8E0FFFFu, AL_CENTER, 1);
        if (old) { if (wbtn(770, 640, 420, 380, 62, SV.nick[0] ? "Сменить ник" : "Выбрать ник", C_GREEN1, C_GREEN2, 27, IC_EDIT, 1)) { wn_close(); kb_open("Твой ник для таблицы рекордов", SV.nick, 12, 0, nick_done); } }
        else {
            if (wbtn(770, 474, 420, 316, 66, "Создать аккаунт", C_GREEN1, C_GREEN2, 25, IC_PLUS, ready)) acc_start(AO_REG);
            if (wbtn(771, 806, 420, 316, 66, "Войти", C_BLUE1, C_BLUE2, 27, IC_USER, ready)) acc_start(AO_LOGIN);
        }
        if (wbtn(773, 640, 516, 260, 58, "Закрыть", C_VIO1, C_VIO2, 25, IC_NONE, 1)) wn_close();
    }
}
static void wn_draw(void) {
    gfx_fade(0x0A0626C8u);
    if (WN.kind == WN_ACC) acc_draw(); else if (WN.kind == WN_DONATE) donate_draw(); else if (WN.kind == WN_UPDATE) upd_draw();
}
static int wn_key(int key) {
    if (key == KEY_ESC) { int st = WN.kind == WN_UPDATE ? plat_ctl(PC_UPDATE_STATE, NULL, 0, 0) : 0; if (!AC.busy && !(st > 0 && st <= 100)) wn_close(); }
    return 1;
}
/* small reader of online.json: "key":"text" and "key":number */
static int json_str(const char *p, const char *key, char *out, int max) {
    char k[48]; snprintf(k, sizeof(k), "\"%s\"", key); out[0] = 0;
    const char *s = strstr(p, k); if (!s) return 0;
    s = strchr(s + strlen(k), ':'); if (!s) return 0;
    for (s++; *s == ' ' || *s == '\t' || *s == '\r' || *s == '\n'; s++) {}
    if (*s != '"') return 0;
    int n = 0; for (s++; *s && *s != '"' && n + 1 < max; s++) { if (*s == '\\' && s[1]) s++; out[n++] = *s; }
    out[n] = 0; return *s == '"' ? n : (out[0] = 0);
}
static int json_int(const char *p, const char *key) {
    char k[48]; snprintf(k, sizeof(k), "\"%s\"", key);
    const char *s = strstr(p, k); if (!s) return 0;
    s = strchr(s + strlen(k), ':'); if (!s) return 0;
    for (s++; *s == ' ' || *s == '"'; s++) {}
    return atoi(s);
}
static int url_ok(const char *u) {                   /* https only, nothing but plain address characters */
    if (strncmp(u, "https://", 8) && !NET.cfg[0]) return 0;           /* (a test address given by hand may be http) */
    if (strncmp(u, "https://", 8) && strncmp(u, "http://", 7)) return 0;
    for (const char *s = u; *s; s++) if ((unsigned char)*s <= 32 || (unsigned char)*s >= 127 || *s == '"' || *s == '\'' || *s == '<' || *s == '>' || *s == '\\') return 0;
    return strlen(u) > 12;
}
/* what online.json says besides the table address: the support page and the newest version */
static void cfg_extras(const char *p) {
    static char t[300]; const char *cfg = NET.cfg[0] ? NET.cfg : ONLINE_CFG_URL; const char *sl = strrchr(cfg, '/');
    don_url[0] = 0; if (json_str(p, "donate", t, (int)sizeof(don_url)) && url_ok(t)) snprintf(don_url, sizeof(don_url), "%.*s", (int)sizeof(don_url) - 1, t);
    memset(&UP.ver, 0, sizeof(UP.ver)); UP.name[0] = 0; UP.file[0] = 0; UP.sha[0] = 0; UP.size = 0;
    snprintf(UP.site, sizeof(UP.site), "%.*s", sl ? (int)(sl - cfg) + 1 : 0, cfg);
    UP.pf = plat_ctl(PC_PLATFORM, NULL, 0, 0);
    int ver = json_int(p, "ver"); const char *pre = UP.pf == PF_WIN ? "exe" : (UP.pf == PF_APK ? "apk" : "html"); char key[24];
    if (ver <= 0 || !json_str(p, "vname", t, (int)sizeof(UP.name)) || strlen(t) > 12) return;
    for (const char *s = t; *s; s++) if (!((*s >= '0' && *s <= '9') || *s == '.')) return;
    snprintf(UP.name, sizeof(UP.name), "%s", t);
    if (UP.pf == PF_WIN || UP.pf == PF_APK) {         /* a file to download: its name, size and SHA-256 must all be there */
        snprintf(key, sizeof(key), "%s_size", pre); UP.size = json_int(p, key);
        snprintf(key, sizeof(key), "%s_sha", pre); json_str(p, key, UP.sha, (int)sizeof(UP.sha));
        json_str(p, pre, t, (int)sizeof(UP.file)); int good = t[0] && strlen(UP.sha) == 64 && UP.size > 100000 && UP.size < (64 << 20);
        for (const char *s = t; *s; s++) if (!((*s >= '0' && *s <= '9') || (*s >= 'A' && *s <= 'Z') || (*s >= 'a' && *s <= 'z') || *s == '.' || *s == '_' || *s == '-')) good = 0;
        if (!good) return;
        snprintf(UP.file, sizeof(UP.file), "%s", t);
    }
    UP.ver = ver;
}

/* ============================== answers from the network ============================== */
static void got_cfg(int status, char *p) {
    if (NET.forced) return;
    if (status != 200) { NET.st = status == 0 ? NS_ERR : NS_OFF; NET.retry = status == 0 ? 25.0f : 600.0f; return; }
    char *k = strstr(p, "\"api\""), *v = k ? strchr(k + 5, ':') : NULL, *q0 = v ? strchr(v, '"') : NULL, *q1 = q0 ? strchr(q0 + 1, '"') : NULL;
    if (q0 && q1 && q1 - q0 - 1 > 12 && q1 - q0 - 1 < (int)sizeof(NET.api) && (!strncmp(q0 + 1, "https://", 8) || (NET.cfg[0] && !strncmp(q0 + 1, "http://127.0.0.1", 16)))) {      /* plain http: only in tests, on this computer */
        memcpy(NET.api, q0 + 1, (size_t)(q1 - q0 - 1)); NET.api[q1 - q0 - 1] = 0; NET.st = NS_ON; }
    else { NET.st = NS_OFF; NET.retry = 600.0f; }
    cfg_extras(p);
    if (NET.st == NS_ON) { NET.proto = 0; AC.ping_t = 0; online_flush(); if (scr == SC_RECORDS) records_load(); if (scr == SC_HUB && HB.tab == 1) hub_request(); }
}
static int net_ok(int status, char **p, char **line) {         /* the first line of every answer is "ok<TAB>..." or "err<TAB>why" */
    if (status != 200) return 0;
    *line = nline(p); if (!*line) return 0;
    return !strcmp(nfld(line), "ok");
}
void app_http(int id, int status, const char *data, int size) {
    if (dbg_http_on) { dbg_http_on = 0; dbg_http_n = size < (int)sizeof(dbg_http_buf) ? (size < 0 ? 0 : size) : (int)sizeof(dbg_http_buf); if (data && dbg_http_n) memcpy(dbg_http_buf, data, (size_t)dbg_http_n); dbg_http_status = status + 1; }
    int kind = id & 255, seq = id >> 8;
    if (kind <= 0 || kind >= RQ_N || seq != NET.seq[kind]) return;          /* an answer nobody waits for any more */
    NET.busy[kind] = 0;
    int n = size < 0 || !data ? 0 : (size < (int)sizeof(nbuf) - 1 ? size : (int)sizeof(nbuf) - 1); if (n) memcpy(nbuf, data, (size_t)n); nbuf[n] = 0;
    char *p = nbuf, *ln = NULL;
    if (kind == RQ_CFG) { got_cfg(status, p); return; }
    if (status == 0 && NET.st == NS_ON && !NET.forced) { NET.st = NS_ERR; NET.retry = 25.0f; }
    int ok = net_ok(status, &p, &ln);
    switch (kind) {
    case RQ_TOP: {
        char me[12]; own_p(RS.key, me); RS.n = 0; RS.mine = -1; RS.st = ok ? 2 : 3;
        while (ok && RS.n < 100 && (ln = nline(&p)) != NULL) {
            TopRow *r = &RS.row[RS.n]; if (!*ln) continue;
            r->rank = atoi(nfld(&ln)); text_clean(r->nick, (int)sizeof(r->nick), nfld(&ln), 12); r->stars = (int)clampf((float)atoi(nfld(&ln)), 0, MAX_STARS); r->ticks = atoi(nfld(&ln));
            snprintf(r->p, sizeof(r->p), "%.10s", nfld(&ln)); if (!strcmp(r->p, me)) RS.mine = RS.n;
            r->badge = atoi(nfld(&ln));                  /* (a table of V0.5 tells who wears a badge) */
            if (!r->nick[0]) snprintf(r->nick, sizeof(r->nick), "Игрок");
            RS.n++;
        }
    } break;
    case RQ_SUB:
        if (ok && sub_level >= 0) meta_rank(atoi(nfld(&ln)));      /* the place in the table (first place is an achievement) */
        if (ok) { if (sub_level >= 0) { SV.sent[sub_level] = 1; save_store(); } else if (sub_level == -2) pub_best_sent = 1; if (scr == SC_RECORDS && RS.st != 1) { int keep = (int)RS.scroll; records_load(); RS.scroll = (float)keep; } }
        else if (status == 200 && ln && (!strcmp(ln, "auth") || !strcmp(ln, "ban"))) { if (!strcmp(ln, "ban")) { if (!acc_banned) AC.note = 1; acc_banned = 1; } else acc_kicked(); }      /* not this record is wrong, the sender is: keep it for later */
        else if (status == 200) { if (sub_level >= 0) { SV.sent[sub_level] = 3; save_store(); } else if (sub_level == -2) pub_best_sent = 1; }       /* the table refused this record: do not send it again */
        sub_level = -1; if (ok) online_flush();
        break;
    case RQ_REP: {
        static Replay r; int good = 0;
        if (ok) { nfld(&ln); char *rep = nfld(&ln); const LObj *objs = RS.level >= 0 ? g_levels[RS.level].objs : CUR.objs; good = replay_decode(rep, &r) && replay_check(objs, &r); }
        if (scr != SC_RECORDS) break;
        if (good) { play_replay(&r, RS.want_nick); if (!rep_mine) meta_watch(); } else gtoast(ok ? "Эта запись повреждена" : "Не удалось загрузить запись");
    } break;
    case RQ_LIST: {
        HB.n = 0; HB.st = ok ? 2 : 3; if (ok) HB.total = atoi(nfld(&ln));
        while (ok && HB.n < HUB_PAGE && (ln = nline(&p)) != NULL) {
            HubItem *it = &HB.it[HB.n]; if (!*ln) continue;
            it->id = atoi(nfld(&ln)); text_clean(it->name, (int)sizeof(it->name), nfld(&ln), 20); text_clean(it->author, (int)sizeof(it->author), nfld(&ln), 12);
            it->stars = (int)clampf((float)atoi(nfld(&ln)), 0, MAX_STARS); it->plays = atoi(nfld(&ln)); it->bg = ((atoi(nfld(&ln)) % BOXES) + BOXES) % BOXES; it->badge = atoi(nfld(&ln));
            if (it->id > 0) HB.n++;
        }
    } break;
    case RQ_LEVEL: {
        static Replay r; int good = 0, lid = 0; char key[24];
        if (ok) {
            lid = atoi(nfld(&ln)); char *name = nfld(&ln), *auth = nfld(&ln); char *dat = nfld(&ln), *rep = nfld(&ln);
            pub_own = CFG.acc && SV.nick[0] && !strcmp(auth, SV.nick);      /* one's own level (it does not count as a level of another player) */
            good = lid > 0 && level_decode(dat, &PUBLV) && replay_decode(rep, &r) && replay_check(PUBLV.o, &r);      /* only levels with a valid proof run are playable */
            if (good) text_clean(PUBLV.name, (int)sizeof(PUBLV.name), name, 20);
        }
        if (scr != SC_HUB) break;
        if (!good) { gtoast(ok ? "Этот уровень повреждён" : "Не удалось загрузить уровень"); break; }
        snprintf(key, sizeof(key), "u%d", lid); play_custom(&PUBLV, 2, key); pub_best_ok = 0; pub_best_sent = 0; pub_key[0] = 0; g_toast_t = 0;
        play_back = SC_HUB; play_back_arg = 1; go(SC_PLAY, -1, LM_PLAY);
    } break;
    case RQ_PING: {                                      /* "ok<TAB>mel-nyam<TAB>4": what this table can do */
        if (ok) { nfld(&ln); NET.proto = atoi(nfld(&ln)); if (NET.proto < 2) NET.proto = 2; online_flush(); }
        else if (status == 200) NET.proto = 2;
    } break;
    case RQ_ACC: acc_answer(ok, status, ln); break;
    case RQ_MINE: acc_mine(ok, p); break;
    case RQ_HB: hb_answer(ok, status, ln); break;
    case RQ_LOAD: case RQ_SAVE: case RQ_MSG: case RQ_CHAT: case RQ_MYLV: meta_http(kind, ok, status, ln, p); break;
#ifdef MN_ADMIN
    case RQ_ADM: adm_http(ok, status, ln, p); break;
#endif
    case RQ_PUB:
        g_toast_t = 0;
        if (ok) { ED.pub_id = atoi(nfld(&ln)); slot_save(ed_slot, &ED); meta_published(ED.pub_id); char m[220]; snprintf(m, sizeof(m), "Номер уровня: %d. Ищи его в разделе «Уровни игроков» — и зови друзей его пройти!", ED.pub_id); msg_open("Опубликовано!", m); }
        else msg_open("Не получилось", status == 200 ? "Таблица не приняла уровень. Попробуй другое название или опубликуй позже." : "Нет связи с таблицей. Попробуй ещё раз чуть позже.");
        break;
    default: break;
    }
}
void app_text(int kind, const char *s) {
    if (kind == 1) {                                     /* tests: talk to this address instead of the one in online.json */
        NET.forced = 1; snprintf(NET.api, sizeof(NET.api), "%s", s ? s : ""); NET.st = NET.api[0] ? NS_ON : NS_OFF;
        if (NET.st == NS_ON) online_flush();
    } else if (kind == 2) { text_clean(SV.nick, (int)sizeof(SV.nick), s ? s : "", 12); save_store(); }
    else if (kind == 3 && s) { static EdLevel t; if (level_decode(s, &t)) { memcpy(ED.o, t.o, sizeof(ED.o)); ED.n = t.n; ED.bg = t.bg; EU.sel = -1; ed_commit(); } }
    else if (kind == 4 && s) {                           /* tests: another address of online.json (the table address, the support page and the newest version come from it) */
        snprintf(NET.cfg, sizeof(NET.cfg), "%s", s); NET.forced = 0; NET.st = NS_NONE; NET.retry = 0; NET.proto = 0; net_cfg();
    }
    else if (kind == 7 && s) chat_send_done(s);          /* tests: a message to the support chat, without the keyboard */
#ifdef MN_ADMIN
    else if (kind == 8 && s) adm_pw_done(s);             /* tests: the admin password, without the keyboard */
#endif
    else if ((kind == 5 || kind == 6) && s) {            /* tests: "nick<newline>password" -> create an account (5) or sign in (6), without the windows */
        const char *nl = strchr(s, '\n'); if (!nl || AC.busy) return;
        snprintf(AC.nick, sizeof(AC.nick), "%.*s", (int)(nl - s), s); acc_hash(nl + 1, AC.ph); AC.op = kind == 5 ? AO_REG : AO_LOGIN; acc_send();
    }
}

/* ============================== keys ============================== */
static int ui_key(int key) {
    if (KB.on) {
        if (key == KEY_BACKSPACE || key == KEY_DELETE) { u8_pop(KB.buf); KB.err[0] = 0; } else if (key == KEY_ENTER) kb_ok(); else if (key == KEY_ESC) KB.on = 0;
        return 1;
    }
    if (MSGB.on) { if (key == KEY_ENTER || key == KEY_ESC || key == KEY_SPACE) MSGB.on = 0; return 1; }
    if (wn_on()) return wn_key(key);
    if (tas_modal_on()) return tas_modal_key(key);
    if (scr == SC_EDITOR) {
        if (key == KEY_ESC) { if (EU.dirty) ed_commit(); go(SC_HUB, 0, 0); return 1; }
        if (EU.sel >= 0 && EU.sel < ED.n && !EU.drag) {
            LObj *o = &ED.o[EU.sel]; float dx = key == KEY_LEFT ? -10.0f : (key == KEY_RIGHT ? 10.0f : 0), dy = key == KEY_UP ? -10.0f : (key == KEY_DOWN ? 10.0f : 0);
            if (key == KEY_DELETE || key == KEY_BACKSPACE) { ed_remove(EU.sel); return 1; }
            if (dx != 0 || dy != 0) {
                int two = ed_two(o->type); float x0 = two ? minf(o->x, o->a) : o->x, x1 = two ? maxf(o->x, o->a) : o->x, y0 = two ? minf(o->y, o->b) : o->y, y1 = two ? maxf(o->y, o->b) : o->y;
                if (x0 + dx >= 30 && x1 + dx <= 1250 && y0 + dy >= 30 && y1 + dy <= 690) { o->x += dx; o->y += dy; if (two) { o->a += dx; o->b += dy; } ed_commit(); }
                return 1;
            }
        }
        return key != KEY_M && key != KEY_F;
    }
    if (scr == SC_RECORDS) {
        if (key == KEY_ESC && RS.level < 0) { go(SC_HUB, 1, 0); return 1; }
        if (key == KEY_UP) { RS.scroll -= 132; return 1; } if (key == KEY_DOWN) { RS.scroll += 132; return 1; }
        if (RS.level >= 0 && (key == KEY_LEFT || key == KEY_RIGHT)) { RS.level = (RS.level + (key == KEY_LEFT ? LEVEL_COUNT - 1 : 1)) % LEVEL_COUNT; records_load(); return 1; }
        return 0;
    }
    if (scr == SC_HUB && key == KEY_ESC) { go(HB.tab ? SC_CHAPTERS : SC_MENU, 0, 0); return 1; }
    return 0;
}

/* ============================== start-up, per-frame work, test hooks ============================== */
static void online_init(void) { NET.st = NS_NONE; NET.retry = 0.5f; RS.mine = -1; sub_level = -1; HB.del = -1; EU.sel = -1; }
static void online_update(float dt) {
    if (nick_pending && !modal_on() && scr_next < 0 && ((scr == SC_PLAY && L_phase == PH_WIN && L_pt > WIN_T0 + 1.7f) || scr == SC_RECORDS)) { nick_pending = 0; nick_asked = 1; if (need_identity()) ask_nick(); }
    if (NET.st == NS_ON) {
        if (!NET.proto) { AC.ping_t -= dt; if (AC.ping_t <= 0 && !NET.busy[RQ_PING]) { AC.ping_t = 20.0f; net_get(RQ_PING, "a=ping"); } }      /* what can this table do? */
        else if (NET.proto >= 4 && !NET.busy[RQ_HB]) {                           /* "I am here": once a minute, and soon after the player has moved to another screen */
            char w[16]; where_code(w, (int)sizeof(w)); AC.hb_t += dt;
            if (AC.hb_t > 60.0f || (AC.hb_t > 12.0f && strcmp(w, AC.hb_w)) || (!AC.hb_w[0] && AC.hb_t > 2.0f)) hb_send();
        }
    }
    if (scr == SC_MENU && scr_next < 0 && !modal_on() && g_fade <= 0) {
        if (AC.note) {
            if (AC.note == 1) msg_open("Аккаунт заблокирован", "Администратор заблокировал этот аккаунт. Рекорды и уровни с него больше не принимаются.");
            else msg_open("Нужно войти заново", "Вход в аккаунт на этом устройстве больше не действует: пароль сменили или аккаунт удалён. Войди заново — прогресс хранится в аккаунте.");
            AC.note = 0;
        } else if (upd_pending() && !UP.asked && g_time > 1.6f) upd_open();        /* a newer version is on the site: offer it once per launch */
    }
    if (NET.forced) return;
    if (NET.st == NS_NONE || NET.st == NS_ERR || NET.st == NS_OFF) {           /* look for the table's address: at start, then now and again */
        NET.retry -= dt;
        if (NET.retry <= 0 && !NET.busy[RQ_CFG]) { NET.retry = NET.st == NS_OFF ? 600.0f : 25.0f; if (plat_caps() & 4) net_cfg(); else NET.st = NS_OFF; }
    }
}
static int online_debug(int cmd, int arg) {
    switch (cmd) {
    case 90: dbg_http_on = 1; dbg_http_status = 0; dbg_http_n = 0; return 0;
    case 91: return dbg_http_status;
    case 92: return dbg_http_n;
    case 93: return arg >= 0 && arg < dbg_http_n ? (u8)dbg_http_buf[arg] : 0;
    case 94: return NET.st;
    case 95: return RS.n | (RS.st << 8) | ((RS.mine + 1) << 12);
    case 96: return HB.n | (HB.st << 8) | (HB.total << 12);
    case 97: return ED.n | (ED.solved << 8) | (ED.pub_id << 16);
    case 98: return KB.on | (MSGB.on << 1) | (wn_on() << 2);
    case 99: { int n = 0; for (int i = 0; i < LEVEL_COUNT; i++) if (SV.sent[i] == (u8)arg) n++; return n; }
    case 100: if (arg >= 0 && arg < RS.n) watch_row(arg); return 0;
    case 101: if (arg >= 0 && arg < HB.n) hub_play(arg); return 0;
    case 102: if (scr == SC_EDITOR) ed_add(arg); return ED.n;
    case 103: if (scr == SC_EDITOR) ed_test(); return 0;
    case 104: if (scr == SC_EDITOR) ed_publish(); return 0;
    case 105: scr_next = -1; enter(SC_RECORDS, arg, 0); g_fade = 0; return 0;
    case 106: scr_next = -1; enter(SC_HUB, arg, 0); g_fade = 0; return 0;
    case 107: scr_next = -1; enter(SC_EDITOR, arg, 0); g_fade = 0; return 0;
    case 108: return RS.level;
    case 109: MSGB.on = 0; KB.on = 0; return 0;
    case 110: return ed_proof_ok ? ed_proof.ticks : 0;
    case 111: { static Replay r; char k[8]; own_key(arg, k); return replay_load(k, &r, objs_hash(g_levels[arg].objs)) ? (replay_check(g_levels[arg].objs, &r) ? r.ticks : -1) : 0; }
    case 112: return pub_best_ok ? pub_best.ticks : 0;
    case 113: return (int)SV.uid;
    case 114: return arg >= 0 && arg < ED.n ? ((int)ED.o[arg].x | ((int)ED.o[arg].y << 12) | (ED.o[arg].type << 24)) : -1;
    case 115: return EU.sel;
    default: return 0;
    }
}
