/* SHA-256 and HMAC-SHA-256 (FIPS 180-4, RFC 2104). Small, plain C, no tables but the round constants.
   Used for: the password of an account (it never leaves the device as it was typed), the check of a downloaded
   update, the requests of the admin tool. */
#ifndef MN_SHA256_H
#define MN_SHA256_H
#include <stdint.h>
#include <string.h>

typedef struct { uint32_t h[8]; uint64_t len; uint8_t buf[64]; int n; } Sha256;

static const uint32_t sha256_k[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2 };

static void sha256_block(Sha256 *c, const uint8_t *p) {
    uint32_t w[64], a = c->h[0], b = c->h[1], d = c->h[3], e = c->h[4], f = c->h[5], g = c->h[6], h = c->h[7], cc = c->h[2];
    for (int i = 0; i < 16; i++) w[i] = (uint32_t)p[i * 4] << 24 | (uint32_t)p[i * 4 + 1] << 16 | (uint32_t)p[i * 4 + 2] << 8 | p[i * 4 + 3];
    for (int i = 16; i < 64; i++) {
        uint32_t x = w[i - 15], y = w[i - 2];
        w[i] = w[i - 16] + ((x >> 7 | x << 25) ^ (x >> 18 | x << 14) ^ (x >> 3)) + w[i - 7] + ((y >> 17 | y << 15) ^ (y >> 19 | y << 13) ^ (y >> 10));
    }
    for (int i = 0; i < 64; i++) {
        uint32_t t1 = h + ((e >> 6 | e << 26) ^ (e >> 11 | e << 21) ^ (e >> 25 | e << 7)) + ((e & f) ^ (~e & g)) + sha256_k[i] + w[i];
        uint32_t t2 = ((a >> 2 | a << 30) ^ (a >> 13 | a << 19) ^ (a >> 22 | a << 10)) + ((a & b) ^ (a & cc) ^ (b & cc));
        h = g; g = f; f = e; e = d + t1; d = cc; cc = b; b = a; a = t1 + t2;
    }
    c->h[0] += a; c->h[1] += b; c->h[2] += cc; c->h[3] += d; c->h[4] += e; c->h[5] += f; c->h[6] += g; c->h[7] += h;
}
static void sha256_init(Sha256 *c) {
    static const uint32_t iv[8] = { 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19 };
    memcpy(c->h, iv, sizeof(iv)); c->len = 0; c->n = 0;
}
static void sha256_update(Sha256 *c, const void *data, size_t len) {
    const uint8_t *p = (const uint8_t *)data; c->len += len;
    while (len > 0) {
        if (c->n == 0 && len >= 64) { sha256_block(c, p); p += 64; len -= 64; continue; }
        size_t k = 64 - (size_t)c->n; if (k > len) k = len;
        memcpy(c->buf + c->n, p, k); c->n += (int)k; p += k; len -= k;
        if (c->n == 64) { sha256_block(c, c->buf); c->n = 0; }
    }
}
static void sha256_final(Sha256 *c, uint8_t out[32]) {
    uint64_t bits = c->len * 8; uint8_t pad[72]; size_t k = (c->n < 56 ? 56 : 120) - (size_t)c->n;
    memset(pad, 0, sizeof(pad)); pad[0] = 0x80;
    for (int i = 0; i < 8; i++) pad[k + (size_t)i] = (uint8_t)(bits >> (56 - 8 * i));
    sha256_update(c, pad, k + 8);
    for (int i = 0; i < 8; i++) { out[i * 4] = (uint8_t)(c->h[i] >> 24); out[i * 4 + 1] = (uint8_t)(c->h[i] >> 16); out[i * 4 + 2] = (uint8_t)(c->h[i] >> 8); out[i * 4 + 3] = (uint8_t)c->h[i]; }
}
static void sha256_tohex(const uint8_t d[32], char out[65]) {
    static const char hx[] = "0123456789abcdef";
    for (int i = 0; i < 32; i++) { out[i * 2] = hx[d[i] >> 4]; out[i * 2 + 1] = hx[d[i] & 15]; }
    out[64] = 0;
}
/* hex digest of the strings a + b (b may be NULL) */
static void sha256_hex2(const char *a, const char *b, char out[65]) {
    Sha256 c; uint8_t d[32]; sha256_init(&c); sha256_update(&c, a, strlen(a)); if (b) sha256_update(&c, b, strlen(b)); sha256_final(&c, d); sha256_tohex(d, out);
}
static void hmac_sha256_hex(const char *key, const char *msg, char out[65]) {
    uint8_t k[64], d[32], pad[64]; size_t kl = strlen(key); Sha256 c;
    memset(k, 0, sizeof(k));
    if (kl > 64) { sha256_init(&c); sha256_update(&c, key, kl); sha256_final(&c, k); } else memcpy(k, key, kl);
    for (int i = 0; i < 64; i++) pad[i] = k[i] ^ 0x36;
    sha256_init(&c); sha256_update(&c, pad, 64); sha256_update(&c, msg, strlen(msg)); sha256_final(&c, d);
    for (int i = 0; i < 64; i++) pad[i] = k[i] ^ 0x5c;
    sha256_init(&c); sha256_update(&c, pad, 64); sha256_update(&c, d, 32); sha256_final(&c, d);
    sha256_tohex(d, out);
}
#endif
