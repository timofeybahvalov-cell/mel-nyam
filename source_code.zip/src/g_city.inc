/* ============================================================================
   «МЕЛ-НЯМ» V0.6 — the city of Melstroy: a map with hills, a river, lakes, districts and streets,
   and on it one house for every account there is. The city grows with the game.
   Also here: the screen of the monthly missions.
   Included by game.c after g_pet.inc.
   ============================================================================ */

/* ---------------- the plan of the city ---------------- */
/* The land is a grid of blocks around the central square. The blocks are numbered along a square spiral;
   some of them are nature for ever (a park, a lake, a hill, the river). Every other block has eight plots.
   A plot number therefore always means the same place, however big the city grows. */
#define CB_W 520.0f
#define CB_H 440.0f
#define CITY_R 15
#define CITY_SIDE (2 * CITY_R + 1)
#define CITY_CELLS (CITY_SIDE * CITY_SIDE)
#define CITY_MAX 4000
#define PLOT_MAX (CITY_CELLS * 8)
enum { NA_BUILD, NA_PARK, NA_LAKE, NA_HILL, NA_RIVER, NA_CENTER };
typedef struct { u32 plot; u16 look; u8 badge; char nick[27]; } CHouse;
static struct {
    CHouse h[CITY_MAX]; int n, st, pages; u32 total, maxplot; float age;      /* st: 0 not asked, 1 asking, 2 here, 3 failed */
    i16 block_of[CITY_CELLS]; i8 ci[CITY_CELLS], cj[CITY_CELLS]; int blocks;   /* cell -> its block number (or -1); block number -> cell */
    i16 at_plot[PLOT_MAX + 1];                                                 /* plot -> index in h (or -1) */
    float cx, cy, z, z_to; int drag, moved, touched; float cx0, cy0;
    u32 sel; int inited, find_miss; float find_t;
} CT;
static int river_row(int i) { static const i8 rr[8] = { -3, -3, -4, -4, -3, -2, -2, -3 }; return rr[((i % 8) + 8) % 8]; }
static int cell_nature(int i, int j) {
    int ring = (i < 0 ? -i : i) > (j < 0 ? -j : j) ? (i < 0 ? -i : i) : (j < 0 ? -j : j); u32 h;
    if (!i && !j) return NA_CENTER;
    if (j == river_row(i)) return NA_RIVER;
    if (ring < 2) return NA_BUILD;
    h = mhash((u32)(i + 64), (u32)(j + 64) * 131u + 9u);
    if (h % 100u >= 15u) return NA_BUILD;
    return NA_PARK + (int)((h >> 8) % 3u);
}
static void city_plan(void) {
    int b = 0;
    for (int k = 0; k < CITY_CELLS; k++) CT.block_of[k] = -1;
    for (int r = 1; r <= CITY_R; r++) for (int s = 0; s < 8 * r; s++) {                    /* a ring: along the top to the right, down the right side, back along the bottom, up the left side */
        int q = s / (2 * r), o = s % (2 * r), i, j;
        if (q == 0) { i = -r + o; j = -r; } else if (q == 1) { i = r; j = -r + o; } else if (q == 2) { i = r - o; j = r; } else { i = -r; j = r - o; }
        if (cell_nature(i, j) != NA_BUILD) continue;
        CT.block_of[(j + CITY_R) * CITY_SIDE + i + CITY_R] = (i16)b; CT.ci[b] = (i8)i; CT.cj[b] = (i8)j; b++;
    }
    CT.blocks = b;
}
static int cell_block(int i, int j) { return i < -CITY_R || i > CITY_R || j < -CITY_R || j > CITY_R ? -1 : CT.block_of[(j + CITY_R) * CITY_SIDE + i + CITY_R]; }
static int plot_pos(u32 plot, float *x, float *y) {    /* where a plot is (the middle of the front of its house); 0 when the city has no such plot */
    int b, s; if (!plot || plot > (u32)CT.blocks * 8u) return 0;
    b = (int)((plot - 1) / 8u); s = (int)((plot - 1) % 8u);
    *x = (float)CT.ci[b] * CB_W - 165.0f + (float)(s % 4) * 110.0f; *y = (float)CT.cj[b] * CB_H + (s < 4 ? -42.0f : 138.0f);
    return 1;
}
static const char *district_name(int i, int j) {
    static const char *const nm[4][4] = { { "Чекушкино", "Лимонадная слобода", "Квасной район", "Морсово" }, { "Новые Энергетики", "Компотный", "Кисельные Берега", "Молочный" },
                                          { "Чайная Горка", "Кофейники", "Какао-Сити", "Минеральные Воды" }, { "Дальние Капучины", "Шоколадный", "Кола-Парк", "Стримерские Выселки" } };
    int ai = i < 0 ? -i : i, aj = j < 0 ? -j : j, ring = ai > aj ? ai : aj, quad = aj >= ai ? (j < 0 ? 0 : 2) : (i > 0 ? 1 : 3);
    if (ring <= 1) return "Центр";
    return nm[(ring - 2) / 2 > 3 ? 3 : (ring - 2) / 2][quad];
}
static const char *street_name(int j) {                /* the street along the top of the row j of blocks */
    static const char *const nm[12] = { "ул. Стримерская", "пр. Чекушки", "ул. Лимонадная", "Квасной пер.", "ул. Морсовая", "бул. Энергетиков", "ул. Компотная", "ул. Молочная", "Чайный пр.", "ул. Кофейная", "ул. Шоколадная", "ул. Победная" };
    return nm[((j % 12) + 12) % 12];
}
static const char *city_rank(int n, int *next) {
    static const int lim[6] = { 10, 30, 100, 300, 1000, 3000 }; static const char *const nm[7] = { "Хутор", "Деревня", "Посёлок", "Городок", "Город", "Большой город", "Мегаполис" };
    int k = 0; while (k < 6 && n >= lim[k]) k++;
    if (next) *next = k < 6 ? lim[k] : 0;
    return nm[k];
}
static void city_center_on(u32 plot, float z);
static int city_others(void) { int n = 0; for (int i = 0; i < CT.n; i++) if (CT.h[i].plot != HM.plot) n++; return n; }
static int city_known(void) { return CT.st == 2; }

/* ---------------- the list of houses comes from the table ---------------- */
static void city_index(void) { for (int p = 0; p <= PLOT_MAX; p++) CT.at_plot[p] = -1; for (int i = 0; i < CT.n; i++) if (CT.h[i].plot <= PLOT_MAX) CT.at_plot[CT.h[i].plot] = (i16)i; }
static void city_me(void) {                             /* my own house is on the map at once, even before the table tells */
    if (!home_on() || !HM.plot || HM.plot > PLOT_MAX) return;
    int k = CT.at_plot[HM.plot];
    if (k < 0 && CT.n < CITY_MAX) { k = CT.n++; memset(&CT.h[k], 0, sizeof(CHouse)); CT.h[k].plot = HM.plot; CT.at_plot[HM.plot] = (i16)k; if (HM.plot > CT.maxplot) CT.maxplot = HM.plot; }
    if (k >= 0) { text_clean(CT.h[k].nick, (int)sizeof(CT.h[k].nick), SV.nick, 12); CT.h[k].look = (u16)home_look(); CT.h[k].badge = (u8)my_badge; }
}
static void city_load(int off) { char q[60]; if (NET.st != NS_ON || NET.proto < 6 || NET.busy[RQ_CITY]) return; if (!off) CT.pages = 0; snprintf(q, sizeof(q), "a=city&o=%d", off); net_get(RQ_CITY, q); if (CT.st != 2) CT.st = 1; }
static void city_visit(u32 plot) {
    char q[80]; int k = plot <= PLOT_MAX ? CT.at_plot[plot] : -1;
    memset(&HV, 0, sizeof(HV)); HV.visit = 1; HV.loading = 1; HV.plot = plot; HV.from_city = 1; if (k >= 0) { snprintf(HV.nick, sizeof(HV.nick), "%s", CT.h[k].nick); HV.badge = CT.h[k].badge; }
    snprintf(q, sizeof(q), "a=house&n=%u&u=%u", (unsigned)plot, (unsigned)SV.uid); net_get(RQ_HOUSE, q); go(SC_HOUSE, 1, 0);
}
static void city_http(int kind, int ok, int status, char *ln, char *p) {
    (void)status;
    if (kind == RQ_CITY) {
        static CHouse tmp[CITY_MAX]; static int tn; int rows;
        if (!ok) { if (CT.st != 2) CT.st = 3; return; }
        if (!CT.pages) tn = 0;
        CT.total = (u32)strtoul(nfld(&ln), NULL, 10); CT.maxplot = (u32)strtoul(nfld(&ln), NULL, 10); rows = atoi(nfld(&ln));
        while ((ln = nline(&p)) != NULL && tn < CITY_MAX) {
            CHouse *c = &tmp[tn]; if (!*ln) continue;
            memset(c, 0, sizeof(*c)); c->plot = (u32)strtoul(nfld(&ln), NULL, 10); text_clean(c->nick, (int)sizeof(c->nick), nfld(&ln), 12); c->look = (u16)atoi(nfld(&ln)); c->badge = (u8)atoi(nfld(&ln));
            if (c->plot && c->plot <= PLOT_MAX) tn++;
        }
        CT.pages++;
        if (rows > 0 && (u32)tn < CT.total && tn < CITY_MAX && CT.pages < 12) { char q[60]; snprintf(q, sizeof(q), "a=city&o=%d", CT.pages * 400); net_get(RQ_CITY, q); return; }      /* the next page */
        { int first = CT.st != 2; memcpy(CT.h, tmp, sizeof(CHouse) * (size_t)tn); CT.n = tn; CT.st = 2; CT.age = 0; CT.pages = 0; city_index(); city_me();
          if (first && !home_on() && !CT.touched && scr == SC_CITY) city_center_on(CT.maxplot + 1, 0);
          month_visit_fix(); }
    } else if (kind == RQ_HOUSE) {
        if (!HV.visit || !HV.loading) return;
        HV.loading = 0;
        if (!ok) { HV.err = 1; return; }
        u32 plot = (u32)strtoul(nfld(&ln), NULL, 10); const char *nick = nfld(&ln); int badge = atoi(nfld(&ln)); u32 visits = (u32)strtoul(nfld(&ln), NULL, 10); const char *data = nfld(&ln);
        if (plot != HV.plot) { HV.err = 1; return; }
        text_clean(HV.nick, (int)sizeof(HV.nick), nick, 12); HV.badge = badge; HV.visits = visits;
        if (!data[0] || !home_decode(data, &HV.h)) { memset(&HV.h, 0, sizeof(HV.h)); HV.empty = 1; }
        home_starter(&HV.h); HK.inited = 0;
        if (home_on() && plot != HM.plot) {
            int seen = 0; Mission *q = month_cur(); u32 key = (HM.month << 6) | HM.m_idx;
            for (int i = 0; i < HS.seen_n; i++) if (HS.seen[i] == plot) seen = 1;       /* the achievements: a visit counts once for each house (as far as this device remembers) */
            if (!seen) { if (HS.seen_n >= 8) { memmove(HS.seen, HS.seen + 1, 7 * sizeof(u32)); HS.seen_n = 7; } HS.seen[HS.seen_n++] = plot; HM.cn[C6_VISITS]++; ach6_check(); home_dirty(); }
            if (HS.mseen_key != key) { HS.mseen_key = key; HS.mseen_n = 0; }
            if (q && q->kind == MK_VISIT) {                                              /* the mission of the month: every house once in this mission, also one that was visited for an earlier mission */
                seen = 0; for (int i = 0; i < HS.mseen_n; i++) if (HS.mseen[i] == plot) seen = 1;
                if (!seen) { if (HS.mseen_n < 8) HS.mseen[HS.mseen_n++] = plot; mis_add(q, 1); home_dirty(); }
            }
        }
    }
}

/* ---------------- drawing the map ---------------- */
static float c_noise(int x, int y) { return (float)(mhash((u32)(x + 4096), (u32)(y + 4096) * 7919u + 3u) & 1023u) / 1023.0f; }
static float c_elev(float gx, float gy) {              /* the height of the land: smooth, between 0 and 1 */
    float fx = gx / 6.0f, fy = gy / 6.0f; int x0 = (int)floorf(fx), y0 = (int)floorf(fy); float tx = fx - (float)x0, ty = fy - (float)y0;
    tx = tx * tx * (3 - 2 * tx); ty = ty * ty * (3 - 2 * ty);
    float a = c_noise(x0, y0), b = c_noise(x0 + 1, y0), c = c_noise(x0, y0 + 1), d = c_noise(x0 + 1, y0 + 1);
    return a + (b - a) * tx + (c - a) * ty + (a - b - c + d) * tx * ty;
}
static void c_tree(float x, float y, float s, int kind, float nk) {
    u32 g1 = color_lerp(kind ? 0x2F9E55FFu : 0x3FAE56FFu, 0x143A30FFu, nk * 0.7f), g2 = color_lerp(kind ? 0x45B866FFu : 0x58C66AFFu, 0x1B4A3AFFu, nk * 0.7f);
    gfx_ellipse(x, y + 2 * s, 20 * s, 7 * s, 0x00000030u); gfx_rect(x - 3 * s, y - 16 * s, 6 * s, 18 * s, 0x7A5232FFu);
    if (kind) { gfx_tri(x - 20 * s, y - 12 * s, x + 20 * s, y - 12 * s, x, y - 50 * s, g1); gfx_tri(x - 15 * s, y - 32 * s, x + 15 * s, y - 32 * s, x, y - 66 * s, g2); }
    else { gfx_circle(x, y - 30 * s, 21 * s, g1); gfx_circle(x - 6 * s, y - 36 * s, 12 * s, g2); }
}
static const u32 wall_pal[8] = { 0xFFE9A8FFu, 0xF6C9A0FFu, 0xCFE8FFFFu, 0xD8F0C0FFu, 0xFFD0DCFFu, 0xE6DCFFFFu, 0xFFF6DCFFu, 0xC8ECE4FFu };
static const u32 roof_pal[6] = { 0xD9553CFFu, 0x8E5A2CFFu, 0x3D7BE8FFu, 0x2F9E55FFu, 0x8E6BE8FFu, 0x5A6072FFu };
/* a house on the map; (x, y): the middle of its front at the ground */
static void c_house(float x, float y, u32 plot, int big, int lod, float nk, int mine, int sel) {
    u32 h = mhash(plot, 31), wall = wall_pal[h % 8u], roof = roof_pal[(h >> 5) % 6u], win = nk > 0.5f ? 0xFFE680FFu : 0x7FC4F0FFu;
    float w = big ? 43.0f : 33.0f, hh = big ? 76.0f : 42.0f, rh = big ? 36.0f : 32.0f;
    if (lod) { gfx_rect(x - w, y - hh, 2 * w, hh, mine ? 0xFFD23FFFu : wall); gfx_tri(x - w - 7, y - hh, x + w + 7, y - hh, x, y - hh - rh, roof); if (sel || mine) gfx_ring(x, y - hh * 0.5f, 78, 9, sel ? 0xFFFFFFFFu : 0xFFD23FFFu); return; }
    d_at(x, y, 1.0f, 0); DX.ow = 2.6f;
    d_ell(0, 1, w + 14, 9, 0x00000030u);
    if (sel) { d_ring(0, -hh * 0.5f, 84, 7, 0xFFFFFFFFu); d_ring(0, -hh * 0.5f, 84, 3, 0xFFD23FFFu); }
    o_rect(w * 0.42f, -hh - rh * 0.9f, 11, 26, 2, 0xB5553CFFu);
    o_rect(-w, -hh, 2 * w, hh, 3, wall); o_tri(-w - 9, -hh + 1, w + 9, -hh + 1, 0, -hh - rh, roof); d_line(-w - 5, -hh + 1, w + 5, -hh + 1, 1.8f, shade(roof, -0.25f));
    o_rect(-8, -25, 16, 25, 2, 0x9A5F33FFu); d_circ(4, -12, 1.6f, 0xFFD23FFFu);
    o_rect(-w + 7, -31, 14, 14, 2, win); o_rect(w - 21, -31, 14, 14, 2, win);
    if (big) { o_rect(-w + 7, -66, 14, 16, 2, win); o_rect(-7, -66, 14, 16, 2, win); o_rect(w - 21, -66, 14, 16, 2, win); d_rect(-w, -42, 2 * w, 3, 0, shade(wall, -0.18f)); }
    if ((h >> 9) % 3u == 0) { d_circ(-w - 9, -6, 8, 0x3FAE56FFu); d_circ(-w - 2, -3, 6, 0x58C66AFFu); } else if ((h >> 9) % 3u == 1) { for (int i = 0; i < 4; i++) d_rect(w + 5 + (float)i * 6, -11, 3, 11, 0, 0xFFFFFFFFu); d_rect(w + 4, -8, 24, 2.5f, 0, 0xFFFFFFFFu); }
    if (mine) { float bob = sinf(g_time * 3.0f) * 4; d_line(0, -hh - rh, 0, -hh - rh - 30, 1.6f, OLC); o_tri(0, -hh - rh - 30, 0, -hh - rh - 16, 20, -hh - rh - 23, 0xFFD23FFFu); d_star(0, -hh - rh - 54 + bob, 13, OLC); d_star(0, -hh - rh - 54 + bob, 10, 0xFFD23FFFu); }
    DX.ow = 3.0f;
}
static void c_lot(float x, float y, int next) {         /* an empty plot */
    gfx_rrect(x - 40, y - 44, 80, 50, 6, 0xC8B078A0u);
    if (next) { d_at(x, y, 1.0f, 0); DX.ow = 2.4f; d_line(0, -4, 0, -40, 2.2f, OLC); o_rect(-25, -62, 50, 26, 4, 0xFFFFFFFFu); d_text(&F_ui, "?", 0, -48, 22, 0x2FAE3AFFu); DX.ow = 3.0f; }
}
static void city_draw(float nk) {
    float z = CT.z, vw = 640 / z, vh = 360 / z, x0 = CT.cx - vw, x1 = CT.cx + vw, y0 = CT.cy - vh, y1 = CT.cy + vh; int lod = z < 0.42f;
    int i0 = (int)floorf(x0 / CB_W - 0.5f), i1 = (int)ceilf(x1 / CB_W + 0.5f), j0 = (int)floorf(y0 / CB_H - 0.5f), j1 = (int)ceilf(y1 / CB_H + 0.9f);
    u32 next_plot = CT.maxplot + 1; int shown = (int)(CT.maxplot / 8u) + 1; char b[64];
    gfx_zoom(z); gfx_offset(640 / z - CT.cx, 360 / z - CT.cy);
    /* the land, like a relief map: bands of height, the higher the lighter and drier */
    { static const u32 band[6] = { 0x46A548FFu, 0x58B84EFFu, 0x6CC655FFu, 0x86D060FFu, 0xA6D670FFu, 0xC6D884FFu };
      int div = z < 0.3f ? 4 : (z < 0.55f ? 8 : 16); float gw = CB_W / (float)div, gh = CB_H / (float)div, k = 4.0f / (float)div;
      int gx0 = (int)floorf(x0 / gw) - 1, gx1 = (int)ceilf(x1 / gw) + 1, gy0 = (int)floorf(y0 / gh) - 1, gy1 = (int)ceilf(y1 / gh) + 1;
      gfx_rect(x0 - 10, y0 - 10, x1 - x0 + 20, y1 - y0 + 20, color_lerp(band[2], 0x16303AFFu, nk * 0.62f));
      for (int gy = gy0; gy <= gy1; gy++) {                                              /* runs of the same band become one rectangle */
          int run0 = gx0, cur = -1;
          for (int gx = gx0; gx <= gx1 + 1; gx++) {
              int b = -1; if (gx <= gx1) { float e = c_elev(((float)gx + 0.5f) * k, ((float)gy + 0.5f) * k); b = (int)(e * 7.2f) - 1; if (b < 0) b = 0; if (b > 5) b = 5; }
              if (b != cur) { if (cur >= 0 && cur != 2) gfx_rect((float)run0 * gw, (float)gy * gh, (float)(gx - run0) * gw + 0.5f, gh + 0.5f, color_lerp(band[cur], 0x16303AFFu, nk * 0.62f)); cur = b; run0 = gx; }
          }
      } }
    /* the river, from one side of the map to the other */
    for (int i = i0 - 1; i <= i1 + 1; i++) { float ya = (float)(river_row(i - 1) + river_row(i)) * 0.5f * CB_H, yb = (float)(river_row(i) + river_row(i + 1)) * 0.5f * CB_H, xa = ((float)i - 0.5f) * CB_W, xb = ((float)i + 0.5f) * CB_W;
        gfx_capsule(xa, ya, xb, yb, 104, color_lerp(0xE8D8A0FFu, 0x3A4A4AFFu, nk * 0.6f)); }
    for (int i = i0 - 1; i <= i1 + 1; i++) { float ya = (float)(river_row(i - 1) + river_row(i)) * 0.5f * CB_H, yb = (float)(river_row(i) + river_row(i + 1)) * 0.5f * CB_H, xa = ((float)i - 0.5f) * CB_W, xb = ((float)i + 0.5f) * CB_W;
        gfx_capsule(xa, ya, xb, yb, 84, color_lerp(0x4FB6FFFFu, 0x1C3C7AFFu, nk * 0.7f)); if (!lod) for (int q = 0; q < 3; q++) { float u = fmodf(g_time * 0.07f + (float)q * 0.33f + (float)(i & 3) * 0.2f, 1.0f); gfx_capsule(xa + (xb - xa) * u, ya + (yb - ya) * u - 30 + (float)q * 30, xa + (xb - xa) * u + 46, ya + (yb - ya) * u - 30 + (float)q * 30 + (yb - ya) * 0.09f, 2.5f, 0xFFFFFF50u); } }
    /* streets around every block that is built on (and around the square) */
    for (int j = j0; j <= j1; j++) for (int i = i0; i <= i1; i++) {
        int bl = cell_block(i, j), built = (!i && !j) || (bl >= 0 && bl < shown); float cx = (float)i * CB_W, cy = (float)j * CB_H;
        if (!built) continue;
        gfx_rect(cx - CB_W * 0.5f, cy - CB_H * 0.5f, CB_W, CB_H, color_lerp(0x6A6F80FFu, 0x2A2E44FFu, nk * 0.6f));
    }
    for (int j = j0; j <= j1; j++) for (int i = i0; i <= i1; i++) {
        int bl = cell_block(i, j), built = (!i && !j) || (bl >= 0 && bl < shown), na = cell_nature(i, j); float cx = (float)i * CB_W, cy = (float)j * CB_H; u32 hh = mhash((u32)(i + 99), (u32)(j + 99) * 57u);
        if (built) {
            if (!lod) { for (float q = -CB_W * 0.5f + 20; q < CB_W * 0.5f; q += 60) { gfx_rect(cx + q, cy - CB_H * 0.5f - 2, 30, 4, 0xFFFFFF90u); gfx_rect(cx + q, cy + CB_H * 0.5f - 2, 30, 4, 0xFFFFFF90u); } for (float q = -CB_H * 0.5f + 20; q < CB_H * 0.5f; q += 60) { gfx_rect(cx - CB_W * 0.5f - 2, cy + q, 4, 30, 0xFFFFFF90u); gfx_rect(cx + CB_W * 0.5f - 2, cy + q, 4, 30, 0xFFFFFF90u); } }
            gfx_rrect(cx - CB_W * 0.5f + 40, cy - CB_H * 0.5f + 40, CB_W - 80, CB_H - 80, 26, na == NA_CENTER ? color_lerp(0xE8DCC8FFu, 0x4A4860FFu, nk * 0.6f) : color_lerp(0x8FD86AFFu, 0x244A3CFFu, nk * 0.62f));
            if (na != NA_CENTER && !lod) gfx_rect(cx - CB_W * 0.5f + 52, cy + 12, CB_W - 104, 12, color_lerp(0xD8C898FFu, 0x3A3C4CFFu, nk * 0.6f));      /* the lane between the two rows of houses */
        } else if (na == NA_BUILD && !lod) {                                              /* land nobody has built on yet: a meadow, a wood or a field */
            int kind = (int)(hh % 3u);
            if (kind == 2) { gfx_rrect(cx - 170, cy - 120, 340, 240, 14, color_lerp(0xE2C860FFu, 0x3A3C30FFu, nk * 0.6f)); for (int q = 0; q < 8; q++) gfx_rect(cx - 160, cy - 106 + (float)q * 30, 320, 6, color_lerp(0xC9A840FFu, 0x30301EFFu, nk * 0.6f)); }
            else for (int q = 0; q < (kind ? 9 : 4); q++) { u32 t = mhash(hh, (u32)q); c_tree(cx - 200 + (float)(t % 400u), cy - 150 + (float)((t >> 9) % 300u), 1.0f + (float)((t >> 20) % 4u) * 0.12f, (int)((t >> 18) & 1u), nk); }
        }
    }
    /* what stands on the land, row by row from the far side to the near one */
    for (int j = j0; j <= j1; j++) {
        for (int i = i0; i <= i1; i++) {
            int na = cell_nature(i, j); float cx = (float)i * CB_W, cy = (float)j * CB_H; u32 hh = mhash((u32)(i + 99), (u32)(j + 99) * 57u);
            if (na == NA_PARK) {
                gfx_rrect(cx - 220, cy - 180, 440, 360, 40, color_lerp(0x6FCB5AFFu, 0x1E4436FFu, nk * 0.62f)); gfx_capsule(cx - 200, cy, cx + 200, cy, 12, color_lerp(0xE8D8A8FFu, 0x4A4860FFu, nk * 0.6f)); gfx_capsule(cx, cy - 160, cx, cy + 160, 12, color_lerp(0xE8D8A8FFu, 0x4A4860FFu, nk * 0.6f));
                gfx_circle(cx, cy, 44, color_lerp(0xE8D8A8FFu, 0x4A4860FFu, nk * 0.6f)); gfx_circle(cx, cy, 30, 0x5CC3FFFFu); if (!lod) { float f = fabsf(sinf(g_time * 2.0f)); gfx_circle(cx, cy - 8 - f * 10, 5, 0xFFFFFFE0u); gfx_capsule(cx, cy, cx, cy - 8 - f * 10, 2.5f, 0xDFF3FFFFu); }
                for (int q = 0; q < 10; q++) { u32 t = mhash(hh, (u32)q + 20u); float tx = cx - 190 + (float)(t % 380u), ty = cy - 150 + (float)((t >> 9) % 300u); if (fabsf(tx - cx) < 34 || fabsf(ty - cy) < 34) continue; c_tree(tx, ty, lod ? 1.3f : 1.0f, (int)((t >> 18) & 1u), nk); }
            } else if (na == NA_LAKE) {
                gfx_ellipse(cx, cy, 216, 156, color_lerp(0xE8D8A0FFu, 0x3A4A4AFFu, nk * 0.6f)); gfx_ellipse(cx, cy, 196, 138, color_lerp(0x4FB6FFFFu, 0x1C3C7AFFu, nk * 0.7f)); gfx_ellipse(cx - 40, cy - 30, 110, 60, color_lerp(0x7FD0FFFFu, 0x2A4C8AFFu, nk * 0.7f));
                if (!lod) { float bx = cx + sinf(g_time * 0.2f + (float)(hh % 7u)) * 90, by = cy + 30; d_at(bx, by, 1.0f, 0); DX.ow = 2.4f; o_quad(-24, -8, 24, -8, 16, 6, -16, 6, 0xC98B4FFFu); d_line(0, -8, 0, -44, 1.8f, OLC); o_tri(2, -44, 2, -14, 24, -16, 0xFFFFFFFFu); DX.ow = 3.0f;
                    for (int q = 0; q < 4; q++) { u32 t = mhash(hh, (u32)q + 40u); float a = (float)(t % 628u) / 100.0f; c_tree(cx + cosf(a) * 232, cy + sinf(a) * 172, 0.9f, 0, nk); } }
            } else if (na == NA_HILL) {
                u32 g0 = color_lerp(0x5AAE50FFu, 0x1A3A30FFu, nk * 0.62f), g1 = color_lerp(0x8ACB62FFu, 0x24483AFFu, nk * 0.62f), g2 = color_lerp(0xC2D98AFFu, 0x30544AFFu, nk * 0.62f);
                gfx_ellipse(cx + 16, cy + 60, 236, 110, 0x00000028u); gfx_ellipse(cx, cy + 20, 226, 150, g0); gfx_ellipse(cx - 14, cy - 6, 176, 114, g1); gfx_ellipse(cx - 30, cy - 34, 118, 74, g2); gfx_ellipse(cx - 40, cy - 56, 62, 36, color_lerp(0xEEF2DCFFu, 0x56706AFFu, nk * 0.6f));
                if (!lod) { for (int q = 0; q < 7; q++) { u32 t = mhash(hh, (u32)q + 60u); float a = 0.3f + (float)(t % 250u) / 100.0f; c_tree(cx + cosf(a) * (150 + (float)((t >> 9) % 60u)), cy + 30 + sinf(a) * (84 + (float)((t >> 15) % 40u)), 1.0f, 1, nk); }
                    gfx_circle(cx + 96, cy - 20, 13, 0x9A9FA8FFu); gfx_circle(cx + 110, cy - 12, 9, 0xB4B8C0FFu); }
            } else if (na == NA_RIVER && !lod && ((i % 3) + 3) % 3 == 0) {                 /* a bridge every third block */
                float bx = ((float)i + 0.5f) * CB_W, by = (float)(river_row(i) + river_row(i + 1)) * 0.5f * CB_H; gfx_rect(bx - 44, by - 128, 88, 256, 0x8A8FA0FFu); gfx_rect(bx - 44, by - 128, 8, 256, 0xE8E8F0FFu); gfx_rect(bx + 36, by - 128, 8, 256, 0xE8E8F0FFu);
            } else if (na == NA_CENTER) {                                                 /* the central square: the town hall, the fountain, the golden Mel */
                d_at(cx, cy - 40, 1.0f, 0); DX.ow = 3.0f;
                o_rect(-110, -84, 220, 84, 4, 0xFFF6DCFFu); o_tri(-128, -82, 128, -82, 0, -140, 0xD9553CFFu); o_rect(-22, -168, 44, 60, 3, 0xFFF6DCFFu); o_tri(-30, -166, 30, -166, 0, -200, 0xD9553CFFu); o_circ(0, -140, 13, 0xFFFFFFFFu); d_line(0, -140, 0, -149, 1.5f, OLC); d_line(0, -140, 6, -137, 1.5f, OLC);
                for (int q = 0; q < 4; q++) o_rect(-90 + (float)q * 52, -62, 24, 30, 3, nk > 0.5f ? 0xFFE680FFu : 0x7FC4F0FFu); o_rect(-16, -36, 32, 36, 3, 0x9A5F33FFu); d_line(0, -200, 0, -232, 1.8f, OLC); o_tri(0, -232, 0, -214, 26, -223, 0xFFD23FFFu);
                gfx_rrect(cx - 60, cy - 60, 120, 22, 8, 0x241650E0u); gfx_text(&F_ui, "МЭРИЯ", cx, cy - 49, 16, WHITE, AL_CENTER);
                gfx_circle(cx - 120, cy + 74, 46, 0xB9C4D4FFu); gfx_circle(cx - 120, cy + 74, 36, 0x5CC3FFFFu); { float f = fabsf(sinf(g_time * 2.2f)); gfx_capsule(cx - 120, cy + 70, cx - 120, cy + 40 - f * 16, 4, 0xDFF3FFFFu); gfx_circle(cx - 120, cy + 40 - f * 16, 8, 0xFFFFFFE0u); }
                item_draw(33, cx + 120, cy + 118, 0.82f, 0); c_tree(cx - 196, cy - 60, 1.1f, 0, nk); c_tree(cx + 196, cy - 60, 1.1f, 0, nk); c_tree(cx + 30, cy + 130, 0.9f, 1, nk);
            }
        }
        for (int row = 0; row < 2; row++) for (int i = i0; i <= i1; i++) {                 /* the far row of houses of every block, then the near one */
            int bl = cell_block(i, j); if (bl < 0 || bl >= shown) continue;
            for (int s = row * 4; s < row * 4 + 4; s++) {
                u32 plot = (u32)bl * 8u + (u32)s + 1u; float hx, hy; int k = plot <= PLOT_MAX ? CT.at_plot[plot] : -1;
                if (!plot_pos(plot, &hx, &hy)) continue;
                if (k < 0) { if (!lod && plot >= next_plot) c_lot(hx, hy, plot == next_plot); continue; }
                int mine = home_on() && plot == HM.plot;
                c_house(hx, hy, plot, CT.h[k].look & 1, lod, nk, mine, plot == CT.sel);
                if (!lod && z >= 0.62f) { float tw = gfx_text_w(&F_ui, CT.h[k].nick, 13); gfx_rrect(hx - tw * 0.5f - 6, hy + 5, tw + 12 + (CT.h[k].badge ? 16.0f : 0.0f), 19, 9, mine ? 0xFFD23FE8u : 0x241650C8u); gfx_text(&F_ui, CT.h[k].nick, hx, hy + 14, 13, mine ? C_INK : WHITE, AL_CENTER); if (CT.h[k].badge) badge_icon(CT.h[k].badge, hx + tw * 0.5f + 9, hy + 14, 7); }
            }
        }
    }
    /* names: of the streets when close, of the districts when far */
    if (!lod && z >= 0.62f) { for (int j = j0; j <= j1; j++) for (int i = i0; i <= i1; i++) { int bl = cell_block(i, j); if (bl < 0 || bl >= shown) continue; float sx = (float)i * CB_W - CB_W * 0.5f + 56, sy = (float)j * CB_H - CB_H * 0.5f + 20; const char *nm = street_name(j); float tw = gfx_text_w(&F_ui, nm, 12);
        gfx_rrect(sx, sy - 9, tw + 14, 18, 4, 0x2B6FE8F0u); gfx_text(&F_ui, nm, sx + 7, sy, 12, WHITE, AL_LEFT); } }
    if (z < 0.62f) { for (int j = j0; j <= j1; j++) for (int i = i0; i <= i1; i++) { int ai = i < 0 ? -i : i, aj = j < 0 ? -j : j, ring = ai > aj ? ai : aj, bl = cell_block(i, j);
        if (bl < 0 || bl >= shown || ring < 2 || !((ai == ring && j == 0) || (aj == ring && i == 0)) || (ring & 1)) continue;
        gfx_text(&F_ui, district_name(i, j), (float)i * CB_W, (float)j * CB_H, 26 / z, 0xFFFFFFD0u, AL_CENTER); }
    }
    if (!lod && CT.st == 2 && !CFG.acc) { float hx, hy; if (plot_pos(next_plot, &hx, &hy)) { float bob = sinf(g_time * 3) * 4; snprintf(b, sizeof(b), "Здесь будет твой дом!"); float tw = gfx_text_w(&F_ui, b, 15); gfx_rrect(hx - tw * 0.5f - 10, hy - 100 + bob, tw + 20, 28, 14, 0x2FAE3AF0u); gfx_tri(hx - 8, hy - 73 + bob, hx + 8, hy - 73 + bob, hx, hy - 62 + bob, 0x2FAE3AF0u); gfx_text(&F_ui, b, hx, hy - 86 + bob, 15, WHITE, AL_CENTER); } }
    gfx_zoom(1); gfx_offset(0, 0);
}

/* ---------------- the screen ---------------- */
static void city_center_on(u32 plot, float z) { float x, y; if (plot_pos(plot, &x, &y)) { CT.cx = x; CT.cy = y - 40; if (z > 0) CT.z_to = z; } }
static void city_enter(int a) {
    if (!CT.blocks) city_plan();
    if (!CT.inited) { CT.inited = 1; CT.z = CT.z_to = 0.8f; CT.cx = 0; CT.cy = 0; city_index(); }
    city_me();
    if (a != 1) { CT.sel = 0; if (home_on() && HM.plot) city_center_on(HM.plot, 0.9f); }
    if (CT.st != 2 || CT.age > 45.0f) city_load(0);                                         /* (the list is asked for again when it is older than 45 s) */
    if (NET.st == NS_ERR || NET.st == NS_NONE) net_cfg();
    HV.from_city = 1;
}
static void city_find_done(const char *t) {
    char want[40], have[40]; int n = 0; CT.find_miss = 1; CT.find_t = 3.0f;
    for (const char *q = t; *q && n < 38; q++) want[n++] = (char)((*q >= 'A' && *q <= 'Z') ? *q + 32 : *q); want[n] = 0;
    if (!n) { CT.find_miss = 0; return; }
    for (int pass = 0; pass < 2; pass++) for (int i = 0; i < CT.n; i++) {
        int m = 0; for (const char *q = CT.h[i].nick; *q && m < 38; q++) have[m++] = (char)((*q >= 'A' && *q <= 'Z') ? *q + 32 : *q); have[m] = 0;
        if (pass ? strstr(have, want) != NULL : !strcmp(have, want)) { CT.sel = CT.h[i].plot; city_center_on(CT.sel, 1.0f); CT.find_miss = 0; return; }
    }
}
static void scr_city(void) {
    float dt = g_dt, nk = night_k(); char b[200]; int next, count = CT.n;
    if (!CT.blocks) city_plan();
    CT.age += dt; city_me();
    if (CT.st != 2 && NET.st == NS_ON && NET.proto >= 6 && !NET.busy[RQ_CITY] && CT.st != 1) city_load(0);
    /* the camera */
    CT.z += (CT.z_to - CT.z) * minf(1.0f, dt * 9.0f);
    { int popup = CT.sel != 0; float ymax = popup ? 560.0f : 636.0f;
      if (P.pressed && !ui_block && P.y > 100 && P.y < ymax && P.x < 1180) { CT.drag = 1; CT.moved = 0; CT.cx0 = CT.cx; CT.cy0 = CT.cy; }
      if (CT.drag) {
          if (fabsf(P.x - P.downx) + fabsf(P.y - P.downy) > 9) CT.moved = 1;
          if (CT.moved) { CT.cx = CT.cx0 - (P.x - P.downx) / CT.z; CT.cy = CT.cy0 - (P.y - P.downy) / CT.z; CT.touched = 1; }
          if (!P.down) {
              CT.drag = 0;
              if (!CT.moved) {                                                           /* a tap: which house is it? */
                  float wx = (P.x - 640) / CT.z + CT.cx, wy = (P.y - 360) / CT.z + CT.cy, best = 1e9f; u32 hit = 0; int shown = (int)(CT.maxplot / 8u) + 1;
                  for (u32 p = 1; p <= (u32)shown * 8u && p <= PLOT_MAX; p++) { float hx, hy, d; if (!plot_pos(p, &hx, &hy)) break; if (CT.at_plot[p] < 0 && p != CT.maxplot + 1) continue; if (fabsf(wx - hx) > 52 || wy < hy - 112 || wy > hy + 26) continue; d = fabsf(wx - hx) + fabsf(wy - (hy - 40)); if (d < best) { best = d; hit = p; } }
                  CT.sel = hit; if (hit) sfx(S_CLICK, 0.5f, P.x);
              }
          }
      } }
    { int shown = (int)(CT.maxplot / 8u) + 1, far = 2; for (int k = 0; k < shown && k < CT.blocks; k++) { int ai = CT.ci[k] < 0 ? -CT.ci[k] : CT.ci[k], aj = CT.cj[k] < 0 ? -CT.cj[k] : CT.cj[k]; if (ai + 1 > far) far = ai + 1; if (aj + 1 > far) far = aj + 1; }
      CT.cx = clampf(CT.cx, -(float)(far + 1) * CB_W, (float)(far + 1) * CB_W); CT.cy = clampf(CT.cy, -(float)(far + 3) * CB_H, (float)(far + 1) * CB_H); }
    city_draw(nk);
    /* the top line */
    gfx_rrect_grad(0, 0, 1280, 104, 0, 0x0E0A2EF0u, 0x0E0A2E00u);
    back_button(SC_MENU, 0); title_text("Город Мелстроев", 640, 42, 40);
    if (CT.st == 2 || count) { const char *rk = city_rank(count, &next); if (next) snprintf(b, sizeof(b), "%s  •  %d %s  •  до звания «%s» ещё %d", rk, count, plural(count, "дом", "дома", "домов"), city_rank(next, NULL), next - count); else snprintf(b, sizeof(b), "%s  •  %d %s", rk, count, plural(count, "дом", "дома", "домов")); }
    else if (NET.st == NS_ON && NET.proto < 6) snprintf(b, sizeof(b), "Город скоро откроется: таблица игры ещё не обновлена");
    else if (CT.st == 1 || NET.st == NS_CFG || NET.st == NS_NONE) snprintf(b, sizeof(b), "Загружаю город...");
    else snprintf(b, sizeof(b), "Нет связи с городом. Проверь интернет");
    gfx_text(&F_txt, b, 640, 80, 20, 0xFFFFFFE0u, AL_CENTER);
    if (CFG.acc) coin_badge(1250, 52);
    /* zoom */
    if (rbtn(2390, 1228, 250, 28, IC_PLUS, C_VIO1, C_VIO2, CT.z_to < 1.5f)) CT.z_to = minf(1.6f, CT.z_to * 1.45f);
    if (rbtn(2391, 1228, 320, 28, IC_MINUS, C_VIO1, C_VIO2, CT.z_to > 0.2f)) CT.z_to = maxf(0.16f, CT.z_to / 1.45f);
    if (home_on() && HM.plot && rbtn(2392, 1228, 390, 28, IC_HOME, C_ORG1, C_ORG2, 1)) { city_center_on(HM.plot, 1.0f); CT.sel = HM.plot; }
    /* the chosen house */
    if (CT.sel) {
        int k = CT.sel <= PLOT_MAX ? CT.at_plot[CT.sel] : -1, mine = home_on() && CT.sel == HM.plot, bl = (int)((CT.sel - 1) / 8u); float px = 250, py = 576;
        panel(px, py, 780, 130);
        if (rbtn(2393, px + 746, py + 34, 20, IC_EXIT, C_RED1, C_RED2, 1)) CT.sel = 0;
        if (k >= 0) {
            int age = CT.h[k].look >> 1, big = CT.h[k].look & 1; char ab[40]; float tw = gfx_text_w(&F_ui, CT.h[k].nick, 30);
            gfx_text(&F_ui, mine ? "Мой дом" : CT.h[k].nick, px + 30, py + 34, 30, mine ? C_GOLD : WHITE, AL_LEFT); if (CT.h[k].badge && !mine) badge_icon(CT.h[k].badge, px + 30 + tw + 22, py + 34, 13);
            snprintf(b, sizeof(b), "%s дом  •  Мелу %s", big ? "Большой" : "Маленький", age_text(age, ab, sizeof(ab))); gfx_text(&F_txt, b, px + 30, py + 70, 21, 0xFFFFFFE0u, AL_LEFT);
            snprintf(b, sizeof(b), "район «%s», %s, участок № %u", district_name(CT.ci[bl], CT.cj[bl]), street_name(CT.cj[bl] + ((CT.sel - 1) % 8u >= 4 ? 1 : 0)), (unsigned)CT.sel); gfx_text(&F_txt, b, px + 30, py + 100, 18, 0xFFFFFFB0u, AL_LEFT);
            if (mine) { if (wbtn(2394, px + 610, py + 84, 230, 56, "Войти", C_GREEN1, C_GREEN2, 26, IC_HOME, 1)) { HV.visit = 0; HV.from_city = 1; go(SC_HOUSE, 0, 0); } }
            else if (wbtn(2394, px + 610, py + 84, 230, 56, "В гости", C_GREEN1, C_GREEN2, 26, IC_NEXT, NET.st == NS_ON)) city_visit(CT.sel);
        } else {
            gfx_text(&F_ui, "Свободный участок", px + 30, py + 34, 30, WHITE, AL_LEFT);
            gfx_text(&F_txt, CFG.acc ? "Здесь поселится следующий игрок, который создаст аккаунт" : "Создай аккаунт — и здесь построят твой дом. Это бесплатно!", px + 30, py + 72, 21, 0xFFFFFFE0u, AL_LEFT);
            if (!CFG.acc && wbtn(2394, px + 610, py + 96, 250, 52, "Создать аккаунт", C_GREEN1, C_GREEN2, 21, IC_USER, 1)) acc_open();
        }
    } else {
        /* the bottom line */
        if (home_on()) { if (wbtn(2395, 190, 672, 300, 62, "Мой дом", C_GREEN1, C_GREEN2, 30, IC_HOME, 1)) { HV.visit = 0; HV.from_city = 1; go(SC_HOUSE, 0, 0); } }
        else if (wbtn(2395, 230, 672, 380, 62, "Получить свой дом", C_GREEN1, C_GREEN2, 27, IC_HOME, 1)) acc_open();
        if (count > 1 && wbtn(2396, home_on() ? 500.0f : 590.0f, 672, 280, 56, "Найти игрока", C_BLUE1, C_BLUE2, 24, IC_SEARCH, 1)) kb_open("Ник игрока", "", 12, 1, city_find_done);
        if (!home_on()) { gfx_rrect(760, 644, 492, 58, 20, 0x0E0A2ED8u); gfx_text(&F_txt, "Дом и говорящего Мела получает каждый,", 1006, 662, 19, WHITE, AL_CENTER); gfx_text(&F_txt, "кто создал аккаунт. Это бесплатно.", 1006, 686, 19, WHITE, AL_CENTER); }
        else if (wbtn(2397, 800, 672, 280, 56, "Задания месяца", C_PINK, 0xB8257FFFu, 23, IC_TASKS, 1)) go(SC_MONTH, 2, 0);
    }
    if (CT.find_t > 0) { CT.find_t -= dt; if (CT.find_miss) { gfx_rrect(440, 300, 400, 60, 24, 0x0E0A2EE8u); gfx_text(&F_ui, "Такого игрока в городе нет", 640, 330, 24, WHITE, AL_CENTER); } }
    parts_draw();
}

/* ============================== the monthly missions ============================== */
static int month_back;
static void month_enter(int a) { month_back = a; month_refresh(); tasks_new6 = 0; }
static void scr_month(void) {
    char b[220], tb[40]; u32 t = now_s();
    bg_draw(0, 0.4f, DECO_NONE, 0, 0, 0);
    back_button(month_back == 1 ? SC_HOUSE : (month_back == 2 ? SC_CITY : SC_TASKS), 0); coin_badge(1250, 62);
    if (!home_on()) {
        title_text("Задания месяца", 640, 62, 46); panel(240, 230, 800, 260);
        gfx_text_wrap(&F_txt, "Задания месяца — для игроков с аккаунтом. За них дают чекушки и мебель для своего дома в Городе Мелстроев. Аккаунт бесплатный: нужны только ник и пароль.", 640, 300, 24, 700, 32, WHITE, AL_CENTER, 1);
        if (wbtn(2398, 640, 432, 320, 62, "Создать аккаунт", C_GREEN1, C_GREEN2, 26, IC_USER, 1)) acc_open();
        return;
    }
    if (!HM.month) { title_text("Задания месяца", 640, 62, 46); gfx_text(&F_txt, "Сверяю часы с таблицей игры...", 640, 380, 24, 0xFFFFFFC0u, AL_CENTER); return; }
    int n = month_days(HM.month), cur = HM.m_idx;
    snprintf(b, sizeof(b), "Задания месяца: %s", month_name(HM.month)); title_text(b, 640, 50, 42);
    if (t) snprintf(b, sizeof(b), "Задания идут по порядку. Спешить некуда, но можно сделать хоть все за день. Новые — через %s", fmt_left(month_left(t), tb, (int)sizeof(tb))); else snprintf(b, sizeof(b), "Задания идут по порядку. Можно сделать хоть все за день");
    gfx_text(&F_txt, b, 640, 92, 18, 0xFFFFFFC0u, AL_CENTER);
    for (int i = 0; i < n; i++) {
        float cw = 150, ch = 78, x = 115 + (float)(i % 7) * 158, y = 118 + (float)(i / 7) * 86; int done = i < cur, now = i == cur, item = month_prize(HM.month, i);
        u32 c0 = done ? 0x2E7F4AFFu : (now ? 0x6A4FE0FFu : 0x2A2068FFu);
        gfx_rrect(x - 2, y - 2, cw + 4, ch + 4, 16, now ? (fmodf(g_time, 1.0f) < 0.5f ? C_GOLD : 0xFFE89AFFu) : (item >= 0 ? 0xD9930FFFu : 0x00000000u)); gfx_rrect(x, y, cw, ch, 14, c0);
        snprintf(b, sizeof(b), "%d", i + 1); gfx_text(&F_ui, b, x + 26, y + 24, 26, done ? 0xFFFFFFB0u : WHITE, AL_CENTER);
        if (item >= 0) { gfx_circle(x + 100, y + 39, 33, 0xFFFFFF18u); item_icon(item, x + 100, y + 39, 54); }
        else { gfx_image_ex(I_bottle, x + 100, y + 39, 0.52f, 0.52f, 0.2f, done ? 0.5f : 1.0f); }
        if (done) { gfx_circle(x + 26, y + 56, 13, C_GREEN2); icon(IC_OK, x + 26, y + 56, 15, WHITE); } else if (!now) icon(IC_LOCK, x + 26, y + 56, 14, 0xFFFFFF70u);
    }
    { float py = 118 + (float)((n + 6) / 7) * 86 + 6, ph = 706 - py; panel(140, py, 1000, ph);
      if (month_all_done()) { gfx_text(&F_ui, "Все задания этого месяца выполнены!", 640, py + ph * 0.36f, 30, C_GOLD, AL_CENTER); gfx_text(&F_txt, "Новые появятся в следующем месяце. Мебель ждёт тебя дома, в коробке.", 640, py + ph * 0.68f, 21, 0xFFFFFFD0u, AL_CENTER); }
      else if (HM.mm.kind) {
          const Mission *m = &HM.mm; int item = month_prize(HM.month, cur); float f = (float)m->prog / (float)(m->target ? m->target : 1), cy = py + ph * 0.5f;
          gfx_circle(196, cy, 34, 0x6A4FE0FFu); icon(mis_icon(m->kind), 196, cy, 30, WHITE);
          snprintf(b, sizeof(b), "Задание %d из %d", cur + 1, n); gfx_text(&F_ui, b, 250, cy - 30, 20, C_GOLD, AL_LEFT);
          text_fit(&F_ui, mis_text(m, b, (int)sizeof(b)), 250, cy, 25, 640, WHITE, AL_LEFT);
          gfx_rrect(250, cy + 22, 520, 16, 8, 0x1A1248FFu); if (f > 0) gfx_rrect(250, cy + 22, maxf(16, 520 * minf(1, f)), 16, 8, C_GREEN1);
          if (m->kind == MK_TIME) snprintf(b, sizeof(b), "%d / %d мин", m->prog / 60, m->target / 60); else snprintf(b, sizeof(b), "%d / %d", m->prog, m->target); gfx_text(&F_ui, b, 790, cy + 30, 19, WHITE, AL_LEFT);
          gfx_text(&F_txt, "Награда", 1030, cy - 34, 17, 0xFFFFFFB0u, AL_CENTER);
          if (item >= 0 && !item_has(&HM, item)) { item_icon(item, 1030, cy + 2, 52); text_fit(&F_ui, item_tab[item].name, 1030, cy + 40, 17, 190, C_GOLD, AL_CENTER); } else reward_tag(1030, cy + 6, item >= 0 ? 60 : m->reward, 30);
      } }
}

/* ============================== a gallery of everything drawn by code (tests, pictures for the site) ============================== */
static int gal_page;
static void scr_gallery(void) {
    char b[80]; Kid k; u8 w[SL_N];
    gfx_rrect_grad(0, 0, 1280, 720, 0, 0x3A2A8CFFu, 0x1E1456FFu);
    if (gal_page < 3) {                                                                  /* the furniture, twelve things a page */
        for (int i = 0; i < 12; i++) { int it = gal_page * 12 + i; float cx = 110 + (float)(i % 6) * 212, cy = 190 + (float)(i / 6) * 340; if (it >= ITEM_N) break;
            gfx_rrect(cx - 100, cy - 150, 200, 300, 18, 0xF8E9CCFFu); item_icon(it, cx, cy - 10, 190 < 250 ? 190 : 250); snprintf(b, sizeof(b), "%d. %s", it, item_tab[it].name); gfx_text(&F_ui, b, cx, cy + 168, 18, WHITE, AL_CENTER); }
    } else if (gal_page == 3) {                                                          /* Mel year by year */
        static const u8 ages[12] = { 0, 1, 3, 5, 7, 10, 13, 16, 18, 30, 45, 70 };
        gfx_rect(0, 600, 1280, 120, 0xA86C36FFu);
        for (int i = 0; i < 12; i++) { float cx = 60 + (float)i * 105; kid_simple(&k, (float)ages[i], NULL, g_time); kid_draw(cx, 620, 0.62f, &k); snprintf(b, sizeof(b), "%d", ages[i]); gfx_text(&F_ui, b, cx, 660, 24, WHITE, AL_CENTER); }
    } else {                                                                             /* dressed up: five sets of clothes on a boy and on a grown-up */
        static const u8 sets[10][SL_N] = { { 1, 9, 15, 24, 30, 35 }, { 2, 10, 17, 26, 31, 36 }, { 3, 11, 18, 25, 32, 37 }, { 4, 12, 20, 27, 33, 38 }, { 8, 13, 23, 29, 34, 39 },
                                           { 5, 0, 14, 28, 0, 40 }, { 6, 0, 16, 0, 30, 0 }, { 7, 9, 19, 24, 33, 35 }, { 0, 0, 21, 25, 31, 0 }, { 0, 10, 22, 26, 0, 37 } };
        gfx_rect(0, 600, 1280, 120, 0xA86C36FFu);
        for (int i = 0; i < 5; i++) { int si = (gal_page - 4) % 2 * 5 + i; float cx = 130 + (float)i * 255; memcpy(w, sets[si], SL_N);
            kid_simple(&k, 9, w, g_time); kid_draw(cx - 52, 620, 0.8f, &k); kid_simple(&k, 24, w, g_time + 1); k.arm[1] = 2.4f; k.fore[1] = 0.3f; kid_draw(cx + 62, 620, 0.8f, &k); }
    }
}
/* A show house for the pictures of the site (and for looking at things without a table): a big furnished house,
   a boy of `age` years in his best clothes, a city of neighbours. Nothing of it is sent anywhere. */
static void demo6(int age) {
    static const char *const nm[24] = { "Vasya2012", "МелФан", "Kotik", "Саша", "ProGamer", "Лимонадик", "Dima", "Маша", "Стример", "Bober", "Алиса", "Egor",
                                        "Мармелад", "Tolik", "Квасик", "Nastya", "Чемпион", "Pixel", "Гоша", "Lena", "Тарзан", "Max", "Соня", "Zhenya" };
    static const i16 lay[23][4] = { { 8, 190, 0, 0 }, { 6, 330, 0, 0 }, { 3, 520, 0, 0 }, { 25, 505, 0, 0 }, { 7, 640, 0, 0 }, { 22, 812, 0, 0 }, { 12, 986, 0, 0 }, { 33, 1122, 0, 0 },
                                    { 9, 330, 264, 0 }, { 23, 812, 316, 0 }, { 35, 640, 0, 0 }, { 13, 986, 300, 0 },
                                    { 28, 150, 0, 1 }, { 0, 292, 0, 1 }, { 20, 470, 0, 1 }, { 16, 640, 0, 1 }, { 10, 800, 0, 3 }, { 19, 900, 0, 1 }, { 21, 1056, 0, 1 },
                                    { 18, 640, 304, 1 }, { 5, 292, 262, 1 }, { 30, 880, 0, 1 }, { 4, 292, 0, 1 } };
    u32 now = now_s(); int xp = 0;
    CFG.acc = 1; if (!SV.uid) SV.uid = 777u; snprintf(SV.nick, sizeof(SV.nick), "Тимофей");
    memset(&HM, 0, sizeof(HM)); HM.magic = HOME_MAGIC; HM.uid = SV.uid; HM.plot = 12; HM.big = 1; HM.guests = 14; HM.earned = 1240;
    HM.items[0] = 0xFFFFFFFFu; HM.items[1] = 0xFu;
    for (int i = 0; i < 23; i++) { Placed *q = &HM.pl[i]; q->id = (u8)(lay[i][0] + 1); q->x = (u8)(lay[i][1] / 6); q->y = (u8)(lay[i][2] / 4); q->fl = (u8)lay[i][3]; }
    HM.pl_rev = 30;
    for (int a = 0; a < age; a++) xp += pet_need(a); HM.xp = (u32)xp + 12u; HM.seen_age = (u8)age;
    { static const u8 own[9] = { 1, 14, 23, 30, 33, 8, 16, 0, 35 }; for (int i = 0; i < 9; i++) HM.cloth[own[i] >> 5] |= 1u << (own[i] & 31); }
    HM.wear[SL_HAT] = 2; HM.wear[SL_TOP] = 15; HM.wear[SL_LEGS] = 24; HM.wear[SL_FEET] = 31; HM.wear[SL_ACC] = 34; HM.wear_rev = 5;
    HM.need[ND_THIRST] = 6400; HM.need[ND_ENERGY] = 8700; HM.need[ND_HEALTH] = 9200; HM.need[ND_JOY] = 7800; HM.pet_t = now;
    HM.bought[2] = 3; HM.bought[10] = 2; HM.bought[12] = 4; HM.bought[5] = 1; HM.bought[15] = 2;
    HM.cn[C6_FEEDS] = 31; HM.cn[C6_VISITS] = 6; HM.cn[C6_WORDS] = 3; HM.ach = 0x1Fu;
    HM.month = now ? month_of(now, NULL) : MONTH_BASE; HM.m_idx = 9; month_make(); HM.mm.prog = (u16)(HM.mm.target / 2);
    HS.loaded = 1; tasks_new6 = 0; HK.inited = 0;
    if (!CT.blocks) city_plan();
    CT.n = 0;
    for (u32 p = 1; p <= 68 && CT.n < CITY_MAX; p++) {
        CHouse *c = &CT.h[CT.n]; u32 h = mhash(p, 911);
        if (h % 23u == 0 && p != 12) continue;                                           /* (a few accounts were deleted: their plots stay empty) */
        memset(c, 0, sizeof(*c)); c->plot = p; c->look = (u16)(((h >> 4) % 4u == 0 ? 1 : 0) | (((h >> 8) % 19u) << 1)); c->badge = p == 1 ? 1 : (p == 5 ? 3 : 0);
        snprintf(c->nick, sizeof(c->nick), "%s", nm[(p * 7u + (h >> 12)) % 24u]); CT.n++;
    }
    CT.maxplot = 68; CT.total = (u32)CT.n; CT.st = 2; CT.age = -100000.0f; CT.inited = 1; CT.z = CT.z_to = 0.8f; city_index(); city_me();
}
/* ============================== test hooks of V0.6 (the headless harness) ============================== */
static int v06_debug(int cmd, int arg) {
    switch (cmd) {
    case 241: return scr;
    case 242: scr_next = -1; enter(arg, 0, 0); g_fade = 0; return 0;
    case 243: return (home_on() ? 1 : 0) | (HS.loaded ? 2 : 0) | (HM.dirty ? 4 : 0) | (HM.big ? 8 : 0) | (HM.asleep ? 16 : 0);
    case 244: return (int)HM.plot;
    case 245: return coins();
    case 246: return home_on() ? pet_age() : -1;
    case 247: return arg >= 0 && arg < ND_N ? pet_pct(arg) : -1;
    case 248: pet_xp(arg, -1, 0); return (int)HM.xp;
    case 249: if (home_on()) { HM.earned += (u32)arg; home_dirty(); } return coins();
    case 250: house_buy_big(0); return HM.big;
    case 251: return items_owned(&HM);
    case 252: return items_placed(&HM);
    case 253: if (home_on() && arg >= 0 && arg < ITEM_N) { HM.items[arg >> 5] |= 1u << (arg & 31); home_dirty(); } return items_owned(&HM);
    case 254: return (int)HM.m_idx | ((int)(HM.month >= MONTH_BASE ? HM.month - MONTH_BASE : 0) << 8);
    case 255: if (month_cur()) { HM.mm.prog = HM.mm.target; HM.mm.done = 1; month_done(); } return HM.m_idx;
    case 256: return HM.mm.kind | (HM.mm.prog << 8) | (HM.mm.target << 20);
    case 257: pet_give(arg); return PT.sip_t > 0;
    case 258: pet_buy(arg); return drink_left(arg);
    case 259: words_load(); return words_known();
    case 260: pet_listen(arg ? LS_TEACH : LS_REPEAT, arg - 1); return PT.listen;
    case 261: return voice_n;
    case 262: return (int)(PT.talk_len * 1000.0f);
    case 263: return CT.n | (CT.st << 16);
    case 264: city_visit((u32)arg); return 0;
    case 265: return (HV.visit ? 1 : 0) | (HV.loading ? 2 : 0) | (HV.err ? 4 : 0) | (HV.empty ? 8 : 0) | (HV.h.big ? 16 : 0);
    case 266: return arg >= 0 && arg < C6_N ? (int)HM.cn[arg] : -1;
    case 267: return (int)HM.ach;
    case 268: if (arg >= 0 && arg < CLOTH_N) { ward_buy(arg); return cloth_has(&HM, arg); } return -1;
    case 269: return arg >= 0 && arg < SL_N ? HM.wear[arg] : -1;
    case 270: for (int k = 0; k < ND_N; k++) HM.need[k] = (u16)(arg * 100); return 0;
    case 271: return HM.seen_age;
    case 272: return PT.grow | (PT.grow ? ((int)(PT.grow_t * 10.0f) << 4) : 0);
    case 273: if (home_on() && arg >= 0 && arg < ITEM_N && item_has(&HM, arg) && he_placed(arg) < 0 && items_placed(&HM) < rm_cap(HM.big)) { Placed np; int sl = he_free_slot(); memset(&np, 0, sizeof(np)); if (sl >= 0 && he_target(arg, rm_w(HM.big) * 0.5f, rm_y0(HM.big, 0) + 200, &np)) { HM.pl[sl] = np; he_changed(); } } return items_placed(&HM);
    case 274: return (int)HM.rev;
    case 275: return (int)HM.guests;
    case 276: CT.sel = (u32)arg; city_center_on((u32)arg, 1.0f); CT.z = CT.z_to; return 0;
    case 277: CT.z = CT.z_to = (float)arg / 100.0f; return 0;
    case 278: pet_sleep_toggle(); return HM.asleep;
    case 279: return (int)HM.xp;
    case 280: if (!CT.blocks) city_plan(); return CT.blocks * 8;
    case 281: if (arg >= 0 && arg < CLOTH_N && cloth_has(&HM, arg)) ward_wear(arg); return 0;
    case 282: CT.cx = (float)arg; return 0;
    case 283: if (PT.grow) grow_finish(); return HM.seen_age;
    case 284: HE.on = arg; HE.sel = -1; HE.drag = -1; return 0;
    case 285: return tasks_new6;
    case 286: if (home_on()) pet_minutes((u32)arg, 0); return 0;
    case 287: return home_on() ? home_look() : -1;
    case 288: return (int)HM.earned;
    case 289: { int pk = 0; if (S_voice) for (int i = 0; i < voice_n; i++) { int v = S_voice->pcm[i]; if (v < 0) v = -v; if (v > pk) pk = v; } return pk; }
    case 290: words_load(); return arg >= 0 && arg < WORD_N ? WD.have[arg] : -1;
    case 291: CT.cy = (float)arg; return 0;
    case 292: return (int)CT.sel;
    case 293: PT.tray = arg; return 0;
    case 294: WR.slot = arg; WR.sel = -1; return 0;
    case 295: return HS.seen_n;
    case 296: return (int)CT.maxplot;
    case 299: demo6(arg > 0 ? arg : 9); return 0;
    case 300: return arg >= 0 && arg < DRINK_N ? drink_left(arg) : -1;
    case 301: HS.t = 0; HS.retry = 0; return 0;                                          /* send (or ask for) the house now */
    case 302: return HM.mm.reward | (month_prize(HM.month, HM.m_idx) + 1) << 16;         /* what the open mission gives: чекушки, or a thing (its number + 1) */
    case 303: return (int)PT.tipsy_t;
    case 304: return MSGB.on | (KB.on << 1) | (ask_on() << 2);
    case 305: MSGB.on = 0; return 0;
    case 306: return arg >= 0 && arg < PLACED_MAX ? (HM.pl[arg].id | (HM.pl[arg].x << 8) | (HM.pl[arg].y << 16) | (HM.pl[arg].fl << 24)) : -1;
    case 307: return (int)HM.pl_rev;
    case 308: return (int)(HV.visits) | ((int)items_placed(&HV.h) << 16);
    case 309: return NET.proto;
    case 311: if (home_on()) { mis_set(&HM.mm, arg & 255, (arg >> 24) & 15, (arg >> 8) & 0xFFFF, 7); HS.mseen_n = 0; home_dirty(); } return HM.mm.kind;      /* tests: the open monthly mission becomes one of this kind (bits 0-7), target (8-23), argument (24-27), 7 чекушек */
    case 298: gal_page = arg; scr_next = -1; scr = SC_GAL; g_fade = 0; return 0;
    case 297: if (home_on()) { HM.pet_t = 0; HM.xp_day = 0; memset(HM.xp_cnt, 0, sizeof(HM.xp_cnt)); HM.xp_wins = 0; } return 0;
    }
    return 0;
}
