/* ============================================================================
   MEL-ENGINE  —  собственный мини-движок игры «Мел-Ням»
   Software-renderer + audio mixer/synth + asset pack. No third-party engine.
   One C codebase -> Windows .exe (Win32) and WebAssembly (HTML).
   ============================================================================ */
#ifndef MN_ENGINE_H
#define MN_ENGINE_H
#include <stdint.h>
#include <stddef.h>

typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;
typedef int16_t i16; typedef int32_t i32;

#define DESIGN_W 1280.0f
#define DESIGN_H 720.0f
#define PI  3.14159265358979f
#define TAU 6.28318530717959f

/* Pixel format: premultiplied alpha, 32 bit.
   default  : 0xAARRGGBB (BGRA bytes)  -> Win32 DIB / GL_BGRA
   PIX_RGBA : 0xAABBGGRR (RGBA bytes)  -> canvas ImageData               */
#ifdef PIX_RGBA
#define PIX(r,g,b,a) (((u32)(a)<<24)|((u32)(b)<<16)|((u32)(g)<<8)|(u32)(r))
#else
#define PIX(r,g,b,a) (((u32)(a)<<24)|((u32)(r)<<16)|((u32)(g)<<8)|(u32)(b))
#endif

/* API colours are straight (non-premultiplied) 0xRRGGBBAA */
#define RGBA(r,g,b,a) ((((u32)(r)&255)<<24)|(((u32)(g)&255)<<16)|(((u32)(b)&255)<<8)|((u32)(a)&255))
#define WHITE 0xFFFFFFFFu
#define BLACK 0x000000FFu

typedef struct Image {
    int w, h;
    u32 *px;              /* premultiplied */
    float scale;          /* pixels per design unit */
    float ax, ay;         /* anchor (pixels) */
    struct Image *mip;    /* half-size mip chain */
} Image;

typedef struct { u32 cp; u16 x, y, w, h; i16 xoff, yoff, adv; u16 pad; } Glyph;   /* adv: 1/16 px */
typedef struct {
    Image *atlas; const Glyph *g; int n;
    float em;             /* atlas pixel size of 1em */
    float line, base;
} Font;

typedef struct { i16 *pcm; int n; int rate; } Sound;

typedef struct {
    int n; float fps; int w, h; float scale, ax, ay;
    float avail;          /* design units of body below the anchor (face centre) */
    const u8 *base; const u32 *offs;
    Image cur; int cur_idx;
} Clip;

/* ---------------- pack ---------------- */
typedef struct { char name[32]; u32 type, off, size; i32 a, b, c, d; } PackEntry;
enum { PK_PNG = 1, PK_JPG = 2, PK_JPGA = 3, PK_FONT = 4, PK_ADPCM = 5, PK_ANIM = 6, PK_RAW = 7 };
void              pack_init(const u8 *data, int size);
const PackEntry  *pack_find(const char *name);
const u8         *pack_data(const PackEntry *e);

Image *img_load(const char *name);          /* decode + mips, NULL if missing   */
Image *img_new(int w, int h, float scale);
void   img_free(Image *im);
void   img_make_mips(Image *im);
int    font_load(Font *f, const char *name);
Sound *snd_load(const char *name);
int    clip_load(Clip *c, const char *name);
const Image *clip_frame(Clip *c, int idx);

/* ---------------- gfx ---------------- */
void  gfx_set_framebuffer(u32 *px, int w, int h);  /* platform */
void  gfx_set_target(Image *im);                   /* NULL = framebuffer */
float gfx_scale(void);                             /* pixels per design unit */
int   gfx_fb_w(void); int gfx_fb_h(void);
void  gfx_offset(float ox, float oy);              /* camera shake offset (design units) */
void  gfx_zoom(float k);                           /* scale of everything drawn after it (1 = normal); the offset is in zoomed units */
void  gfx_clip(float x, float y, float w, float h);
void  gfx_clip_reset(void);
void  gfx_snap(int on);                            /* snap unrotated sprites to pixel grid */

void  gfx_clear(u32 rgba);
void  gfx_copy_from(const Image *src);             /* full target copy (bg cache) */
void  gfx_cover(const Image *im, float darken);    /* scale image to cover target */
void  gfx_grab(Image *dst);                        /* copy the current target into dst (same size) */
void  gfx_fade(u32 rgba);                          /* full-screen blend */

void  gfx_image(const Image *im, float x, float y);
void  gfx_image_ex(const Image *im, float x, float y, float sx, float sy, float rot, float alpha);
void  gfx_image_tint(const Image *im, float x, float y, float sx, float sy, float rot, u32 rgba, int additive);
void  gfx_image_sub(const Image *im, float srcx, float srcy, float srcw, float srch,
                    float x, float y, float sx, float sy, u32 rgba);  /* top-left anchored sub-rect (src in px) */

void  gfx_rect(float x, float y, float w, float h, u32 rgba);
void  gfx_rrect(float x, float y, float w, float h, float r, u32 rgba);
void  gfx_rrect_grad(float x, float y, float w, float h, float r, u32 top, u32 bot);
void  gfx_circle(float cx, float cy, float r, u32 rgba);
void  gfx_ring(float cx, float cy, float r, float thick, u32 rgba);
void  gfx_capsule(float x0, float y0, float x1, float y1, float r, u32 rgba);
void  gfx_capsule2(float x0, float y0, float x1, float y1, float r0, float r1, u32 rgba); /* tapered */
void  gfx_tri(float x0, float y0, float x1, float y1, float x2, float y2, u32 rgba);

enum { AL_LEFT = 0, AL_CENTER = 1, AL_RIGHT = 2 };
float gfx_text_w(const Font *f, const char *s, float size);
void  gfx_text(const Font *f, const char *s, float x, float y, float size, u32 rgba, int align);
/* word-wrapped, returns number of lines; y is the top of first line */
int   gfx_text_wrap(const Font *f, const char *s, float x, float y, float size, float maxw, float lineh, u32 rgba, int align, int draw);

/* ---------------- audio ---------------- */
void  audio_init(int out_rate);
void  audio_mix(i16 *out, int frames);            /* stereo interleaved; platform calls (locked) */
int   snd_play(const Sound *s, float vol, float pan, float pitch);
int   snd_play_voice(const Sound *s, float vol);  /* speech: ducks the music */
void  snd_stop(int id);
void  snd_music(const Sound *s);                  /* looped; NULL stops */
void  snd_volumes(float sfx, float music);
Sound *snd_new(int n, int rate);

/* ---------------- utils ---------------- */
u32   rnd_u32(void);
float rnd_f(void);                 /* [0,1) */
float rnd_range(float a, float b);
void  rnd_seed(u32 s);
static inline float clampf(float x, float a, float b) { return x < a ? a : (x > b ? b : x); }
static inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
static inline float minf(float a, float b) { return a < b ? a : b; }
static inline float maxf(float a, float b) { return a > b ? a : b; }
float ease_out_back(float t);
float ease_out_cubic(float t);
float ease_in_cubic(float t);
float ease_out_elastic(float t);
float ease_in_out(float t);
u32   color_lerp(u32 a, u32 b, float t);
u32   color_alpha(u32 rgba, float a);  /* multiply alpha */

/* ---------------- platform layer (implemented per platform) ---------------- */
void   plat_audio_lock(void);
void   plat_audio_unlock(void);
void   plat_save(const void *data, int size);
int    plat_load(void *data, int maxsize);
void   plat_store(const char *key, const void *data, int size);  /* named blob (replays, own levels); size 0 deletes it; key: [a-z0-9]{1,16} */
int    plat_fetch(const char *key, void *data, int maxsize);     /* bytes read, 0 when missing */
/* asynchronous HTTP(S): body == NULL is a GET, otherwise a POST of text/plain. The answer comes back on the main
   thread through app_http(id, status, data, size); status 0 means "no connection". */
void   plat_http(int id, const char *url, const char *body, int body_len);
void   plat_quit(void);
void   plat_fullscreen(void);
u32    plat_random(void);          /* a few unpredictable bits (player id) */
int    plat_caps(void);            /* bit0: can quit, bit1: can fullscreen, bit2: has a network layer */
void   plat_log(const char *s);

/* ---------------- app (game.c) called by platform ---------------- */
void   app_init(const u8 *pack, int packsize, int audio_rate);
void   app_resize(u32 *px, int w, int h);
void   app_frame(float dt);
void   app_pointer(int type, float x, float y);   /* 0 move, 1 down, 2 up; design units */
void   app_key(int key, int down);
int    app_debug(int cmd, int arg);               /* test hooks (headless harness) */
void   app_char(u32 codepoint);                   /* a typed character (physical keyboard) */
void   app_http(int id, int status, const char *data, int size);
void   app_text(int kind, const char *s);         /* 1: use this address for the online table (tests) */
enum { KEY_ESC = 1, KEY_ENTER, KEY_SPACE, KEY_R, KEY_M, KEY_F, KEY_LEFT, KEY_RIGHT, KEY_BACKSPACE, KEY_UP, KEY_DOWN, KEY_DELETE };

#endif
