/* «Мел-Ням» — TAS mode: the fastest full-star runs. This file is a part of game.c.

   Built-in levels: the runs were found in advance by the offline search (tools/tas_find.c, the same code as tas.c
   with a much bigger budget) and are stored in tas_data.h. The orange «TAS» button of the main menu appears when
   every star of the chapter has been collected.
   Levels made by players and test runs of the editor: after the level has been beaten with all its stars the result
   panel offers «TAS»; then the search (tas.c) runs inside the game, a portion per frame, starting from the player's
   own run. */
#include "tas.h"
#include "tas_data.h"

static u8 tas_ok[MAXLV]; static u32 tas_lhash[MAXLV]; static int tas_verified, tas_news;
static char tas_toast[96];
static int tas_unlocked(void) { return stars_all > 0 && total_stars() >= stars_all; }
/* every stored run is replayed on the real simulation once: a run that does not fit its level is not offered */
static void tas_verify(void) {
    if (tas_verified) return; tas_verified = 1;
    for (int i = 0; i < LEVEL_COUNT && i < TAS_DATA_LEVELS && i < MAXLV; i++) {
        const TasRun *r = &tas_runs[i];
        tas_lhash[i] = objs_hash(g_levels[i].objs);
        tas_ok[i] = r->ticks && r->n <= REC_MAX && tas_check(g_levels[i].objs, tas_words + r->off, r->n) == (int)r->ticks;
    }
}
static int tas_has(int i) { tas_verify(); return i >= 0 && i < LEVEL_COUNT && i < TAS_DATA_LEVELS && i < MAXLV && tas_ok[i]; }
static int tas_my_ticks(int i) { return lvl_stars(i) >= lv_max[i] ? (int)SV.ticks[i] : 0; }     /* the player's own full-star time (0: none) */

/* ---------- the run found by the search inside the game (the last one; it is also kept on the device) ---------- */
static Replay tas_c; static u32 tas_c_hash; static int tas_c_ok;
static int tas_c_own;                               /* the player's time that the last search started from: the same question is not asked twice */
static int tas_c_for(const LObj *objs, u32 h) {
    static Replay r;
    if (tas_c_ok && tas_c_hash == h) return 1;
    if (replay_load("tasc", &r, h) && r.stars >= sim_max_stars(objs) && replay_check(objs, &r)) { tas_c = r; tas_c_hash = h; tas_c_ok = 1; return 1; }
    return 0;
}

/* ---------- playing a run ---------- */
static void tas_play(const u32 *a, int n, int ticks, const char *note) {         /* CUR and play_back are set by the caller */
    memset(&PLAYB, 0, sizeof(PLAYB)); PLAYB.n = n; PLAYB.ticks = ticks; PLAYB.stars = CUR.maxst; memcpy(PLAYB.a, a, sizeof(u32) * (size_t)n);
    playb_tas = 1; snprintf(playb_who, sizeof(playb_who), "%s", note); g_toast_t = 0;
    go(SC_PLAY, -1, LM_REPLAY);
}
static void tas_play_builtin(int i, int back, int back_arg) {
    if (!tas_has(i) || scr_next >= 0) return;
    const TasRun *r = &tas_runs[i];
    cur_builtin(i); play_back = back; play_back_arg = back_arg;
    tas_play(tas_words + r->off, r->n, r->ticks, r->proved ? "быстрее невозможно" : "лучший найденный путь");
    if (r->proved) playb_tas = 2;
}
static void tas_end_toast(void) {                    /* the run has reached Mel */
    char tb[24], tb2[24]; int me = CUR.kind == 0 ? tas_my_ticks(CUR.idx) : 0;
    if (me) snprintf(tas_toast, sizeof(tas_toast), "TAS %s  •  твой рекорд %s", fmt_time(L_ticks, tb, (int)sizeof(tb)), fmt_time(me, tb2, (int)sizeof(tb2)));
    else snprintf(tas_toast, sizeof(tas_toast), "TAS %s", fmt_time(L_ticks, tb, (int)sizeof(tb)));
    L_toast = tas_toast; L_toast_t = 2.6f;
}

/* ---------- the search inside the game ---------- */
static struct {
    int on, state;                                   /* state: 1 searching, 2 a run is ready, 3 nothing was found */
    int builtin, back, back_arg;                     /* a built-in level (-1: the level that is being played) and where "back" leads after its run */
    int own, ticks, cut; long long tried; float prog, portion, t;        /* cut: stopped by the time limit, not by its budget */
    Tas *t_; u32 hash; const LObj *objs;
} TS;
#define TAS_PATIENCE 30.0f                           /* seconds: a search that has a run stops here even if its budget is not spent */
static int tas_modal_on(void) { return TS.on; }
static void tas_search_close(void) { if (TS.t_) tas_free(TS.t_); TS.t_ = NULL; TS.on = 0; }
static void tas_search_open(const LObj *objs, u32 h, int builtin, const Replay **seed, int nseed, int own) {
    TasCfg cfg; tas_cfg_game(&cfg);
    Tas *t = tas_new(objs, &cfg); int mx = sim_max_stars(objs);
    if (!t) { gtoast("Не хватает памяти для поиска TAS"); return; }
    for (int i = 0; i < nseed; i++) if (seed[i] && seed[i]->stars >= mx && !seed[i]->over && seed[i]->n <= TAS_MAXA) tas_seed(t, seed[i]->a, seed[i]->n);
    memset(&TS, 0, sizeof(TS));
    TS.on = 1; TS.state = 1; TS.t_ = t; TS.hash = h; TS.objs = objs; TS.builtin = builtin; TS.own = own; TS.portion = 40000.0f;
}
static void tas_search_watch(void) {
    int bi = TS.builtin, back = TS.back, back_arg = TS.back_arg;
    tas_search_close();
    if (!tas_c_ok || scr_next >= 0) return;
    if (bi >= 0) { cur_builtin(bi); play_back = back; play_back_arg = back_arg; }
    tas_play(tas_c.a, tas_c.n, tas_c.ticks, "найдено перебором");
}
/* called every frame: a portion of the search. The portion follows the frame time, so the window stays alive on slow devices. */
static void tas_search_update(void) {
    if (tas_news && !modal_on() && scr_next < 0 && scr == SC_PLAY && L_phase == PH_WIN && L_pt > WIN_T0 + 1.5f) {
        tas_news = 0;
        msg_open("Открыт режим TAS!", "Все звёзды главы собраны! В главном меню справа вверху появилась оранжевая кнопка «TAS»: там самые быстрые прохождения всех уровней, которые нашёл перебор.");
    }
    if (!TS.on) return;
    TS.t += g_dt;
    if (TS.state != 1 || !TS.t_) return;
    if (g_dt > 0.034f) TS.portion *= 0.7f; else if (g_dt < 0.0215f) TS.portion *= 1.12f;
    TS.portion = clampf(TS.portion, 10000.0f, 1500000.0f);
    int more = tas_work(TS.t_, (long long)TS.portion);
    const TasPlan *b = tas_best(TS.t_);
    TS.prog = tas_progress(TS.t_); TS.tried = tas_tried(TS.t_); TS.ticks = b ? b->ticks : 0;
    if (b) {                                         /* a slow device: half a minute is enough, show what has been found */
        if (more && TS.t > TAS_PATIENCE) { more = 0; TS.cut = 1; }
        if (TS.t / TAS_PATIENCE > TS.prog) TS.prog = TS.t / TAS_PATIENCE;
    }
    if (more) return;
    TS.state = 3;
    if (b && b->n <= REC_MAX) {
        static Replay r; memset(&r, 0, sizeof(r));
        r.n = b->n; r.ticks = b->ticks; r.stars = sim_max_stars(TS.objs); memcpy(r.a, b->a, sizeof(u32) * (size_t)b->n);
        if (replay_check(TS.objs, &r)) { tas_c = r; tas_c_hash = TS.hash; tas_c_ok = 1; tas_c_own = TS.own; replay_save("tasc", &r, TS.hash); TS.state = 2; }
    }
    tas_free(TS.t_); TS.t_ = NULL; TS.prog = 1; TS.t = 0;
    sfx_p(TS.state == 2 ? S_STAR3 : S_TICK, 0.7f, 640, 1.0f);
}
static const char *fmt_big(long long v, char *buf, int n) {        /* 1 234 567 */
    char d[32]; int k = snprintf(d, sizeof(d), "%lld", v), o = 0;
    for (int i = 0; i < k && o < n - 2; i++) { if (i && (k - i) % 3 == 0) buf[o++] = ' '; buf[o++] = d[i]; }
    buf[o] = 0; return buf;
}
static void tas_modal_draw(void) {
    char buf[200], nb[40], tb[24], tb2[24]; float cx = 640;
    gfx_fade(0x0A0626EEu);
    panel(280, 158, 720, 404);
    if (TS.state == 1) {
        title_text("TAS: ищу самый быстрый путь", cx, 214, 38);
        gfx_text_wrap(&F_txt, "Алгоритм пробует вариант за вариантом и оставляет самый быстрый. Такой точности человеку не добиться!", cx, 262, 21, 620, 28, 0xE8E0FFFFu, AL_CENTER, 1);
        float bx = 350, bw = 580, by = 338, bh = 30, f = clampf(TS.prog, 0, 1);
        gfx_rrect(bx - 3, by - 3, bw + 6, bh + 6, 18, 0x0E0A2EC0u);
        if (f > 0.01f) gfx_rrect_grad(bx, by, maxf(bh, bw * f), bh, 15, C_ORG1, C_ORG2);
        snprintf(buf, sizeof(buf), "%d%%", (int)(f * 100.0f)); gfx_text(&F_ui, buf, cx, by + bh * 0.5f, 21, WHITE, AL_CENTER);
        snprintf(buf, sizeof(buf), "Проверено вариантов: %s", fmt_big(TS.tried, nb, (int)sizeof(nb))); gfx_text(&F_ui, buf, cx, 404, 24, WHITE, AL_CENTER);
        if (TS.ticks) {
            if (TS.own) snprintf(buf, sizeof(buf), "Лучшее время: %s  •  твоё: %s", fmt_time(TS.ticks, tb, (int)sizeof(tb)), fmt_time(TS.own, tb2, (int)sizeof(tb2)));
            else snprintf(buf, sizeof(buf), "Лучшее время: %s", fmt_time(TS.ticks, tb, (int)sizeof(tb)));
            gfx_text(&F_ui, buf, cx, 440, 24, C_GOLD, AL_CENTER);
        } else gfx_text(&F_ui, "Пока ни одного пути со всеми звёздами...", cx, 440, 22, 0xFFFFFFC0u, AL_CENTER);
        if (wbtn(680, cx, 506, 220, 60, "Отмена", C_VIO1, C_VIO2, 28, IC_NONE, 1)) tas_search_close();
    } else if (TS.state == 2) {
        title_text("TAS найден!", cx, 216, 44);
        snprintf(buf, sizeof(buf), "Самый быстрый путь: %s", fmt_time(tas_c.ticks, tb, (int)sizeof(tb))); gfx_text(&F_ui, buf, cx, 284, 32, C_GOLD, AL_CENTER);
        if (TS.own > tas_c.ticks) { int cs = (int)(((long long)(TS.own - tas_c.ticks) * 100 + SIM_HZ / 2) / SIM_HZ); snprintf(buf, sizeof(buf), "Твоё время %s: TAS быстрее на %d.%02d с", fmt_time(TS.own, tb, (int)sizeof(tb)), cs / 100, cs % 100); }
        else if (TS.own) snprintf(buf, sizeof(buf), TS.cut ? "Твоё время %s: за полминуты быстрее пути не нашлось." : "Твоё время %s: быстрее пути перебор не нашёл. Отлично!", fmt_time(TS.own, tb, (int)sizeof(tb)));
        else buf[0] = 0;
        text_fit(&F_txt, buf, cx, 334, 23, 650, 0xE8E0FFFFu, AL_CENTER);
        snprintf(buf, sizeof(buf), TS.cut ? "Проверено вариантов: %s  •  поиск остановлен по времени" : "Проверено вариантов: %s", fmt_big(TS.tried, nb, (int)sizeof(nb))); text_fit(&F_txt, buf, cx, 376, 21, 650, 0xFFFFFFC0u, AL_CENTER);
        int ready = TS.t > 0.25f;
        int watch = wbtn(681, cx - 130, 478, 250, 72, "Смотреть", C_GREEN1, C_GREEN2, 32, IC_PLAY, ready), close = wbtn(682, cx + 140, 478, 220, 72, "Закрыть", C_VIO1, C_VIO2, 30, IC_NONE, ready);
        if (watch) tas_search_watch(); else if (close) tas_search_close();
    } else {
        title_text("Не получилось", cx, 222, 42);
        gfx_text_wrap(&F_txt, "Перебор не нашёл ни одного пути со всеми звёздами: уровень слишком хитрый. Пройди его ещё раз и попробуй снова.", cx, 300, 23, 620, 31, 0xE8E0FFFFu, AL_CENTER, 1);
        if (wbtn(683, cx, 478, 220, 68, "Понятно", C_GREEN1, C_GREEN2, 30, IC_NONE, 1)) tas_search_close();
    }
}
static int tas_modal_key(int key) {
    if (key == KEY_ESC) tas_search_close();
    else if ((key == KEY_ENTER || key == KEY_SPACE) && TS.state != 1 && TS.t > 0.25f) { if (TS.state == 2) tas_search_watch(); else tas_search_close(); }
    return 1;
}

/* a built-in level: the stored run - or, when the player's own record is faster than it, a new search that starts from both */
static void tas_open_builtin(int i, int back, int back_arg) {
    static Replay own, stored; const Replay *seed[3]; int ns = 0; char k[8];
    if (!tas_has(i) || scr_next >= 0) return;
    const TasRun *r = &tas_runs[i]; int me = tas_my_ticks(i); u32 h = tas_lhash[i];
    if (!me || me >= (int)r->ticks) { tas_play_builtin(i, back, back_arg); return; }
    if (tas_c_for(g_levels[i].objs, h) && (tas_c.ticks <= me || tas_c_own == me)) { cur_builtin(i); play_back = back; play_back_arg = back_arg; tas_play(tas_c.a, tas_c.n, tas_c.ticks, "найдено перебором"); return; }
    own_key(i, k); if (replay_load(k, &own, h) && own.ticks == me) seed[ns++] = &own;
    memset(&stored, 0, sizeof(stored)); stored.n = r->n; stored.ticks = r->ticks; stored.stars = lv_max[i]; memcpy(stored.a, tas_words + r->off, sizeof(u32) * (size_t)r->n); seed[ns++] = &stored;
    if (tas_c_ok && tas_c_hash == h) seed[ns++] = &tas_c;
    tas_search_open(g_levels[i].objs, h, i, seed, ns, me); TS.back = back; TS.back_arg = back_arg;
}
/* the result panel: is the «TAS» button there? (st: stars of the run that has just ended) */
static int tas_offered(int st) {
    int mx = CUR.maxst;
    if (CUR.kind == 0) return tas_unlocked() && tas_has(CUR.idx);
    return st >= mx || (CUR.kind == 2 && pub_best_ok && pub_best.stars >= mx) || (CUR.kind == 1 && ed_proof_ok && ed_proof.stars >= mx);
}
static void tas_from_win(void) {
    if (scr_next >= 0) return;
    if (CUR.kind == 0) { tas_open_builtin(CUR.idx, play_back, play_back_arg); return; }
    const Replay *seed[4]; int ns = 0, mx = CUR.maxst, own = 0; u32 h = objs_hash(CUR.objs);
    if (REC.n >= 0 && REC.stars >= mx && REC.ticks > 0 && !REC.over) { seed[ns++] = &REC; own = REC.ticks; }
    if (CUR.kind == 2 && pub_best_ok && pub_best.stars >= mx) { seed[ns++] = &pub_best; if (!own || pub_best.ticks < own) own = pub_best.ticks; }
    if (CUR.kind == 1 && ed_proof_ok && ed_proof.stars >= mx) { seed[ns++] = &ed_proof; if (!own || ed_proof.ticks < own) own = ed_proof.ticks; }
    if (tas_c_for(CUR.objs, h)) {
        if (!own || tas_c.ticks <= own || tas_c_own == own) { tas_play(tas_c.a, tas_c.n, tas_c.ticks, "найдено перебором"); return; }     /* found before, and still not beaten */
        seed[ns++] = &tas_c;
    }
    tas_search_open(CUR.objs, h, -1, seed, ns, own);
}

/* ---------- the TAS screen: all 60 levels ---------- */
static void tas_enter(int a) { (void)a; tas_verify(); mel_set(CL_IDLE, 1); }
static void tas_mark(float x, float y, float r) {    /* "the exhaustive search has finished" */
    gfx_circle(x, y, r + 1.5f, 0x0A3A1AC0u); gfx_circle(x, y, r, 0x35D46CFFu);
    gfx_capsule(x - r * 0.48f, y + r * 0.02f, x - r * 0.12f, y + r * 0.40f, r * 0.17f, WHITE); gfx_capsule(x - r * 0.12f, y + r * 0.40f, x + r * 0.50f, y - r * 0.36f, r * 0.17f, WHITE);
}
static void scr_tas(void) {
    char buf[200], tb[24], tb2[24]; long long sum_t = 0, sum_me = 0; int all_me = 1, shown = 0;
    tas_verify();
    bg_draw(0, 0.34f, DECO_NONE, 0, 0, 0);
    if (rbtn(6, 62, 62, 32, IC_BACK, C_VIO1, C_VIO2, 1)) go(SC_MENU, 0, 0);
    {
        const char *t2 = "самые быстрые прохождения"; float w1 = gfx_text_w(&F_ui, "TAS", 34) + 34, w2 = gfx_text_w(&F_ui, t2, 40), x = 662 - (w1 + 16 + w2) * 0.5f;
        gfx_rrect_grad(x, 24, w1, 48, 24, C_ORG1, C_ORG2); gfx_text(&F_ui, "TAS", x + w1 * 0.5f, 48, 34, WHITE, AL_CENTER);
        gfx_text(&F_ui, t2, x + w1 + 16, 48, 40, WHITE, AL_LEFT);
    }
    gfx_text(&F_txt, "Перебор проверил миллионы вариантов и оставил самый быстрый путь со всеми звёздами. Нажми на уровень и смотри!", 662, 92, 18.5f, 0xE4DCFFFFu, AL_CENTER);
    float x0 = 44, colw = 119.2f, y0 = 176, rowh = 79;
    for (int b = 0; b < BOXES; b++) {
        float x = x0 + colw * ((float)b + 0.5f);
        snprintf(buf, sizeof(buf), "%d. %s", b + 1, box_name[b]); text_fit(&F_ui, buf, x, 124, 16.5f, colw - 8, color_lerp(box_c1[b], 0xFFFFFFFFu, 0.45f), AL_CENTER);
        for (int i = 0; i < PER_BOX; i++) {
            int li = b * PER_BOX + i, id = 600 + li, ok = tas_has(li), me = ok ? tas_my_ticks(li) : 0; const TasRun *r = &tas_runs[li < TAS_DATA_LEVELS ? li : 0];
            int ticks = ok ? (int)r->ticks : 0, proved = ok && r->proved;
            if (ok && tas_c_ok && tas_c_hash == tas_lhash[li] && tas_c.ticks < ticks) { ticks = tas_c.ticks; proved = 0; }      /* a faster run was found on this device */
            float y = y0 + rowh * (float)i;
            int click = btn_logic(id, x, y, 110, 72, ok);
            float a = B_anim[id], s = 1.0f + 0.05f * maxf(a, 0), press = a < 0 ? -a : 0, W = 110 * s, H = 72 * s, yy = y + press * 3.0f;
            u32 c0 = ok ? box_c1[b] : 0x8C88A8FFu, c1 = ok ? box_c2[b] : 0x56526EFFu;
            gfx_rrect(x - W * 0.5f - 1, y - H * 0.5f + 7, W + 2, H, 19, 0x00000050u);
            gfx_rrect(x - W * 0.5f, y - H * 0.5f + 5, W, H, 18, color_lerp(c1, 0x000000FFu, 0.45f));
            gfx_rrect_grad(x - W * 0.5f, yy - H * 0.5f, W, H, 18, c0, c1);
            gfx_rrect(x - W * 0.5f + 6, yy - H * 0.5f + 4, W - 12, H * 0.32f, 11, 0xFFFFFF24u);
            snprintf(buf, sizeof(buf), "%d-%d", b + 1, i + 1);
            gfx_text(&F_txt, buf, x - W * 0.5f + 11 * s, yy - 22 * s, 15.5f * s, 0x160C3CE6u, AL_LEFT);
            if (!ok) { gfx_text(&F_ui, "—", x, yy + 4, 26 * s, 0xFFFFFFA0u, AL_CENTER); continue; }
            if (proved) tas_mark(x + W * 0.5f - 15 * s, yy - 21 * s, 8.5f * s);
            fmt_time(ticks, tb, (int)sizeof(tb));
            gfx_text(&F_ui, tb, x, yy - 1 * s, 24.5f * s, WHITE, AL_CENTER);
            gfx_rrect(x - W * 0.5f + 7 * s, yy + 13 * s, W - 14 * s, 18 * s, 9 * s, 0x120A3870u);          /* the player's own best full-star time */
            if (me && me < ticks) gfx_text(&F_txt, "ты быстрее!", x, yy + 22 * s, 14 * s, 0xFFF3A0FFu, AL_CENTER);
            else if (me) { snprintf(buf, sizeof(buf), "ты %s", fmt_time(me, tb2, (int)sizeof(tb2))); gfx_text(&F_txt, buf, x, yy + 22 * s, 14 * s, me == ticks ? 0xFFF3A0FFu : 0xFFFFFFF0u, AL_CENTER); }
            else gfx_text(&F_txt, "—", x, yy + 22 * s, 14 * s, 0xFFFFFFC0u, AL_CENTER);
            sum_t += ticks; shown++; if (me) sum_me += me; else all_me = 0;
            if (click) tas_open_builtin(li, SC_TAS, 0);
        }
    }
    tas_mark(190, 648, 9); gfx_text(&F_txt, "— полный перебор: быстрее пройти нельзя.   Без значка — лучший путь из найденных.", 208, 648, 18.5f, 0xE4DCFFFFu, AL_LEFT);
    if (shown) {
        if (all_me && sum_me > 0) snprintf(buf, sizeof(buf), "Все уровни: TAS %s  •  твои рекорды %s", fmt_time((int)sum_t, tb, (int)sizeof(tb)), fmt_time((int)sum_me, tb2, (int)sizeof(tb2)));
        else snprintf(buf, sizeof(buf), "Все уровни: TAS %s", fmt_time((int)sum_t, tb, (int)sizeof(tb)));
        gfx_text(&F_ui, buf, 640, 688, 23, C_GOLD, AL_CENTER);
    }
}

/* ---------- test hooks (app_debug 120..139) ---------- */
static int tas_debug(int cmd, int arg) {
    switch (cmd) {
    case 120: if (!tas_has(arg) || scr_next >= 0) return 0; tas_open_builtin(arg, SC_TAS, 0); return 1;      /* watch the run of a built-in level */
    case 121: return tas_has(arg) ? (int)tas_runs[arg].ticks : 0;
    case 122: { int n = 0; for (int i = 0; i < LEVEL_COUNT; i++) n += tas_has(i); return n; }
    case 123: if (scr != SC_PLAY || L_phase != PH_WIN || L_mode != LM_PLAY || !tas_offered(S.stars > CUR.maxst ? CUR.maxst : S.stars)) return 0; tas_from_win(); return 1;      /* the «TAS» button of the result panel */
    case 124: return TS.on | (TS.state << 1) | ((int)(TS.prog * 1000.0f) << 4);
    case 125: return TS.on && TS.state == 1 ? TS.ticks : (tas_c_ok ? tas_c.ticks : 0);
    case 126: if (!TS.on || TS.state != 2) return 0; tas_search_watch(); return 1;
    case 127: return tas_unlocked();
    case 128: return playb_tas;
    case 129: return tas_has(arg) ? (int)tas_runs[arg].proved : 0;
    case 130: scr_next = -1; enter(SC_TAS, 0, 0); g_fade = 0; return 0;
    case 131: return (int)(TS.tried / 1000);
    case 132: if (arg == 1) TS.cut = 1; return (int)TS.portion | (TS.cut << 30);
    case 133: return TS.own;
    case 134: if (TS.on) tas_search_close(); return 0;
    case 135: tas_c_ok = 0; tas_c_own = 0; plat_store("tasc", "", 0); return 0;
    case 136: { int n = 0; for (int i = 0; i < LEVEL_COUNT; i++) n += tas_has(i) && tas_runs[i].proved; return n; }
    case 137:                                        /* tests and screenshots: every star collected; times: `arg` ticks, or (arg <= 0) those of a decent player */
        tas_verify();                                /* arg <= -2: all the levels but one (level -arg - 2) */
        for (int i = 0; i < LEVEL_COUNT; i++) {
            if (arg <= -2 && i == -arg - 2) continue;
            SV.best[i] = (u8)(lv_max[i] + 1);
            if (!SV.ticks[i]) SV.ticks[i] = (u32)(arg > 0 ? arg : (tas_has(i) ? (int)tas_runs[i].ticks * (112 + (i * 37 + 11) % 61) / 100 : 2400));
        }
        return total_stars();
    case 138: return input_ok() ? player_act(arg >> 12, arg & 4095) : 0;         /* tests: a player's action (action << 12 | argument) */
    case 139: {                                      /* tests: the search for a built-in level, started from the player's own recording alone */
        static Replay own; const Replay *seed[1]; char k[8]; int ns = 0;
        if (arg < 0 || arg >= LEVEL_COUNT || TS.on) return 0;
        tas_verify(); own_key(arg, k); if (replay_load(k, &own, tas_lhash[arg])) seed[ns++] = &own;
        tas_search_open(g_levels[arg].objs, tas_lhash[arg], arg, seed, ns, ns ? own.ticks : 0); TS.back = SC_TAS;
        return TS.on;
    }
    default: return 0;
    }
}
