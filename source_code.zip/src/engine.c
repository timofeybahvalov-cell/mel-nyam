/* ============================================================================
   MEL-ENGINE implementation: asset pack, software rasterizer, text, audio mixer.
   ============================================================================ */
#include "engine.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_STATIC
#define STBI_NO_STDIO
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#define STBI_NO_LINEAR
#define STBI_NO_HDR
#define STBI_NO_FAILURE_STRINGS
#define STBI_ASSERT(x)
#if defined(__GNUC__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#include "stb_image.h"
#if defined(__GNUC__)
#pragma GCC diagnostic pop
#endif

/* ============================== utils ============================== */
static u32 g_rng = 0x1234ABCDu;
void rnd_seed(u32 s) { g_rng = s ? s : 1; }
u32 rnd_u32(void) { u32 x = g_rng; x ^= x << 13; x ^= x >> 17; x ^= x << 5; return g_rng = x; }
float rnd_f(void) { return (float)(rnd_u32() >> 8) * (1.0f / 16777216.0f); }
float rnd_range(float a, float b) { return a + (b - a) * rnd_f(); }

float ease_out_back(float t) { float c1 = 1.70158f, c3 = c1 + 1; t = clampf(t, 0, 1); float u = t - 1; return 1 + c3 * u * u * u + c1 * u * u; }
float ease_out_cubic(float t) { t = clampf(t, 0, 1); float u = 1 - t; return 1 - u * u * u; }
float ease_in_cubic(float t) { t = clampf(t, 0, 1); return t * t * t; }
float ease_in_out(float t) { t = clampf(t, 0, 1); return t * t * (3 - 2 * t); }
float ease_out_elastic(float t) {
    t = clampf(t, 0, 1); if (t <= 0) return 0; if (t >= 1) return 1;
    return powf(2, -10 * t) * sinf((t * 10 - 0.75f) * (TAU / 3)) + 1;
}
u32 color_lerp(u32 a, u32 b, float t) {
    t = clampf(t, 0, 1);
    int r = (int)lerpf((float)(a >> 24), (float)(b >> 24), t), g = (int)lerpf((float)((a >> 16) & 255), (float)((b >> 16) & 255), t);
    int bl = (int)lerpf((float)((a >> 8) & 255), (float)((b >> 8) & 255), t), al = (int)lerpf((float)(a & 255), (float)(b & 255), t);
    return RGBA(r, g, bl, al);
}
u32 color_alpha(u32 c, float a) { a = clampf(a, 0, 1); return (c & 0xFFFFFF00u) | (u32)((float)(c & 255) * a + 0.5f); }

/* ============================== pack ============================== */
static const u8 *g_pk; static int g_pk_n; static const PackEntry *g_pk_e;
void pack_init(const u8 *data, int size) {
    (void)size; g_pk = data; g_pk_n = 0;
    if (!data || memcmp(data, "MNPK", 4) != 0) return;
    memcpy(&g_pk_n, data + 8, 4); g_pk_e = (const PackEntry *)(data + 16);
}
const PackEntry *pack_find(const char *name) {
    for (int i = 0; i < g_pk_n; i++) if (strncmp(g_pk_e[i].name, name, 31) == 0) return &g_pk_e[i];
    return NULL;
}
const u8 *pack_data(const PackEntry *e) { return g_pk + e->off; }

/* ============================== pixels ============================== */
static inline u32 premul(u32 c) {
    u32 r = c >> 24, g = (c >> 16) & 255, b = (c >> 8) & 255, a = c & 255;
    r = (r * a + 127) / 255; g = (g * a + 127) / 255; b = (b * a + 127) / 255;
    return PIX(r, g, b, a);
}
static inline u32 px_over(u32 d, u32 s) {
    u32 ia = 256 - ((s >> 24) + (s >> 31));
    u32 rb = (((d & 0x00FF00FFu) * ia) >> 8) & 0x00FF00FFu;
    u32 ag = (((d >> 8) & 0x00FF00FFu) * ia) & 0xFF00FF00u;
    return s + (rb | ag);
}
static inline u32 px_add(u32 d, u32 s) {
    u32 rb = (d & 0x00FF00FFu) + (s & 0x00FF00FFu);
    u32 ag = ((d >> 8) & 0x00FF00FFu) + ((s >> 8) & 0x00FF00FFu);
    rb |= ((rb >> 8) & 0x00010001u) * 0xFFu;
    ag |= ((ag >> 8) & 0x00010001u) * 0xFFu;
    return (rb & 0x00FF00FFu) | ((ag & 0x00FF00FFu) << 8);
}
static inline u32 px_scale(u32 s, u32 a) { /* a: 0..256 */
    u32 rb = (((s & 0x00FF00FFu) * a) >> 8) & 0x00FF00FFu;
    u32 ag = (((s >> 8) & 0x00FF00FFu) * a) & 0xFF00FF00u;
    return rb | ag;
}
static inline u32 px_lerp(u32 a, u32 b, u32 t) { /* t: 0..256 */
    u32 it = 256 - t;
    u32 rb = (((a & 0x00FF00FFu) * it + (b & 0x00FF00FFu) * t) >> 8) & 0x00FF00FFu;
    u32 ag = (((a >> 8) & 0x00FF00FFu) * it + ((b >> 8) & 0x00FF00FFu) * t) & 0xFF00FF00u;
    return rb | ag;
}
static inline u32 px_mul(u32 s, u32 m) { /* bytewise multiply */
    u32 m0 = m & 255, m1 = (m >> 8) & 255, m2 = (m >> 16) & 255, m3 = m >> 24;
    m0 += m0 >> 7; m1 += m1 >> 7; m2 += m2 >> 7; m3 += m3 >> 7;
    u32 r0 = ((s & 255) * m0) >> 8, r1 = (((s >> 8) & 255) * m1) >> 8, r2 = (((s >> 16) & 255) * m2) >> 8, r3 = ((s >> 24) * m3) >> 8;
    return r0 | (r1 << 8) | (r2 << 16) | (r3 << 24);
}

/* ============================== images ============================== */
Image *img_new(int w, int h, float scale) {
    Image *im = (Image *)calloc(1, sizeof(Image));
    im->w = w; im->h = h; im->scale = scale; im->ax = w * 0.5f; im->ay = h * 0.5f;
    im->px = (u32 *)calloc((size_t)w * h + 4, 4);
    return im;
}
void img_free(Image *im) {
    while (im) { Image *m = im->mip; free(im->px); free(im); im = m; }
}
void img_make_mips(Image *im) {
    Image *cur = im; int lv = 0;
    while (cur->w >= 16 && cur->h >= 16 && lv < 3 && !cur->mip) {
        int w = (cur->w + 1) / 2, h = (cur->h + 1) / 2;
        Image *m = img_new(w, h, cur->scale * 0.5f);
        m->ax = cur->ax * 0.5f; m->ay = cur->ay * 0.5f;
        for (int y = 0; y < h; y++) {
            int y0 = y * 2, y1 = y0 + 1 < cur->h ? y0 + 1 : y0;
            const u32 *r0 = cur->px + y0 * cur->w, *r1 = cur->px + y1 * cur->w; u32 *d = m->px + y * w;
            for (int x = 0; x < w; x++) {
                int x0 = x * 2, x1 = x0 + 1 < cur->w ? x0 + 1 : x0;
                u32 a = r0[x0], b = r0[x1], c = r1[x0], e = r1[x1];
                u32 rb = ((a & 0x00FF00FFu) + (b & 0x00FF00FFu) + (c & 0x00FF00FFu) + (e & 0x00FF00FFu) + 0x00020002u) >> 2 & 0x00FF00FFu;
                u32 ag = (((a >> 8) & 0x00FF00FFu) + ((b >> 8) & 0x00FF00FFu) + ((c >> 8) & 0x00FF00FFu) + ((e >> 8) & 0x00FF00FFu) + 0x00020002u) >> 2 & 0x00FF00FFu;
                d[x] = rb | (ag << 8);
            }
        }
        cur->mip = m; cur = m; lv++;
    }
}
static void fill_from_rgba(u32 *dst, const u8 *p, int n) {
    for (int i = 0; i < n; i++, p += 4) {
        u32 a = p[3], r = p[0], g = p[1], b = p[2];
        if (a == 255) dst[i] = PIX(r, g, b, 255);
        else if (a == 0) dst[i] = 0;
        else { r = (r * a + 127) / 255; g = (g * a + 127) / 255; b = (b * a + 127) / 255; dst[i] = PIX(r, g, b, a); }
    }
}
/* JPEG holding [colour(premultiplied) | alpha] side by side */
static int decode_jpga(const u8 *data, int size, Image *out) {
    int w, h, n; u8 *p = stbi_load_from_memory(data, size, &w, &h, &n, 3);
    if (!p) return 0;
    int hw = w / 2;
    if (!out->px || out->w != hw || out->h != h) { free(out->px); out->px = (u32 *)calloc((size_t)hw * h + 4, 4); out->w = hw; out->h = h; }
    for (int y = 0; y < h; y++) {
        const u8 *c = p + (size_t)y * w * 3, *al = c + hw * 3; u32 *d = out->px + y * hw;
        for (int x = 0; x < hw; x++, c += 3, al += 3) {
            u32 a = al[1]; if (a < 8) { d[x] = 0; continue; } if (a > 247) a = 255;
            u32 r = c[0], g = c[1], b = c[2];
            if (r > a) r = a; if (g > a) g = a; if (b > a) b = a;
            d[x] = PIX(r, g, b, a);
        }
    }
    stbi_image_free(p);
    return 1;
}
Image *img_load(const char *name) {
    const PackEntry *e = pack_find(name); if (!e) return NULL;
    const u8 *data = pack_data(e); Image *im = NULL; int w, h, n;
    if (e->type == PK_PNG) {
        u8 *p = stbi_load_from_memory(data, (int)e->size, &w, &h, &n, 4); if (!p) return NULL;
        im = img_new(w, h, 1); fill_from_rgba(im->px, p, w * h); stbi_image_free(p);
    } else if (e->type == PK_JPG) {
        u8 *p = stbi_load_from_memory(data, (int)e->size, &w, &h, &n, 3); if (!p) return NULL;
        im = img_new(w, h, 1);
        for (int i = 0; i < w * h; i++) im->px[i] = PIX(p[i * 3], p[i * 3 + 1], p[i * 3 + 2], 255);
        stbi_image_free(p);
    } else if (e->type == PK_JPGA) {
        im = (Image *)calloc(1, sizeof(Image));
        if (!decode_jpga(data, (int)e->size, im)) { free(im); return NULL; }
    } else return NULL;
    im->scale = e->a > 0 ? e->a / 1000.0f : 1.0f;
    im->ax = e->b >= 0 ? (float)e->b : im->w * 0.5f;
    im->ay = e->c >= 0 ? (float)e->c : im->h * 0.5f;
    if (!(e->d & 1)) img_make_mips(im);
    return im;
}
int font_load(Font *f, const char *name) {
    const PackEntry *e = pack_find(name); if (!e || e->type != PK_FONT) return 0;
    char nm[40]; strncpy(nm, name, 31); nm[31] = 0; strcat(nm, "_img");
    f->atlas = img_load(nm); if (!f->atlas) return 0;
    f->g = (const Glyph *)pack_data(e); f->n = e->a; f->em = (float)e->b; f->line = (float)e->c; f->base = (float)e->d;
    return 1;
}
int clip_load(Clip *c, const char *name) {
    const PackEntry *e = pack_find(name); memset(c, 0, sizeof(*c)); c->cur_idx = -1;
    if (!e || e->type != PK_ANIM) return 0;
    const u8 *d = pack_data(e); i32 hdr[8]; memcpy(hdr, d, 32);
    c->n = e->a; c->fps = e->b / 100.0f; c->w = e->c; c->h = e->d;
    c->scale = hdr[0] / 1000.0f; c->ax = (float)hdr[1]; c->ay = (float)hdr[2]; c->avail = (float)hdr[3];
    c->offs = (const u32 *)(d + 32); c->base = d;
    c->cur.scale = c->scale; c->cur.ax = c->ax; c->cur.ay = c->ay;
    return 1;
}
const Image *clip_frame(Clip *c, int idx) {
    if (c->n <= 0) return NULL;
    if (idx < 0) idx = 0; if (idx >= c->n) idx = c->n - 1;
    if (idx != c->cur_idx) {
        u32 o0, o1; memcpy(&o0, c->offs + idx, 4); memcpy(&o1, c->offs + idx + 1, 4);
        if (decode_jpga(c->base + o0, (int)(o1 - o0), &c->cur)) c->cur_idx = idx;
        c->cur.scale = c->scale; c->cur.ax = c->ax; c->cur.ay = c->ay;
    }
    return c->cur.px ? &c->cur : NULL;
}

/* ============================== gfx state ============================== */
static u32 *T_px; static int T_w, T_h, C_x0, C_y0, C_x1, C_y1;
static u32 *FB_px; static int FB_w, FB_h;
static float RS = 1.0f, RS0 = 1.0f, OX = 0, OY = 0; static int SNAP = 0;

void gfx_set_framebuffer(u32 *px, int w, int h) { FB_px = px; FB_w = w; FB_h = h; RS0 = RS = (float)h / DESIGN_H; gfx_set_target(NULL); }
void gfx_zoom(float k) { RS = RS0 * (k > 0.01f ? k : 0.01f); }
void gfx_set_target(Image *im) {
    if (im) { T_px = im->px; T_w = im->w; T_h = im->h; } else { T_px = FB_px; T_w = FB_w; T_h = FB_h; }
    C_x0 = 0; C_y0 = 0; C_x1 = T_w; C_y1 = T_h;
}
float gfx_scale(void) { return RS; }
int gfx_fb_w(void) { return FB_w; }
int gfx_fb_h(void) { return FB_h; }
void gfx_offset(float ox, float oy) { OX = ox; OY = oy; }
void gfx_snap(int on) { SNAP = on; }
void gfx_clip(float x, float y, float w, float h) {
    int x0 = (int)floorf((x + OX) * RS + 0.5f), y0 = (int)floorf((y + OY) * RS + 0.5f);
    int x1 = (int)floorf((x + w + OX) * RS + 0.5f), y1 = (int)floorf((y + h + OY) * RS + 0.5f);
    C_x0 = x0 < 0 ? 0 : x0; C_y0 = y0 < 0 ? 0 : y0; C_x1 = x1 > T_w ? T_w : x1; C_y1 = y1 > T_h ? T_h : y1;
}
void gfx_clip_reset(void) { C_x0 = 0; C_y0 = 0; C_x1 = T_w; C_y1 = T_h; }

void gfx_clear(u32 rgba) {
    u32 c = premul(rgba | 255); int n = T_w * T_h; u32 *d = T_px;
    for (int i = 0; i < n; i++) d[i] = c;
}
void gfx_copy_from(const Image *src) {
    if (!src || src->w != T_w || src->h != T_h) return;
    int ox = (int)floorf(OX * RS + 0.5f), oy = (int)floorf(OY * RS + 0.5f);
    if (ox == 0 && oy == 0) { memcpy(T_px, src->px, (size_t)T_w * T_h * 4); return; }
    if (ox > T_w / 2) ox = T_w / 2; if (ox < -T_w / 2) ox = -T_w / 2;
    for (int y = 0; y < T_h; y++) {
        int sy = y - oy; if (sy < 0) sy = 0; if (sy >= T_h) sy = T_h - 1;
        const u32 *s = src->px + sy * T_w; u32 *d = T_px + y * T_w;
        if (ox >= 0) { memcpy(d + ox, s, (size_t)(T_w - ox) * 4); for (int x = 0; x < ox; x++) d[x] = s[0]; }
        else { memcpy(d, s - ox, (size_t)(T_w + ox) * 4); for (int x = T_w + ox; x < T_w; x++) d[x] = s[T_w - 1]; }
    }
}
void gfx_grab(Image *dst) { if (dst && dst->px && dst->w == T_w && dst->h == T_h) memcpy(dst->px, T_px, (size_t)T_w * T_h * 4); }
void gfx_cover(const Image *im, float darken) {
    if (!im) return;
    float k = maxf((float)T_w / im->w, (float)T_h / im->h);     /* dst px per src px */
    float inv = 1.0f / k;
    float offx = (im->w - T_w * inv) * 0.5f, offy = (im->h - T_h * inv) * 0.5f;
    u32 dk = (u32)(clampf(darken, 0, 1) * 256.0f);
    for (int y = 0; y < T_h; y++) {
        float v = (y + 0.5f) * inv + offy - 0.5f; v = clampf(v, 0, im->h - 1.001f);
        int iv = (int)v; u32 wy = (u32)((v - iv) * 256.0f);
        const u32 *r0 = im->px + iv * im->w, *r1 = r0 + im->w; u32 *d = T_px + y * T_w;
        for (int x = 0; x < T_w; x++) {
            float u = (x + 0.5f) * inv + offx - 0.5f; u = clampf(u, 0, im->w - 1.001f);
            int iu = (int)u; u32 wx = (u32)((u - iu) * 256.0f);
            u32 c = px_lerp(px_lerp(r0[iu], r0[iu + 1], wx), px_lerp(r1[iu], r1[iu + 1], wx), wy);
            if (dk < 256) c = px_scale(c, dk);
            d[x] = c | PIX(0, 0, 0, 255);
        }
    }
}
void gfx_fade(u32 rgba) {
    u32 s = premul(rgba); if (!(s >> 24)) return;
    u32 ia = 256 - ((s >> 24) + (s >> 31));
    for (int y = C_y0; y < C_y1; y++) {
        u32 *d = T_px + y * T_w + C_x0; int n = C_x1 - C_x0;
        for (int i = 0; i < n; i++) {
            u32 v = d[i];
            u32 rb = (((v & 0x00FF00FFu) * ia) >> 8) & 0x00FF00FFu;
            u32 ag = (((v >> 8) & 0x00FF00FFu) * ia) & 0xFF00FF00u;
            d[i] = s + (rb | ag);
        }
    }
}

/* ============================== blitters ============================== */
static void blit_copy(const Image *im, int sx, int sy, int sw, int sh, int dx, int dy, u32 mul, int additive) {
    int x0 = dx < C_x0 ? C_x0 : dx, y0 = dy < C_y0 ? C_y0 : dy;
    int x1 = dx + sw > C_x1 ? C_x1 : dx + sw, y1 = dy + sh > C_y1 ? C_y1 : dy + sh;
    if (x0 >= x1 || y0 >= y1) return;
    int n = x1 - x0;
    for (int y = y0; y < y1; y++) {
        const u32 *s = im->px + (sy + y - dy) * im->w + sx + (x0 - dx); u32 *d = T_px + y * T_w + x0;
        if (mul == 0xFFFFFFFFu && !additive) {
            for (int i = 0; i < n; i++) { u32 c = s[i]; if (!c) continue; if ((c >> 24) == 255) d[i] = c; else d[i] = px_over(d[i], c); }
        } else if (!additive) {
            for (int i = 0; i < n; i++) { u32 c = s[i]; if (!c) continue; d[i] = px_over(d[i], px_mul(c, mul)); }
        } else {
            for (int i = 0; i < n; i++) { u32 c = s[i]; if (!c) continue; if (mul != 0xFFFFFFFFu) c = px_mul(c, mul); d[i] = px_add(d[i], c) | PIX(0, 0, 0, 255); }
        }
    }
}
static inline void span_clip(float v0, float dv, float lo, float hi, float *xs, float *xe) {
    if (dv > 1e-9f) { float a = (lo - v0) / dv, b = (hi - v0) / dv; if (a > *xs) *xs = a; if (b < *xe) *xe = b; }
    else if (dv < -1e-9f) { float a = (hi - v0) / dv, b = (lo - v0) / dv; if (a > *xs) *xs = a; if (b < *xe) *xe = b; }
    else if (v0 < lo || v0 > hi) { *xe = *xs - 1; }
}
/* generic affine bilinear blit of sub-rect (sx0,sy0,sw,sh) of im. cx,cy: dest pixel pos of anchor (ax,ay rel. to sub-rect).
   scx,scy: dest pixels per source pixel, rot radians, mul: premultiplied bytewise tint */
static void blit_xf(const Image *im, float sx0, float sy0, float sw, float sh, float cx, float cy, float ax, float ay,
                    float scx, float scy, float rot, u32 mul, int additive) {
    float mn = fabsf(scx) < fabsf(scy) ? fabsf(scx) : fabsf(scy);
    while (mn < 0.6f && im->mip) {
        im = im->mip; mn *= 2; scx *= 2; scy *= 2; sx0 *= 0.5f; sy0 *= 0.5f; sw *= 0.5f; sh *= 0.5f; ax *= 0.5f; ay *= 0.5f;
    }
    if (fabsf(scx) < 1e-4f || fabsf(scy) < 1e-4f || !(mul >> 24)) return;
    int isx0 = (int)sx0, isy0 = (int)sy0, isw = (int)(sw + 0.5f), ish = (int)(sh + 0.5f);
    if (isx0 < 0) isx0 = 0; if (isy0 < 0) isy0 = 0;
    if (isx0 + isw > im->w) isw = im->w - isx0; if (isy0 + ish > im->h) ish = im->h - isy0;
    if (isw < 2 || ish < 2) return;
    if (rot == 0.0f && fabsf(scx - 1) < 0.002f && fabsf(scy - 1) < 0.002f) {
        float fx = cx - ax, fy = cy - ay, rx = floorf(fx + 0.5f), ry = floorf(fy + 0.5f);
        if (SNAP || (fabsf(fx - rx) < 0.03f && fabsf(fy - ry) < 0.03f)) { blit_copy(im, isx0, isy0, isw, ish, (int)rx, (int)ry, mul, additive); return; }
    }
    float cs = cosf(rot), sn = sinf(rot);
    float A = cs / scx, B = sn / scx, D = -sn / scy, E = cs / scy;
    float minx = 1e9f, miny = 1e9f, maxx = -1e9f, maxy = -1e9f;
    for (int i = 0; i < 4; i++) {
        float lx = ((i & 1) ? (float)isw : 0.0f) - ax, ly = ((i & 2) ? (float)ish : 0.0f) - ay; lx *= scx; ly *= scy;
        float dx = cx + lx * cs - ly * sn, dy = cy + lx * sn + ly * cs;
        if (dx < minx) minx = dx; if (dx > maxx) maxx = dx; if (dy < miny) miny = dy; if (dy > maxy) maxy = dy;
    }
    int bx0 = (int)floorf(minx), bx1 = (int)ceilf(maxx), by0 = (int)floorf(miny), by1 = (int)ceilf(maxy);
    if (bx0 < C_x0) bx0 = C_x0; if (by0 < C_y0) by0 = C_y0; if (bx1 > C_x1) bx1 = C_x1; if (by1 > C_y1) by1 = C_y1;
    if (bx0 >= bx1 || by0 >= by1) return;
    float uhi = (float)isw - 1.001f, vhi = (float)ish - 1.001f;
    i32 umax = (isw - 1) << 16, vmax = (ish - 1) << 16;
    i32 du = (i32)(A * 65536.0f), dv = (i32)(D * 65536.0f);
    const u32 *sbase = im->px + isy0 * im->w + isx0; int stride = im->w;
    int plain = (mul == 0xFFFFFFFFu) && !additive;
    for (int y = by0; y < by1; y++) {
        float py = (float)y + 0.5f - cy;
        float u0 = A * (0.5f - cx) + B * py + ax - 0.5f, v0 = D * (0.5f - cx) + E * py + ay - 0.5f;
        float xs = (float)bx0, xe = (float)(bx1 - 1);
        span_clip(u0, A, 0.0f, uhi, &xs, &xe); span_clip(v0, D, 0.0f, vhi, &xs, &xe);
        int ix0 = (int)ceilf(xs), ix1 = (int)floorf(xe);
        if (ix0 > ix1) continue;
        i32 fu = (i32)((u0 + A * (float)ix0) * 65536.0f), fv = (i32)((v0 + D * (float)ix0) * 65536.0f);
        int n = ix1 - ix0 + 1;
        while (n > 0 && (fu < 0 || fu >= umax || fv < 0 || fv >= vmax)) { fu += du; fv += dv; ix0++; n--; }
        while (n > 0) { i32 eu = fu + du * (n - 1), ev = fv + dv * (n - 1); if (eu < 0 || eu >= umax || ev < 0 || ev >= vmax) n--; else break; }
        u32 *d = T_px + y * T_w + ix0;
        if (plain) {
            for (; n > 0; n--, d++, fu += du, fv += dv) {
                const u32 *p = sbase + (fv >> 16) * stride + (fu >> 16);
                u32 c00 = p[0], c10 = p[1], c01 = p[stride], c11 = p[stride + 1];
                if (!(c00 | c10 | c01 | c11)) continue;
                u32 wx = ((u32)fu >> 8) & 255, wy = ((u32)fv >> 8) & 255;
                u32 s = px_lerp(px_lerp(c00, c10, wx), px_lerp(c01, c11, wx), wy);
                *d = px_over(*d, s);
            }
        } else if (!additive) {
            for (; n > 0; n--, d++, fu += du, fv += dv) {
                const u32 *p = sbase + (fv >> 16) * stride + (fu >> 16);
                u32 c00 = p[0], c10 = p[1], c01 = p[stride], c11 = p[stride + 1];
                if (!(c00 | c10 | c01 | c11)) continue;
                u32 wx = ((u32)fu >> 8) & 255, wy = ((u32)fv >> 8) & 255;
                u32 s = px_lerp(px_lerp(c00, c10, wx), px_lerp(c01, c11, wx), wy);
                *d = px_over(*d, px_mul(s, mul));
            }
        } else {
            for (; n > 0; n--, d++, fu += du, fv += dv) {
                const u32 *p = sbase + (fv >> 16) * stride + (fu >> 16);
                u32 c00 = p[0], c10 = p[1], c01 = p[stride], c11 = p[stride + 1];
                if (!(c00 | c10 | c01 | c11)) continue;
                u32 wx = ((u32)fu >> 8) & 255, wy = ((u32)fv >> 8) & 255;
                u32 s = px_lerp(px_lerp(c00, c10, wx), px_lerp(c01, c11, wx), wy);
                if (mul != 0xFFFFFFFFu) s = px_mul(s, mul);
                *d = px_add(*d, s) | PIX(0, 0, 0, 255);
            }
        }
    }
}

void gfx_image_tint(const Image *im, float x, float y, float sx, float sy, float rot, u32 rgba, int additive) {
    if (!im || !im->px) return;
    float k = RS / im->scale;
    blit_xf(im, 0, 0, (float)im->w, (float)im->h, (x + OX) * RS, (y + OY) * RS, im->ax, im->ay, sx * k, sy * k, rot,
            rgba == WHITE ? 0xFFFFFFFFu : premul(rgba), additive);
}
void gfx_image_ex(const Image *im, float x, float y, float sx, float sy, float rot, float alpha) {
    if (alpha <= 0.003f) return;
    u32 a = alpha >= 0.997f ? 255u : (u32)(alpha * 255.0f + 0.5f);
    gfx_image_tint(im, x, y, sx, sy, rot, 0xFFFFFF00u | a, 0);
}
void gfx_image(const Image *im, float x, float y) { gfx_image_tint(im, x, y, 1, 1, 0, WHITE, 0); }
void gfx_image_sub(const Image *im, float srcx, float srcy, float srcw, float srch, float x, float y, float sx, float sy, u32 rgba) {
    if (!im || !im->px) return;
    float k = RS / im->scale;
    blit_xf(im, srcx, srcy, srcw, srch, (x + OX) * RS, (y + OY) * RS, 0, 0, sx * k, sy * k, 0, rgba == WHITE ? 0xFFFFFFFFu : premul(rgba), 0);
}

/* ============================== primitives ============================== */
static inline void px_cov(u32 *d, u32 pm, float cov) {
    if (cov <= 0.004f) return;
    if (cov >= 0.996f) { *d = px_over(*d, pm); return; }
    *d = px_over(*d, px_scale(pm, (u32)(cov * 256.0f)));
}
static inline void fill_span(int y, int x0, int x1, u32 pm) { /* [x0,x1) */
    if (y < C_y0 || y >= C_y1) return;
    if (x0 < C_x0) x0 = C_x0; if (x1 > C_x1) x1 = C_x1;
    u32 *d = T_px + y * T_w;
    if ((pm >> 24) == 255) { for (int x = x0; x < x1; x++) d[x] = pm; }
    else { for (int x = x0; x < x1; x++) d[x] = px_over(d[x], pm); }
}
void gfx_rect(float x, float y, float w, float h, u32 rgba) {
    u32 pm = premul(rgba); if (!(pm >> 24)) return;
    int x0 = (int)floorf((x + OX) * RS + 0.5f), y0 = (int)floorf((y + OY) * RS + 0.5f);
    int x1 = (int)floorf((x + w + OX) * RS + 0.5f), y1 = (int)floorf((y + h + OY) * RS + 0.5f);
    for (int yy = y0; yy < y1; yy++) fill_span(yy, x0, x1, pm);
}
static void rrect_impl(float x, float y, float w, float h, float r, u32 top, u32 bot) {
    float X0 = (x + OX) * RS, Y0 = (y + OY) * RS, W = w * RS, H = h * RS, R = r * RS;
    if (W <= 0 || H <= 0) return;
    if (R > W * 0.5f) R = W * 0.5f; if (R > H * 0.5f) R = H * 0.5f;
    float cx = X0 + W * 0.5f, cy = Y0 + H * 0.5f, hw = W * 0.5f, hh = H * 0.5f;
    int ix0 = (int)floorf(X0 - 1), ix1 = (int)ceilf(X0 + W + 1), iy0 = (int)floorf(Y0 - 1), iy1 = (int)ceilf(Y0 + H + 1);
    if (ix0 < C_x0) ix0 = C_x0; if (iy0 < C_y0) iy0 = C_y0; if (ix1 > C_x1) ix1 = C_x1; if (iy1 > C_y1) iy1 = C_y1;
    int same = (top == bot); u32 pm = premul(top);
    for (int yy = iy0; yy < iy1; yy++) {
        float py = (float)yy + 0.5f, qy = fabsf(py - cy) - (hh - R);
        if (!same) pm = premul(color_lerp(top, bot, (py - Y0) / H));
        if (!(pm >> 24)) continue;
        u32 *d = T_px + yy * T_w;
        /* full-coverage interior span for this row */
        float inner;
        if (qy <= 0) inner = hw - 0.75f;
        else { float t = R - 0.5f; float q = t * t - qy * qy; inner = (t > 0 && q > 0) ? (hw - R) + sqrtf(q) - 0.5f : -1.0f; if (qy > R + 0.5f) continue; }
        int fx0 = (int)ceilf(cx - inner), fx1 = (int)floorf(cx + inner);
        if (inner < 0) { fx0 = 1 << 30; fx1 = -(1 << 30); }
        else if (fx0 < ix0) fx0 = ix0;
        for (int xx = ix0; xx < ix1; xx++) {
            if (xx == fx0 && fx1 > fx0) {
                int e = fx1 < ix1 ? fx1 : ix1;
                if ((pm >> 24) == 255) for (; xx < e; xx++) d[xx] = pm; else for (; xx < e; xx++) d[xx] = px_over(d[xx], pm);
                xx--; continue;
            }
            float px = (float)xx + 0.5f, qx = fabsf(px - cx) - (hw - R), dist;
            if (qx > 0 && qy > 0) dist = sqrtf(qx * qx + qy * qy) - R; else dist = (qx > qy ? qx : qy) - R;
            px_cov(&d[xx], pm, 0.5f - dist);
        }
    }
}
void gfx_rrect(float x, float y, float w, float h, float r, u32 rgba) { rrect_impl(x, y, w, h, r, rgba, rgba); }
void gfx_rrect_grad(float x, float y, float w, float h, float r, u32 top, u32 bot) { rrect_impl(x, y, w, h, r, top, bot); }

void gfx_circle(float cx, float cy, float r, u32 rgba) {
    u32 pm = premul(rgba); if (!(pm >> 24) || r <= 0) return;
    float X = (cx + OX) * RS, Y = (cy + OY) * RS, R = r * RS;
    int ix0 = (int)floorf(X - R - 1), ix1 = (int)ceilf(X + R + 1), iy0 = (int)floorf(Y - R - 1), iy1 = (int)ceilf(Y + R + 1);
    if (ix0 < C_x0) ix0 = C_x0; if (iy0 < C_y0) iy0 = C_y0; if (ix1 > C_x1) ix1 = C_x1; if (iy1 > C_y1) iy1 = C_y1;
    float rin = R - 0.5f, rout = R + 0.5f, rin2 = rin > 0 ? rin * rin : 0, rout2 = rout * rout;
    for (int yy = iy0; yy < iy1; yy++) {
        float dy = (float)yy + 0.5f - Y; u32 *d = T_px + yy * T_w;
        for (int xx = ix0; xx < ix1; xx++) {
            float dx = (float)xx + 0.5f - X, d2 = dx * dx + dy * dy;
            if (d2 >= rout2) continue;
            if (d2 <= rin2) d[xx] = px_over(d[xx], pm); else px_cov(&d[xx], pm, rout - sqrtf(d2));
        }
    }
}
void gfx_ring(float cx, float cy, float r, float thick, u32 rgba) {
    u32 pm = premul(rgba); if (!(pm >> 24) || r <= 0) return;
    float X = (cx + OX) * RS, Y = (cy + OY) * RS, R = r * RS, HT = thick * RS * 0.5f;
    float ro = R + HT + 1;
    int ix0 = (int)floorf(X - ro), ix1 = (int)ceilf(X + ro), iy0 = (int)floorf(Y - ro), iy1 = (int)ceilf(Y + ro);
    if (ix0 < C_x0) ix0 = C_x0; if (iy0 < C_y0) iy0 = C_y0; if (ix1 > C_x1) ix1 = C_x1; if (iy1 > C_y1) iy1 = C_y1;
    float ro2 = ro * ro, ri = R - HT - 1, ri2 = ri > 0 ? ri * ri : 0;
    for (int yy = iy0; yy < iy1; yy++) {
        float dy = (float)yy + 0.5f - Y; u32 *d = T_px + yy * T_w;
        for (int xx = ix0; xx < ix1; xx++) {
            float dx = (float)xx + 0.5f - X, d2 = dx * dx + dy * dy;
            if (d2 >= ro2 || d2 <= ri2) continue;
            px_cov(&d[xx], pm, 0.5f - (fabsf(sqrtf(d2) - R) - HT));
        }
    }
}
void gfx_capsule2(float x0, float y0, float x1, float y1, float r0, float r1, u32 rgba) {
    u32 pm = premul(rgba); if (!(pm >> 24)) return;
    float ax = (x0 + OX) * RS, ay = (y0 + OY) * RS, bx = (x1 + OX) * RS, by = (y1 + OY) * RS, R0 = r0 * RS, R1 = r1 * RS;
    float rm = R0 > R1 ? R0 : R1;
    int ix0 = (int)floorf(minf(ax, bx) - rm - 1), ix1 = (int)ceilf(maxf(ax, bx) + rm + 1);
    int iy0 = (int)floorf(minf(ay, by) - rm - 1), iy1 = (int)ceilf(maxf(ay, by) + rm + 1);
    if (ix0 < C_x0) ix0 = C_x0; if (iy0 < C_y0) iy0 = C_y0; if (ix1 > C_x1) ix1 = C_x1; if (iy1 > C_y1) iy1 = C_y1;
    float bax = bx - ax, bay = by - ay, bb = bax * bax + bay * bay, ibb = bb > 1e-6f ? 1.0f / bb : 0.0f;
    for (int yy = iy0; yy < iy1; yy++) {
        float py = (float)yy + 0.5f - ay; u32 *d = T_px + yy * T_w;
        for (int xx = ix0; xx < ix1; xx++) {
            float px = (float)xx + 0.5f - ax;
            float h = (px * bax + py * bay) * ibb; h = h < 0 ? 0 : (h > 1 ? 1 : h);
            float ex = px - bax * h, ey = py - bay * h, d2 = ex * ex + ey * ey, rr = R0 + (R1 - R0) * h, ro = rr + 0.5f;
            if (d2 >= ro * ro) continue;
            float ri = rr - 0.5f;
            if (ri > 0 && d2 <= ri * ri) d[xx] = px_over(d[xx], pm); else px_cov(&d[xx], pm, ro - sqrtf(d2));
        }
    }
}
void gfx_capsule(float x0, float y0, float x1, float y1, float r, u32 rgba) { gfx_capsule2(x0, y0, x1, y1, r, r, rgba); }
void gfx_tri(float x0, float y0, float x1, float y1, float x2, float y2, u32 rgba) {
    u32 pm = premul(rgba); if (!(pm >> 24)) return;
    float X[3] = { (x0 + OX) * RS, (x1 + OX) * RS, (x2 + OX) * RS }, Y[3] = { (y0 + OY) * RS, (y1 + OY) * RS, (y2 + OY) * RS };
    float area = (X[1] - X[0]) * (Y[2] - Y[0]) - (X[2] - X[0]) * (Y[1] - Y[0]);
    if (fabsf(area) < 1e-3f) return;
    float sg = area > 0 ? 1.0f : -1.0f, ex[3], ey[3], ec[3];
    for (int i = 0; i < 3; i++) {
        int j = (i + 1) % 3; float dx = X[j] - X[i], dy = Y[j] - Y[i], l = sqrtf(dx * dx + dy * dy); if (l < 1e-6f) return;
        ex[i] = -dy / l * sg; ey[i] = dx / l * sg; ec[i] = -(ex[i] * X[i] + ey[i] * Y[i]);
    }
    int ix0 = (int)floorf(minf(X[0], minf(X[1], X[2])) - 1), ix1 = (int)ceilf(maxf(X[0], maxf(X[1], X[2])) + 1);
    int iy0 = (int)floorf(minf(Y[0], minf(Y[1], Y[2])) - 1), iy1 = (int)ceilf(maxf(Y[0], maxf(Y[1], Y[2])) + 1);
    if (ix0 < C_x0) ix0 = C_x0; if (iy0 < C_y0) iy0 = C_y0; if (ix1 > C_x1) ix1 = C_x1; if (iy1 > C_y1) iy1 = C_y1;
    for (int yy = iy0; yy < iy1; yy++) {
        float py = (float)yy + 0.5f; u32 *d = T_px + yy * T_w;
        for (int xx = ix0; xx < ix1; xx++) {
            float px = (float)xx + 0.5f;
            float e0 = ex[0] * px + ey[0] * py + ec[0], e1 = ex[1] * px + ey[1] * py + ec[1], e2 = ex[2] * px + ey[2] * py + ec[2];
            float m = e0 < e1 ? e0 : e1; if (e2 < m) m = e2;
            if (m <= -0.5f) continue;
            px_cov(&d[xx], pm, m + 0.5f);
        }
    }
}

/* ============================== text ============================== */
static u32 utf8_next(const char **ps) {
    const u8 *s = (const u8 *)*ps; u32 c = *s;
    if (!c) return 0;
    if (c < 0x80) { *ps += 1; return c; }
    if ((c & 0xE0) == 0xC0 && s[1]) { *ps += 2; return ((c & 0x1F) << 6) | (s[1] & 0x3F); }
    if ((c & 0xF0) == 0xE0 && s[1] && s[2]) { *ps += 3; return ((c & 0x0F) << 12) | ((s[1] & 0x3F) << 6) | (s[2] & 0x3F); }
    if ((c & 0xF8) == 0xF0 && s[1] && s[2] && s[3]) { *ps += 4; return ((c & 0x07) << 18) | ((s[1] & 0x3F) << 12) | ((s[2] & 0x3F) << 6) | (s[3] & 0x3F); }
    *ps += 1; return '?';
}
static const Glyph *glyph_find(const Font *f, u32 cp) {
    int lo = 0, hi = f->n - 1;
    while (lo <= hi) { int mid = (lo + hi) >> 1; u32 c = f->g[mid].cp; if (c == cp) return &f->g[mid]; if (c < cp) lo = mid + 1; else hi = mid - 1; }
    return NULL;
}
static float text_w_n(const Font *f, const char *s, const char *end, float size) {
    float k = size / f->em, w = 0;
    while (*s && (!end || s < end)) { u32 cp = utf8_next(&s); const Glyph *g = glyph_find(f, cp); if (!g) g = glyph_find(f, '?'); if (g) w += g->adv * (1.0f / 16.0f) * k; }
    return w;
}
float gfx_text_w(const Font *f, const char *s, float size) { return text_w_n(f, s, NULL, size); }
static void text_draw_n(const Font *f, const char *s, const char *end, float x, float y, float size, u32 rgba, int align) {
    if (!f->atlas) return;
    float k = size / f->em;
    if (align == AL_CENTER) x -= text_w_n(f, s, end, size) * 0.5f; else if (align == AL_RIGHT) x -= text_w_n(f, s, end, size);
    float pk = k * RS;                          /* dest pixels per atlas pixel */
    float X = (x + OX) * RS, Yb = (y + OY) * RS + f->base * 0.5f * pk;   /* y is the centre of caps */
    u32 mul = rgba == WHITE ? 0xFFFFFFFFu : premul(rgba);
    while (*s && (!end || s < end)) {
        u32 cp = utf8_next(&s); const Glyph *g = glyph_find(f, cp); if (!g) g = glyph_find(f, '?'); if (!g) continue;
        if (g->w > 0 && g->h > 0)
            blit_xf(f->atlas, (float)g->x, (float)g->y, (float)g->w, (float)g->h, X + g->xoff * pk, Yb + g->yoff * pk, 0, 0, pk, pk, 0, mul, 0);
        X += g->adv * (1.0f / 16.0f) * pk;
    }
}
void gfx_text(const Font *f, const char *s, float x, float y, float size, u32 rgba, int align) { text_draw_n(f, s, NULL, x, y, size, rgba, align); }
int gfx_text_wrap(const Font *f, const char *s, float x, float y, float size, float maxw, float lineh, u32 rgba, int align, int draw) {
    int lines = 0; const char *line = s;
    while (*line) {
        const char *p = line, *last_break = NULL, *end = NULL;
        while (1) {
            const char *q = p; u32 cp = utf8_next(&q);
            if (cp == 0) { end = p; break; }
            if (cp == '\n') { end = p; break; }
            if (cp == ' ') { if (text_w_n(f, line, p, size) > maxw && last_break) { end = last_break; break; } last_break = p; }
            p = q;
        }
        if (text_w_n(f, line, end, size) > maxw && last_break && last_break < end) end = last_break;
        if (draw) text_draw_n(f, line, end, x, y + lines * lineh, size, rgba, align);
        lines++;
        line = end; while (*line == ' ' || *line == '\n') { if (*line == '\n') { line++; break; } line++; }
    }
    return lines;
}

/* ============================== audio ============================== */
#define MAX_VOICES 24
typedef struct { const Sound *s; double pos, step; float vl, vr, gain, gain_to; int loop, id, kind; } Voice;
static Voice g_v[MAX_VOICES]; static int g_next_id = 1; static int g_out_rate = 44100;
static float g_vol_sfx = 1.0f, g_vol_music = 0.6f, g_vol_voice = 1.0f, g_duck = 1.0f;
static const Sound *g_music; static int g_music_voice = -1;
#define MAX_SOUNDS 96
static const Sound *g_snd[MAX_SOUNDS]; static int g_nsnd, g_ext;      /* every sound made, in order; g_ext: the platform plays them (plat_snd) */

Sound *snd_new(int n, int rate) {
    Sound *s = (Sound *)calloc(1, sizeof(Sound)); s->n = n; s->rate = rate; s->pcm = (i16 *)calloc((size_t)n + 4, 2);
    if (g_nsnd < MAX_SOUNDS) g_snd[g_nsnd++] = s;
    return s;
}
void audio_external(int on) { g_ext = on; }
int snd_count(void) { return g_nsnd; }
const Sound *snd_by_index(int i) { return i >= 0 && i < g_nsnd ? g_snd[i] : NULL; }
static int snd_index(const Sound *s) { for (int i = 0; i < g_nsnd; i++) if (g_snd[i] == s) return i; return -1; }
static const signed char ima_idx[16] = { -1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8 };
static const i16 ima_step[89] = { 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230,
    253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871,
    5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767 };
Sound *snd_load(const char *name) {
    const PackEntry *e = pack_find(name); if (!e) return NULL;
    const u8 *d = pack_data(e);
    if (e->type == PK_ADPCM) {
        int n = e->b; Sound *s = snd_new(n, e->a);
        int pred = 0, idx = 0;
        for (int i = 0; i < n; i++) {
            int nib = (d[i >> 1] >> ((i & 1) * 4)) & 15, step = ima_step[idx], diff = step >> 3;
            if (nib & 1) diff += step >> 2; if (nib & 2) diff += step >> 1; if (nib & 4) diff += step;
            if (nib & 8) pred -= diff; else pred += diff;
            if (pred > 32767) pred = 32767; if (pred < -32768) pred = -32768;
            idx += ima_idx[nib]; if (idx < 0) idx = 0; if (idx > 88) idx = 88;
            s->pcm[i] = (i16)pred;
        }
        return s;
    }
    if (e->type == PK_RAW) { int n = e->b; Sound *s = snd_new(n, e->a); memcpy(s->pcm, d, (size_t)n * 2); return s; }
    return NULL;
}
void audio_init(int out_rate) { g_out_rate = out_rate > 8000 ? out_rate : 44100; memset(g_v, 0, sizeof(g_v)); }
static int voice_alloc(void) {
    for (int i = 0; i < MAX_VOICES; i++) if (!g_v[i].s) return i;
    int best = -1; double bp = -1;
    for (int i = 0; i < MAX_VOICES; i++) if (!g_v[i].loop && g_v[i].kind == 0 && g_v[i].pos > bp) { bp = g_v[i].pos; best = i; }
    return best;
}
static int play_kind(const Sound *s, float vol, float pan, float pitch, int loop, int kind) {
    if (!s || s->n <= 0) return 0;
    plat_audio_lock();
    int i = voice_alloc(), id = 0;
    if (i >= 0) {
        Voice *v = &g_v[i]; v->s = s; v->pos = 0; v->step = (double)pitch * s->rate / g_out_rate;
        pan = clampf(pan, -1, 1); v->vl = vol * (pan > 0 ? 1 - pan : 1); v->vr = vol * (pan < 0 ? 1 + pan : 1);
        v->gain = 1; v->gain_to = 1; v->loop = loop; v->kind = kind; id = v->id = g_next_id++;
        if (loop) { v->gain = 0; }
    }
    plat_audio_unlock();
    return id;
}
static int play_ext(int op, const Sound *s, float vol, float pan, float pitch) {
    int i = snd_index(s); if (i < 0 || s->n <= 1) return 0;
    int id = g_next_id++; plat_snd(op, i, id, vol, pan, pitch); return id;
}
int snd_play(const Sound *s, float vol, float pan, float pitch) { if (g_ext) return play_ext(SND_SFX, s, vol, clampf(pan, -1, 1), pitch); return play_kind(s, vol, pan, pitch, 0, 0); }
int snd_play_voice(const Sound *s, float vol) {
    if (g_ext) return play_ext(SND_VOICE, s, vol, 0, 1);
    plat_audio_lock();
    for (int i = 0; i < MAX_VOICES; i++) if (g_v[i].s && g_v[i].kind == 1) g_v[i].gain_to = 0;   /* one speech line at a time */
    plat_audio_unlock();
    return play_kind(s, vol, 0, 1, 0, 1);
}
void snd_stop(int id) {
    if (!id) return;
    if (g_ext) { plat_snd(SND_STOP, -1, id, 0, 0, 0); return; }
    plat_audio_lock();
    for (int i = 0; i < MAX_VOICES; i++) if (g_v[i].s && g_v[i].id == id) g_v[i].gain_to = 0;
    plat_audio_unlock();
}
void snd_music(const Sound *s) {
    if (s == g_music) return;
    if (g_ext) { g_music = s; g_music_voice = g_next_id++; plat_snd(SND_MUSIC, s ? snd_index(s) : -1, g_music_voice, 1.0f, 0, 1); return; }
    plat_audio_lock();
    for (int i = 0; i < MAX_VOICES; i++) if (g_v[i].s && g_v[i].kind == 2) g_v[i].gain_to = 0;
    plat_audio_unlock();
    g_music = s;
    if (s) g_music_voice = play_kind(s, 1.0f, 0, 1, 1, 2);
}
void snd_changed(const Sound *s) { if (g_ext) { int i = snd_index(s); if (i >= 0) plat_snd(SND_RELOAD, i, 0, 0, 0, 0); } }
void snd_volumes(float sfx, float music, float voice) {
    g_vol_sfx = sfx; g_vol_music = music; g_vol_voice = voice;
    if (g_ext) plat_snd(SND_VOLUMES, -1, 0, sfx, music, voice);
}

void audio_mix(i16 *out, int frames) {
    static float mix[1024 * 2];
    while (frames > 0) {
        int n = frames > 1024 ? 1024 : frames;
        memset(mix, 0, sizeof(float) * (size_t)n * 2);
        int speech = 0;
        for (int i = 0; i < MAX_VOICES; i++) if (g_v[i].s && g_v[i].kind == 1 && g_v[i].gain_to > 0) speech = 1;
        float duck_to = speech ? 0.35f : 1.0f;
        for (int i = 0; i < MAX_VOICES; i++) {
            Voice *v = &g_v[i]; const Sound *s = v->s; if (!s) continue;
            float base = v->kind == 2 ? g_vol_music : (v->kind == 1 ? g_vol_voice : g_vol_sfx);
            const i16 *pcm = s->pcm; int sn = s->n; double pos = v->pos, step = v->step; float gain = v->gain, gto = v->gain_to;
            float gstep = 1.0f / (0.012f * g_out_rate);            /* 12 ms ramps */
            if (v->kind == 2) gstep = 1.0f / (0.4f * g_out_rate);  /* music fades */
            float duck = g_duck;
            for (int k = 0; k < n; k++) {
                if (pos >= sn - 1) { if (v->loop) { pos -= (sn - 1); if (pos >= sn - 1) pos = 0; } else { v->s = NULL; break; } }
                int ip = (int)pos; float fr = (float)(pos - ip);
                float smp = ((float)pcm[ip] + ((float)pcm[ip + 1] - (float)pcm[ip]) * fr) * (1.0f / 32768.0f);
                if (gain < gto) { gain += gstep; if (gain > gto) gain = gto; } else if (gain > gto) { gain -= gstep; if (gain < gto) gain = gto; }
                float g = gain * base;
                if (v->kind == 2) { duck += (duck_to - duck) * 0.0004f; g *= duck; }
                mix[k * 2] += smp * v->vl * g; mix[k * 2 + 1] += smp * v->vr * g;
                pos += step;
            }
            if (v->kind == 2) g_duck = duck;
            v->pos = pos; v->gain = gain;
            if (v->s && gain <= 0 && gto <= 0) v->s = NULL;
        }
        for (int k = 0; k < n * 2; k++) {
            float x = mix[k] * 0.9f;
            if (x > 0.8f) x = 0.8f + (x - 0.8f) / (1.0f + (x - 0.8f) * 5.0f) ; else if (x < -0.8f) x = -0.8f + (x + 0.8f) / (1.0f - (x + 0.8f) * 5.0f);
            if (x > 1) x = 1; if (x < -1) x = -1;
            out[k] = (i16)(x * 32767.0f);
        }
        out += n * 2; frames -= n;
    }
}
