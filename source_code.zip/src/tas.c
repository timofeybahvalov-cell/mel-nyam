/* TAS search (see tas.h). Works on the bare simulation; no rendering, no platform calls. */
#include "tas.h"
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <stdio.h>
#include <math.h>
/* TAS_TOOLS (tools/tas_find.c): progress lines, the self-test and the check of the pruning estimate. The game is built without it. */

#define T_MAXT 4800                 /* 40 s: no run may be longer */
#define NSEED 6
#define NWIN 6
#define BFS_SLACK 6                 /* the wave also keeps runs that are this many ticks slower than the best one: polishing may turn them into faster ones */
#define ILS_SLACK 30
#define STAR_REACH 44.0f            /* a little more than the real radii: the estimate below must never be too high */
#define MOUTH_REACH 47.0f

typedef struct { i32 parent; u32 a; } Node;
typedef struct { int off, len; } Seg;
typedef struct { signed char frac8, res, exact; } Pass;     /* one pass of the wave: it starts at frac8/8 of the best run known so far */
#define REC_HEAD 16                 /* a state of the wave: node, key (2 words), estimate; then the packed simulation */
#define RAIL_FAR 67.0f              /* a rail pin that is further than this from its target moves at full speed, whatever the target is */
enum { PH_SEED, PH_POLISH, PH_BFS, PH_ILS, PH_DONE };

static const short SH[] = { -1, 1, -2, 2, -3, 3, -4, 4, -5, 5, -6, 6, -7, 7, -8, 8, -10, 10, -12, 12, -14, 14, -16, 16, -20, 20, -24, 24, -32, 32, -40, 40, -56, 56, -80, 80, -120, 120 };
#define NSH ((int)(sizeof(SH) / sizeof(SH[0])))
static const short DQ[] = { -1, 1, -2, 2, -3, 3, -4, 4, -6, 6, -8, 8, -12, 12, -16, 16, -24, 24, -32, 32, -48, 48, -64, 64, -96, 96, -128, 128 };
#define NDQ ((int)(sizeof(DQ) / sizeof(DQ[0])))
#define PS 5
static const float RES_CS[TAS_RES_N] = { 40, 28, 20, 14, 10, 7, 5, 3.5f, 2.5f, 1.75f, 1.25f };            /* cell: pixels */
static const float RES_VS[TAS_RES_N] = { 2.4f, 1.7f, 1.2f, 0.85f, 0.6f, 0.42f, 0.3f, 0.21f, 0.15f, 0.105f, 0.075f };   /* cell: pixels per tick */
static const int   RES_NQ[TAS_RES_N] = { 3, 3, 5, 5, 5, 9, 9, 9, 17, 17, 33 };                           /* rail targets tried */

struct Tas {
    TasCfg cfg; const LObj *objs;
    Sim S0, S0v, W, V;                      /* start (bare / with rope nodes), scratch of the wave, scratch of plan_run */
    int maxst, visual, thieves, lcm, nr, nseg, psize, rsize; Seg seg[96];
    Pass plist[80]; int np, pi, skip_frac;
    int nrail, rail[MAX_PINS]; float rail_len[MAX_PINS];
    float dst[17][17], lb_v, lb_a;
    int nins; u32 ins[40];
    TasPlan best, cur, cand, tmp, seed0[NSEED], queue[NSEED + NWIN]; int have, nseed0, qn, qi, q_maxph;
    long long units, tried; int phase, proved, fix, final_done, ils_on, ils_new, stop_bfs;
    int pol_on, p_ph, p_i, p_j, p_k, p_dirty, p_maxph, p_sweep;
    int pres, pfrac, exact, layer, limit, fi, fn, fn0, sweep, gn, lossy, aborted, cn, cmax, nnodes, nmax, nq, qv[33]; long long gseen, pass_end; u32 cmask;
    float cs, vs;
    u8 *fa, *fb; u32 *closed; Node *nodes;
    TasPlan win[NWIN]; int nwin;
    u32 rng;
#ifdef TAS_TOOLS
    long long st_lbruns, st_lbbad; int st_lbover, st_lbslack; short lbs[T_MAXT + 2];
#endif
    long long st_exp, st_pol, st_ils; int st_pass, st_bfswin, st_badwin, st_ilswin, st_lastres, st_lastcells, st_lossy;
};

static u32 rnd(Tas *t) { t->rng = t->rng * 1664525u + 1013904223u; return t->rng >> 8; }
static u32 fbits(float f) { u32 u; memcpy(&u, &f, 4); return u; }
static float fdist(float ax, float ay, float bx, float by) { float dx = bx - ax, dy = by - ay; return sqrtf(dx * dx + dy * dy); }

/* ---------------------------------------------------------------- runs */
static void plan_sort(TasPlan *p) {
    for (int i = 1; i < p->n; i++) { u32 a = p->a[i]; int j = i; while (j > 0 && (p->a[j - 1] >> 15) > (a >> 15)) { p->a[j] = p->a[j - 1]; j--; } p->a[j] = a; }
}
static long long plan_sum(const TasPlan *p) { long long s = 0; for (int i = 0; i < p->n; i++) s += p->a[i] >> 15; return s; }
static int better(const TasPlan *a, const TasPlan *b) {          /* faster; then fewer actions; then earlier actions */
    if (a->ticks != b->ticks) return a->ticks < b->ticks;
    if (a->n != b->n) return a->n < b->n;
    return plan_sum(a) < plan_sum(b);
}
static int lower_bound(const Tas *t, const Sim *s);
/* play a run on the bare simulation; returns the tick of a full-star win (0: no such win before `limit`).
   norm (optional) receives only the actions that really did something */
static int plan_run(Tas *t, const TasPlan *p, int limit, TasPlan *norm) {
#ifdef TAS_TOOLS
    int chk = t->cfg.verbose & 2, worst = 0;
#endif
    Sim *s = &t->V; int i = 0, n = 0;
    memcpy(s, t->visual ? &t->S0v : &t->S0, sizeof(Sim));
    if (limit > T_MAXT) limit = T_MAXT;
    while (s->state == ST_PLAY && s->tick < limit) {
        while (i < p->n && (int)(p->a[i] >> 15) <= s->tick) {
            u32 a = p->a[i++];
            if (sim_act(s, (int)((a >> 12) & 7u), (int)(a & 4095u)) && norm && n < TAS_MAXA) norm->a[n++] = ((u32)s->tick << 15) | (a & 32767u);
        }
#ifdef TAS_TOOLS
        if (chk) { int lb = lower_bound(t, s), v = s->tick + lb; if (v > worst) worst = v; t->lbs[s->tick] = (short)lb; }
#endif
        sim_step(s);
    }
    t->units += (t->visual ? 40 : 1) * (long long)s->tick + 40; t->tried++;
    if (norm) { norm->n = n; norm->ticks = s->tick; }
    int win = (s->state == ST_EATEN && s->stars >= t->maxst) ? s->tick : 0;
#ifdef TAS_TOOLS
    if (chk && win) {                                       /* the estimate of the remaining time must never have been above what this winning run really needed */
        t->st_lbruns++;
        if (worst > win) { t->st_lbbad++; if (worst - win > t->st_lbover) t->st_lbover = worst - win; }
        for (int k = 0; k + 8 <= win; k++) { int pc = t->lbs[k] * 100 / (win - k); if (pc > t->st_lbslack) t->st_lbslack = pc; }     /* how much of the real remaining time the estimate claims, at most */
    }
#endif
    return win;
}
int tas_check(const LObj *objs, const u32 *a, int n) {
    static Sim T; int i = 0, keep = sim_skip_visual, mx = sim_max_stars(objs); sim_skip_visual = 0;
    sim_load(&T, objs);
    while (T.state == ST_PLAY && T.tick < T_MAXT) {
        while (i < n && (int)(a[i] >> 15) <= T.tick) { sim_act(&T, (int)((a[i] >> 12) & 7u), (int)(a[i] & 4095u)); i++; }
        sim_step(&T);
    }
    sim_skip_visual = keep;
    return (T.state == ST_EATEN && T.stars >= mx) ? T.tick : 0;
}

/* ---------------------------------------------------------------- set-up */
static void seg_add(Tas *t, size_t off, size_t len) {
    if (!len) return;
    if (t->nseg && (size_t)(t->seg[t->nseg - 1].off + t->seg[t->nseg - 1].len) == off) t->seg[t->nseg - 1].len += (int)len;
    else { t->seg[t->nseg].off = (int)off; t->seg[t->nseg].len = (int)len; t->nseg++; }
    t->psize += (int)len;
}
static void pack(const Tas *t, const Sim *s, u8 *o) {
    for (int i = 0; i < t->nseg; i++) { const u8 *q = (const u8 *)s + t->seg[i].off; int n = t->seg[i].len; if (n == 4) memcpy(o, q, 4); else if (n == 8) memcpy(o, q, 8); else memcpy(o, q, (size_t)n); o += n; }
}
static void unpack(const Tas *t, const u8 *o, Sim *s) {
    for (int i = 0; i < t->nseg; i++) { u8 *q = (u8 *)s + t->seg[i].off; int n = t->seg[i].len; if (n == 4) memcpy(q, o, 4); else if (n == 8) memcpy(q, o, 8); else memcpy(q, o, (size_t)n); o += n; }
}
static int gcd_i(int a, int b) { while (b) { int c = a % b; a = b; b = c; } return a; }

void tas_cfg_game(TasCfg *c) {
    memset(c, 0, sizeof(*c));
    c->units = 36000000; c->frontier = 4000; c->closed_log2 = 19; c->nodes_log2 = 19; c->res_first = 1; c->res_last = 6; c->exact = 0;
    c->ins_step = 2; c->fmem = 6 << 20; c->suffix = (1 << 6) | (1 << 4) | (1 << 2);
}
Tas *tas_new(const LObj *objs, const TasCfg *cfg) {
    Tas *t = (Tas *)calloc(1, sizeof(Tas)); if (!t) return NULL;
    int keep = sim_skip_visual;
    t->cfg = *cfg; t->objs = objs; t->maxst = sim_max_stars(objs);
    sim_skip_visual = 0; sim_load(&t->S0v, objs);
    sim_skip_visual = 1; sim_load(&t->S0, objs);
    sim_skip_visual = keep;
    const Sim *s = &t->S0;
    t->W = *s; t->nr = s->npins; t->rng = 2463534242u;
    for (int i = 0; i < s->npins; i++) {
        const Pin *p = &s->pin[i]; if (p->thief_v > 0) t->thieves = 1;
        if (p->rail) { t->rail_len[t->nrail] = fdist(p->x0, p->y0, p->x1, p->y1); if (t->rail_len[t->nrail] < 1) t->rail_len[t->nrail] = 1; t->rail[t->nrail++] = i; }
    }
    t->lcm = 0;
    for (int i = 0; i < s->nlasers; i++) if (s->laser[i].off_t > 0) { int per = s->laser[i].on_t + s->laser[i].off_t; t->lcm = t->lcm ? t->lcm / gcd_i(t->lcm, per) * per : per; if (t->lcm > 1000000) t->lcm = 1000000; }
    /* What a state of the wave has to remember: only what changes and what the rules read. The rope nodes are only drawn
       (a thief that falls off a cut rope is the one exception, so levels with thieves keep whole ropes). */
    seg_add(t, offsetof(Sim, c), sizeof(Pt)); seg_add(t, offsetof(Sim, in_bubble), sizeof(int));
    for (int i = 0; i < t->nr; i++) seg_add(t, offsetof(Sim, rope) + (size_t)i * sizeof(Rope), t->thieves ? sizeof(Rope) : offsetof(Rope, p));
    for (int i = 0; i < s->npins; i++) {
        size_t o = offsetof(Sim, pin) + (size_t)i * sizeof(Pin);
        if (s->pin[i].rail) seg_add(t, o + offsetof(Pin, x), offsetof(Pin, r) - offsetof(Pin, x));
        seg_add(t, o + offsetof(Pin, used), offsetof(Pin, pulse) - offsetof(Pin, used));
        if (s->pin[i].rail) seg_add(t, o + offsetof(Pin, u), offsetof(Pin, thief_v) - offsetof(Pin, u));
    }
    for (int i = 0; i < s->nstars; i++) seg_add(t, offsetof(Sim, star) + (size_t)i * sizeof(Star) + offsetof(Star, got), sizeof(int));
    for (int i = 0; i < s->nbubbles; i++) seg_add(t, offsetof(Sim, bubble) + (size_t)i * sizeof(Bubble) + offsetof(Bubble, used), sizeof(int));
    for (int i = 0; i < s->nblowers; i++) seg_add(t, offsetof(Sim, blower) + (size_t)i * sizeof(Blower) + offsetof(Blower, squeeze), sizeof(float));
    for (int i = 0; i < s->nportals; i++) seg_add(t, offsetof(Sim, portal) + (size_t)i * sizeof(Portal) + offsetof(Portal, lock), sizeof(int));
    for (int i = 0; i < s->ngravs; i++) seg_add(t, offsetof(Sim, grav) + (size_t)i * sizeof(GravBtn) + offsetof(GravBtn, pulse), sizeof(float));
    seg_add(t, offsetof(Sim, state), offsetof(Sim, events) - offsetof(Sim, state));
    t->rsize = (REC_HEAD + t->psize + 3) & ~3;
    if (t->cfg.ins_step < 1) t->cfg.ins_step = 1;
    if (t->cfg.fmem > 0 && t->cfg.frontier > t->cfg.fmem / t->rsize) t->cfg.frontier = t->cfg.fmem / t->rsize;
    if (t->cfg.frontier < 64) t->cfg.frontier = 64;
    /* shortest way between stars, Mel and portals (a portal costs nothing): used to drop states that are too late anyway */
    {
        float X[17], Y[17]; int on[17]; memset(on, 0, sizeof(on));
        for (int i = 0; i < s->nstars; i++) { X[i] = s->star[i].x; Y[i] = s->star[i].y; on[i] = 1; }
        X[10] = s->mx; Y[10] = s->my; on[10] = s->has_mel;
        for (int i = 0; i < s->nportals; i++) { X[11 + i] = s->portal[i].x; Y[11 + i] = s->portal[i].y; on[11 + i] = 1; }
        for (int a = 0; a < 17; a++) for (int b = 0; b < 17; b++) {
            float d = 1e9f;
            if (on[a] && on[b]) { d = fdist(X[a], Y[a], X[b], Y[b]); if (b >= 11) { d -= PORTAL_R; if (d < 0) d = 0; } }
            t->dst[a][b] = a == b ? 0 : d;
        }
        for (int i = 0; i < s->nportals; i++) if (s->portal[i].link >= 0) t->dst[11 + i][11 + s->portal[i].link] = 0;
        for (int k = 0; k < 17; k++) for (int a = 0; a < 17; a++) for (int b = 0; b < 17; b++) if (t->dst[a][k] + t->dst[k][b] < t->dst[a][b]) t->dst[a][b] = t->dst[a][k] + t->dst[k][b];
        /* How fast can the bottle get? Gravity gives 1050 px/s per second. A blower gives 540 px/s at once and again every 16 ticks
           (4050 px/s per second). A bouncer throws it off at 430 px/s at least, a portal lets it out at 260 px/s at least,
           a pin on a rail drags it along at up to 400 px/s and speeds up by 1600 px/s per second. */
        t->lb_v = (s->nbouncers ? 70.0f + 430.0f * sqrtf((float)s->nbouncers) : 0.0f) + 300.0f * (s->nportals > 0) + 400.0f * (t->nrail > 0) + 540.0f * (float)s->nblowers;
        t->lb_a = 1050.0f + 4050.0f * (float)s->nblowers + 1600.0f * (t->nrail > 0);
        t->lb_v += t->lb_a / (2.0f * (float)SIM_HZ);        /* (the simulation moves in steps: a step uses the speed it has just gained) */
    }
    /* actions that polishing may add to a run */
    for (int i = 0; i < s->npins; i++) t->ins[t->nins++] = ((u32)ACT_CUT << 12) | (u32)i;
    if (s->nbubbles) t->ins[t->nins++] = (u32)ACT_POP << 12;
    for (int i = 0; i < s->nblowers; i++) t->ins[t->nins++] = ((u32)ACT_BLOW << 12) | (u32)i;
    for (int i = 0; i < s->ngravs; i++) t->ins[t->nins++] = ((u32)ACT_GRAV << 12) | (u32)i;
    for (int k = 0; k < t->nrail && t->nins + 3 <= 40; k++) for (int q = 0; q < 3; q++) t->ins[t->nins++] = ((u32)ACT_SLIDE << 12) | (u32)t->rail[k] | ((u32)(q == 0 ? 0 : q == 1 ? 128 : 255) << 4);
    /* the passes of the wave: from the start with ever finer cells, then the exhaustive one, then from later and later starts of the best run */
    t->skip_frac = -1;
    for (int r = t->cfg.res_first; r <= t->cfg.res_last && r < TAS_RES_N && t->np < 78; r++) { t->plist[t->np].frac8 = 0; t->plist[t->np].res = (signed char)r; t->np++; }
    if (t->cfg.exact) { t->plist[t->np].frac8 = 0; t->plist[t->np].res = TAS_RES_N - 1; t->plist[t->np].exact = 1; t->np++; }
    for (int f = 7; f >= 1; f--) {
        if (!(t->cfg.suffix & (1 << f))) continue;
        int r0 = t->cfg.res_last - 3 > t->cfg.res_first ? t->cfg.res_last - 3 : t->cfg.res_first;
        for (int r = r0; r <= t->cfg.res_last && r < TAS_RES_N && t->np < 78; r++) { t->plist[t->np].frac8 = (signed char)f; t->plist[t->np].res = (signed char)r; t->np++; }
        if (t->cfg.exact && t->np < 78) { t->plist[t->np].frac8 = (signed char)f; t->plist[t->np].res = TAS_RES_N - 1; t->plist[t->np].exact = 1; t->np++; }
    }
    t->phase = PH_SEED;
    return t;
}
void tas_seed(Tas *t, const u32 *a, int n) {
    if (t->nseed0 >= NSEED || n > TAS_MAXA) return;
    TasPlan *p = &t->seed0[t->nseed0++]; p->n = n; p->ticks = 0; memcpy(p->a, a, sizeof(u32) * (size_t)n);
}
static void bfs_release(Tas *t) { free(t->fa); free(t->fb); free(t->closed); free(t->nodes); t->fa = t->fb = NULL; t->closed = NULL; t->nodes = NULL; }
void tas_free(Tas *t) { if (!t) return; bfs_release(t); free(t); }
float tas_progress(const Tas *t) { if (t->phase == PH_DONE) return 1.0f; float f = (float)((double)t->units / (double)(t->cfg.units > 0 ? t->cfg.units : 1)); return f > 0.999f ? 0.999f : f; }
long long tas_tried(const Tas *t) { return t->tried; }
const TasPlan *tas_best(const Tas *t) { return t->have ? &t->best : NULL; }
int tas_proved(const Tas *t) { return t->proved; }
void tas_stats(const Tas *t, char *out, int max) {
    int k = snprintf(out, (size_t)max, "units=%lldM tried=%lld wave: passes=%d states=%lld wins=%d bad=%d | polish=%lld | kicks=%lld kickwins=%d | psize=%d",
             t->units / 1000000, t->tried, t->st_pass, t->st_exp, t->st_bfswin, t->st_badwin, t->st_pol, t->st_ils, t->st_ilswin, t->psize);
#ifdef TAS_TOOLS
    if ((t->cfg.verbose & 2) && k > 0 && k < max) snprintf(out + k, (size_t)(max - k), " | LBCHECK wins=%lld over=%lld worst=+%d tight=%d%%", t->st_lbruns, t->st_lbbad, t->st_lbover, t->st_lbslack);
#else
    (void)k;
#endif
}

/* ---------------------------------------------------------------- polishing: the neighbours of t->cur, one at a time */
static void pol_begin(Tas *t, int maxph) { t->pol_on = 1; t->p_ph = 0; t->p_i = t->p_j = t->p_k = 0; t->p_dirty = 0; t->p_maxph = maxph; t->p_sweep = 0; }
static u32 shifted(u32 a, int d) { int x = (int)(a >> 15) + d; if (x < 0) x = 0; return ((u32)x << 15) | (a & 32767u); }
static int pol_next(Tas *t, TasPlan *o) {
    const TasPlan *b = &t->cur; int n = b->n;
    for (;;) {
        if (t->p_ph > t->p_maxph) return 0;
        switch (t->p_ph) {
        case 0:                                             /* without one of the actions */
            if (t->p_i >= n) break;
            { int k = n - 1 - t->p_i++; *o = *b; memmove(o->a + k, o->a + k + 1, sizeof(u32) * (size_t)(n - 1 - k)); o->n = n - 1; return 1; }
        case 1:                                             /* an action and everything after it: earlier / later */
        case 2:                                             /* one action: earlier / later */
            if (t->p_i >= n) break;
            if (t->p_k >= NSH || (t->p_ph == 2 && t->p_i == n - 1)) { t->p_i++; t->p_k = 0; continue; }
            { int d = SH[t->p_k++], i = t->p_i, tk = (int)(b->a[i] >> 15) + d, last = t->p_ph == 1 ? n : i + 1;
              if (tk < 0 || tk >= b->ticks) continue;
              *o = *b; for (int j = i; j < last; j++) o->a[j] = shifted(o->a[j], d);
              return 1; }
        case 3:                                             /* another target for a rail pin */
            if (t->p_i >= n) break;
            if (((b->a[t->p_i] >> 12) & 7u) != ACT_SLIDE || t->p_k >= NDQ) { t->p_i++; t->p_k = 0; continue; }
            { u32 a = b->a[t->p_i]; int q = (int)((a >> 4) & 255u) + DQ[t->p_k++]; if (q < 0 || q > 255) continue;
              *o = *b; o->a[t->p_i] = (a & ~(255u << 4)) | ((u32)q << 4); return 1; }
        case 4:                                             /* one more action, at any moment */
            if (t->p_i >= t->nins || n >= TAS_MAXA - 1) break;
            if (t->p_k >= b->ticks) { t->p_i++; t->p_k = 0; continue; }
            { int tk = t->p_k; t->p_k += t->cfg.ins_step; *o = *b; o->a[o->n++] = ((u32)tk << 15) | t->ins[t->p_i]; return 1; }
        case 5:                                             /* two neighbours, each its own way */
            if (t->p_i >= n - 1) break;
            { int j = t->p_i + 1 + t->p_j, w = 2 * PS + 1;
              if (t->p_j >= 3 || j >= n) { t->p_i++; t->p_j = 0; t->p_k = 0; continue; }
              if (t->p_k >= w * w) { t->p_j++; t->p_k = 0; continue; }
              int d1 = t->p_k / w - PS, d2 = t->p_k % w - PS; t->p_k++;
              if (!d1 || !d2 || (int)(b->a[t->p_i] >> 15) + d1 < 0) continue;
              *o = *b; o->a[t->p_i] = shifted(o->a[t->p_i], d1); o->a[j] = shifted(o->a[j], d2); return 1; }
        }
        t->p_ph++; t->p_i = t->p_j = t->p_k = 0;
    }
}

/* ---------------------------------------------------------------- the wave */
static void cell_key(const Tas *t, const Sim *s, u32 *k1, u32 *k2) {
    u32 v[112]; int n = 0, ex = t->exact, free_auto = 0; u32 d0 = 0, d1 = 0;
    for (int i = 0; i < s->nstars; i++) if (s->star[i].got) d0 |= 1u << i;
    if (s->in_bubble) d0 |= 1u << 10;
    if (s->gdir < 0) d0 |= 1u << 11;
    for (int i = 0; i < s->nbubbles; i++) if (s->bubble[i].used) d0 |= 1u << (12 + i);
    for (int i = 0; i < s->nportals; i++) if (s->portal[i].lock) d0 |= 1u << (18 + i);
    for (int i = 0; i < s->nblowers; i++) { float q = s->blower[i].squeeze; if (q > 0.55f) { if (ex) v[n++] = fbits(q); else d0 |= 1u << (24 + i); } else if (ex) v[n++] = 0; }
    for (int i = 0; i < s->ngravs; i++) { float q = s->grav[i].pulse; if (q > 0.6f) { if (ex) v[n++] = fbits(q); else d1 |= 1u << (20 + i); } else if (ex) v[n++] = 0; }
    for (int i = 0; i < s->npins; i++) { if (s->pin[i].used) d1 |= 1u << i; else if (s->pin[i].autopin) free_auto = 1; }
    for (int i = 0; i < t->nr; i++) {
        const Rope *r = &s->rope[i]; if (!r->active) continue;
        if (!r->cut) {
            d1 |= 1u << (10 + r->pin);
            if (s->pin[r->pin].autopin) v[n++] = ex ? fbits(r->len) : (((u32)r->pin << 24) | (u32)(int)(r->len / (2.0f * t->cs)));
            if (ex) {                                       /* (a thief on a rope that hangs from the start is the same for every state of a tick) */
                v[n++] = (u32)i;
                if (r->thief == 1 && s->pin[r->pin].autopin) v[n++] = s->time < r->thief_t0 ? (fbits(r->thief_t0 - s->time) ^ 0x80000000u) : fbits(r->thief_s);
            }
        } else if (ex && free_auto) {                       /* a cut rope still holds its slot for a while: that decides which slot a new rope gets */
            v[n++] = ((u32)i << 28) ^ fbits(r->fade);
            if (r->thief == 2) { v[n++] = fbits(r->ty); v[n++] = fbits(r->tvy); }
        }
    }
    v[n++] = d0; v[n++] = d1;
    for (int k = 0; k < t->nrail; k++) {
        const Pin *p = &s->pin[t->rail[k]];
        float far = (p->ut - p->u) * t->rail_len[k];        /* all far targets on one side are the same thing: the pin can be retargeted later for free */
        u32 tgt = far > RAIL_FAR ? 0x7FFFFFF1u : far < -RAIL_FAR ? 0x7FFFFFF2u : (ex ? fbits(p->ut) : (u32)(int)(p->ut * 255.0f + 0.5f));
        if (ex) { v[n++] = fbits(p->u); v[n++] = tgt; v[n++] = fbits(p->uv); }
        else { v[n++] = (u32)(int)floorf(p->u * t->rail_len[k] / t->cs); v[n++] = tgt; v[n++] = (u32)(int)floorf(p->uv / (t->vs * 120.0f)); }
    }
    if (t->lcm) v[n++] = (u32)(s->tick % t->lcm);
    if (ex) { v[n++] = fbits(s->c.x); v[n++] = fbits(s->c.y); v[n++] = fbits(s->c.px); v[n++] = fbits(s->c.py); }
    else {
        v[n++] = (u32)(int)floorf(s->c.x / t->cs); v[n++] = (u32)(int)floorf(s->c.y / t->cs);
        v[n++] = (u32)(int)floorf((s->c.x - s->c.px) / t->vs); v[n++] = (u32)(int)floorf((s->c.y - s->c.py) / t->vs);
    }
    u32 h1 = 2166136261u, h2 = 0x9E3779B9u;
    for (int i = 0; i < n; i++) { h1 = (h1 ^ v[i]) * 16777619u; h1 ^= h1 >> 15; h2 = (h2 + v[i]) * 0x85EBCA6Bu; h2 ^= h2 >> 13; }
    if (!h1 && !h2) h2 = 1;
    *k1 = h1; *k2 = h2;
}
static int closed_put(Tas *t, u32 k1, u32 k2) {             /* 1: a new cell, 0: seen before, -1: the table is full */
    u32 i = (k1 ^ (k2 >> 7)) & t->cmask;
    for (;;) {
        u32 *e = t->closed + 2 * (size_t)i;
        if (!e[0] && !e[1]) { if (t->cn >= t->cmax) return -1; e[0] = k1; e[1] = k2; t->cn++; return 1; }
        if (e[0] == k1 && e[1] == k2) return 0;
        i = (i + 1) & t->cmask;
    }
}
/* the least number of ticks this state still needs: every star that is left, then Mel; no faster than gravity, blowers and bounces allow */
static int lower_bound(const Tas *t, const Sim *s) {
    float cx = s->c.x, cy = s->c.y, L = 0, dp[MAX_PORTALS]; int left = 0, np = s->nportals;
    for (int i = 0; i < np; i++) { dp[i] = fdist(cx, cy, s->portal[i].x, s->portal[i].y) - PORTAL_R; if (dp[i] < 0) dp[i] = 0; }
    for (int i = 0; i < s->nstars; i++) if (!s->star[i].got) {
        float a = fdist(cx, cy, s->star[i].x, s->star[i].y), b = t->dst[i][10] - STAR_REACH - MOUTH_REACH;
        for (int k = 0; k < np; k++) if (dp[k] + t->dst[11 + k][i] < a) a = dp[k] + t->dst[11 + k][i];
        a -= STAR_REACH; if (a < 0) a = 0; if (b < 0) b = 0;
        if (a + b > L) L = a + b; left = 1;
    }
    if (!left) {
        L = fdist(cx, cy, s->mx, s->my);
        for (int k = 0; k < np; k++) if (dp[k] + t->dst[11 + k][10] < L) L = dp[k] + t->dst[11 + k][10];
        L -= MOUTH_REACH; if (L < 0) L = 0;
    }
    float v = fdist(0, 0, s->c.x - s->c.px, s->c.y - s->c.py) * (float)SIM_HZ * 1.25f + t->lb_v, a = t->lb_a;
    return (int)((sqrtf(v * v + 2.0f * a * L) - v) / a * (float)SIM_HZ);
}
static void bfs_winner(Tas *t, i32 node, u32 last) {
    u32 rev[TAS_MAXA]; int n = 0; TasPlan *p = &t->cand, *w = &t->tmp;
    if (last) rev[n++] = last;
    for (i32 k = node; k >= 0 && n < TAS_MAXA; k = t->nodes[k].parent) rev[n++] = t->nodes[k].a;
    p->n = n; for (int i = 0; i < n; i++) p->a[i] = rev[n - 1 - i];
    int ticks = plan_run(t, p, T_MAXT, w);
    if (!ticks) { t->st_badwin++; return; }
    w->ticks = ticks; t->st_bfswin++;
    if (!t->exact && ticks + BFS_SLACK < t->limit) t->limit = ticks + BFS_SLACK;
    for (int i = 0; i < t->nwin; i++) if (t->win[i].n == w->n && !memcmp(t->win[i].a, w->a, sizeof(u32) * (size_t)w->n)) return;
    int k = t->nwin;
    if (k == NWIN) { if (!better(w, &t->win[NWIN - 1])) return; k = NWIN - 1; } else t->nwin++;
    t->win[k] = *w;
    while (k > 0 && better(&t->win[k], &t->win[k - 1])) { TasPlan x = t->win[k]; t->win[k] = t->win[k - 1]; t->win[k - 1] = x; k--; }
}
static void bfs_push(Tas *t, const Sim *s, i32 node, u32 k1, u32 k2, i32 lb) {
    u8 *r;
    if (t->gn < t->cfg.frontier) r = t->fb + (size_t)t->gn++ * (size_t)t->rsize;
    else {                                                  /* too many states for one tick: a random one makes room, most often one that is further from the goal */
        if (t->exact) { t->aborted = 1; return; }
        t->lossy = 1;
        r = t->fb + (size_t)(rnd(t) % (u32)t->cfg.frontier) * (size_t)t->rsize;
        i32 old; memcpy(&old, r + 12, 4);
        if (lb >= old && (rnd(t) & 3u)) return;
    }
    memcpy(r, &node, 4); memcpy(r + 4, &k1, 4); memcpy(r + 8, &k2, 4); memcpy(r + 12, &lb, 4); pack(t, s, r + REC_HEAD);
}
static int rope_live(const Sim *s, int pin) { for (int i = 0; i < MAX_ROPES; i++) if (s->rope[i].active && !s->rope[i].cut && s->rope[i].pin == pin) return 1; return 0; }
/* one tick later without any action */
static void bfs_step(Tas *t, const u8 *rec) {
    Sim *s = &t->W; i32 node; u32 pk1, pk2, k1, k2;
    memcpy(&node, rec, 4); memcpy(&pk1, rec + 4, 4); memcpy(&pk2, rec + 8, 4);
    unpack(t, rec + REC_HEAD, s);
    sim_step(s); t->units += 4; t->tried++; t->st_exp++;
    if (s->state != ST_PLAY) { if (s->state == ST_EATEN && s->stars >= t->maxst) bfs_winner(t, node, 0); return; }
    i32 lb = (i32)lower_bound(t, s);
    if (s->tick + lb > t->limit) return;
    cell_key(t, s, &k1, &k2);
    if (k1 != pk1 || k2 != pk2) {                           /* (a state that just stays in its own cell goes on) */
        int r = closed_put(t, k1, k2); if (r == 0) return; if (r < 0) { t->aborted = 1; return; }
    }
    bfs_push(t, s, node, k1, k2, lb);
}
/* every action that is possible in this state */
static void bfs_acts(Tas *t, const u8 *rec) {
    Sim *s = &t->W; i32 node; u32 k1, k2, acts[96]; int na = 0;
    memcpy(&node, rec, 4);
    unpack(t, rec + REC_HEAD, s);
    for (int i = 0; i < t->nr; i++) { const Rope *r = &s->rope[i]; if (r->active && !r->cut) acts[na++] = ((u32)ACT_CUT << 12) | (u32)r->pin; }
    if (s->in_bubble) acts[na++] = (u32)ACT_POP << 12;
    for (int i = 0; i < s->nblowers; i++) if (!(s->blower[i].squeeze > 0.55f)) acts[na++] = ((u32)ACT_BLOW << 12) | (u32)i;
    for (int i = 0; i < s->ngravs; i++) if (!(s->grav[i].pulse > 0.6f)) acts[na++] = ((u32)ACT_GRAV << 12) | (u32)i;
    for (int k = 0; k < t->nrail; k++) {
        int pi = t->rail[k]; const Pin *p = &s->pin[pi];
        if (p->used ? !rope_live(s, pi) : !p->autopin) continue;         /* nothing hangs on this pin any more */
        int cur = (int)(p->ut * 255.0f + 0.5f), seen = 0; float len = t->rail_len[k], far = (p->ut - p->u) * len;
        if (far > RAIL_FAR) seen = 1; else if (far < -RAIL_FAR) seen = 2;
        for (int j = 0; j < t->nq && na < 96; j++) {
            int q = t->qv[j]; float f = ((float)q / 255.0f - p->u) * len; int cls = f > RAIL_FAR ? 1 : f < -RAIL_FAR ? 2 : 0;
            if (cls ? (seen & cls) : q == cur) continue;                  /* one target per side is enough while it is far away */
            seen |= cls; acts[na++] = ((u32)ACT_SLIDE << 12) | (u32)pi | ((u32)q << 4);
        }
    }
    int layer = s->tick;
    for (int k = 0; k < na; k++) {
        if (k) unpack(t, rec + REC_HEAD, s);
        int act = (int)(acts[k] >> 12), arg = (int)(acts[k] & 4095u); float px = s->c.px, py = s->c.py;
        if (!sim_act(s, act, arg)) continue;
        if (act == ACT_BLOW && s->c.px == px && s->c.py == py) continue;      /* the bottle is not in front of this blower */
        u32 word = ((u32)layer << 15) | acts[k];
        if (t->exact) {
            /* the exhaustive pass allows any number of actions in one tick: the state right after the action joins the same tick */
            i32 lb = (i32)lower_bound(t, s); t->units += 2; t->tried++; t->st_exp++;
            if (s->tick + lb > t->limit) continue;
            cell_key(t, s, &k1, &k2);
            int r = closed_put(t, k1, k2); if (r == 0) continue;
            if (r < 0 || t->nnodes >= t->nmax || t->fn >= t->cfg.frontier) { t->aborted = 1; return; }
            t->nodes[t->nnodes].parent = node; t->nodes[t->nnodes].a = word; i32 nn = t->nnodes++;
            u8 *q = t->fa + (size_t)t->fn++ * (size_t)t->rsize;
            memcpy(q, &nn, 4); memcpy(q + 4, &k1, 4); memcpy(q + 8, &k2, 4); memcpy(q + 12, &lb, 4); pack(t, s, q + REC_HEAD);
            continue;
        }
        sim_step(s); t->units += 4; t->tried++; t->st_exp++;
        if (s->state != ST_PLAY) { if (s->state == ST_EATEN && s->stars >= t->maxst) bfs_winner(t, node, word); continue; }
        i32 lb = (i32)lower_bound(t, s);
        if (s->tick + lb > t->limit) continue;
        cell_key(t, s, &k1, &k2);
        { int r = closed_put(t, k1, k2); if (r == 0) continue; if (r < 0) { t->aborted = 1; return; } }
        if (t->nnodes >= t->nmax) { t->aborted = 1; return; }
        t->nodes[t->nnodes].parent = node; t->nodes[t->nnodes].a = word;
        bfs_push(t, s, t->nnodes++, k1, k2, lb);
        if (t->aborted) return;
    }
}
static int bfs_begin(Tas *t, const Pass *ps) {
    size_t fsz = (size_t)t->cfg.frontier * (size_t)t->rsize, csz = (size_t)2 << t->cfg.closed_log2; int res = ps->res, exact = ps->exact;
    if (!t->fa) {
        t->fa = (u8 *)malloc(fsz); t->fb = (u8 *)malloc(fsz); t->closed = (u32 *)malloc(csz * sizeof(u32)); t->nodes = (Node *)malloc(((size_t)1 << t->cfg.nodes_log2) * sizeof(Node));
        if (!t->fa || !t->fb || !t->closed || !t->nodes) { bfs_release(t); return 0; }
    }
    memset(t->closed, 0, csz * sizeof(u32));
    t->cmask = ((u32)1 << t->cfg.closed_log2) - 1; t->cmax = (int)(((size_t)1 << t->cfg.closed_log2) * 7 / 10); t->cn = 0;
    t->nmax = 1 << t->cfg.nodes_log2; t->nnodes = 0; t->nwin = 0; t->lossy = 0; t->aborted = 0;
    t->pres = res; t->pfrac = ps->frac8; t->exact = exact; t->cs = RES_CS[res]; t->vs = RES_VS[res]; t->nq = exact ? 33 : RES_NQ[res];
    for (int j = 0; j < t->nq; j++) t->qv[j] = (j * 255 + (t->nq - 1) / 2) / (t->nq - 1);
    t->limit = t->have ? t->best.ticks - 1 + (exact ? 0 : BFS_SLACK) : T_MAXT;
    { long long left = t->cfg.units - t->units; t->pass_end = t->units + (exact ? left / 3 : left / 4); }
    /* the wave starts from the level as it is at the beginning, or from the best run played up to some tick */
    Sim *s = &t->W; i32 node = -1; int t0 = t->have ? t->best.ticks * ps->frac8 / 8 : 0, i = 0;
    memcpy(s, &t->S0, sizeof(Sim));
    while (s->tick < t0 && s->state == ST_PLAY) {
        while (i < t->best.n && (int)(t->best.a[i] >> 15) <= s->tick) {
            u32 a = t->best.a[i++];
            if (sim_act(s, (int)((a >> 12) & 7u), (int)(a & 4095u))) { t->nodes[t->nnodes].parent = node; t->nodes[t->nnodes].a = ((u32)s->tick << 15) | (a & 32767u); node = t->nnodes++; }
        }
        sim_step(s);
    }
    if (s->state != ST_PLAY) return 0;
    u32 k1, k2; cell_key(t, s, &k1, &k2); closed_put(t, k1, k2);
    t->gn = 0; t->fi = 0; t->layer = s->tick;
    { u8 *x = t->fb; t->fb = t->fa; bfs_push(t, s, node, k1, k2, 0); t->fb = x; }
    t->fn = t->fn0 = 1; t->gn = 0; t->sweep = 0;
    t->st_pass++;
    return 1;
}
/* One tick of the wave is done in two sweeps: first every state moves on without an action, then the actions are tried.
   So a state that is already on its way keeps its cell, and a state that has only just branched off does not push it out. */
static int bfs_work(Tas *t, long long end) {                /* 1: more to do */
    while (t->units < end) {
        if (t->aborted || (t->exact && t->nwin)) return 0;
        if (t->units > t->pass_end) { t->aborted = 2; return 0; }
        if (t->fi >= t->fn) {
            if (t->sweep == 0) { t->sweep = 1; t->fi = 0; continue; }
            u8 *x = t->fa; t->fa = t->fb; t->fb = x; t->fn = t->fn0 = t->gn; t->gn = 0; t->fi = 0; t->sweep = 0; t->layer++;
            if (!t->fn || t->layer >= t->limit) return 0;
            continue;
        }
        const u8 *rec = t->fa + (size_t)t->fi * (size_t)t->rsize;
        if (t->sweep == 0) { bfs_step(t, rec); if (++t->fi >= t->fn0) t->fi = t->fn; }
        else { if (t->fi >= t->fn0) bfs_step(t, rec); if (!t->aborted) bfs_acts(t, rec); t->fi++; }      /* (fi >= fn0: a state that an action has just made, see bfs_acts) */
    }
    return 1;
}

/* ---------------------------------------------------------------- the stages */
static void take(Tas *t, const TasPlan *p) { if (!t->have || better(p, &t->best)) { t->best = *p; t->have = 1; if (t->ils_on) { t->ils_new = 1; t->st_ilswin++; } } }
static void next_stage(Tas *t) {
    long long left = t->cfg.units - t->units;
    if (t->ils_on) { if (t->ils_new) { t->ils_new = 0; t->cur = t->best; pol_begin(t, 5); t->phase = PH_POLISH; return; } t->phase = PH_ILS; return; }
    while (!t->stop_bfs && !t->proved && t->pi < t->np && left > t->cfg.units / 25) {
        const Pass *ps = &t->plist[t->pi++];
        if (ps->frac8 == t->skip_frac && !ps->exact) continue;            /* a coarser pass from this start was already too big */
        if ((ps->frac8 || ps->exact) && !t->have) continue;
        if (bfs_begin(t, ps)) { t->phase = PH_BFS; return; }
    }
    bfs_release(t);
    if (!t->final_done && t->have) { t->final_done = 1; t->cur = t->best; pol_begin(t, 5); t->phase = PH_POLISH; return; }
    if (t->proved || !t->have) { t->units = t->cfg.units; return; }
    t->ils_on = 1; t->phase = PH_ILS;
}
static void finish(Tas *t) {
    if (t->pol_on && t->cur.ticks > 0 && (!t->have || better(&t->cur, &t->best))) { t->best = t->cur; t->have = 1; }
    t->pol_on = 0; bfs_release(t);
    if (t->have && !t->fix) {
        /* The real simulation (with rope nodes) has the last word. The two can only differ when a thief falls off a cut rope:
           then the known runs are checked and polished once more on the real one (slower, so with a small extra budget). */
        int tk = tas_check(t->objs, t->best.a, t->best.n);
        if (tk != t->best.ticks) {
            TasPlan old = t->best;
            t->fix = 1; t->visual = 1; sim_skip_visual = 0; t->have = 0; t->proved = 0; t->ils_on = 0;
            int r = plan_run(t, &old, T_MAXT, &t->tmp); if (r) { t->tmp.ticks = r; take(t, &t->tmp); }
            for (int i = 0; i < t->nseed0; i++) { r = plan_run(t, &t->seed0[i], T_MAXT, &t->tmp); if (r) { t->tmp.ticks = r; take(t, &t->tmp); } }
            if (t->have) {
                t->final_done = 1; t->stop_bfs = 1; t->ils_on = 1; t->ils_new = 0; t->qn = t->qi = 0;
                t->cfg.units = t->units + t->cfg.units / 4;
                t->cur = t->best; pol_begin(t, 3); t->phase = PH_POLISH;
                return;
            }
        }
    }
    t->phase = PH_DONE;
}
static void ils_kick(Tas *t) {
    TasPlan *o = &t->cand; *o = t->best; int moves = 1 + (int)(rnd(t) % 3u);
    for (int m = 0; m < moves; m++) {
        int n = o->n, type = (int)(rnd(t) % 8u), d = 1 + (int)(rnd(t) % 40u); if (rnd(t) & 1u) d = -d;
        if (n == 0) type = 6;
        if (type <= 2) { int i = (int)(rnd(t) % (u32)n); o->a[i] = shifted(o->a[i], d); }
        else if (type == 3) { int i = (int)(rnd(t) % (u32)n); for (int j = i; j < n; j++) o->a[j] = shifted(o->a[j], d); }
        else if (type == 4) { int i = (int)(rnd(t) % (u32)n); memmove(o->a + i, o->a + i + 1, sizeof(u32) * (size_t)(n - 1 - i)); o->n--; }
        else if (type == 5) { int i = (int)(rnd(t) % (u32)n); u32 a = o->a[i];
            if (((a >> 12) & 7u) == ACT_SLIDE) { int q = (int)((a >> 4) & 255u) + d * 2; q = q < 0 ? 0 : q > 255 ? 255 : q; o->a[i] = (a & ~(255u << 4)) | ((u32)q << 4); } else o->a[i] = shifted(a, d); }
        else if (t->nins && n < TAS_MAXA - 1) { int tk = (int)(rnd(t) % (u32)(t->best.ticks > 0 ? t->best.ticks : 1)); o->a[o->n++] = ((u32)tk << 15) | t->ins[rnd(t) % (u32)t->nins]; }
    }
    plan_sort(o); t->st_ils++;
    int r = plan_run(t, o, t->best.ticks + ILS_SLACK, &t->tmp);
    if (!r) return;
    t->tmp.ticks = r;
    if (t->tmp.n == t->best.n && !memcmp(t->tmp.a, t->best.a, sizeof(u32) * (size_t)t->best.n)) return;
    t->cur = t->tmp; pol_begin(t, 3); t->phase = PH_POLISH;
}
int tas_work(Tas *t, long long units) {
    if (t->phase == PH_DONE) return 0;
    int keep = sim_skip_visual; long long end = t->units + units;
    sim_skip_visual = !t->visual;
    while (t->phase != PH_DONE && t->units < end) {
        if (t->units >= t->cfg.units) { finish(t); sim_skip_visual = !t->visual; continue; }
        switch (t->phase) {
        case PH_SEED:
            for (int i = 0; i < t->nseed0; i++) { int r = plan_run(t, &t->seed0[i], T_MAXT, &t->tmp); if (r) { t->tmp.ticks = r; t->queue[t->qn++] = t->tmp; take(t, &t->tmp); } }
            t->qi = 0; t->q_maxph = 5; t->phase = PH_POLISH;
            break;
        case PH_POLISH:
            if (!t->pol_on) {
                if (t->qi < t->qn) { t->cur = t->queue[t->qi++]; pol_begin(t, t->q_maxph); }
                else { t->qn = t->qi = 0; next_stage(t); break; }
            }
            if (pol_next(t, &t->cand)) {
                plan_sort(&t->cand); t->st_pol++;
                int r = plan_run(t, &t->cand, t->cur.ticks, &t->tmp);
                if (r) { t->tmp.ticks = r; if (better(&t->tmp, &t->cur)) { t->cur = t->tmp; t->p_dirty = 1; } }
            } else if (t->p_dirty && ++t->p_sweep < 60) { t->p_ph = 0; t->p_i = t->p_j = t->p_k = 0; t->p_dirty = 0; }
            else { t->pol_on = 0; take(t, &t->cur); }
            break;
        case PH_BFS:
            if (!bfs_work(t, end)) {
                int complete = !t->aborted && !t->lossy;
                t->st_lastres = t->exact ? 99 : t->pres; t->st_lastcells = t->cn; t->st_lossy = t->lossy || t->aborted;
#ifdef TAS_TOOLS
                if (t->cfg.verbose & 1) fprintf(stderr, "    wave from %d/8 %s%d: cells=%d layer=%d/%d wins=%d best=%d %s%s units=%lldM\n", t->pfrac, t->exact ? "exact " : "res ", t->pres, t->cn, t->layer, t->limit, t->nwin,
                                            t->nwin ? t->win[0].ticks : 0, t->aborted == 2 ? "BUDGET " : t->aborted ? "FULL " : "", t->lossy ? "lossy" : "", t->units / 1000000);
#endif
                t->qn = 0;
                if (t->exact) {
                    if (t->nwin) take(t, &t->win[0]);
                    if (complete && t->pfrac == 0 && !t->nrail) t->proved = 1;      /* every state the level can be in before that tick has been visited (rails have too many targets for that) */
                } else {
                    for (int i = 0; i < t->nwin; i++) t->queue[t->qn++] = t->win[i];
                    if (t->aborted) t->skip_frac = t->pfrac;
                }
                t->qi = 0; t->q_maxph = 3; t->phase = PH_POLISH;
            }
            break;
        case PH_ILS:
            ils_kick(t);
            break;
        }
    }
    if (t->phase != PH_DONE && t->units >= t->cfg.units) finish(t);
    sim_skip_visual = keep;
    return t->phase != PH_DONE;
}

#ifdef TAS_TOOLS
/* tools only: the packed state must behave exactly like the full one. Random runs; returns the number of differences. */
int tas_selftest(const LObj *objs, int rounds) {
    TasCfg cfg; tas_cfg_game(&cfg); Tas *t = tas_new(objs, &cfg); if (!t) return -1;
    int bad = 0, keep = sim_skip_visual; sim_skip_visual = 1;
    u8 *buf = (u8 *)malloc((size_t)t->psize + 16); Sim *a = &t->V, *b = &t->W;
    for (int r = 0; r < rounds; r++) {
        memcpy(a, &t->S0, sizeof(Sim)); int split = (int)(rnd(t) % 500u), packed = 0;
        for (int k = 0; k < 900 && a->state == ST_PLAY; k++) {
            if (k == split) { pack(t, a, buf); unpack(t, buf, b); packed = 1; }
            if (t->nins && rnd(t) % 12u == 0) { u32 w = t->ins[rnd(t) % (u32)t->nins]; if (((w >> 12) & 7u) == ACT_SLIDE) w = (w & ~(255u << 4)) | ((rnd(t) & 255u) << 4);
                int ra = sim_act(a, (int)(w >> 12), (int)(w & 4095u)); if (packed && sim_act(b, (int)(w >> 12), (int)(w & 4095u)) != ra) { bad++; break; } }
            sim_step(a);
            if (packed) { sim_step(b); if (memcmp(&a->c, &b->c, sizeof(Pt)) || a->state != b->state || a->stars != b->stars || a->in_bubble != b->in_bubble || a->gdir != b->gdir || a->tick != b->tick) { bad++; break; } }
        }
    }
    free(buf); sim_skip_visual = keep; tas_free(t);
    return bad;
}

/* tools only: follow a run and print the estimate of the remaining time at every 10th tick */
void tas_debug_trace(Tas *t, const u32 *a, int n, int limit) {
    Sim *s = &t->V; int i = 0, keep = sim_skip_visual; sim_skip_visual = 1; memcpy(s, &t->S0, sizeof(Sim));
    while (s->state == ST_PLAY && s->tick < 4000) {
        while (i < n && (int)(a[i] >> 15) <= s->tick) { sim_act(s, (int)((a[i] >> 12) & 7u), (int)(a[i] & 4095u)); i++; }
        sim_step(s);
        int lb = lower_bound(t, s);
        if (s->tick % 10 == 0 || s->tick + lb > limit) printf("tick %d pos %.0f,%.0f stars %d bubble %d lb %d sum %d%s state %d\n", s->tick, s->c.x, s->c.y, s->stars, s->in_bubble, lb, s->tick + lb, s->tick + lb > limit ? "  <-- PRUNED" : "", s->state);
        if (s->tick + lb > limit) break;
    }
    sim_skip_visual = keep;
}
#endif
