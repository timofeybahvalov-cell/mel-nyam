/* ============================================================================
   «МЕЛ-НЯМ» V0.6 — «Мой говорящий Мел»: the little Mel close by.
   He is given drinks, stroked, put to bed and dressed; he repeats what is said into the microphone
   in the voice of his age, learns the names of things like a parrot, and grows year by year.
   Included by game.c after g_house.inc.
   ============================================================================ */

/* ---------------- the voice: one recording at a time ---------------- */
#define VOICE_RATE 16000
#define VOICE_MAX (VOICE_RATE * 5)
static Sound *S_voice; static int voice_n;           /* what was said last (or a learned word), ready to be played */
static u8 voice_env[160]; static int voice_env_n;    /* how loud it is, 25 times a second: his mouth moves with it */
static i16 voice_tmp[VOICE_MAX];
enum { VO_OK, VO_EMPTY, VO_QUIET, VO_SILENT };
static void voice_ready(int n) {
    if (!S_voice) return;
    plat_audio_lock(); memcpy(S_voice->pcm, voice_tmp, (size_t)n * 2); S_voice->n = n > 0 ? n : 1; S_voice->rate = VOICE_RATE; plat_audio_unlock();
    snd_changed(S_voice); voice_n = n; voice_env_n = 0;
    for (int i = 0; i + 640 <= n && voice_env_n < 160; i += 640) { int pk = 0; for (int k = 0; k < 640; k++) { int v = voice_tmp[i + k]; if (v < 0) v = -v; if (v > pk) pk = v; } voice_env[voice_env_n++] = (u8)(pk >> 7); }
}
/* a recording of the microphone -> 16 kHz, silence cut away, as loud as it should be; fills voice_tmp, returns VO_... (*len: samples) */
static int voice_take(const i16 *pcm, int n, int rate, int max_len, int *len) {
    static i16 raw[VOICE_MAX + 8000]; int m = 0, peak = 0, a = -1, b = -1; long dc = 0;
    *len = 0;
    if (!pcm || n < 400 || rate < 4000) return VO_EMPTY;
    double step = (double)rate / VOICE_RATE;
    for (int i = 0; m < VOICE_MAX + 8000; i++) {     /* resample: the mean of the piece of input one output sample covers (or a line between two, when the input is slower) */
        double p0 = i * step, p1 = p0 + step; int i0 = (int)p0, i1 = (int)p1; if (i0 >= n - 1) break; if (i1 >= n) i1 = n - 1;
        if (step >= 1.5) { long s = 0; for (int k = i0; k <= i1; k++) s += pcm[k]; raw[m++] = (i16)(s / (i1 - i0 + 1)); }
        else { double f = p0 - i0; raw[m++] = (i16)(pcm[i0] * (1 - f) + pcm[i0 + 1] * f); }
    }
    for (int i = 0; i < m; i++) dc += raw[i]; dc /= (m > 0 ? m : 1);
    for (int i = 0; i < m; i++) { int v = raw[i] - (int)dc; if (v > 32767) v = 32767; if (v < -32768) v = -32768; raw[i] = (i16)v; if (v < 0) v = -v; if (v > peak) peak = v; }
    if (peak < 60) return VO_SILENT;                  /* not a sound at all: the microphone is off or the system does not let the game hear it */
    if (peak < 500) return VO_QUIET;
    int thr = peak / 9; if (thr < 260) thr = 260;
    for (int i = 0; i + 160 <= m; i += 160) { int pk = 0; for (int k = 0; k < 160; k++) { int v = raw[i + k]; if (v < 0) v = -v; if (v > pk) pk = v; } if (pk > thr) { if (a < 0) a = i; b = i + 160; } }
    if (a < 0 || b - a < 1600) return VO_QUIET;      /* (shorter than a tenth of a second: a click, not a word) */
    a -= 960; if (a < 0) a = 0; b += 1920; if (b > m) b = m; if (b - a > max_len) b = a + max_len;
    float gain = 26000.0f / (float)peak; if (gain > 12.0f) gain = 12.0f;
    for (int i = a; i < b; i++) { float v = (float)raw[i] * gain, e = 1.0f; if (i - a < 240) e = (float)(i - a) / 240.0f; if (b - i < 480) e = minf(e, (float)(b - i) / 480.0f); voice_tmp[i - a] = (i16)clampf(v * e, -32000, 32000); }
    *len = b - a; return VO_OK;
}
/* IMA ADPCM: a learned word takes four bits a sample */
static const i16 ima_step[89] = { 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767 };
static const i8 ima_idx[8] = { -1, -1, -1, -1, 2, 4, 6, 8 };
static int ima_code(int *pred, int *idx, int sample, int encode, int code) {      /* one sample: encode it (returns the code) or decode `code` (returns the sample) */
    int step = ima_step[*idx], diff, vp = step >> 3;
    if (encode) { diff = sample - *pred; code = 0; if (diff < 0) { code = 8; diff = -diff; } if (diff >= step) { code |= 4; diff -= step; } if (diff >= step >> 1) { code |= 2; diff -= step >> 1; } if (diff >= step >> 2) code |= 1; }
    if (code & 4) vp += step; if (code & 2) vp += step >> 1; if (code & 1) vp += step >> 2;
    *pred += (code & 8) ? -vp : vp; if (*pred > 32767) *pred = 32767; if (*pred < -32768) *pred = -32768;
    *idx += ima_idx[code & 7]; if (*idx < 0) *idx = 0; if (*idx > 88) *idx = 88;
    return encode ? code : *pred;
}
/* ---------------- the words he has learned (they stay on this device) ---------------- */
#define WORD_N 12
#define WORD_MAX (VOICE_RATE * 2)
#define WORDS_MAGIC 0x3144524Fu
typedef struct { const char *name; i8 skin, pic; } WordDef;      /* skin: the picture of a drink, or -1 and a drawn thing */
static const WordDef word_tab[WORD_N] = { { "Вода", 1, 0 }, { "Молоко", 11, 0 }, { "Сок", 2, 0 }, { "Чай", 12, 0 }, { "Компот", 13, 0 }, { "Лимонад", 5, 0 }, { "Какао", 16, 0 }, { "Кола", 18, 0 },
                                          { "Мяч", -1, 0 }, { "Кот", -1, 1 }, { "Дом", -1, 2 }, { "Звезда", -1, 3 } };
static struct { u32 magic, uid; u8 have[WORD_N]; u32 r[4]; } WD;
static int words_known(void) { int n = 0; for (int i = 0; i < WORD_N; i++) n += WD.have[i] != 0; return n; }
static void words_load(void) {
    if (WD.magic == WORDS_MAGIC && WD.uid == SV.uid) return;
    if (plat_fetch("words", &WD, (int)sizeof(WD)) != (int)sizeof(WD) || WD.magic != WORDS_MAGIC || WD.uid != SV.uid) { memset(&WD, 0, sizeof(WD)); WD.magic = WORDS_MAGIC; WD.uid = SV.uid; }
}
static void word_store(int w, int n) {               /* voice_tmp[0..n) becomes the word number w */
    static u8 blob[WORD_MAX / 2 + 16]; int pred = voice_tmp[0], idx = 0, len = 8; char key[8];
    if (n > WORD_MAX) n = WORD_MAX;
    memcpy(blob, &n, 4); blob[4] = (u8)(pred & 255); blob[5] = (u8)((pred >> 8) & 255); blob[6] = 0; blob[7] = 0;
    for (int i = 1; i < n; i++) { int c = ima_code(&pred, &idx, voice_tmp[i], 1, 0); if (i & 1) blob[len] = (u8)c; else blob[len++] |= (u8)(c << 4); }
    snprintf(key, sizeof(key), "w%d", w); plat_store(key, blob, len + 1);
    WD.have[w] = 1; plat_store("words", &WD, (int)sizeof(WD));
}
static int word_fetch(int w) {                       /* the word number w into voice_tmp; returns its length (0: there is none) */
    static u8 blob[WORD_MAX / 2 + 16]; char key[8]; int n = 0, got, pred, idx = 0, len = 8;
    snprintf(key, sizeof(key), "w%d", w); got = plat_fetch(key, blob, (int)sizeof(blob));
    if (got < 12) return 0;
    memcpy(&n, blob, 4); if (n < 2 || n > WORD_MAX || got < 8 + n / 2) return 0;
    pred = (i16)(blob[4] | (blob[5] << 8)); voice_tmp[0] = (i16)pred;
    for (int i = 1; i < n; i++) { int c = (i & 1) ? (blob[len] & 15) : (blob[len++] >> 4); voice_tmp[i] = (i16)ima_code(&pred, &idx, 0, 0, c); }
    return n;
}
static void word_pic(int w, float cx, float cy, float box) {
    const WordDef *d = &word_tab[w];
    if (d->skin >= 0) { const Image *im = skin_pic(d->skin); float s = box / ((float)im->h / im->scale); gfx_image_ex(im, cx, cy, s, s, 0, 1); return; }
    d_at(cx, cy, box / 100.0f, 0);
    if (d->pic == 0) { o_circ(0, 0, 40, 0xFF5A5AFFu); d_curve(-36, -14, 0, -30, 36, -14, 5, 0xFFFFFFFFu); d_curve(-36, 14, 0, 30, 36, 14, 5, 0xFFFFFFFFu); d_circ(-14, -18, 7, 0xFFFFFF90u); }
    else if (d->pic == 1) item_draw(25, cx + box * 0.04f, cy + box * 0.44f, box / 82.0f, 0);
    else if (d->pic == 2) { o_rect(-32, -8, 64, 50, 4, 0xFFE9A8FFu); o_tri(-44, -6, 44, -6, 0, -46, 0xD9553CFFu); o_rect(-9, 12, 18, 30, 3, 0x9A5F33FFu); o_rect(14, 4, 14, 14, 2, 0x9ADFFFFFu); }
    else { d_star(0, 2, 46, OLC); d_star(0, 2, 40, 0xFFD23FFFu); d_star(-3, -1, 20, 0xFFE680FFu); }
}

/* ---------------- what happens on the screen ---------------- */
enum { TR_NONE, TR_DRINKS, TR_WORDS };
enum { LS_NONE, LS_REPEAT, LS_TEACH };
static struct {
    int tray, sel_d, sel_w, page;
    float sip_t; int sip_d;                          /* he drinks */
    float talk_t, talk_len, talk_wait; float talk_pitch;      /* he speaks */
    float jump_t, no_t, tipsy_t, look_t, wave_t;
    char bubble[120]; float bubble_t; int bubble_pic;
    int listen, mic_seen_loud; float listen_t, quiet_t, wait_t; int listen_w;
    float stroke; int strokes, pokes;
    struct { float x, y, t; } heart[10];
    int grow; float grow_t; int grow_from, grow_to, grow_gift;      /* the stairs of ages */
    float cam, chatter_t, nap; int show_w; float show_t;
    int inited;
} PT;
static void pet_reset_view(void) { memset(&PT, 0, sizeof(PT)); PT.inited = 1; PT.sel_d = -1; PT.sel_w = -1; PT.show_w = -1; PT.sip_d = -1; memset(&WD, 0, sizeof(WD)); voice_n = 0; }
static void pet_bubble(const char *s, float t) { snprintf(PT.bubble, sizeof(PT.bubble), "%s", s); PT.bubble_t = t; PT.bubble_pic = -1; }
static void pet_hearts(float x, float y, int n) { for (int i = 0; i < 10 && n > 0; i++) if (PT.heart[i].t <= 0) { PT.heart[i].x = x + rnd_range(-50, 50); PT.heart[i].y = y + rnd_range(-20, 20); PT.heart[i].t = 1.0f; n--; } }
static void pet_tire(int thirst, int energy) { pet_add(ND_THIRST, -thirst); pet_add(ND_ENERGY, -energy); }      /* playing makes him thirsty and a little tired */
static void pet_speak(float wait) {                  /* play what is in the voice buffer, in the voice of his age */
    if (voice_n <= 0 || !S_voice) return;
    PT.talk_pitch = pet_pitch(pet_age()); PT.talk_wait = wait; PT.talk_len = (float)voice_n / VOICE_RATE / PT.talk_pitch; PT.talk_t = 0;
}
static int pet_busy(void) { return PT.sip_t > 0 || PT.talk_len > 0 || PT.listen || PT.grow; }
static void pet_say_word(int w, float wait) { int n = WD.have[w] ? word_fetch(w) : 0; if (n > 0) { voice_ready(n); pet_speak(wait); PT.bubble_t = 0; PT.show_w = w; PT.show_t = 2.4f; } }
static int mic_state(void) { return plat_ctl(PC_MIC, NULL, MIC_STATE, 0); }
static void pet_listen(int mode, int w) {
    if (pet_busy()) return;
    if (HM.asleep) { pet_bubble("Тсс! Я сплю...", 2.0f); return; }
    if (!plat_ctl(PC_MIC, NULL, MIC_START, mode == LS_TEACH ? 2500 : 4500)) { msg_open("Микрофон", "Микрофон не найден или игре нельзя им пользоваться. Разреши доступ к микрофону и попробуй ещё раз."); return; }
    PT.listen = mode; PT.listen_w = w; PT.listen_t = 0; PT.quiet_t = 0; PT.wait_t = 0; PT.mic_seen_loud = 0; PT.bubble_t = 0; PT.show_t = 0;
}
static void pet_listen_stop(int cancel) { if (!PT.listen) return; if (cancel) { plat_ctl(PC_MIC, NULL, MIC_CANCEL, 0); PT.listen = LS_NONE; } else { PT.wait_t = 0.01f; plat_ctl(PC_MIC, NULL, MIC_STOP, 0); } }
void app_mic(const i16 *pcm, int n, int rate) {       /* the platform hands over what was recorded */
    int mode = PT.listen, len = 0, r; PT.listen = LS_NONE; PT.wait_t = 0;
    if (!mode || !home_on()) return;
    r = voice_take(pcm, n, rate, mode == LS_TEACH ? WORD_MAX : VOICE_MAX, &len);
    if (r == VO_SILENT) { msg_open("Микрофон молчит", "Игра не слышит ни звука. Проверь, что микрофон подключён и включён и что игре разрешено им пользоваться (в настройках системы или браузера)."); return; }
    if (r != VO_OK) { pet_bubble(r == VO_QUIET ? "Не слышу! Скажи погромче" : "Ничего не записалось", 2.6f); PT.no_t = 0.8f; return; }
    voice_ready(len);
    if (mode == LS_TEACH && PT.listen_w >= 0 && PT.listen_w < WORD_N) {
        int w = PT.listen_w, was = WD.have[w]; char b[100];
        words_load(); word_store(w, len); PT.show_w = w; PT.show_t = 3.0f;
        if ((u32)words_known() > HM.cn[C6_WORDS]) HM.cn[C6_WORDS] = (u32)words_known();
        if (!was) pet_xp(10, XD_WORD, 3);
        pet_add(ND_JOY, 4); pet_tire(4, 1); snprintf(b, sizeof(b), was ? "Запомнил по-новому: «%s»" : "Выучил слово «%s»!", word_tab[w].name); gtoast(b); sfx(S_STAR2, 0.6f, 640);
        ach6_check(); home_dirty();
    } else { HM.cn[C6_TALKS]++; mis_kind(MK_PLAY, 1); pet_xp(2, XD_TALK, 10); pet_add(ND_JOY, 2); pet_tire(4, 1); home_dirty(); }
    pet_speak(0.3f);
}
static void pet_drink_done(int d) {
    const DrinkDef *q = &drink_tab[d];
    for (int k = 0; k < ND_N; k++) pet_add(k, q->fx[k]);
    if (!q->price) HM.bought[d]++;                                                       /* (water is free: it is "bought" as it is drunk) */
    HM.used[d]++; HM.cn[C6_FEEDS]++; mis_kind(MK_FEED, 1); pet_xp(3, XD_DRINK, 8);
    if (q->alc) { PT.tipsy_t = 45.0f; pet_bubble("Ик!.. Ой.", 2.2f); }
    else if (q->fx[ND_HEALTH] < -3) pet_bubble("Вкусно! Только животик урчит...", 2.6f);
    else if (q->fx[ND_JOY] >= 12) { pet_bubble("Ух ты, вкуснятина!", 2.2f); PT.jump_t = 0.6f; }
    else if (q->fx[ND_ENERGY] >= 25) { pet_bubble("Я полон сил!", 2.2f); PT.jump_t = 0.6f; }
    else pet_bubble(d == 1 ? "Водичка! Спасибо." : "Спасибо!", 2.0f);
    pet_hearts(KG.hx, KG.hy - 60, 3); ach6_check(); home_dirty();
}
static void pet_give(int d) {
    if (pet_busy()) return;
    if (HM.asleep) { pet_bubble("Тсс! Я сплю...", 2.0f); return; }
    if (drink_tab[d].alc && pet_age() < ADULT_AGE) { pet_bubble("Мне такое нельзя! Я ещё маленький.", 2.6f); PT.no_t = 0.9f; sfx(S_FAIL, 0.4f, 640); return; }
    if (drink_tab[d].price && drink_left(d) <= 0) return;
    if (HM.need[ND_THIRST] >= 9900 && drink_tab[d].fx[ND_THIRST] > 0) { pet_bubble("Я напился! Давай лучше поиграем.", 2.6f); PT.no_t = 0.9f; return; }
    PT.sip_t = 1.9f; PT.sip_d = d; PT.bubble_t = 0;
    for (int w = 0; w < WORD_N; w++) if (word_tab[w].skin == drink_skin(d) && WD.have[w]) { pet_say_word(w, 0.05f); break; }      /* he knows what this is called */
}
static void pet_buy(int d) {
    const DrinkDef *q = &drink_tab[d]; char b[150];
    if (!q->price) return;
    if (q->alc && pet_age() < ADULT_AGE) { pet_bubble("Это для взрослых. Мне такое нельзя!", 2.6f); PT.no_t = 0.9f; return; }
    if (coins() < q->price) { snprintf(b, sizeof(b), "«%s» стоит %d, а у тебя %d. Чекушки дают за задания.", drink_name(d), q->price, coins()); gtoast(b);      /* (at most about 115 bytes) */ sfx(S_FAIL, 0.4f, 640); return; }
    if (HM.bought[d] >= 60000) return;
    HM.bought[d]++; sfx(S_STAR1, 0.6f, 1000); home_dirty();
}
static void pet_sleep_toggle(void) {
    if (pet_busy()) return;
    if (HM.asleep) { HM.asleep = 0; pet_bubble(HM.need[ND_ENERGY] > 8000 ? "Доброе утро!" : "Я ещё не выспался...", 2.2f); }
    else if (HM.need[ND_ENERGY] >= 9500) { pet_bubble("Я не хочу спать! Давай играть.", 2.4f); PT.no_t = 0.9f; return; }
    else { HM.asleep = 1; HM.cn[C6_SLEEPS]++; mis_kind(MK_SLEEP, 1); PT.tray = TR_NONE; }
    sfx(S_CLICK, 0.6f, 640); home_dirty();
}
static void pet_enter(int a) {
    (void)a; words_load(); pet_clock(); month_refresh();
    if (!S_voice) { S_voice = snd_new(VOICE_MAX, VOICE_RATE); if (S_voice) S_voice->n = 1; }
    if (!PT.inited) { PT.inited = 1; PT.sel_d = -1; PT.sel_w = -1; PT.show_w = -1; PT.sip_d = -1; }
    PT.tray = TR_NONE; PT.listen = LS_NONE; PT.sip_t = 0; PT.talk_len = 0; PT.grow = 0; PT.bubble_t = 0; PT.chatter_t = rnd_range(14, 26); PT.cam = 0; HK.inited = 0;
    if (home_on() && HM.seen_age > pet_age()) HM.seen_age = (u8)pet_age();
}
static void pet_music(float k) { if (g_music_k != k) { g_music_k = k; apply_volumes(); } }
static void pet_leave(void) { if (PT.listen) pet_listen_stop(1); plat_ctl(PC_MIC, NULL, MIC_CLOSE, 0); pet_music(1.0f); }

/* a round gauge: how full a need is */
static void need_gauge(int k, float x, float y) {
    static const u32 col[ND_N] = { 0x4FB6FFFFu, 0xFFC93CFFu, 0xFF5A7AFFu, 0x6FE36AFFu }; static const char *const nm[ND_N] = { "Жажда", "Бодрость", "Здоровье", "Радость" };
    int pct = pet_pct(k); float f = (float)pct / 100.0f, r = 33; u32 c = pct < 25 ? (fmodf(g_time, 0.8f) < 0.4f ? 0xFF4040FFu : col[k]) : col[k];
    gfx_circle(x, y, r + 5, 0x0E0A2EE0u); gfx_circle(x, y, r, 0x2A2260FFu);
    gfx_clip(x - r, y + r - 2 * r * f, 2 * r, 2 * r * f); gfx_circle(x, y, r, c); gfx_clip_reset();
    d_at(x, y, 1.0f, 0);
    if (k == ND_THIRST) { d_circ(0, 5, 11, 0xFFFFFFFFu); d_tri(-9.5f, 0, 9.5f, 0, 0, -18, 0xFFFFFFFFu); }
    else if (k == ND_ENERGY) { d_quad(3, -18, -11, 3, -1, 3, -4, 18, 0xFFFFFFFFu); d_quad(-4, 18, 11, -4, 1, -4, 3, -18, 0xFFFFFFFFu); }
    else if (k == ND_HEALTH) { d_circ(-7, -5, 8.5f, 0xFFFFFFFFu); d_circ(7, -5, 8.5f, 0xFFFFFFFFu); d_tri(-14.5f, -1, 14.5f, -1, 0, 16, 0xFFFFFFFFu); }
    else { d_ring(0, 0, 14, 3, 0xFFFFFFFFu); d_circ(-5, -4, 2.2f, 0xFFFFFFFFu); d_circ(5, -4, 2.2f, 0xFFFFFFFFu); d_curve(-7, 3, 0, 10, 7, 3, 1.5f, 0xFFFFFFFFu); }
    gfx_text(&F_ui, nm[k], x + 46, y - 11, 19, WHITE, AL_LEFT); { char b[16]; snprintf(b, sizeof(b), "%d%%", pct); gfx_text(&F_ui, b, x + 46, y + 13, 22, pct < 25 ? 0xFF8B7AFFu : C_GOLD, AL_LEFT); }
}
static void fx_line(const DrinkDef *q, float x, float y) {      /* what a drink does, in four small numbers */
    static const char *const nm[ND_N] = { "жажда", "бодрость", "здоровье", "радость" }; char b[40];
    for (int k = 0; k < ND_N; k++) { int v = q->fx[k]; float cx = x + (float)(k % 2) * 172, cy = y + (float)(k / 2) * 26; snprintf(b, sizeof(b), "%s %s%d", nm[k], v > 0 ? "+" : (v < 0 ? "-" : ""), v < 0 ? -v : v); gfx_text(&F_txt, b, cx, cy, 20, v > 0 ? 0x9CF06AFFu : (v < 0 ? 0xFF8B7AFFu : 0xFFFFFF80u), AL_LEFT); }
}
static const char *age_text(int age, char *b, int n) { snprintf(b, (size_t)n, "%d %s", age, plural(age, "год", "года", "лет")); return b; }

/* ---------------- the stairs of ages: he jumps up a step for every birthday ---------------- */
static int grow_last;
static void grow_start(void) {
    grow_last = 0;
    int to = pet_age(), from = HM.seen_age; if (to <= from || PT.grow) return;
    if (to - from > 6) from = to - 6;                                                    /* (many birthdays at once: the last six are shown) */
    PT.grow = 1; PT.grow_t = 0; PT.grow_from = from; PT.grow_to = to; PT.grow_gift = 0; for (int a = HM.seen_age + 1; a <= to; a++) PT.grow_gift += 5 + a;
    PT.tray = TR_NONE; sfx(S_START, 0.6f, 640);
}
static void grow_finish(void) { HM.seen_age = (u8)(PT.grow_to > 199 ? 199 : PT.grow_to); HM.earned += (u32)PT.grow_gift; PT.grow = 0; ach6_check(); home_dirty(); }
static void grow_draw(void) {
    float t = PT.grow_t, hop = 1.05f, t0 = 0.8f; int steps = PT.grow_to - PT.grow_from; float pos = clampf((t - t0) / hop, 0, (float)steps);      /* how many steps he has climbed */
    int done = t >= t0 + hop * (float)steps; float fr = pos - floorf(pos), k = done ? 0 : ease_in_out(clampf(fr / 0.72f, 0, 1)), cur = floorf(pos) + (done ? 0 : k), jump = done ? 0 : sinf(clampf(fr / 0.72f, 0, 1) * PI) * 92;
    int st = (int)floorf(pos + 0.28f);
    char b[120], ab[40]; Kid kd;
    gfx_fade(0x0A0C2CE6u);
    for (int i = -3; i <= 7; i++) {                                                      /* the stairs slide past: he stays in the middle */
        int age = PT.grow_from + (int)floorf(cur) + i; float rel = (float)(PT.grow_from + (int)floorf(cur) + i - PT.grow_from) - cur, x = 640 + rel * 176, y = 560 - rel * 54; int gold = age == 3 || age == 7 || age == 13 || age == 18 || age == 30 || age == 60;
        if (age < 0) continue;
        gfx_rrect(x - 92, y, 184, 400, 10, OLC); gfx_rrect_grad(x - 88, y + 4, 176, 400, 8, gold ? 0xFFE06AFFu : (age & 1 ? 0x8E6BE8FFu : 0xA98BFFFFu), gold ? 0xD9930FFFu : 0x4A32B0FFu);
        gfx_rect(x - 88, y + 4, 176, 7, 0xFFFFFF50u); snprintf(b, sizeof(b), "%d", age); gfx_text(&F_ui, b, x, y + 44, 44, WHITE, AL_CENTER);
        if (gold) gfx_text(&F_txt, pet_stage(age), x, y + 82, 17, 0xFFFFFFE0u, AL_CENTER);
    }
    kid_simple(&kd, (float)PT.grow_from + cur, HM.wear, g_time); kd.smile = 1; kd.mouth = jump > 10 ? 0.7f : 0.0f; kd.arm[0] = kd.arm[1] = 0.3f + jump / 92.0f * 1.8f; kd.fore[0] = kd.fore[1] = 0.25f;
    if (done) { kd.arm[0] = kd.arm[1] = 2.1f + sinf(g_time * 9) * 0.2f; kd.mouth = 0.6f; }
    kid_draw(640, 560 - jump - (done ? fabsf(sinf(g_time * 5.0f)) * 14 : 0), 1.0f, &kd);
    if (st != grow_last) { if (st > 0 && st <= steps && t > t0) { sfx_p(S_STAR1 + (st % 3), 0.7f, 640, 1.0f + 0.06f * (float)st); fx_confetti(540, 740, 380, 14); } grow_last = st; }
    if (!done) { title_text("Мел растёт!", 640, 86, 50); gfx_text(&F_txt, "Лестница возрастов", 640, 132, 24, 0xFFFFFFD0u, AL_CENTER); return; }
    if (t - g_dt < t0 + hop * (float)steps) { sfx_p(S_WIN, 0.8f, 640, 1.0f); fx_confetti(100, 1180, -10, 80); }
    snprintf(b, sizeof(b), "Мелу исполнилось %s!", age_text(PT.grow_to, ab, sizeof(ab))); title_text(b, 640, 86, 50);
    snprintf(b, sizeof(b), "Теперь он: %s. Подарок на день рождения: %d %s", pet_stage(PT.grow_to), PT.grow_gift, plural(PT.grow_gift, "чекушка", "чекушки", "чекушек")); gfx_text(&F_txt, b, 640, 134, 24, 0xFFFFFFE0u, AL_CENTER);
    if (PT.grow_to == ADULT_AGE || (PT.grow_from < ADULT_AGE && PT.grow_to > ADULT_AGE)) gfx_text(&F_txt, "Он совсем взрослый: теперь ему можно и взрослые напитки", 640, 166, 21, C_GOLD, AL_CENTER);
    if (t > t0 + hop * (float)steps + 0.7f && wbtn(2340, 1040, 640, 260, 70, "Ура!", C_GREEN1, C_GREEN2, 36, IC_OK, 1)) grow_finish();
}

/* ---------------- the screen ---------------- */
static const u8 drink_order[DRINK_N] = { 1, 14, 11, 10, 12, 2, 3, 4, 13, 5, 15, 16, 17, 6, 18, 19, 7, 8, 0, 9 };      /* cheap first, the grown-up ones last */
static void scr_pet(void) {
    float dt = g_dt, nk = night_k(); int age, into, need, big; char b[160], ab[40]; Kid k;
    if (!home_on()) { go(SC_CITY, 0, 0); return; }
    big = HM.big; age = pet_age_of(HM.xp, &into, &need);
    if (!pet_busy() && age > HM.seen_age) grow_start();
    /* ----- time passes ----- */
    if (HM.asleep) {                                                                     /* while the player watches, a nap takes a minute and a half at most */
        PT.nap += dt * 100.0f;
        if (PT.nap >= 1.0f) { int add = (int)PT.nap, v = (int)HM.need[ND_ENERGY] + add; PT.nap -= (float)add; if (v >= 10000) { v = 10000; HM.asleep = 0; pet_bubble("Я выспался!", 2.4f); PT.jump_t = 0.6f; home_dirty(); } HM.need[ND_ENERGY] = (u16)v; }
    }
    if (PT.tipsy_t > 0) PT.tipsy_t -= dt; if (PT.jump_t > 0) PT.jump_t -= dt; if (PT.no_t > 0) PT.no_t -= dt; if (PT.bubble_t > 0) PT.bubble_t -= dt; if (PT.show_t > 0) PT.show_t -= dt; if (PT.wave_t > 0) PT.wave_t -= dt;
    if (PT.sip_t > 0 && PT.talk_len <= 0) { float was = PT.sip_t; PT.sip_t -= dt; if (was > 1.0f && PT.sip_t <= 1.0f) sfx(S_GULP, 0.8f, 640); if (PT.sip_t <= 0) { PT.sip_t = 0; pet_drink_done(PT.sip_d); } }
    if (PT.talk_len > 0) {
        if (PT.talk_wait > 0) { PT.talk_wait -= dt; if (PT.talk_wait <= 0) { if (SV.sound) snd_play(S_voice, 1.0f, 0, PT.talk_pitch); else gtoast("Звук выключен: включи его, чтобы услышать Мела"); } }
        else { PT.talk_t += dt; if (PT.talk_t >= PT.talk_len + 0.15f) PT.talk_len = 0; }
    }
    if (PT.listen) {
        int ms = mic_state();
        if (PT.wait_t > 0) { PT.wait_t += dt; if (PT.wait_t > 4.0f) { PT.listen = LS_NONE; PT.wait_t = 0; pet_bubble("Ничего не записалось", 2.2f); } }      /* stopped: the recording is on its way */
        else if (ms == 2) { PT.listen = LS_NONE; msg_open("Микрофон", "Игре нельзя пользоваться микрофоном. Разреши доступ к микрофону (в браузере — значок замка возле адреса, на телефоне — в настройках приложения) и попробуй ещё раз."); }
        else if (ms == 3) {
            int lv = plat_ctl(PC_MIC, NULL, MIC_LEVEL, 0); PT.listen_t += dt;
            if (lv > 14) { PT.mic_seen_loud = 1; PT.quiet_t = 0; } else PT.quiet_t += dt;
            if ((PT.mic_seen_loud && PT.quiet_t > 0.9f && PT.listen_t > 0.6f) || PT.listen_t > (PT.listen == LS_TEACH ? 2.4f : 4.4f)) pet_listen_stop(0);
        }
    }
    pet_music(PT.listen ? 0.0f : (PT.talk_len > 0 ? 0.25f : 1.0f));                       /* (the microphone must hear the player, not the tune) */
    if (!pet_busy() && !HM.asleep && !PT.tray) {                                          /* now and then he says a word he knows, by himself */
        PT.chatter_t -= dt;
        if (PT.chatter_t <= 0) { int kn[WORD_N], n = 0; PT.chatter_t = rnd_range(18, 34); for (int w = 0; w < WORD_N; w++) if (WD.have[w]) kn[n++] = w; if (n && SV.sound) pet_say_word(kn[rnd_u32() % (u32)n], 0.05f); }
    }
    /* ----- the room around him ----- */
    { float z = clampf(300.0f / (kid_height((float)age) * KID_S), 1.25f, 2.1f), want = PT.tray ? -210.0f : 0.0f; PT.cam += (want - PT.cam) * minf(1.0f, dt * 8.0f);
      hk_update(&HM, dt, 1); rv_set(z, (640 + PT.cam) / z - HK.x, 600 / z - kid_floor_y(big)); }
    sky_draw(nk); rv_on(); house_draw(&HM, nk, HM.asleep ? 1.0f : 0.0f, -1);
    /* ----- Mel ----- */
    kid_simple(&k, (float)age, HM.wear, g_time);
    { float mxr = rv_x(P.x) - HK.x, myr = rv_y(P.y) - (kid_floor_y(big) - kid_height((float)age) * KID_S * 0.8f); k.lookx = clampf(mxr / 300.0f, -1, 1); k.looky = clampf(myr / 300.0f, -1, 1); }
    if (HM.asleep) k.state |= KS_ASLEEP;
    else {
        if (HM.need[ND_THIRST] < 2500) k.state |= KS_THIRSTY; if (HM.need[ND_HEALTH] < 3000) k.state |= KS_SICK; if (HM.need[ND_ENERGY] < 2500) k.state |= KS_TIRED; if (PT.tipsy_t > 0) k.state |= KS_TIPSY;
        k.smile = HM.need[ND_JOY] < 2500 ? -0.7f : (HM.need[ND_JOY] < 5000 ? 0.1f : 0.9f);
        if (PT.tipsy_t > 0) { k.lean = sinf(g_time * 1.7f) * 0.5f; k.tilt = sinf(g_time * 1.3f) * 0.2f; }
        if (PT.no_t > 0) { k.tilt = sinf(PT.no_t * 22.0f) * 0.22f; k.smile = -0.5f; }
        if (PT.sip_t > 0 && PT.talk_len <= 0) { float u = PT.sip_t > 1.5f ? (1.9f - PT.sip_t) / 0.4f : (PT.sip_t < 0.3f ? PT.sip_t / 0.3f : 1.0f); k.drink = PT.sip_d; k.sip = clampf(u, 0.02f, 1); k.arm[1] = 0.3f + 1.9f * k.sip; k.fore[1] = 1.0f * k.sip; k.mouth = 0.45f * k.sip; k.looky = 0.2f; k.lookx = 0.4f; }
        else if (PT.sip_t > 0) { k.drink = PT.sip_d; k.sip = 0.02f; k.arm[1] = 1.2f; k.fore[1] = 0.8f; }
        if (PT.talk_len > 0 && PT.talk_wait <= 0) { int i = (int)(PT.talk_t * PT.talk_pitch * 25.0f); float e = i >= 0 && i < voice_env_n ? (float)voice_env[i] / 200.0f : 0; k.mouth = clampf(e * 1.4f, 0, 1); k.arm[0] = 0.5f + e * 0.6f; k.arm[1] = 0.5f + e * 0.6f; }
        if (PT.listen) { k.arm[0] = 2.2f; k.fore[0] = 1.2f; k.tilt = -0.16f; k.lookx = -0.6f; k.mouth = 0.12f; }      /* a hand at his ear */
        if (PT.wave_t > 0) { k.arm[1] = 2.2f + sinf(g_time * 9.0f) * 0.3f; k.fore[1] = 0.3f; k.mouth = 0.5f; }
    }
    if (!PT.grow) { float jy = PT.jump_t > 0 ? sinf((0.6f - PT.jump_t) / 0.6f * PI) * 34 : 0; kid_draw(HK.x, kid_floor_y(big) - jy, KID_S, &k); }
    KG.hx = sc_x(KG.hx); KG.hy = sc_y(KG.hy); KG.top = sc_y(KG.top); KG.mouthx = sc_x(KG.mouthx); KG.mouthy = sc_y(KG.mouthy); KG.R *= RV.z;      /* where his head is on the screen (he was drawn in the units of the room) */
    for (int i = 0; i < 2; i++) { KG.handx[i] = sc_x(KG.handx[i]); KG.handy[i] = sc_y(KG.handy[i]); }
    rv_off();
    if (PT.grow) { PT.grow_t += dt; grow_draw(); parts_draw(); return; }
    /* ----- stroking and poking ----- */
    if (!ui_block && !HM.asleep && !PT.listen && P.x < (PT.tray ? 860.0f : 1120.0f) && P.x > 190) {
        int on_him = fabsf(P.x - KG.hx) < KG.R * 1.5f && P.y > KG.top - 10 && P.y < 610;
        if (P.down && on_him) { static float lx, ly; if (P.pressed) { lx = P.x; ly = P.y; } PT.stroke += fabsf(P.x - lx) + fabsf(P.y - ly); lx = P.x; ly = P.y;
            if (PT.stroke > 240) { PT.stroke = 0; PT.strokes++; pet_hearts(KG.hx, KG.top, 2); pet_add(ND_JOY, 2); sfx_p(S_STAR1, 0.35f, P.x, 1.3f); if (PT.strokes % 3 == 0) { mis_kind(MK_PLAY, 1); HM.cn[C6_PLAYS]++; pet_xp(2, XD_PLAY, 10); pet_tire(3, 1); home_dirty(); } } }
        if (P.tapped && on_him && !pet_busy()) { PT.jump_t = 0.6f; PT.pokes++; pet_add(ND_JOY, 1); pet_tire(1, 0); if (PT.pokes % 4 == 1 && speech_on()) snd_play(SND[V_LAUGH], 0.7f, 0, pet_pitch(age)); else sfx_p(S_BUBBLE, 0.5f, P.x, 1.2f); }
    }
    for (int i = 0; i < 10; i++) if (PT.heart[i].t > 0) { float u = 1 - PT.heart[i].t, hx = PT.heart[i].x + sinf(u * 6 + (float)i) * 10, hy = PT.heart[i].y - u * 90, hs = (0.6f + 0.4f * sinf(u * PI)) * 1.1f; u32 c = color_alpha(0xFF5A7AFFu, minf(1, PT.heart[i].t * 2));
        PT.heart[i].t -= dt; gfx_circle(hx - 7 * hs, hy - 5 * hs, 8.5f * hs, c); gfx_circle(hx + 7 * hs, hy - 5 * hs, 8.5f * hs, c); gfx_tri(hx - 14.5f * hs, hy - 1 * hs, hx + 14.5f * hs, hy - 1 * hs, hx, hy + 16 * hs, c); }
    /* ----- what he says ----- */
    if (PT.show_t > 0 && PT.show_w >= 0) { float sx = KG.hx + KG.R * 1.9f, sy = KG.hy - KG.R * 0.9f; gfx_circle(sx, sy, 62, 0xFFFFFFF0u); gfx_circle(sx - 56, sy + 52, 12, 0xFFFFFFF0u); gfx_circle(sx - 76, sy + 74, 6, 0xFFFFFFF0u); word_pic(PT.show_w, sx, sy - 6, 78); gfx_text(&F_ui, word_tab[PT.show_w].name, sx, sy + 44, 19, C_INK, AL_CENTER); }
    else if (PT.bubble_t > 0) { float tw = gfx_text_w(&F_ui, PT.bubble, 24) + 44, bx = clampf(KG.hx, tw * 0.5f + 190, (PT.tray ? 860.0f : 1110.0f) - tw * 0.5f), by = KG.top - 44, a = minf(1, PT.bubble_t * 3);
        gfx_rrect(bx - tw * 0.5f, by - 27, tw, 54, 27, color_alpha(0xFFFFFFFFu, a)); gfx_tri(KG.hx - 12, by + 25, KG.hx + 12, by + 25, KG.hx, by + 44, color_alpha(0xFFFFFFFFu, a)); gfx_text(&F_ui, PT.bubble, bx, by, 24, color_alpha(C_INK, a), AL_CENTER); }
    if (PT.listen) {
        int ms = mic_state(), lv = plat_ctl(PC_MIC, NULL, MIC_LEVEL, 0); const char *tx = PT.wait_t > 0 ? "Секунду..." : (ms == 3 ? (PT.listen == LS_TEACH ? "Скажи слово!" : "Говори! Мел слушает") : "Разреши игре слушать микрофон");
        gfx_rrect(640 - 260 + PT.cam, 96, 520, 64, 32, 0x0E0A2EE8u); gfx_circle(640 - 222 + PT.cam, 128, 16 + (float)lv * 0.12f, ms == 3 ? 0xFF4040FFu : 0x8A8FA6FFu); gfx_text(&F_ui, tx, 640 + 16 + PT.cam, 128, 26, WHITE, AL_CENTER);
        if (PT.listen == LS_TEACH && PT.listen_w >= 0) word_pic(PT.listen_w, KG.hx + KG.R * 2.0f, KG.hy, 110);
    }
    /* ----- the top line and the gauges ----- */
    back_button(SC_HOUSE, 0);
    snprintf(b, sizeof(b), "Мел  •  %s  •  %s", age_text(age, ab, sizeof(ab)), pet_stage(age));
    { float tw = gfx_text_w(&F_ui, b, 28) + 60; if (tw < 420) tw = 420; gfx_rrect(640 - tw * 0.5f, 22, tw, 62, 20, 0x0E0A2ED8u); gfx_text(&F_ui, b, 640, 42, 28, WHITE, AL_CENTER);
      gfx_rrect(640 - 180, 62, 360, 12, 6, 0x2A2260FFu); if (into > 0) gfx_rrect(640 - 180, 62, maxf(12, 360.0f * (float)into / (float)need), 12, 6, C_GREEN1); }
    coin_badge(1250, 52);
    gfx_rrect(12, 118, 222, 384, 26, 0x0E0A2EA8u); for (int i = 0; i < ND_N; i++) need_gauge(i, 62, 172 + (float)i * 92);
    /* ----- the buttons ----- */
    { static const char *const lb[5] = { "Напитки", "Говорить", "Слова", "Одежда", "Спать" }; float y = 676; int sleepy = HM.asleep;
      if (wbtn(2320, 150, y, 216, 60, lb[0], 0x6FE3D2FFu, 0x1C8F86FFu, 24, IC_SHOP, !sleepy)) { PT.tray = PT.tray == TR_DRINKS ? TR_NONE : TR_DRINKS; }
      if (wbtn(2321, 376, y, 216, 60, PT.listen == LS_REPEAT ? "Стоп" : lb[1], PT.listen == LS_REPEAT ? C_RED1 : C_GREEN1, PT.listen == LS_REPEAT ? C_RED2 : C_GREEN2, 24, IC_SOUND, !sleepy && (PT.listen == LS_REPEAT || !pet_busy()))) { if (PT.listen == LS_REPEAT) pet_listen_stop(0); else { PT.tray = TR_NONE; pet_listen(LS_REPEAT, -1); } }
      if (wbtn(2322, 602, y, 216, 60, lb[2], C_ORG1, C_ORG2, 24, IC_EDIT, !sleepy)) { PT.tray = PT.tray == TR_WORDS ? TR_NONE : TR_WORDS; }
      if (wbtn(2323, 828, y, 216, 60, lb[3], C_PINK, 0xB8257FFFu, 24, IC_USER, !pet_busy())) go(SC_WARD, 0, 0);
      if (wbtn(2324, 1054, y, 216, 60, sleepy ? "Разбудить" : lb[4], C_VIO1, C_VIO2, 24, IC_MUSIC_OFF, 1)) pet_sleep_toggle(); }
    /* ----- the fridge ----- */
    if (PT.tray == TR_DRINKS) {
        int pages = (DRINK_N + 8) / 9; float px = 872, py = 98;
        panel(px, py, 392, 536); gfx_text(&F_ui, "Напитки", px + 196, py + 30, 28, WHITE, AL_CENTER);
        if (PT.page >= pages) PT.page = pages - 1; if (PT.page < 0) PT.page = 0;
        if (rbtn(2326, px + 40, py + 30, 20, IC_BACK, C_VIO1, C_VIO2, PT.page > 0)) PT.page--;
        if (rbtn(2327, px + 352, py + 30, 20, IC_NEXT, C_VIO1, C_VIO2, PT.page < pages - 1)) PT.page++;
        for (int i = 0; i < 9 && PT.page * 9 + i < DRINK_N; i++) {
            int d = drink_order[PT.page * 9 + i], left = drink_left(d), kid = drink_tab[d].alc && age < ADULT_AGE; float cx = px + 74 + (float)(i % 3) * 122, cy = py + 108 + (float)(i / 3) * 102; const Image *im = skin_pic(drink_skin(d)); float s = 70.0f / ((float)im->h / im->scale);
            int hit = btn_logic(2350 + i, cx, cy, 114, 98, 1);
            gfx_rrect(cx - 57, cy - 49, 114, 98, 14, PT.sel_d == d ? 0x6A4FE0FFu : 0x2A2068FFu); if (PT.sel_d == d) gfx_rrect(cx - 57, cy - 49, 114, 5, 2, C_GOLD);
            gfx_image_ex(im, cx - 22, cy - 6, s, s, 0, kid ? 0.35f : 1.0f); text_fit(&F_txt, drink_name(d), cx, cy + 38, 16, 108, WHITE, AL_CENTER);
            if (kid) gfx_text(&F_ui, "18+", cx + 24, cy - 8, 22, 0xFF8B7AFFu, AL_CENTER);
            else if (!drink_tab[d].price) { gfx_ring(cx + 19, cy - 8, 7.5f, 3.4f, C_CYAN); gfx_ring(cx + 33, cy - 8, 7.5f, 3.4f, C_CYAN); }      /* (as much as he likes) */
            else if (left > 0) { snprintf(b, sizeof(b), "×%d", left); gfx_text(&F_ui, b, cx + 26, cy - 8, 24, C_GREEN1, AL_CENTER); }
            else { snprintf(b, sizeof(b), "%d", drink_tab[d].price); gfx_text(&F_ui, b, cx + 22, cy - 8, 22, C_GOLD, AL_CENTER); gfx_image_ex(I_bottle, cx + 44, cy - 8, 0.3f, 0.3f, 0.2f, 1); }
            if (hit) PT.sel_d = d;
        }
        if (PT.sel_d >= 0) {
            int d = PT.sel_d, left = drink_left(d), pr = drink_tab[d].price, kid = drink_tab[d].alc && age < ADULT_AGE; float y = py + 398;
            gfx_text(&F_ui, drink_name(d), px + 24, y, 23, C_GOLD, AL_LEFT); fx_line(&drink_tab[d], px + 24, y + 27);
            if (kid) gfx_text(&F_txt, "Только для взрослого Мела: с 18 лет", px + 196, y + 100, 20, 0xFF8B7AFFu, AL_CENTER);
            else {
                snprintf(b, sizeof(b), pr ? "Дать (×%d)" : "Дать", left);
                if (wbtn(2328, px + (pr ? 104.0f : 196.0f), y + 100, pr ? 176.0f : 300.0f, 48, b, C_GREEN1, C_GREEN2, 22, IC_NONE, (!pr || left > 0) && !pet_busy())) pet_give(d);
                if (pr) { snprintf(b, sizeof(b), "Купить: %d", pr); if (wbtn(2329, px + 290, y + 100, 176, 48, b, 0xFFE06AFFu, 0xD9930FFFu, 22, IC_NONE, 1)) pet_buy(d); }
            }
        } else gfx_text(&F_txt, "Выбери напиток", px + 196, py + 462, 22, 0xFFFFFFB0u, AL_CENTER);
    }
    /* ----- the words ----- */
    if (PT.tray == TR_WORDS) {
        float px = 872, py = 98; panel(px, py, 392, 536); gfx_text(&F_ui, "Учим слова", px + 196, py + 30, 28, WHITE, AL_CENTER);
        for (int w = 0; w < WORD_N; w++) {
            float cx = px + 74 + (float)(w % 3) * 122, cy = py + 104 + (float)(w / 3) * 92; int hit = btn_logic(2360 + w, cx, cy, 114, 84, 1);
            gfx_rrect(cx - 57, cy - 42, 114, 84, 14, PT.sel_w == w ? 0x6A4FE0FFu : 0x2A2068FFu); word_pic(w, cx - 24, cy - 2, 58);
            text_fit(&F_txt, word_tab[w].name, cx + 22, cy + 22, 16, 64, WHITE, AL_CENTER);
            if (WD.have[w]) { gfx_circle(cx + 36, cy - 20, 13, C_GREEN2); icon(IC_OK, cx + 36, cy - 20, 16, WHITE); }
            if (hit) { PT.sel_w = w; if (WD.have[w] && !pet_busy()) pet_say_word(w, 0.05f); else { PT.show_w = w; PT.show_t = 2.0f; PT.bubble_t = 0; } }
        }
        if (PT.sel_w >= 0) {
            int w = PT.sel_w; float y = py + 456;
            snprintf(b, sizeof(b), WD.have[w] ? "«%s»: Мел знает это слово" : "«%s»: Мел ещё не знает", word_tab[w].name); gfx_text(&F_txt, b, px + 196, y - 20, 20, WD.have[w] ? 0x9CF06AFFu : 0xFFFFFFD0u, AL_CENTER);
            if (PT.listen == LS_TEACH) { if (wbtn(2331, px + 196, y + 30, 300, 54, "Стоп", C_RED1, C_RED2, 24, IC_SOUND, 1)) pet_listen_stop(0); }
            else if (wbtn(2331, px + 196, y + 30, 300, 54, WD.have[w] ? "Научить заново" : "Научить: скажи слово", C_GREEN1, C_GREEN2, 22, IC_SOUND, !pet_busy())) pet_listen(LS_TEACH, w);
        } else gfx_text_wrap(&F_txt, "Покажи Мелу предмет и скажи в микрофон, как он называется. Мел запомнит слово и будет его повторять.", px + 196, py + 446, 19, 340, 24, 0xFFFFFFD0u, AL_CENTER, 1);
    }
    parts_draw();
}

/* ============================== the clothes shop ============================== */
static struct { int slot, sel; u8 try_on[SL_N]; } WR;
static void ward_enter(int a) { (void)a; WR.sel = -1; memcpy(WR.try_on, HM.wear, SL_N); }
static void ward_wear(int c) {                       /* put on, or take off when it is on already */
    int sl = cloth_tab[c].slot; HM.wear[sl] = HM.wear[sl] == c + 1 ? 0 : (u8)(c + 1); HM.wear_rev++; memcpy(WR.try_on, HM.wear, SL_N); sfx(S_ATTACH, 0.6f, 640); home_dirty();
}
static void ward_buy(int c) {
    if (cloth_has(&HM, c) || coins() < cloth_tab[c].price) return;
    HM.cloth[c >> 5] |= 1u << (c & 31); sfx_p(S_WIN, 0.6f, 640, 1.3f); fx_confetti(120, 460, 80, 30); ach6_check(); home_dirty(); ward_wear(c);
}
static void scr_ward(void) {
    char b[120]; int age, list[CLOTH_N], n = 0; Kid k;
    if (!home_on()) { go(SC_CITY, 0, 0); return; }
    age = pet_age(); bg_draw(0, 0.5f, DECO_MENU, 0, 0, 0);
    back_button(SC_PET, 0); title_text("Магазин одежды", 640, 50, 42); coin_badge(1250, 52);
    /* Mel in front of the mirror */
    gfx_rrect_grad(60, 104, 380, 520, 28, 0x4A3AA8FFu, 0x241A62FFu); gfx_ellipse(250, 574, 150, 26, 0x00000050u); gfx_rrect(84, 122, 332, 12, 6, 0xFFFFFF30u);
    kid_simple(&k, (float)age, WR.try_on, g_time); k.arm[0] = 0.5f; k.arm[1] = 0.5f; k.lookx = clampf((P.x - 250) / 400.0f, -1, 1);
    { float s = minf(2.1f, 410.0f / kid_height((float)age)); kid_draw(250, 572, s, &k); }
    /* the shelves */
    for (int i = 0; i < SL_N; i++) { float x = 520 + (float)i * 122; if (wbtn(2370 + i, x, 126, 114, 46, slot_name[i], WR.slot == i ? C_GOLD : C_VIO1, WR.slot == i ? 0xD9930FFFu : C_VIO2, 20, IC_NONE, 1)) { WR.slot = i; WR.sel = -1; memcpy(WR.try_on, HM.wear, SL_N); } }
    for (int c = 0; c < CLOTH_N; c++) if (cloth_tab[c].slot == WR.slot) list[n++] = c;
    for (int i = 0; i < n; i++) {
        int c = list[i], has = cloth_has(&HM, c), on = HM.wear[WR.slot] == c + 1; float cx = 545 + (float)(i % 5) * 148, cy = 262 + (float)(i / 5) * 190; Kid m; u8 w1[SL_N];
        int hit = btn_logic(2380 + i, cx, cy, 138, 176, 1);
        gfx_rrect(cx - 69, cy - 88, 138, 176, 16, WR.sel == c ? 0x6A4FE0FFu : 0x2A2068FFu); if (on) gfx_rrect(cx - 69, cy - 88, 138, 6, 3, C_GREEN1);
        memset(w1, 0, sizeof(w1)); w1[WR.slot] = (u8)(c + 1); kid_simple(&m, 9.0f, w1, 0); m.blink = 0;
        gfx_clip(cx - 66, cy - 84, 132, 122);
        if (WR.slot == SL_HAT) kid_draw(cx, cy + 236, 1.0f, &m); else if (WR.slot == SL_EYES) kid_draw(cx, cy + 212, 1.0f, &m); else if (WR.slot == SL_FEET) kid_draw(cx, cy + 16, 1.5f, &m); else if (WR.slot == SL_LEGS) kid_draw(cx, cy + 24, 0.95f, &m); else kid_draw(cx, cy + 122, 1.0f, &m);
        gfx_clip_reset();
        text_fit(&F_txt, cloth_tab[c].name, cx, cy + 52, 17, 130, WHITE, AL_CENTER);
        if (has) gfx_text(&F_ui, on ? "Надето" : "Куплено", cx, cy + 74, 17, on ? C_GREEN1 : 0xFFFFFFA0u, AL_CENTER);
        else { snprintf(b, sizeof(b), "%d", cloth_tab[c].price); float tw = gfx_text_w(&F_ui, b, 20); gfx_text(&F_ui, b, cx - 10, cy + 74, 20, coins() >= cloth_tab[c].price ? C_GOLD : 0xFF8B7AFFu, AL_CENTER); gfx_image_ex(I_bottle, cx + tw * 0.5f + 4, cy + 74, 0.28f, 0.28f, 0.2f, 1); }
        if (hit) { WR.sel = c; memcpy(WR.try_on, HM.wear, SL_N); WR.try_on[WR.slot] = (u8)(c + 1); }
    }
    if (WR.sel >= 0) {
        int c = WR.sel, has = cloth_has(&HM, c), on = HM.wear[cloth_tab[c].slot] == c + 1;
        gfx_text(&F_ui, cloth_tab[c].name, 250, 646, 26, C_GOLD, AL_CENTER);
        if (has) { if (wbtn(2378, 250, 690, 300, 50, on ? "Снять" : "Надеть", on ? C_ORG1 : C_GREEN1, on ? C_ORG2 : C_GREEN2, 24, IC_NONE, 1)) ward_wear(c); }
        else { snprintf(b, sizeof(b), "Купить: %d", cloth_tab[c].price); if (wbtn(2379, 250, 690, 300, 50, b, 0xFFE06AFFu, 0xD9930FFFu, 24, IC_NONE, coins() >= cloth_tab[c].price)) ward_buy(c); }
    } else gfx_text(&F_txt, "Нажми на вещь, чтобы примерить", 250, 664, 21, 0xFFFFFFC0u, AL_CENTER);
    parts_draw();
}
