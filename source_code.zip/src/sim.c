#include "sim.h"
#include <math.h>
#include <string.h>

#define GRAV 1050.0f
#define BUOY 430.0f
#define DAMP_AIR 0.9997f
#define DAMP_BUB 0.970f
#define NODE_DAMP 0.985f
#define STAR_R 43.0f
#define BUBBLE_R 46.0f
#define SPIKE_R 21.0f
#define BUBBLE_HIT_R 40.0f          /* a bubble bursts as soon as its skin touches spikes or a laser beam */
#define LASER_R 19.0f
#define BLOW_RANGE 400.0f
#define BLOW_V 540.0f
#define BOUNCE_E 0.86f
#define BOUNCE_MIN (430.0f * SIM_DT)
#define PAD_T 8.0f
#define PORTAL_MIN (260.0f * SIM_DT)
#define SLIDE_V 400.0f
#define SLIDE_A 1600.0f
#define SLIDE_K 6.0f
#define THIEF_REACH 30.0f

int sim_skip_visual;
static float dist2(float ax, float ay, float bx, float by) { float dx = bx - ax, dy = by - ay; return sqrtf(dx * dx + dy * dy); }

/* sin/cos from float + - * / only: the same bits on every compiler and CPU (libm differs in the last bit) */
void sim_sincos(float deg, float *sn, float *cs) {
    deg -= 360.0f * floorf(deg / 360.0f);
    int q = (int)(deg / 90.0f); if (q > 3) q = 3; if (q < 0) q = 0;
    float r = (deg - 90.0f * (float)q) * (PI / 180.0f), r2 = r * r;
    float s = r * (1.0f - r2 / 6.0f * (1.0f - r2 / 20.0f * (1.0f - r2 / 42.0f * (1.0f - r2 / 72.0f * (1.0f - r2 / 110.0f)))));
    float c = 1.0f - r2 / 2.0f * (1.0f - r2 / 12.0f * (1.0f - r2 / 30.0f * (1.0f - r2 / 56.0f * (1.0f - r2 / 90.0f))));
    if (r == 0.0f) { s = 0.0f; c = 1.0f; }
    switch (q) { case 0: *sn = s; *cs = c; break; case 1: *sn = c; *cs = -s; break; case 2: *sn = -s; *cs = -c; break; default: *sn = -c; *cs = s; break; }
}

static void rope_relax(Sim *s, Rope *r, int iters) {
    int n = r->n; const Pin *p = &s->pin[r->pin];
    for (int it = 0; it < iters; it++) {
        r->p[0].x = p->x; r->p[0].y = p->y;
        if (!r->cut || s->state == ST_PLAY) { r->p[n - 1].x = s->c.x; r->p[n - 1].y = s->c.y; }
        for (int i = 0; i < n - 1; i++) {
            if (r->cut && i == r->cut_at) continue;
            Pt *a = &r->p[i], *b = &r->p[i + 1];
            float dx = b->x - a->x, dy = b->y - a->y, d = sqrtf(dx * dx + dy * dy);
            if (d <= r->seg || d < 1e-5f) continue;
            float wa = (i == 0) ? 0.0f : 1.0f, wb = (i + 1 == n - 1 && (!r->cut || s->state == ST_PLAY)) ? 0.0f : 1.0f;
            float tot = wa + wb; if (tot <= 0) continue;
            float k = (d - r->seg) / d / tot;
            a->x += dx * k * wa; a->y += dy * k * wa; b->x -= dx * k * wb; b->y -= dy * k * wb;
        }
    }
}
static void rope_integrate(Sim *s, Rope *r) {
    int n = r->n; float g = GRAV * (float)s->gdir * SIM_DT * SIM_DT;
    for (int i = 1; i < n; i++) {
        if (i == n - 1 && (!r->cut || s->state == ST_PLAY)) break;
        Pt *q = &r->p[i];
        float vx = (q->x - q->px) * NODE_DAMP, vy = (q->y - q->py) * NODE_DAMP;
        q->px = q->x; q->py = q->y; q->x += vx; q->y += vy + g;
    }
}
static int rope_make(Sim *s, int pin, float len) {
    int ri = -1;
    for (int i = 0; i < MAX_ROPES; i++) if (!s->rope[i].active) { ri = i; break; }
    if (ri < 0) return -1;
    Rope *r = &s->rope[ri]; memset(r, 0, sizeof(*r));
    Pin *p = &s->pin[pin]; float d = dist2(p->x, p->y, s->c.x, s->c.y);
    if (len < d) len = d;
    if (len < 24) len = 24;
    int n = (int)(len / 14.0f) + 2; if (n < 3) n = 3; if (n > ROPE_NODES) n = ROPE_NODES;
    r->active = 1; r->pin = pin; r->n = n; r->len = len; r->seg = len / (float)(n - 1); r->fade = 1;
    float sag = len > d ? sqrtf(len * len - d * d) * 0.45f : 0.0f;
    for (int i = 0; i < n; i++) {
        float t = (float)i / (float)(n - 1);
        r->p[i].x = p->x + (s->c.x - p->x) * t; r->p[i].y = p->y + (s->c.y - p->y) * t + sinf(PI * t) * sag * (float)s->gdir;
        r->p[i].px = r->p[i].x; r->p[i].py = r->p[i].y;
    }
    if (p->thief_v > 0) { r->thief = 1; r->thief_v = p->thief_v; r->thief_t0 = s->time + p->thief_d; r->thief_s = 0; }
    p->used = 1; p->rope = ri;
    return ri;
}

int sim_max_stars(const LObj *o) { int n = 0; for (; o->type != O_END; o++) if (o->type == O_STAR) n++; return n > MAX_STARS ? MAX_STARS : n; }

void sim_load(Sim *s, const LObj *o) {
    memset(s, 0, sizeof(*s));
    s->mx = -9999; s->my = -9999; s->gdir = 1; s->mouth_min = 1e9f;
    const LObj *q;
    for (q = o; q->type != O_END; q++) if (q->type == O_CANDY) { s->c.x = s->c.px = q->x; s->c.y = s->c.py = q->y; }
    for (q = o; q->type != O_END; q++) {
        switch (q->type) {
        case O_PIN: case O_AUTOPIN: case O_RAIL:
            if (s->npins < MAX_PINS) {
                Pin *p = &s->pin[s->npins]; p->x = q->x; p->y = q->y; p->rope = -1;
                if (q->type == O_AUTOPIN) { p->autopin = 1; p->r = q->a; p->thief_v = q->b; }
                else if (q->type == O_PIN) { p->thief_v = q->b; p->thief_d = q->c; rope_make(s, s->npins, q->a); }
                else {
                    p->rail = 1; p->x0 = q->x; p->y0 = q->y; p->x1 = q->a; p->y1 = q->b; p->u = p->ut = clampf(q->c, 0, 1);
                    p->x = p->x0 + (p->x1 - p->x0) * p->u; p->y = p->y0 + (p->y1 - p->y0) * p->u;
                    p->thief_v = q->e;
                    if (q->d < 0) { p->autopin = 1; p->r = -q->d; }      /* a sticky pin on a rail: it grabs the bottle, then it can be dragged */
                    else rope_make(s, s->npins, q->d);
                }
                s->npins++;
            } break;
        case O_STAR: if (s->nstars < MAX_STARS) { s->star[s->nstars].x = q->x; s->star[s->nstars].y = q->y; s->nstars++; } break;
        case O_BUBBLE: if (s->nbubbles < MAX_BUBBLES) { s->bubble[s->nbubbles].x = q->x; s->bubble[s->nbubbles].y = q->y; s->nbubbles++; } break;
        case O_BLOWER: if (s->nblowers < MAX_BLOWERS) {
                Blower *b = &s->blower[s->nblowers++]; b->x = q->x; b->y = q->y; b->ang = q->a * (PI / 180.0f);
                sim_sincos(q->a, &b->dy, &b->dx);
            } break;
        case O_SPIKES: if (s->nspikes < MAX_SPIKES) { Spikes *k = &s->spikes[s->nspikes++]; k->x0 = q->x; k->y0 = q->y; k->x1 = q->a; k->y1 = q->b; } break;
        case O_BOUNCER: if (s->nbouncers < MAX_BOUNCERS) {
                Bouncer *b = &s->bouncer[s->nbouncers++]; b->x = q->x; b->y = q->y; b->ang = q->a * (PI / 180.0f); b->hl = q->b > 0 ? q->b : 60.0f;
                sim_sincos(q->a, &b->dy, &b->dx); b->nx = b->dy; b->ny = -b->dx;
            } break;
        case O_PORTAL: if (s->nportals < MAX_PORTALS) {
                Portal *p = &s->portal[s->nportals++]; p->x = q->x; p->y = q->y; p->pair = (int)q->b; p->link = -1; p->keep = q->a < 0;
                p->ang = q->a * (PI / 180.0f); if (p->keep) { p->dx = 0; p->dy = 1; } else sim_sincos(q->a, &p->dy, &p->dx);
            } break;
        case O_GRAV: if (s->ngravs < MAX_GRAVS) { GravBtn *g = &s->grav[s->ngravs++]; g->x = q->x; g->y = q->y; } break;
        case O_LASER: if (s->nlasers < MAX_LASERS) {
                Laser *l = &s->laser[s->nlasers++]; l->x0 = q->x; l->y0 = q->y; l->x1 = q->a; l->y1 = q->b;
                l->on_t = (int)(q->c * (float)SIM_HZ + 0.5f); l->off_t = (int)(q->d * (float)SIM_HZ + 0.5f); l->ph_t = (int)(q->e * (float)SIM_HZ + 0.5f);
                if (l->on_t < 1) l->on_t = 1; if (l->off_t < 0) l->off_t = 0; if (l->ph_t < 0) l->ph_t = 0;
            } break;
        case O_MEL: s->mx = q->x; s->my = q->y; s->has_mel = 1; break;
        default: break;
        }
    }
    for (int i = 0; i < s->nportals; i++) for (int j = 0; j < s->nportals; j++) if (i != j && s->portal[i].pair == s->portal[j].pair && s->portal[i].link < 0) { s->portal[i].link = j; break; }
    /* settle the ropes (bottle must not move during settling: only the taut ones hold it) */
    for (int it = 0; it < 4; it++)
        for (int i = 0; i < MAX_ROPES; i++) if (s->rope[i].active) {
            Rope *r = &s->rope[i]; const Pin *p = &s->pin[r->pin];
            float dx = s->c.x - p->x, dy = s->c.y - p->y, d = sqrtf(dx * dx + dy * dy);
            if (d > r->len) { float k = r->len / d; s->c.x = p->x + dx * k; s->c.y = p->y + dy * k; }
        }
    s->c.px = s->c.x; s->c.py = s->c.y;
    for (int k = 0; k < 90 && !sim_skip_visual; k++)
        for (int i = 0; i < MAX_ROPES; i++) if (s->rope[i].active) { rope_integrate(s, &s->rope[i]); rope_relax(s, &s->rope[i], 8); }
    for (int i = 0; i < MAX_ROPES; i++) if (s->rope[i].active) for (int j = 0; j < s->rope[i].n; j++) { s->rope[i].p[j].px = s->rope[i].p[j].x; s->rope[i].p[j].py = s->rope[i].p[j].y; }
    s->mouth_dist = dist2(s->c.x, s->c.y, s->mx, s->my);
}

static float seg_point_dist(float x0, float y0, float x1, float y1, float px, float py) {
    float dx = x1 - x0, dy = y1 - y0, l2 = dx * dx + dy * dy, t = l2 > 1e-6f ? ((px - x0) * dx + (py - y0) * dy) / l2 : 0.0f;
    t = clampf(t, 0, 1);
    return dist2(x0 + dx * t, y0 + dy * t, px, py);
}
static float wrap_pi(float a) { while (a > PI) a -= TAU; while (a < -PI) a += TAU; return a; }

int sim_laser_on(const Sim *s, int i) {
    const Laser *l = &s->laser[i]; if (l->off_t <= 0) return 1;
    return (s->tick + l->ph_t) % (l->on_t + l->off_t) < l->on_t;
}
float sim_laser_wait(const Sim *s, int i) {
    const Laser *l = &s->laser[i]; if (l->off_t <= 0) return 1e9f;
    int t = (s->tick + l->ph_t) % (l->on_t + l->off_t);
    return (float)(t < l->on_t ? l->on_t - t : l->on_t + l->off_t - t) * SIM_DT;
}
int sim_thief_pos(const Sim *s, int ri, float *x, float *y) {
    const Rope *r = &s->rope[ri]; if (!r->active || !r->thief) return 0;
    if (r->thief == 2) { *x = r->tx; *y = r->ty; return 2; }
    float f = clampf(r->thief_s / r->len, 0, 1) * (float)(r->n - 1); int i = (int)f; if (i > r->n - 2) i = r->n - 2; f -= (float)i;
    *x = r->p[i].x + (r->p[i + 1].x - r->p[i].x) * f; *y = r->p[i].y + (r->p[i + 1].y - r->p[i].y) * f;
    return 1;
}
static void rope_cut_at(Sim *s, Rope *r, int link, float x, float y) {
    if (link < 0) link = 0; if (link > r->n - 2) link = r->n - 2;
    if (r->thief == 1) { float tx, ty; sim_thief_pos(s, (int)(r - s->rope), &tx, &ty); r->thief = 2; r->tx = tx; r->ty = ty; r->tvy = 0; s->events |= EV_THIEF_FALL; s->thief_x = tx; s->thief_y = ty; }
    r->cut = 1; r->cut_at = link; r->fade = 1;
    s->events |= EV_CUT; s->cut_x = x; s->cut_y = y;
    /* give the loose ends a little kick */
    Pt *a = &r->p[link], *b = &r->p[link + 1];
    if (link > 0) { a->px = a->x + 0.6f; a->py = a->y + 0.3f; }
    if (link + 1 < r->n - 1) { b->px = b->x - 0.6f; b->py = b->y + 0.3f; }
}
static void bubble_burst(Sim *s) { s->in_bubble = 0; s->events |= EV_BUBBLE_POP; s->pop_x = s->c.x; s->pop_y = s->c.y; }

void sim_step(Sim *s) {
    Pt *c = &s->c;
    s->time += SIM_DT; s->tick++;
    if (s->state == ST_PLAY) {
        float damp = s->in_bubble ? DAMP_BUB : DAMP_AIR;
        float vx = (c->x - c->px) * damp, vy = (c->y - c->py) * damp;
        c->px = c->x; c->py = c->y;
        c->x += vx; c->y += vy + (s->in_bubble ? -BUOY : GRAV) * (float)s->gdir * SIM_DT * SIM_DT;
        if (s->in_bubble) s->bubble_t += SIM_DT;
        /* bouncers */
        for (int i = 0; i < s->nbouncers; i++) {
            Bouncer *b = &s->bouncer[i];
            float rx = c->x - b->x, ry = c->y - b->y, along = rx * b->dx + ry * b->dy, dn = rx * b->nx + ry * b->ny;
            float rad = (s->in_bubble ? BUBBLE_HIT_R : CANDY_R) + PAD_T, ad = dn < 0 ? -dn : dn, aa = along < 0 ? -along : along;
            if (aa > b->hl + 10.0f || ad >= rad) continue;
            float sg = dn < 0 ? -1.0f : 1.0f, wx = c->x - c->px, wy = c->y - c->py, vn = (wx * b->nx + wy * b->ny) * sg;
            if (vn >= 0) continue;                                   /* already moving away */
            float out = -vn * BOUNCE_E; if (out < BOUNCE_MIN) out = BOUNCE_MIN;
            float k = (out - vn) * sg; wx += b->nx * k; wy += b->ny * k;
            c->x += b->nx * sg * (rad - ad); c->y += b->ny * sg * (rad - ad);
            c->px = c->x - wx; c->py = c->y - wy;
            b->pulse = 1; s->events |= EV_BOUNCE; s->ev_bouncer = i;
        }
        /* pins that ride on rails: they chase the target with limited speed and acceleration (no whiplash) */
        for (int i = 0; i < s->npins; i++) {
            Pin *p = &s->pin[i]; if (!p->rail || (p->u == p->ut && p->uv == 0.0f)) continue;
            float len = dist2(p->x0, p->y0, p->x1, p->y1); if (len < 1) len = 1;
            float want = clampf((p->ut - p->u) * len * SLIDE_K, -SLIDE_V, SLIDE_V), dv = clampf(want - p->uv, -SLIDE_A * SIM_DT, SLIDE_A * SIM_DT);
            p->uv += dv; p->u += p->uv * SIM_DT / len;
            float rest = (p->ut - p->u) * len; if (rest < 0) rest = -rest;
            if (rest < 0.4f && p->uv > -20.0f && p->uv < 20.0f) { p->u = p->ut; p->uv = 0; }
            if (p->u <= 0) { p->u = 0; if (p->uv < 0) p->uv = 0; } else if (p->u >= 1) { p->u = 1; if (p->uv > 0) p->uv = 0; }
            p->x = p->x0 + (p->x1 - p->x0) * p->u; p->y = p->y0 + (p->y1 - p->y0) * p->u;
        }
        for (int it = 0; it < 5; it++)
            for (int i = 0; i < MAX_ROPES; i++) {
                Rope *r = &s->rope[i]; if (!r->active || r->cut) continue;
                const Pin *p = &s->pin[r->pin];
                float dx = c->x - p->x, dy = c->y - p->y, d = sqrtf(dx * dx + dy * dy);
                if (d > r->len) { float k = r->len / d; c->x = p->x + dx * k; c->y = p->y + dy * k; }
            }
        for (int i = 0; i < s->npins; i++) {
            Pin *p = &s->pin[i];
            if (p->autopin && !p->used && dist2(c->x, c->y, p->x, p->y) < p->r) {
                if (rope_make(s, i, 0) >= 0) { s->events |= EV_ATTACH; s->ev_x = p->x; s->ev_y = p->y; p->pulse = 1; }
            }
        }
        if (!s->in_bubble)
            for (int i = 0; i < s->nbubbles; i++) {
                Bubble *b = &s->bubble[i];
                if (!b->used && dist2(c->x, c->y, b->x, b->y) < BUBBLE_R) {
                    b->used = 1; s->in_bubble = 1; s->bubble_t = 0; s->events |= EV_BUBBLE_IN;
                    /* entering a bubble kills most of the momentum */
                    c->px = c->x - (c->x - c->px) * 0.35f; c->py = c->y - (c->y - c->py) * 0.35f;
                    break;
                }
            }
        /* portals: in through one, out of its twin; ropes do not survive the trip */
        for (int i = 0; i < s->nportals; i++) {
            Portal *p = &s->portal[i]; float d = dist2(c->x, c->y, p->x, p->y);
            if (p->lock) { if (d > PORTAL_R + 22.0f) p->lock = 0; continue; }
            if (d >= PORTAL_R || p->link < 0) continue;
            Portal *o = &s->portal[p->link];
            float wx = c->x - c->px, wy = c->y - c->py, sp = sqrtf(wx * wx + wy * wy); if (sp < PORTAL_MIN) sp = PORTAL_MIN;
            for (int k = 0; k < MAX_ROPES; k++) { Rope *r = &s->rope[k]; if (r->active && !r->cut) { int j = r->n / 2; rope_cut_at(s, r, j, r->p[j].x, r->p[j].y); } }
            if (!o->keep) { wx = o->dx * sp; wy = o->dy * sp; }
            c->x = o->x; c->y = o->y; c->px = c->x - wx; c->py = c->y - wy;
            o->lock = 1; p->pulse = 1; o->pulse = 1; s->events |= EV_PORTAL; s->ev_portal = i; s->ev_portal2 = p->link;
            break;
        }
        for (int i = 0; i < s->nstars; i++) {
            Star *t = &s->star[i];
            if (!t->got && dist2(c->x, c->y, t->x, t->y) < STAR_R) { t->got = 1; t->t = 0; s->stars++; s->events |= EV_STAR; s->ev_star = i; }
        }
        for (int i = 0; i < s->nspikes && s->state == ST_PLAY; i++) {
            const Spikes *k = &s->spikes[i]; float d = seg_point_dist(k->x0, k->y0, k->x1, k->y1, c->x, c->y);
            if (d < SPIKE_R) { s->state = ST_BROKEN; s->state_t = 0; s->events |= EV_BREAK; if (s->in_bubble) bubble_burst(s); }
            else if (s->in_bubble && d < BUBBLE_HIT_R) bubble_burst(s);
        }
        for (int i = 0; i < s->nlasers && s->state == ST_PLAY; i++) {
            const Laser *l = &s->laser[i]; if (!sim_laser_on(s, i)) continue;
            float d = seg_point_dist(l->x0, l->y0, l->x1, l->y1, c->x, c->y);
            if (d < LASER_R) { s->state = ST_BROKEN; s->state_t = 0; s->events |= EV_BREAK | EV_BURN; if (s->in_bubble) bubble_burst(s); }
            else if (s->in_bubble && d < BUBBLE_HIT_R) bubble_burst(s);
        }
        /* thieves climb down their ropes */
        for (int i = 0; i < MAX_ROPES && s->state == ST_PLAY; i++) {
            Rope *r = &s->rope[i]; if (!r->active || r->cut || r->thief != 1 || s->time < r->thief_t0) continue;
            r->thief_s += r->thief_v * SIM_DT;
            if (r->thief_s >= r->len - THIEF_REACH) { s->state = ST_STOLEN; s->state_t = 0; s->events |= EV_STOLEN; sim_thief_pos(s, i, &s->thief_x, &s->thief_y); if (s->in_bubble) bubble_burst(s); }
        }
        s->mouth_dist = dist2(c->x, c->y, s->mx, s->my);
        if (s->mouth_dist < s->mouth_min) s->mouth_min = s->mouth_dist;
        if (s->state == ST_PLAY && s->has_mel && s->mouth_dist < MOUTH_R) { s->state = ST_EATEN; s->state_t = 0; s->events |= EV_EAT; s->in_bubble = 0; }
        if (s->state == ST_PLAY && (c->x < -70 || c->x > DESIGN_W + 70 || c->y > DESIGN_H + 80 || c->y < -90)) { s->state = ST_LOST; s->state_t = 0; s->events |= EV_LOST; }
        /* visual rotation of the bottle: the neck points along the taut ropes (nothing in the rules reads it) */
        if (!sim_skip_visual) {
        float tx = 0, ty = 0; int nt = 0;
        for (int i = 0; i < MAX_ROPES; i++) {
            const Rope *r = &s->rope[i]; if (!r->active || r->cut) continue;
            const Pin *p = &s->pin[r->pin];
            float dx = p->x - c->x, dy = p->y - c->y, d = sqrtf(dx * dx + dy * dy);
            if (d > r->len * 0.94f && d > 1) { tx += dx / d; ty += dy / d; nt++; }
        }
        if (nt) { float diff = wrap_pi(atan2f(tx, -ty) - s->rot); s->rotv += diff * 140.0f * SIM_DT; s->rotv *= 0.94f; }
        else if (s->in_bubble) { float diff = wrap_pi(sinf(s->time * 2.2f) * 0.18f - s->rot); s->rotv += diff * 30.0f * SIM_DT; s->rotv *= 0.95f; }
        else { float want = clampf((c->x - c->px) / SIM_DT * 0.012f, -7.0f, 7.0f); s->rotv += (want - s->rotv) * 0.01f; }
        s->rot = wrap_pi(s->rot + s->rotv * SIM_DT);
        }
    } else {
        s->state_t += SIM_DT;
    }
    for (int i = 0; i < MAX_ROPES; i++) {
        Rope *r = &s->rope[i]; if (!r->active) continue;
        if (!sim_skip_visual) { rope_integrate(s, r); rope_relax(s, r, 8); }
        if (r->thief == 2) { r->tvy += GRAV * (float)s->gdir * SIM_DT; r->ty += r->tvy * SIM_DT; if (r->ty > DESIGN_H + 120 || r->ty < -120) r->thief = 0; }
        if (r->cut) { r->fade -= SIM_DT / 0.5f; if (r->fade <= 0 && r->thief != 2) r->active = 0; }
    }
    for (int i = 0; i < s->nblowers; i++) { Blower *b = &s->blower[i]; if (b->squeeze > 0) { b->squeeze -= SIM_DT * 3.5f; if (b->squeeze < 0) b->squeeze = 0; } }
    for (int i = 0; i < s->npins; i++) { Pin *p = &s->pin[i]; if (p->pulse > 0) { p->pulse -= SIM_DT * 2.5f; if (p->pulse < 0) p->pulse = 0; } }
    for (int i = 0; i < s->nbouncers; i++) { Bouncer *b = &s->bouncer[i]; if (b->pulse > 0) { b->pulse -= SIM_DT * 3.0f; if (b->pulse < 0) b->pulse = 0; } }
    for (int i = 0; i < s->nportals; i++) { Portal *p = &s->portal[i]; if (p->pulse > 0) { p->pulse -= SIM_DT * 2.5f; if (p->pulse < 0) p->pulse = 0; } }
    for (int i = 0; i < s->ngravs; i++) { GravBtn *g = &s->grav[i]; if (g->pulse > 0) { g->pulse -= SIM_DT * 2.5f; if (g->pulse < 0) g->pulse = 0; } }
    for (int i = 0; i < s->nstars; i++) s->star[i].t += SIM_DT;
}

static int seg_seg(float ax, float ay, float bx, float by, float cx, float cy, float dx, float dy, float *ix, float *iy) {
    float rx = bx - ax, ry = by - ay, sx = dx - cx, sy = dy - cy, den = rx * sy - ry * sx;
    if (fabsf(den) < 1e-6f) return 0;
    float t = ((cx - ax) * sy - (cy - ay) * sx) / den, u = ((cx - ax) * ry - (cy - ay) * rx) / den;
    if (t < 0 || t > 1 || u < 0 || u > 1) return 0;
    *ix = ax + rx * t; *iy = ay + ry * t; return 1;
}
int sim_cut(Sim *s, float x0, float y0, float x1, float y1) {
    int cnt = 0; s->ncut = 0;
    if (s->state != ST_PLAY) return 0;
    for (int i = 0; i < MAX_ROPES; i++) {
        Rope *r = &s->rope[i]; if (!r->active || r->cut) continue;
        for (int j = 0; j < r->n - 1; j++) {
            float ix, iy; const Pt *a = &r->p[j], *b = &r->p[j + 1];
            if (seg_seg(x0, y0, x1, y1, a->x, a->y, b->x, b->y, &ix, &iy)) { rope_cut_at(s, r, j, ix, iy); s->cutlog[cnt].pin = r->pin; s->cutlog[cnt].link = j; cnt++; break; }
        }
    }
    s->ncut = cnt;
    return cnt;
}
static int cut_pin(Sim *s, int pin, int link) {
    if (s->state != ST_PLAY || pin < 0 || pin >= s->npins) return 0;
    for (int i = 0; i < MAX_ROPES; i++) {
        Rope *r = &s->rope[i];
        if (r->active && !r->cut && r->pin == pin) {
            int j = link >= 0 ? link : r->n / 2; if (j > r->n - 2) j = r->n - 2;
            rope_cut_at(s, r, j, (r->p[j].x + r->p[j + 1].x) * 0.5f, (r->p[j].y + r->p[j + 1].y) * 0.5f); return 1;
        }
    }
    return 0;
}
static int do_pop(Sim *s) {
    if (s->state != ST_PLAY || !s->in_bubble) return 0;
    bubble_burst(s);
    return 1;
}
static int do_blow(Sim *s, int i) {
    if (i < 0 || i >= s->nblowers) return 0;
    Blower *b = &s->blower[i];
    if (b->squeeze > 0.55f) return 0;                    /* still squeezed */
    b->squeeze = 1; s->events |= EV_BLOW; s->ev_blower = i;
    if (s->state != ST_PLAY) return 1;
    float rx = s->c.x - b->x, ry = s->c.y - b->y, along = rx * b->dx + ry * b->dy, lat = fabsf(rx * -b->dy + ry * b->dx);
    if (along > -20 && along < BLOW_RANGE && lat < 62.0f + along * 0.16f) {
        float k = BLOW_V * clampf(1.15f * (1.0f - along / BLOW_RANGE), 0, 1);   /* fades to zero at the range limit */
        s->c.px -= b->dx * k * SIM_DT; s->c.py -= b->dy * k * SIM_DT;
    }
    return 1;
}
static int do_grav(Sim *s, int i) {
    if (s->state != ST_PLAY || i < 0 || i >= s->ngravs) return 0;
    GravBtn *g = &s->grav[i]; if (g->pulse > 0.6f) return 0;
    g->pulse = 1; s->gdir = -s->gdir; s->events |= EV_GRAV; s->ev_grav = i;
    return 1;
}
static int do_slide(Sim *s, int pin, int q) {
    if (pin < 0 || pin >= s->npins || !s->pin[pin].rail) return 0;
    s->pin[pin].ut = (float)(q < 0 ? 0 : (q > 255 ? 255 : q)) / 255.0f;
    return 1;
}
int sim_act(Sim *s, int act, int arg) {
    switch (act) {
    case ACT_CUT: return cut_pin(s, arg & 15, ((arg >> 4) & 63) - 1);
    case ACT_POP: return do_pop(s);
    case ACT_BLOW: return do_blow(s, arg);
    case ACT_GRAV: return do_grav(s, arg);
    case ACT_SLIDE: return do_slide(s, arg & 15, (arg >> 4) & 255);
    }
    return 0;
}
int sim_do(Sim *s, const Step *st) { return sim_act(s, st->act, st->arg); }
int sim_pick(const Sim *s, float x, float y, int *act, int *arg) {
    if (s->state != ST_PLAY) return 0;
    if (s->in_bubble && dist2(x, y, s->c.x, s->c.y) < BUBBLE_VIS_R + 12) { *act = ACT_POP; *arg = 0; return 1; }
    for (int i = 0; i < s->nblowers; i++) if (dist2(x, y, s->blower[i].x, s->blower[i].y) < 50) { *act = ACT_BLOW; *arg = i; return 1; }
    for (int i = 0; i < s->ngravs; i++) if (dist2(x, y, s->grav[i].x, s->grav[i].y) < 48) { *act = ACT_GRAV; *arg = i; return 1; }
    return 0;
}
int sim_rail_pick(const Sim *s, float x, float y) {
    int best = -1; float bd = 46.0f;
    if (s->state != ST_PLAY) return -1;
    for (int i = 0; i < s->npins; i++) if (s->pin[i].rail) { float d = dist2(x, y, s->pin[i].x, s->pin[i].y); if (d < bd) { bd = d; best = i; } }
    return best;
}
int sim_rail_q(const Sim *s, int pin, float x, float y) {
    const Pin *p = &s->pin[pin]; float dx = p->x1 - p->x0, dy = p->y1 - p->y0, l2 = dx * dx + dy * dy;
    float u = l2 > 1e-6f ? ((x - p->x0) * dx + (y - p->y0) * dy) / l2 : 0.0f; u = clampf(u, 0, 1);
    return (int)(u * 255.0f + 0.5f);
}
int sim_ropes_left(const Sim *s) { int n = 0; for (int i = 0; i < MAX_ROPES; i++) if (s->rope[i].active && !s->rope[i].cut) n++; return n; }
