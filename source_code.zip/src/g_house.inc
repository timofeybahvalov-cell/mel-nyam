/* ============================================================================
   «МЕЛ-НЯМ» V0.6 — a house from the inside: the rooms, the furniture, the little Mel who lives there.
   The same picture serves the owner (who moves the furniture), a guest (who only looks)
   and the close view of «Мой говорящий Мел» (g_pet.inc).
   Included by game.c after g_draw6.inc.
   ============================================================================ */

/* ---------------- a room, in its own units ---------------- */
#define RM_H 420.0f                                  /* the wall */
#define RM_F 84.0f                                   /* the strip of floor under it */
#define RM_FLOOR (RM_H + RM_F)
#define KID_S 0.75f                                  /* Mel among the furniture */
static struct { float z, ox, oy; } RV = { 1, 0, 0 };
static float rm_w(int big) { return big ? 1500.0f : 960.0f; }
static float rm_y0(int big, int f) { return big && !f ? RM_FLOOR : 0.0f; }      /* the top of the wall of a storey (0: the ground floor, 1: upstairs) */
static float rm_h(int big) { return big ? RM_FLOOR * 2 : RM_FLOOR; }
static int   rm_cap(int big) { return big ? 40 : 10; }                           /* how many things fit */
static void rv_set(float z, float ox, float oy) { RV.z = z; RV.ox = ox; RV.oy = oy; }
static void rv_on(void) { gfx_zoom(RV.z); gfx_offset(RV.ox, RV.oy); }
static void rv_off(void) { gfx_zoom(1); gfx_offset(0, 0); }
static float rv_x(float sx) { return sx / RV.z - RV.ox; }
static float rv_y(float sy) { return sy / RV.z - RV.oy; }
static float sc_x(float rx) { return (rx + RV.ox) * RV.z; }
static float sc_y(float ry) { return (ry + RV.oy) * RV.z; }
static void rv_house(int big) { if (big) rv_set(0.5f, 530, 236); else rv_set(0.92f, 215.6f, 163); }      /* the whole house on the screen */

/* how dark it is outside: 0 day .. 1 night (the clock of Moscow) */
static float night_k(void) {
    u32 now = now_s(); float hr = now ? (float)((now + MSK) % 86400u) / 3600.0f : 13.0f;
    return hr < 5 || hr >= 22 ? 1.0f : (hr < 7 ? (7 - hr) * 0.5f : (hr >= 20 ? (hr - 20) * 0.5f : 0.0f));
}
static void sky_draw(float nk) {
    gfx_rrect_grad(0, 0, DESIGN_W, DESIGN_H, 0, color_lerp(0x4FB0FFFFu, 0x10163CFFu, nk), color_lerp(0xD6F0FFFFu, 0x3B2C74FFu, nk));
    if (nk > 0.3f) for (int i = 0; i < 46; i++) { u32 h = mhash((u32)i, 5); float tw = 0.6f + 0.4f * sinf(g_time * 1.5f + (float)i); gfx_circle((float)(h % 1280u), (float)((h >> 11) % 420u), 1.2f + (float)((h >> 20) % 3u) * 0.5f, color_alpha(0xFFFFFFFFu, (nk - 0.3f) * 1.4f * tw)); }
    if (nk < 0.6f) { gfx_circle(1120, 96, 62, color_alpha(0xFFF3B0FFu, 0.35f * (1 - nk))); gfx_circle(1120, 96, 44, color_alpha(0xFFE06AFFu, 1 - nk * 1.6f)); }
    else { gfx_circle(1120, 96, 40, 0xF2F4FFFFu); gfx_circle(1136, 86, 34, color_lerp(0x10163CFFu, 0x3B2C74FFu, 0.13f)); }
    for (int i = 0; i < 4; i++) { float cx = fmodf((float)i * 390 + g_time * (6.0f + (float)i * 2), 1640) - 180, cy = 70 + (float)((i * 53) % 110); u32 c = color_alpha(color_lerp(0xFFFFFFFFu, 0x6A6FA8FFu, nk), 0.9f);
        gfx_ellipse(cx, cy, 70, 22, c); gfx_ellipse(cx - 34, cy + 8, 44, 17, c); gfx_ellipse(cx + 40, cy + 9, 50, 16, c); gfx_ellipse(cx + 6, cy - 14, 38, 20, c); }
}

/* where a thing is in its room */
static void pl_box(const Placed *p, int big, float *x0, float *y0, float *x1, float *y1, float *ax, float *ay) {
    const ItemDef *d = &item_tab[p->id - 1]; float cx = (float)p->x * 6.0f, fy = rm_y0(big, p->fl & 1), w = (float)d->w, hh = (float)d->h, a, b, any;
    switch (d->kind) {
    case IK_FLOOR: b = fy + RM_H + 26; a = b - hh; any = b; break;
    case IK_RUG:   b = fy + RM_H + 70; a = b - hh; any = b; break;
    case IK_WALL:  any = fy + RM_H - (float)p->y * 4.0f; a = any - hh * 0.5f; b = any + hh * 0.5f; break;
    default:       a = fy; b = fy + hh; any = fy; break;
    }
    if (x0) *x0 = cx - w * 0.5f; if (x1) *x1 = cx + w * 0.5f; if (y0) *y0 = a; if (y1) *y1 = b; if (ax) *ax = cx; if (ay) *ay = any;
}
static void pl_draw(const Placed *p, int big) { float ax, ay; pl_box(p, big, NULL, NULL, NULL, NULL, &ax, &ay); item_draw(p->id - 1, ax, ay, 1.0f, (p->fl & 2) != 0); }
/* one storey: the wall, the floor, what is fixed (window, door, stairs) and the furniture; skip: a thing that is not drawn (it is in the player's hand) */
static void room_draw(const Home *h, int big, int f, float nk, float dark, int skip) {
    float w = rm_w(big), y0 = rm_y0(big, f), wx = big ? (f ? 1040.0f : 560.0f) : 610.0f;
    u32 wall = f ? 0xCFE4F6FFu : 0xF8E9CCFFu, wall2 = f ? 0xBDD7EEFFu : 0xF0DBB4FFu;
    gfx_rect(0, y0, w, RM_H, wall); for (float x = 30; x < w; x += 60) gfx_rect(x, y0, 30, RM_H, wall2);
    gfx_rect(0, y0 + RM_H - 18, w, 18, 0xFFFFFFFFu); gfx_rect(0, y0 + RM_H - 18, w, 3, 0xD9CDB8FFu);
    gfx_rrect_grad(0, y0 + RM_H, w, RM_F, 0, 0xD49A5CFFu, 0xA86C36FFu); for (float x = f ? 62 : 124; x < w - 4; x += 124) gfx_rect(x, y0 + RM_H, 3, RM_F, 0x7A4A2460u);
    gfx_rect(0, y0 + RM_H + 40, w, 2, 0x7A4A2440u);
    d_at(wx, y0 + 84, 1.0f, 0);                                                          /* a window: the sky of this hour */
    o_rect(-84, -8, 168, 150, 6, 0xFFFFFFFFu); d_grad(-74, 2, 148, 130, 2, color_lerp(0x6FC0FFFFu, 0x141A44FFu, nk), color_lerp(0xD6F0FFFFu, 0x3B2C74FFu, nk));
    if (nk > 0.6f) { d_circ(38, 34, 15, 0xF2F4FFFFu); d_circ(-30, 50, 1.6f, 0xFFFFFFFFu); d_circ(8, 92, 1.4f, 0xFFFFFFFFu); d_circ(-52, 100, 1.5f, 0xFFFFFFFFu); } else { d_circ(38, 34, 17, 0xFFE06AFFu); d_ell(-26, 96, 34, 11, 0xFFFFFFE0u); d_ell(-4, 86, 22, 12, 0xFFFFFFE0u); }
    d_rect(-4, 2, 8, 130, 0, 0xFFFFFFFFu); d_rect(-74, 62, 148, 8, 0, 0xFFFFFFFFu); o_rect(-92, 136, 184, 12, 4, 0xF2F2F6FFu);
    if (!f) { d_at(86, y0 + RM_H, 1.0f, 0); o_rect(-48, -218, 96, 218, 6, 0x9A5F33FFu); d_rect(-36, -204, 72, 84, 4, 0xB57A44FFu); d_rect(-36, -106, 72, 90, 4, 0xB57A44FFu); o_circ(30, -106, 6, 0xFFD23FFFu); }      /* the front door */
    if (big && !f) {                                                                     /* the stairs go up along the right wall, to the opening in the ceiling */
        d_at(w - 14, y0 + RM_H + 26, 1.0f, 0);
        for (int i = 8; i >= 0; i--) { float sx = -44 - (float)i * 26, top = -(float)(i + 1) * 56.0f; o_rect(sx - 44, top, 88, -top, 2, i & 1 ? 0xB57A44FFu : 0xC98B4FFFu); d_rect(sx - 44, top, 88, 8, 2, 0xE2AC72FFu); }
        for (int i = 0; i < 9; i += 2) { float sx = -44 - (float)i * 26 - 34, top = -(float)(i + 1) * 56.0f; d_line(sx, top, sx, top - 62, 2.6f, OLC); d_line(sx, top, sx, top - 62, 1.3f, 0xE2AC72FFu); }
        d_line(-78, -118, -286, -566, 5.0f, OLC); d_line(-78, -118, -286, -566, 2.8f, 0xE2AC72FFu);
    }
    if (big && f) { d_at(w - 14, y0 + RM_H, 1.0f, 0); d_rect(-306, 0, 306, RM_F + 6, 0, 0x2A1E38A0u); d_rect(-306, 0, 6, RM_F + 6, 0, OLC); }      /* the opening the stairs come up through */
    for (int pass = 0; pass < 4; pass++) for (int i = 0; i < PLACED_MAX; i++) {
        const Placed *p = &h->pl[i]; static const u8 order[4] = { IK_WALL, IK_CEIL, IK_RUG, IK_FLOOR };
        if (!p->id || i == skip || (p->fl & 1) != (big ? f : 0) || item_tab[p->id - 1].kind != order[pass]) continue;
        pl_draw(p, big);
    }
    if (dark > 0.01f) gfx_rect(0, y0, w, RM_FLOOR, color_alpha(0x0A0C2CFFu, dark * 0.62f));
}
/* the walls around the rooms, the roof, the ground */
static void house_shell(int big, float nk) {
    float w = rm_w(big), hh = rm_h(big), t = 16, rh = big ? 150.0f : 120.0f;
    gfx_rect(-3000, hh, 7000, 900, color_lerp(0x5DBB4FFFu, 0x234A3CFFu, nk)); gfx_rect(-3000, hh, 7000, 10, color_lerp(0x7FD468FFu, 0x2E6048FFu, nk));
    for (int i = 0; i < 9; i++) { float bx = -1400 + (float)i * 480 + (float)((i * 97) % 130); if (bx > -150 && bx < w + 150) continue; gfx_ellipse(bx, hh + 4, 76, 44, color_lerp(0x3FA544FFu, 0x1C3F34FFu, nk)); gfx_ellipse(bx + 50, hh + 8, 50, 30, color_lerp(0x4FBB55FFu, 0x21483AFFu, nk)); }
    d_at(0, 0, 1.0f, 0); DX.ow = 5.0f;
    o_quad(-70, 0, w + 70, 0, w - 90, -rh, 90, -rh, 0xD9553CFFu);                        /* the roof */
    for (int r = 1; r < 4; r++) { float k = (float)r / 4.0f; d_line(90 - 160 * k + 14, -rh + rh * k, w - 90 + 160 * k - 14, -rh + rh * k, 1.6f, 0xB03A28FFu); }
    o_rect(w * 0.72f, -rh - 54, 62, 100, 4, 0xB5553CFFu); o_rect(w * 0.72f - 8, -rh - 64, 78, 18, 4, 0xE8D8C0FFu);
    for (int i = 0; i < 3; i++) { float p = fmodf(g_time * 0.25f + (float)i * 0.33f, 1.0f); d_circ(w * 0.72f + 31 + sinf(p * 5 + (float)i) * 14, -rh - 80 - p * 110, 14 + p * 22, color_alpha(0xFFFFFFFFu, 0.42f * (1 - p))); }
    gfx_rect(-t, -t * 0.5f, w + 2 * t, t, OLC); gfx_rect(-t, 0, t, hh + 8, OLC); gfx_rect(w, 0, t, hh + 8, OLC); gfx_rect(-t - 12, hh, w + 2 * t + 24, 20, 0x6A5F70FFu); gfx_rect(-t - 12, hh, w + 2 * t + 24, 4, OLC);
    if (big) gfx_rect(0, RM_FLOOR - 6, w, 12, OLC);
    DX.ow = 3.0f;
}
/* the whole inside of a house (the view RV must be on) */
static void house_draw(const Home *h, float nk, float dark, int skip) {
    house_shell(h->big, nk);
    if (h->big) room_draw(h, 1, 1, nk, dark, skip);
    room_draw(h, h->big, 0, nk, dark, skip);
    if (h->big) gfx_rect(0, RM_FLOOR - 6, rm_w(1), 12, OLC);
}

/* ---------------- Mel in his house: he hops from place to place ---------------- */
static struct { float x, to, hop, wait, t, look; int inited; } HK;
static float kid_floor_y(int big) { return rm_y0(big, 0) + RM_H + 60; }
static void hk_update(const Home *h, float dt, int stay) {
    float w = rm_w(h->big);
    if (!HK.inited) { HK.inited = 1; HK.x = HK.to = w * 0.5f; HK.wait = 2.0f; }
    HK.x = clampf(HK.x, 150, w - (h->big ? 400.0f : 150.0f)); HK.t += dt;
    if (stay || h->asleep) { HK.to = HK.x; HK.hop = 0; return; }
    if (fabsf(HK.to - HK.x) < 4) { HK.hop = 0; HK.wait -= dt; if (HK.wait <= 0) { HK.wait = rnd_range(2.5f, 6.0f); HK.to = clampf(HK.x + rnd_range(-360, 360), 190, w - (h->big ? 400.0f : 150.0f)); } }
    else { float dir = HK.to > HK.x ? 1.0f : -1.0f; HK.hop += dt * 2.8f; HK.x += dir * 120 * dt; HK.look = dir; if (HK.hop >= 1) HK.hop -= 1; }
}
static float hk_jump(void) { return HK.hop > 0 ? sinf(HK.hop * PI) * 16 : 0; }

/* ---------------- whose house is on the screen ---------------- */
static struct { int visit, loading, err, empty, badge, from_city; u32 plot, visits; char nick[40]; Home h; } HV;
static const Home *hv_home(void) { return HV.visit ? &HV.h : &HM; }
static int where_visit(void) { return HV.visit ? (int)HV.plot : 0; }
static struct { int on, sel, drag, moved, inv0; int item; float gx, gy, x, y; int ok; float note_t; } HE;      /* moving the furniture */
static int he_free_slot(void) { for (int i = 0; i < PLACED_MAX; i++) if (!HM.pl[i].id) return i; return -1; }
static int he_placed(int item) { for (int i = 0; i < PLACED_MAX; i++) if (HM.pl[i].id == item + 1) return i; return -1; }
static void he_changed(void) { HM.pl_rev++; HM.cn[C6_MOVES]++; mis_kind(MK_PLACE, 1); ach6_check(); home_dirty(); }
static void item_got(int item) { (void)item; HE.note_t = 6.0f; }                       /* a new thing waits in the box */
static void house_enter(int a) {
    HK.inited = 0; memset(&HE, 0, sizeof(HE)); HE.sel = -1; HE.drag = -1;
    if (a != 1) { HV.visit = 0; HV.loading = 0; HV.err = 0; }
    if (!HV.visit) { pet_clock(); month_refresh(); }
}
static void house_buy_big(int arg) {
    (void)arg;
    if (HM.big || coins() < HOUSE_PRICE) return;
    HM.big = 1; sfx_p(S_WIN, 0.8f, 640, 1.0f); fx_confetti(200, 1080, -10, 60); HK.inited = 0; home_dirty(); ach6_check(); gtoast("Дом перестроен: теперь в нём два этажа!");
}
/* a thing in the hand: where it would stand (room units); returns 0 when the pointer is outside the house */
static int he_target(int item, float px, float py, Placed *out) {
    const ItemDef *d = &item_tab[item]; int big = HM.big; float w = rm_w(big), hh = rm_h(big), x = px, fy; int f = 0;
    if (px < -60 || px > w + 60 || py < -40 || py > hh + 30) return 0;
    if (big && py < RM_FLOOR) f = 1;
    fy = rm_y0(big, f);
    x = clampf(x, (float)d->w * 0.5f + 6, w - (float)d->w * 0.5f - 6);
    out->id = (u8)(item + 1); out->x = (u8)clampf(x / 6.0f + 0.5f, 0, 255); out->fl = (u8)((out->fl & 2) | f); out->y = 0;
    if (d->kind == IK_WALL) { float up = fy + RM_H - py; out->y = (u8)(clampf(up, (float)d->h * 0.5f + 36, RM_H - (float)d->h * 0.5f - 12) / 4.0f); }
    return 1;
}
static void scr_house(void) {
    const Home *h = hv_home(); int own = !HV.visit, big = h->big; float nk = night_k(), dt = g_dt; char b[160];
    sky_draw(nk);
    if (HV.visit && (HV.loading || HV.err)) {
        title_text(HV.loading ? "Идём в гости..." : "Не получилось зайти в гости", 640, 330, 40);
        if (HV.err) gfx_text(&F_txt, "Проверь интернет и попробуй ещё раз", 640, 384, 24, 0xFFFFFFD0u, AL_CENTER);
        back_button(SC_CITY, 1); return;
    }
    if (own && !home_on()) { go(SC_CITY, 0, 0); return; }
    rv_house(big); rv_on();
    hk_update(h, dt, HE.on);
    house_draw(h, nk, h->asleep ? 1.0f : 0.0f, HE.drag >= 0 && HE.drag < PLACED_MAX ? HE.drag : -1);
    if (!HV.empty) {                                                                     /* Mel is at home */
        Kid k; kid_simple(&k, (float)pet_age_of(h->xp, NULL, NULL), h->wear, HK.t); k.lookx = HK.look * 0.6f;
        if (h->asleep) k.state |= KS_ASLEEP; else if (HV.visit) { k.arm[1] = 2.2f + sinf(HK.t * 7.0f) * 0.35f; k.fore[1] = 0.3f; k.mouth = 0.5f; }
        else { if (h->need[ND_THIRST] < 2500) k.state |= KS_THIRSTY; if (h->need[ND_HEALTH] < 3000) k.state |= KS_SICK; if (h->need[ND_ENERGY] < 2500) k.state |= KS_TIRED; if (h->need[ND_JOY] < 2500) k.smile = -0.6f; }
        kid_draw(HK.x, kid_floor_y(big) - hk_jump(), KID_S, &k);
        if (own && !HE.on && !ui_block && P.tapped && fabsf(rv_x(P.x) - HK.x) < 90 && rv_y(P.y) > kid_floor_y(big) - kid_height(k.age) * KID_S - 20 && rv_y(P.y) < kid_floor_y(big) + 20) { sfx(S_CLICK, 0.6f, P.x); rv_off(); go(SC_PET, 0, 0); return; }
    }
    /* ----- moving the furniture ----- */
    if (own && HE.on) {
        float px = rv_x(P.x), py = rv_y(P.y);
        if (HE.sel >= 0 && HM.pl[HE.sel].id && HE.drag < 0) {                            /* the chosen thing has a frame */
            float x0, y0, x1, y1; pl_box(&HM.pl[HE.sel], big, &x0, &y0, &x1, &y1, NULL, NULL);
            for (int i = 0; i < 4; i++) { float cx = i & 1 ? x1 + 6 : x0 - 6, cy = i & 2 ? y1 + 6 : y0 - 6; gfx_capsule(cx, cy, cx + (i & 1 ? -26.0f : 26.0f), cy, 3.5f, 0xFFD23FFFu); gfx_capsule(cx, cy, cx, cy + (i & 2 ? -26.0f : 26.0f), 3.5f, 0xFFD23FFFu); }
        }
        if (P.pressed && !ui_block && P.y < 624 && P.y > 96 && HE.drag < 0) {             /* take a thing that stands in the room: the one in front first */
            int hit = -1;
            for (int pass = 3; pass >= 0 && hit < 0; pass--) for (int i = PLACED_MAX - 1; i >= 0; i--) {
                static const u8 order[4] = { IK_WALL, IK_CEIL, IK_RUG, IK_FLOOR }; float x0, y0, x1, y1;
                if (!HM.pl[i].id || item_tab[HM.pl[i].id - 1].kind != order[pass]) continue;
                pl_box(&HM.pl[i], big, &x0, &y0, &x1, &y1, NULL, NULL);
                if (px >= x0 - 8 && px <= x1 + 8 && py >= y0 - 8 && py <= y1 + 8) { hit = i; break; }
            }
            HE.sel = hit;
            if (hit >= 0) { float ax, ay; pl_box(&HM.pl[hit], big, NULL, NULL, NULL, NULL, &ax, &ay); HE.drag = hit; HE.item = HM.pl[hit].id - 1; HE.gx = px - ax; HE.gy = item_tab[HE.item].kind == IK_WALL ? py - ay : 0; HE.moved = 0; }
        }
        if (HE.drag >= 0) {
            Placed np; memset(&np, 0, sizeof(np)); if (HE.drag < PLACED_MAX) np.fl = HM.pl[HE.drag].fl;
            if (fabsf(P.x - P.downx) + fabsf(P.y - P.downy) > 10) HE.moved = 1;
            HE.ok = he_target(HE.item, px - HE.gx, py - HE.gy, &np);
            if (HE.drag < PLACED_MAX && !HE.moved) pl_draw(&HM.pl[HE.drag], big);         /* (not moved yet: it stands where it stood) */
            else if (HE.ok) { float x0, y0, x1, y1; pl_box(&np, big, &x0, &y0, &x1, &y1, NULL, NULL); gfx_rrect(x0 - 6, y1 - 6, x1 - x0 + 12, 14, 7, 0x5CE06AA0u); pl_draw(&np, big); }
            else { rv_off(); item_icon(HE.item, P.x, P.y, 110); gfx_circle(P.x + 44, P.y - 44, 20, C_RED2); icon(IC_TRASH, P.x + 44, P.y - 44, 22, WHITE); rv_on(); }
            if (!P.down) {                                                               /* let go */
                if (HE.drag < PLACED_MAX) {
                    if (HE.moved) { if (HE.ok) HM.pl[HE.drag] = np; else { HM.pl[HE.drag].id = 0; HE.sel = -1; sfx(S_WHOOSH, 0.5f, P.x); } he_changed(); if (HE.ok) sfx(S_ATTACH, 0.6f, P.x); }
                } else if (HE.ok) {
                    int sl = he_free_slot();
                    if (items_placed(&HM) >= rm_cap(big)) gtoast(big ? "В доме больше нет места" : "В маленьком доме помещается 10 вещей. Большой дом вместит 40!");
                    else if (sl >= 0) { HM.pl[sl] = np; HE.sel = sl; he_changed(); sfx(S_ATTACH, 0.6f, P.x); }
                }
                HE.drag = -1;
            }
        }
    }
    rv_off();
    /* ----- the top line ----- */
    back_button(HV.from_city || HV.visit ? SC_CITY : SC_MENU, 1);
    if (own) { snprintf(b, sizeof(b), "Мой дом"); title_text(b, 640, 44, 40); snprintf(b, sizeof(b), HM.plot ? "Город Мелстроев, участок № %u  •  гостей было: %u" : "Город Мелстроев", (unsigned)HM.plot, (unsigned)HM.guests); gfx_text(&F_txt, b, 640, 82, 20, 0xFFFFFFE0u, AL_CENTER); coin_badge(1250, 62); }
    else {
        snprintf(b, sizeof(b), "В гостях у %s", HV.nick); float tw = gfx_text_w(&F_ui, b, 38); title_text(b, 640, 44, 38); if (HV.badge) badge_icon(HV.badge, 640 + tw * 0.5f + 26, 44, 15);
        if (HV.empty) snprintf(b, sizeof(b), "Участок № %u  •  хозяин ещё не заходил в свой дом", (unsigned)HV.plot);
        else { int age = pet_age_of(h->xp, NULL, NULL); snprintf(b, sizeof(b), "Участок № %u  •  его Мелу %d %s  •  гостей было: %u", (unsigned)HV.plot, age, plural(age, "год", "года", "лет"), (unsigned)HV.visits); }
        gfx_text(&F_txt, b, 640, 82, 20, 0xFFFFFFE0u, AL_CENTER);
    }
    if (!own) return;
    /* ----- the owner's buttons ----- */
    if (!HE.on) {
        int nb = HM.big ? 3 : 4; float x = 640 - (float)(nb - 1) * 142, y = 676;
        if (wbtn(2301, x, y, 270, 58, "Мой Мел", C_GREEN1, C_GREEN2, 26, IC_HEART, 1)) go(SC_PET, 0, 0);
        x += 284;
        if (wbtn(2302, x, y, 270, 58, "Мебель", C_BLUE1, C_BLUE2, 26, IC_EDIT, 1)) { HE.on = 1; HE.sel = -1; HE.note_t = 0; }
        if (HE.note_t > 0 || items_owned(&HM) > items_placed(&HM)) gfx_circle(x + 124, y - 24, 9, C_RED1);
        x += 284;
        if (wbtn(2303, x, y, 270, 58, "Задания месяца", C_PINK, 0xB8257FFFu, 23, IC_TASKS, 1)) go(SC_MONTH, 1, 0);
        x += 284;
        if (!HM.big) { snprintf(b, sizeof(b), "Большой дом: %d", HOUSE_PRICE); if (wbtn(2304, x, y, 270, 58, b, 0xFFE06AFFu, 0xD9930FFFu, 23, IC_HOME, 1)) {
            if (coins() >= HOUSE_PRICE) ask_open("Большой дом", "Перестроить дом в большой за 300 чекушек? В нём два этажа, комнаты шире и помещается 40 вещей вместо 10.", "Перестроить", house_buy_big, 0);
            else { snprintf(b, sizeof(b), "Большой дом стоит %d чекушек, а у тебя %d. Чекушки дают за задания и достижения.", HOUSE_PRICE, coins()); msg_open("Не хватает чекушек", b); } } }
    } else {
        /* the box of things that stand nowhere */
        int list[ITEM_N], n = 0, vis = 11; float x0 = 150, y = 672;
        for (int i = 0; i < ITEM_N; i++) if (item_has(&HM, i) && he_placed(i) < 0) list[n++] = i;
        gfx_rrect(26, 628, 1228, 88, 18, 0x0E0A2ED8u);
        if (HE.inv0 > n - vis) HE.inv0 = n - vis; if (HE.inv0 < 0) HE.inv0 = 0;
        if (n > vis) { if (rbtn(2310, 62, y, 24, IC_BACK, C_VIO1, C_VIO2, HE.inv0 > 0)) HE.inv0 -= 5; if (rbtn(2311, 1010, y, 24, IC_NEXT, C_VIO1, C_VIO2, HE.inv0 < n - vis)) HE.inv0 += 5; }
        if (!n) gfx_text(&F_txt, items_placed(&HM) ? "Все вещи расставлены. Новые дают задания месяца." : "Вещей пока нет. Их дают задания месяца.", 530, y, 22, 0xFFFFFFD0u, AL_CENTER);
        for (int k = 0; k < vis && HE.inv0 + k < n; k++) {
            int it = list[HE.inv0 + k]; float cx = x0 + (float)k * 78;
            gfx_rrect(cx - 35, y - 35, 70, 70, 12, 0x3A2A8CFFu); item_icon(it, cx, y, 56);
            if (P.pressed && !ui_block && HE.drag < 0 && fabsf(P.x - cx) < 36 && fabsf(P.y - y) < 36) { HE.drag = PLACED_MAX; HE.item = it; HE.gx = 0; HE.gy = 0; HE.moved = 1; HE.sel = -1; sfx(S_CLICK, 0.5f, P.x); }
        }
        if (HE.sel >= 0 && HM.pl[HE.sel].id && HE.drag < 0) {
            { const char *nm = item_tab[HM.pl[HE.sel].id - 1].name; float tw = gfx_text_w(&F_ui, nm, 24) + 44; gfx_rrect(640 - tw * 0.5f, 586, tw, 38, 19, 0x0E0A2ED8u); gfx_text(&F_ui, nm, 640, 605, 24, C_GOLD, AL_CENTER); }
            if (rbtn(2312, 1076, y, 27, IC_ROT, C_ORG1, C_ORG2, 1)) { HM.pl[HE.sel].fl ^= 2; he_changed(); }
            if (rbtn(2313, 1142, y, 27, IC_TRASH, C_RED1, C_RED2, 1)) { HM.pl[HE.sel].id = 0; HE.sel = -1; he_changed(); sfx(S_WHOOSH, 0.5f, 1142); }
        } else { snprintf(b, sizeof(b), "%d / %d", items_placed(&HM), rm_cap(big)); gfx_text(&F_ui, b, 1108, y, 24, 0xFFFFFFE0u, AL_CENTER); }
        if (rbtn(2314, 1212, y, 30, IC_OK, C_GREEN1, C_GREEN2, 1)) { HE.on = 0; HE.sel = -1; HE.drag = -1; }
        if (HE.drag < 0 && HE.sel < 0) { gfx_rrect(190, 588, 900, 34, 17, 0x0E0A2ED8u); gfx_text(&F_txt, "Перетащи вещь из коробки в комнату. Вещь в комнате можно передвинуть, а чтобы убрать — вынеси за стену.", 640, 605, 19, WHITE, AL_CENTER); }
    }
    if (HE.note_t > 0) HE.note_t -= dt;
}
