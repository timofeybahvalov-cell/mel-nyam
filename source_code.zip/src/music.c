/* ============================================================================
   MEL-ENGINE — the tunes of the ten locations (V0.5).

   The menu tune lives in the asset pack as recorded sound. These ten do not: they are written down as notes
   (chords, a melody line, a bass and drum patterns) and played into a buffer by the small synthesiser below when a
   location is entered. Ten more recordings would have made every build about 4 MB bigger.

   The work is cut into slices: music_begin() only lists the notes, every music_step() plays a few of them, so a frame
   of the game never waits for the music (the tune that was playing simply goes on until the new one is ready).
   Everything here is deterministic: the same track always gives the same samples on one machine.
   ============================================================================ */
#include "engine.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>

#define SR MUSIC_RATE
#define MAXLEN (46 * SR)
#define STEP_BUDGET 400000                 /* sample-partials per music_step(): well under a millisecond on a PC */

static float mbuf[MAXLEN];
static float sintab[4096]; static int sin_ok;

/* ---------------- instruments: a few sine partials each, with their own loudness and decay ---------------- */
typedef struct { int np; float ratio[6], amp[6], dec[6]; float att, rel, sus; } Inst;      /* sus 0: struck or plucked (dies away by itself) */
enum { IN_MARIMBA, IN_BELL, IN_SQUARE, IN_SAW, IN_EPIANO, IN_PLUCK, IN_FLUTE, IN_ORGAN, IN_STEEL, IN_BRASS, IN_BASS, IN_SUB, IN_SAWBASS, IN_PAD, IN_N };
static const Inst inst[IN_N] = {
    [IN_MARIMBA] = { 3, { 1, 4, 9.2f },              { 1, .35f, .12f },                      { 6.5f, 22, 40 },             .003f, 0, 0 },
    [IN_BELL]    = { 4, { 1, 2.76f, 5.4f, 8.9f },    { 1, .45f, .2f, .08f },                 { 6, 9, 18, 26 },             .002f, 0, 0 },
    [IN_SQUARE]  = { 5, { 1, 3, 5, 7, 9 },           { 1, .33f, .2f, .14f, .11f },           { 3, 3, 3.5f, 4, 5 },         .004f, .04f, .55f },
    [IN_SAW]     = { 6, { 1, 2, 3, 4, 5, 6 },        { 1, .5f, .33f, .25f, .2f, .166f },     { 3, 3.5f, 4, 5, 6, 7 },      .006f, .06f, .5f },
    [IN_EPIANO]  = { 4, { 1, 2, 3, 4 },              { 1, .28f, .1f, .06f },                 { 2.2f, 4, 6, 12 },           .004f, .15f, .22f },
    [IN_PLUCK]   = { 5, { 1, 2, 3, 4, 5 },           { 1, .5f, .28f, .15f, .08f },           { 5, 8, 12, 16, 22 },         .002f, 0, 0 },
    [IN_FLUTE]   = { 3, { 1, 2, 3 },                 { 1, .22f, .06f },                      { 1, 2, 3 },                  .05f, .09f, .8f },
    [IN_ORGAN]   = { 5, { 1, 2, 3, 4, 6 },           { 1, .6f, .3f, .25f, .12f },            { .5f, .5f, .5f, .5f, .5f },  .01f, .05f, .9f },
    [IN_STEEL]   = { 4, { 1, 2, 3.01f, 4.02f },      { 1, .6f, .25f, .1f },                  { 5, 7, 12, 18 },             .002f, 0, 0 },
    [IN_BRASS]   = { 6, { 1, 2, 3, 4, 5, 6 },        { 1, .7f, .5f, .35f, .22f, .15f },      { 2, 2, 2.5f, 3, 3.5f, 4 },   .03f, .07f, .7f },
    [IN_BASS]    = { 3, { 1, 2, 3 },                 { 1, .35f, .12f },                      { 5.5f, 7, 9 },               .006f, 0, 0 },
    [IN_SUB]     = { 2, { 1, 2 },                    { 1, .2f },                             { 1, 2 },                     .01f, .04f, .8f },
    [IN_SAWBASS] = { 5, { 1, 2, 3, 4, 5 },           { 1, .55f, .35f, .22f, .15f },          { 4, 5, 6, 8, 10 },           .004f, .03f, .45f },
    [IN_PAD]     = { 4, { 1, 2, 3, 4 },              { 1, .4f, .2f, .1f },                   { .3f, .4f, .5f, .6f },       .25f, .3f, .85f },
};
enum { DR_KICK, DR_SNARE, DR_HAT, DR_OHAT, DR_CLAP, DR_RIM, DR_SHAKER, DR_COWBELL, DR_TOM };

/* ---------------- the tracks ----------------
   chords: one per bar (the list repeats when it is shorter than the track).
   mel:    bars are divided by '|', a bar has eight steps (eighth notes): a note name, '.' = rest, '-' = the note goes on.
   bass, comp and the drums: one character for every sixteenth of a bar (the pattern repeats; 32 characters = two bars).
     bass: 1 3 5 6 7 8 = that note of the chord, '.' = nothing.
     comp: x = the chord struck, 1..4 = one note of the chord (A..D: the same an octave higher).
     drums: x = a hit, o = a soft hit. */
typedef struct {
    float bpm, swing; int bars;
    const char *chords, *mel;
    int lead, lead2; float lead_vol, lead_len;
    const char *bass; int bass_in; float bass_vol;
    const char *comp; int comp_in; float comp_vol, comp_len, pad;      /* pad: a soft chord held through every bar (0 = none) */
    const char *kick, *snare, *hat, *perc; int snare_kind, perc_kind; float drum_vol;
} Track;
static const Track tracks[MUSIC_TRACKS] = {
    /* 0 Стримерская: an easy lo-fi beat */
    { 84, 0.16f, 16, "Dm7 G7 Cmaj7 Am7 Dm7 G7 Em7 A7",
      "A4 . C5 . D5 . C5 A4|B4 . D5 . . . G4 .|E5 . D5 C5 . G4 . .|A4 . C5 . E5 . . .|F5 . E5 D5 . A4 . C5|D5 . B4 . G4 . . .|G4 . B4 . D5 . E5 .|C#5 . E5 . A4 . . .|"
      "D5 . F5 . A5 . F5 D5|F5 . D5 . B4 . D5 .|E5 G5 . E5 . C5 . .|C5 . A4 . E5 . C5 .|A4 . D5 . F5 . E5 D5|B4 . D5 . G5 . F5 .|E5 . . D5 . B4 . G4|A4 . . . C#5 . E5 .",
      IN_FLUTE, IN_BELL, 0.30f, 1.7f,
      "1.......5...1...", IN_BASS, 0.55f,
      "x.....x.........", IN_EPIANO, 0.17f, 7.0f, 0,
      "x.....x...x.....", "....x.......x...", "x.x.x.x.x.x.x.xo", "", DR_SNARE, DR_SHAKER, 0.85f },
    /* 1 Пентхаус: lounge with a disco bass */
    { 108, 0, 16, "Am7 Dm7 G7 Cmaj7 Fmaj7 Dm7 E7 E7",
      "E5 . . C5 . A4 . C5|D5 . . F5 . . A4 .|B4 . D5 . F5 . D5 .|E5 . . . G4 . C5 .|A5 . G5 . F5 . E5 .|F5 . . D5 . . A4 .|G#4 . B4 . D5 . E5 .|E5 . . . . . G#4 B4|"
      "A4 C5 E5 . A5 . E5 .|D5 . F5 . A5 . F5 .|G5 . F5 . D5 . B4 .|C5 . E5 . G5 . . .|C6 . A5 . F5 . C5 .|D5 . F5 . A5 . . F5|E5 . G#5 . B5 . G#5 .|E5 . D5 . B4 . G#4 .",
      IN_EPIANO, IN_BELL, 0.38f, 2.2f,
      "1.8.1.8.1.8.1.8.", IN_BASS, 0.50f,
      "..x..x....x..x..", IN_EPIANO, 0.15f, 2.0f, 0.04f,
      "x...x...x...x...", "....x.......x...", "o.x.o.x.o.x.o.x.", "", DR_CLAP, DR_SHAKER, 0.80f },
    /* 2 Вилла: bossa nova */
    { 124, 0, 16, "Dm7 G7 Cmaj7 A7 Dm7 G7 Cmaj7 Cmaj7",
      "F5 . E5 D5 . A4 . D5|. B4 . D5 . F5 E5 D5|E5 . . G5 . E5 . C5|. C#5 . E5 . G5 . E5|F5 . A5 . F5 . D5 .|F5 . D5 . B4 . G4 .|C5 . E5 . G5 . B5 .|G5 . . . E5 . . .|"
      "A5 . . F5 . D5 . F5|G5 . . F5 . D5 . B4|C5 . D5 E5 . G5 . E5|A5 . G5 . E5 . C#5 .|D5 . F5 . A5 . C6 .|B5 . G5 . F5 . D5 .|E5 . G5 . C6 . G5 .|E5 . . . C5 . . .",
      IN_PLUCK, IN_FLUTE, 0.36f, 1.6f,
      "1.....5.1.....5.", IN_BASS, 0.50f,
      "x..x..x...x.x...", IN_PLUCK, 0.13f, 1.5f, 0,
      "x.....x.x.....x.", "", "xoxoxoxoxoxoxoxo", "x..x..x...x..x..", DR_SNARE, DR_RIM, 0.70f },
    /* 3 Спортзал: a fast square-wave tune */
    { 128, 0, 16, "Em Em G D Em Em C D",
      "E5 E5 G5 E5 B4 . D5 E5|G5 . E5 . B4 D5 E5 .|G5 G5 B5 G5 D5 . G5 A5|A5 . F#5 . D5 . F#5 .|E5 E5 G5 E5 B4 . D5 E5|B5 . G5 . E5 G5 B5 .|C6 . G5 . E5 . G5 .|A5 . F#5 . D5 . . .|"
      "B5 . B5 A5 G5 . E5 .|G5 . G5 F#5 E5 . B4 .|D5 . G5 . B5 . D6 .|A5 . F#5 A5 D6 . A5 .|B5 . B5 A5 G5 . E5 .|E5 G5 B5 E6 . B5 G5 .|E5 . G5 . C6 . E6 .|D6 . A5 . F#5 . D5 .",
      IN_SQUARE, IN_SQUARE, 0.28f, 0.9f,
      "1.1.8.1.1.1.8.1.", IN_SAWBASS, 0.36f,
      "x.....x...x.....", IN_SAW, 0.10f, 1.6f, 0,
      "x...x...x...x...", "....x.......x..x", "x.xxx.xxx.xxx.xx", "", DR_SNARE, DR_CLAP, 0.85f },
    /* 4 Гараж: a blues shuffle */
    { 112, 0.33f, 16, "A7 A7 A7 A7 D7 D7 A7 A7 E7 D7 A7 E7 A7 D7 A7 E7",
      "A4 . C5 . D5 . E5 .|G5 . E5 . D5 C5 A4 .|A4 . C5 . D5 . E5 G5|A5 . . . G5 . E5 .|D5 . F#5 . A5 . C6 .|A5 . F#5 . D5 . C5 .|A4 . C5 . D5 . E5 .|G5 . E5 . C5 . A4 .|"
      "E5 . G#5 . B5 . D6 .|C6 . A5 . F#5 . D5 .|E5 . C5 . A4 . C5 D5|E5 . . . B4 . G#4 .|A5 . G5 . E5 . D5 C5|D5 . F#5 . A5 . F#5 .|A4 C5 D5 E5 G5 . A5 .|E5 . D5 . B4 . G#4 .",
      IN_SAW, IN_ORGAN, 0.30f, 1.3f,
      "1.1.3.3.5.5.6.5.", IN_BASS, 0.52f,
      "....x.......x...", IN_ORGAN, 0.075f, 1.6f, 0.05f,
      "x.....x.x.......", "....x.......x...", "x.x.x.x.x.x.x.x.", "", DR_SNARE, DR_SHAKER, 0.85f },
    /* 5 Самолёт: slow and airy, with a running arpeggio */
    { 100, 0, 16, "Fmaj7 G Em7 Am Fmaj7 G Am Am",
      "A5 - - . C6 - - .|B5 - - . D6 - B5 .|G5 - - . B5 - - .|A5 - - . E5 - - .|C6 - - . A5 . F5 .|D6 - - . B5 . G5 .|E6 - . D6 C6 . A5 .|A5 - - - - . . .|"
      "F5 . A5 . C6 . E6 .|D6 . B5 . G5 . B5 .|E5 . G5 . B5 . D6 .|C6 . A5 . E5 . A5 .|A5 . C6 . F6 . E6 .|D6 - . B5 - . G5 .|A5 . C6 . E6 - . C6|A5 - - . E5 - - .",
      IN_FLUTE, IN_BELL, 0.26f, 1.0f,
      "1.1.1.1.1.1.1.1.", IN_SUB, 0.24f,
      "12A3B3A2C3B3A2A3", IN_PLUCK, 0.12f, 1.4f, 0.07f,
      "x.......x.....x.", "....x.......x...", "x.x.x.x.x.x.x.x.", "", DR_SNARE, DR_SHAKER, 0.75f },
    /* 6 Клуб: four on the floor */
    { 126, 0, 16, "Am F C G Am F C E",
      "A5 . A5 C6 . A5 E5 .|F5 . F5 A5 . F5 C5 .|G5 . G5 C6 . G5 E5 .|D5 . D5 G5 . B5 D6 .|A5 . A5 C6 . A5 E5 .|F5 . A5 C6 . A5 F5 .|E6 . C6 . G5 . E5 .|E5 . G#5 . B5 . E6 .|"
      "E6 . C6 A5 . C6 E6 .|F6 . C6 A5 . C6 F6 .|E6 . C6 G5 . C6 E6 .|D6 . B5 G5 . B5 D6 .|E6 . C6 A5 . C6 E6 .|F6 . . C6 . A5 . F5|G5 . C6 . E6 . G6 .|G#5 . B5 . E6 . . .",
      IN_SAW, IN_SQUARE, 0.27f, 0.9f,
      "..1...1...1...1.", IN_SAWBASS, 0.36f,
      "..x...x...x...x.", IN_SAW, 0.07f, 1.3f, 0.045f,
      "x...x...x...x...", "....x.......x...", "o.x.o.x.o.x.o.x.", "xxxxxxxxxxxxxxxx", DR_CLAP, DR_SHAKER, 0.90f },
    /* 7 Яхта: an easy reggae off-beat */
    { 96, 0.12f, 16, "C G Am F C G F G",
      "E5 . G5 . C6 . G5 E5|D5 . G5 . B5 . G5 .|C5 . E5 . A5 . E5 C5|A4 . C5 . F5 . . .|G5 . E5 . C5 . E5 G5|B5 . G5 . D5 . G5 .|A5 . F5 . C5 . F5 A5|G5 . . . B4 . D5 .|"
      "C6 . . G5 . E5 . G5|B5 . . G5 . D5 . G5|A5 . . E5 . C5 . E5|F5 . A5 . C6 . A5 .|E5 G5 C6 . E6 . C6 .|D5 G5 B5 . D6 . B5 .|C5 F5 A5 . C6 . A5 .|B4 D5 G5 . B5 . . .",
      IN_MARIMBA, IN_STEEL, 0.46f, 1.5f,
      "1..1....5..5.1..", IN_BASS, 0.58f,
      "..x...x...x...x.", IN_ORGAN, 0.11f, 0.9f, 0,
      "........x.......", "", "x.x.x.x.x.x.x.x.", "........x.......", DR_SNARE, DR_RIM, 0.80f },
    /* 8 Остров: calypso on steel drums */
    { 110, 0, 16, "G C D G G C D G Em C G D Em C D G",
      "D5 . B4 D5 G5 . D5 .|E5 . C5 E5 G5 . E5 .|F#5 . D5 F#5 A5 . F#5 .|G5 . D5 . B4 . . .|B5 . G5 B5 D6 . B5 .|C6 . G5 C6 E6 . C6 .|A5 . F#5 A5 D6 . C6 .|B5 . G5 . D5 . . .|"
      "E5 . G5 . B5 . G5 E5|E5 . G5 . C6 . G5 E5|D5 . G5 . B5 . G5 D5|D5 . F#5 . A5 . . .|B5 . G5 . E5 . G5 B5|C6 . G5 . E5 . G5 C6|D6 . C6 . A5 . F#5 .|G5 . . . . . D5 .",
      IN_STEEL, IN_MARIMBA, 0.38f, 1.4f,
      "1..5..8.1..5..8.", IN_BASS, 0.55f,
      "..x.x...x.x...x.", IN_PLUCK, 0.12f, 1.0f, 0,
      "x...x...x...x...", "", "xoxoxoxoxoxoxoxo", "x.x.x..x.x.x..x.", DR_SNARE, DR_COWBELL, 0.72f },
    /* 9 Арена: the exam, fast and stern */
    { 140, 0, 16, "Dm Dm Bb C Dm Dm Bb A",
      "D5 . . D5 F5 . A5 .|A5 . G5 F5 . E5 D5 .|Bb4 . . Bb4 D5 . F5 .|G5 . F5 E5 . G5 C6 .|D6 . . A5 . F5 . D5|F5 . A5 . D6 - - .|D6 . Bb5 . F5 . D5 .|E5 . C#5 . A4 . C#5 E5|"
      "A5 . A5 . D6 . A5 .|F5 . A5 . D6 . F6 .|F6 . D6 . Bb5 . F5 .|E6 . C6 . G5 . E5 .|D6 . F6 . A6 . F6 .|D6 . A5 . F5 . D5 .|Bb5 . D6 . F6 . D6 .|A5 . C#6 . E6 - - .",
      IN_BRASS, IN_BELL, 0.28f, 1.2f,
      "1.11.11.1.11.11.", IN_SAWBASS, 0.36f,
      "x.x.x.x.x.x.x.x.", IN_SAW, 0.06f, 0.9f, 0.04f,
      "x..x..x.x..x..x.", "....x.......x...", "xoxoxoxoxoxoxoxo", "..............xx", DR_SNARE, DR_TOM, 0.85f },
};

/* ---------------- notes -> a list of things to play ---------------- */
typedef struct { int t0, dur; float f, vol; short kind, in; } Ev;      /* kind 0: a note of instrument `in`; kind 1: a drum `in` */
#define MAXEV 6000
static Ev ev[MAXEV]; static int nev, ev_i;
static Sound *m_dst; static int m_n, m_phase, m_pos; static float m_peak, m_dc, m_lp; static double m_sq;

static float midi_f(int m) { return 440.0f * powf(2.0f, (float)(m - 69) / 12.0f); }
static int note_midi(const char *s, int n) {             /* "C#5" -> 73; 0 when it is not a note */
    static const int base[7] = { 9, 11, 0, 2, 4, 5, 7 };   /* A B C D E F G */
    if (n < 2 || s[0] < 'A' || s[0] > 'G') return 0;
    int m = base[s[0] - 'A'], i = 1;
    if (s[i] == '#') { m++; i++; } else if (s[i] == 'b') { m--; i++; }
    if (i >= n || s[i] < '0' || s[i] > '9') return 0;
    return m + 12 * (s[i] - '0' + 1);
}
typedef struct { int root, n, t[4], third, seventh; } Chord;      /* root 0..11; t: semitones above the root */
static void chord_parse(const char *s, int n, Chord *c) {
    static const int base[7] = { 9, 11, 0, 2, 4, 5, 7 };
    int i = 1; c->root = base[s[0] - 'A']; if (i < n && s[i] == '#') { c->root++; i++; } else if (i < n && s[i] == 'b') { c->root--; i++; }
    c->root = (c->root + 12) % 12; c->n = 3; c->t[0] = 0; c->t[1] = 4; c->t[2] = 7; c->t[3] = 12; c->third = 4; c->seventh = 10;
    const char *q = s + i; int qn = n - i;
    if (qn >= 4 && !strncmp(q, "maj7", 4)) { c->n = 4; c->t[3] = 11; c->seventh = 11; }
    else if (qn >= 2 && !strncmp(q, "m7", 2)) { c->n = 4; c->t[1] = 3; c->t[3] = 10; c->third = 3; }
    else if (qn >= 1 && q[0] == 'm') { c->t[1] = 3; c->third = 3; }
    else if (qn >= 1 && q[0] == '7') { c->n = 4; c->t[3] = 10; }
}
static const char *nth_word(const char *s, int k, int *len) {     /* the k-th word of a space-separated list, wrapping around */
    int total = 0; const char *p = s;
    while (*p) { while (*p == ' ') p++; if (!*p) break; total++; while (*p && *p != ' ') p++; }
    if (!total) { *len = 0; return s; }
    k %= total; p = s;
    for (;;) { while (*p == ' ') p++; const char *b = p; while (*p && *p != ' ') p++; if (k-- == 0) { *len = (int)(p - b); return b; } }
}
static void add_ev(int kind, int in, float t, float dur, float f, float vol) {
    if (nev >= MAXEV || vol <= 0) return;
    Ev *e = &ev[nev++]; e->kind = (short)kind; e->in = (short)in; e->t0 = (int)(t * SR + 0.5f); e->dur = (int)(dur * SR + 0.5f); e->f = f; e->vol = vol;
}
static char pat_at(const char *p, int bar, int step) { int n = p ? (int)strlen(p) : 0; if (!n) return '.'; return p[(bar * 16 + step) % n]; }

static void build_events(const Track *tr) {
    float beat = 60.0f / tr->bpm, s16 = beat * 0.25f, s8 = beat * 0.5f, sw = tr->swing * s8 * 0.5f;
    nev = 0;
    /* the melody: split into bars and steps first, so that a held note ('-') knows how long it is */
    const char *p = tr->mel; int last = -1;
    for (int bar = 0; bar < tr->bars && *p; bar++) {
        for (int st = 0; st < 8; st++) {
            while (*p == ' ') p++;
            const char *b = p; while (*p && *p != ' ' && *p != '|') p++;
            int n = (int)(p - b), m = note_midi(b, n);
            float t = (float)bar * 4 * beat + (float)st * s8 + ((st & 1) ? sw : 0);
            if (m) {
                int second = bar >= tr->bars / 2;
                last = nev; add_ev(0, tr->lead, t, s8 * tr->lead_len, midi_f(m), tr->lead_vol);
                if (second && tr->lead2 >= 0) add_ev(0, tr->lead2, t, s8 * tr->lead_len, midi_f(m + (tr->lead2 == tr->lead ? 12 : 0)), tr->lead_vol * (tr->lead2 == tr->lead ? 0.22f : 0.5f));
            } else if (n == 1 && b[0] == '-' && last >= 0) { ev[last].dur += (int)(s8 * SR); if (last + 1 < nev && ev[last + 1].t0 == ev[last].t0) ev[last + 1].dur += (int)(s8 * SR); }
            else last = -1;
        }
        while (*p == ' ') p++;
        if (*p == '|') p++;
    }
    for (int bar = 0; bar < tr->bars; bar++) {
        int cl; const char *cs = nth_word(tr->chords, bar, &cl); Chord c; chord_parse(cs, cl, &c);
        float t0 = (float)bar * 4 * beat;
        int voic[4];                                    /* the chord around the middle of the keyboard: every note between G3 and F#4 */
        for (int k = 0; k < 4; k++) { int m = 48 + c.root + c.t[k]; while (m < 55) m += 12; while (m > 66) m -= 12; voic[k] = m; }
        if (tr->pad > 0) for (int k = 0; k < 3; k++) add_ev(0, IN_PAD, t0, 4 * beat * 0.96f, midi_f(voic[k]), tr->pad);
        for (int st = 0; st < 16; st++) {
            float t = t0 + (float)st * s16 + ((st & 2) ? sw : 0);
            char ch = pat_at(tr->bass, bar, st);
            if (ch != '.') {
                int semi = ch == '1' ? 0 : ch == '3' ? c.third : ch == '5' ? 7 : ch == '6' ? 9 : ch == '7' ? c.seventh : ch == '8' ? 12 : -1;
                if (semi >= 0) {
                    int len = 1; while (st + len < 16 && pat_at(tr->bass, bar, st + len) == '.' && len < 4) len++;
                    int m = 36 + c.root + semi; if (m > 52) m -= 12;                      /* the bass stays between C2 and E3 */
                    add_ev(0, tr->bass_in, t, s16 * (float)len * 0.92f, midi_f(m), tr->bass_vol);
                }
            }
            ch = pat_at(tr->comp, bar, st);
            if (ch == 'x') for (int k = 0; k < (c.n < 4 ? 3 : 4); k++) add_ev(0, tr->comp_in, t + (float)k * 0.006f, s16 * tr->comp_len, midi_f(voic[k]), tr->comp_vol);
            else if ((ch >= '1' && ch <= '4') || (ch >= 'A' && ch <= 'D')) { int up = ch >= 'A', k = up ? ch - 'A' : ch - '1'; add_ev(0, tr->comp_in, t, s16 * tr->comp_len, midi_f(voic[k] + 12 + (up ? 12 : 0)), tr->comp_vol); }
            float dv = tr->drum_vol;
            ch = pat_at(tr->kick, bar, st);  if (ch != '.') add_ev(1, DR_KICK, t, 0, 0, dv * (ch == 'x' ? 0.55f : 0.3f));
            ch = pat_at(tr->snare, bar, st); if (ch != '.') add_ev(1, tr->snare_kind, t, 0, 0, dv * (ch == 'x' ? 0.24f : 0.12f));
            ch = pat_at(tr->hat, bar, st);   if (ch != '.') add_ev(1, ch == 'O' ? DR_OHAT : DR_HAT, t, 0, 0, dv * (ch == 'x' ? 0.085f : 0.05f));
            ch = pat_at(tr->perc, bar, st);  if (ch != '.') add_ev(1, tr->perc_kind, t, 0, 0, dv * (ch == 'x' ? 0.10f : 0.055f));
        }
    }
}

/* ---------------- playing one thing into the buffer (the tail wraps around: the loop has no seam) ---------------- */
static int play_note(const Ev *e) {
    const Inst *in = &inst[e->in]; int N = m_n, cost = 0;
    int att = (int)(in->att * SR); if (att < 1) att = 1;
    for (int k = 0; k < in->np; k++) {
        float f = e->f * in->ratio[k]; if (f > 0.45f * SR) continue;
        float d = expf(-in->dec[k] / SR), a = in->amp[k] * e->vol, env = 1.0f, rel = 1.0f, rd = in->sus > 0 ? expf(-1.0f / (in->rel * SR)) : 1.0f;
        int len = in->sus > 0 ? e->dur + (int)(in->rel * 6.0f * SR) : (int)(6.9f / in->dec[k] * SR);
        if (len > 3 * SR) len = 3 * SR;
        u32 ph = 0, inc = (u32)((double)f * 4294967296.0 / SR);
        int pos = e->t0 % N;
        for (int i = 0; i < len; i++) {
            float g = a * (in->sus + (1.0f - in->sus) * env); env *= d;
            if (i < att) g *= (float)i / (float)att;
            if (in->sus > 0 && i > e->dur) { rel *= rd; g *= rel; }
            mbuf[pos] += sintab[ph >> 20] * g; ph += inc;
            if (++pos >= N) pos = 0;
        }
        cost += len;
    }
    return cost;
}
static u32 nz = 22222;
static float noise(void) { nz = nz * 1664525u + 1013904223u; return (float)(int)(nz >> 8) / 8388608.0f - 1.0f; }
static int play_drum(const Ev *e) {
    int N = m_n, pos = e->t0 % N, len = 0; float v = e->vol;
#define OUT(x) do { mbuf[pos] += (x); if (++pos >= N) pos = 0; } while (0)
    switch (e->in) {
    case DR_KICK: {
        len = (int)(0.22f * SR); float ph = 0, f = 150, fd = expf(-26.0f / SR), a = 1, ad = expf(-15.0f / SR);
        for (int i = 0; i < len; i++) { ph += f / SR; f = 46.0f + (f - 46.0f) * fd; OUT(sintab[(u32)(ph * 4096.0f) & 4095] * a * v); a *= ad; }
    } break;
    case DR_TOM: {
        len = (int)(0.2f * SR); float ph = 0, f = 220, fd = expf(-12.0f / SR), a = 1, ad = expf(-14.0f / SR);
        for (int i = 0; i < len; i++) { ph += f / SR; f = 110.0f + (f - 110.0f) * fd; OUT(sintab[(u32)(ph * 4096.0f) & 4095] * a * v * 2.2f); a *= ad; }
    } break;
    case DR_SNARE: {
        len = (int)(0.14f * SR); float lp = 0, a = 1, ad = expf(-26.0f / SR), ph = 0, ta = 1, tad = expf(-34.0f / SR), k = 1.0f - expf(-6.2832f * 1800.0f / SR);
        for (int i = 0; i < len; i++) { float n = noise(); lp += (n - lp) * k; ph += 190.0f / SR; OUT(((n - lp) * a + sintab[(u32)(ph * 4096.0f) & 4095] * ta * 0.55f) * v); a *= ad; ta *= tad; }
    } break;
    case DR_CLAP: {
        len = (int)(0.16f * SR); float lp = 0, lp2 = 0, k = 1.0f - expf(-6.2832f * 900.0f / SR), k2 = 1.0f - expf(-6.2832f * 3200.0f / SR);
        for (int i = 0; i < len; i++) {
            float t = (float)i / SR, env = t < 0.03f ? (fmodf(t, 0.01f) < 0.006f ? 1.0f : 0.25f) : expf(-(t - 0.03f) * 30.0f);
            float n = noise(); lp += (n - lp) * k; lp2 += (n - lp - lp2) * k2; OUT(lp2 * env * v * 2.4f);
        }
    } break;
    case DR_HAT: case DR_OHAT: case DR_SHAKER: {
        float dec = e->in == DR_HAT ? 70.0f : (e->in == DR_OHAT ? 16.0f : 34.0f), fc = e->in == DR_SHAKER ? 4200.0f : 6500.0f;
        len = (int)((e->in == DR_HAT ? 0.06f : (e->in == DR_OHAT ? 0.25f : 0.1f)) * SR);
        float lp = 0, a = 1, ad = expf(-dec / SR), k = 1.0f - expf(-6.2832f * fc / SR); int at = e->in == DR_SHAKER ? (int)(0.012f * SR) : 1;
        for (int i = 0; i < len; i++) { float n = noise(); lp += (n - lp) * k; OUT((n - lp) * a * v * (i < at ? (float)i / (float)at : 1.0f)); a *= ad; }
    } break;
    case DR_RIM: {
        len = (int)(0.05f * SR); float ph = 0, a = 1, ad = expf(-90.0f / SR);
        for (int i = 0; i < len; i++) { ph += 1750.0f / SR; OUT((sintab[(u32)(ph * 4096.0f) & 4095] * 0.8f + noise() * 0.25f) * a * v * 1.6f); a *= ad; }
    } break;
    case DR_COWBELL: {
        len = (int)(0.12f * SR); float p1 = 0, p2 = 0, a = 1, ad = expf(-30.0f / SR);
        for (int i = 0; i < len; i++) { p1 += 587.0f / SR; p2 += 845.0f / SR; float s = (sintab[(u32)(p1 * 4096.0f) & 4095] > 0 ? 0.5f : -0.5f) + (sintab[(u32)(p2 * 4096.0f) & 4095] > 0 ? 0.5f : -0.5f); OUT(s * a * v * 0.8f); a *= ad; }
    } break;
    default: break;
    }
#undef OUT
    return len;
}

/* ---------------- the public part ---------------- */
int music_max(void) { return MAXLEN; }
int music_len(int track) {
    if (track < 0 || track >= MUSIC_TRACKS) return 0;
    int n = (int)((double)tracks[track].bars * 4.0 * 60.0 / tracks[track].bpm * SR + 0.5); return n > MAXLEN ? MAXLEN : n;
}
void music_begin(int track, Sound *dst) {
    if (!sin_ok) { for (int i = 0; i < 4096; i++) sintab[i] = sinf((float)i * (TAU / 4096.0f)); sin_ok = 1; }
    if (track < 0 || track >= MUSIC_TRACKS || !dst) { m_dst = NULL; m_phase = 0; return; }
    m_dst = dst; m_n = music_len(track);                 /* (dst->pcm must have room for music_max() samples) */
    memset(mbuf, 0, (size_t)m_n * sizeof(float));
    nz = 22222u + (u32)track * 977u;
    build_events(&tracks[track]); ev_i = 0; m_phase = 1; m_pos = 0; m_peak = 0; m_dc = 0; m_lp = 0; m_sq = 0;
}
int music_step(void) {
    if (!m_dst || !m_phase) return 0;
    if (m_phase == 1) {                                  /* the notes and the drums */
        int cost = 0;
        while (ev_i < nev && cost < STEP_BUDGET) { const Ev *e = &ev[ev_i++]; cost += e->kind ? play_drum(e) : play_note(e); }
        if (ev_i >= nev) { m_phase = 2; m_pos = 0; double s = 0; for (int i = 0; i < m_n; i += 16) s += mbuf[i]; m_dc = (float)(s / (double)((m_n + 15) / 16)); m_lp = mbuf[m_n - 1] - m_dc; }
        return 1;
    }
    if (m_phase == 2) {                                  /* a gentle low-pass (the top would only hiss at this sample rate), and how loud the loudest moment is */
        float k = 1.0f - expf(-6.2832f * 7000.0f / SR); int end = m_pos + 150000; if (end > m_n) end = m_n;
        for (int i = m_pos; i < end; i++) { m_lp += (mbuf[i] - m_dc - m_lp) * k; mbuf[i] = m_lp; float a = m_lp < 0 ? -m_lp : m_lp; if (a > m_peak) m_peak = a; m_sq += (double)m_lp * m_lp; }
        m_pos = end; if (m_pos >= m_n) { m_phase = 3; m_pos = 0; }
        return 1;
    }
    {                                                    /* loud moments are rounded off, not clipped; on average the tune is as loud as the menu tune */
        float g = m_peak > 1e-6f ? 1.25f / m_peak : 0, rms = (float)sqrt(m_sq / (double)m_n) * g, out = 0.78f / 0.8695f;
        if (rms > 1e-6f && 0.15f / rms < out) out = 0.15f / rms;
        out *= 32767.0f; int end = m_pos + 150000; if (end > m_n) end = m_n;
        for (int i = m_pos; i < end; i++) { float x = mbuf[i] * g, x2 = x * x, y = x * (27.0f + x2) / (27.0f + 9.0f * x2); m_dst->pcm[i] = (i16)(y * out); }
        m_pos = end;
        if (m_pos >= m_n) { m_dst->n = m_n; m_dst->rate = SR; m_phase = 0; return 0; }
    }
    return 1;
}
