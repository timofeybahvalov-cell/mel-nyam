/* ============================================================================
   «Мел-Ням» — Windows platform layer (pure Win32: window, GDI blit, waveOut audio).
   No third-party libraries. The asset pack is linked into the .exe as RCDATA.
   ============================================================================ */
#define WIN32_LEAN_AND_MEAN
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <mmsystem.h>
#include <wininet.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "engine.h"

#define ID_PACK 100

static HWND g_hwnd;
static u32 *g_fb; static int g_fbw, g_fbh;              /* framebuffer (render resolution)      */
static int g_cw, g_ch, g_dx, g_dy, g_dw, g_dh;          /* client size, letterboxed 16:9 target */
static int g_cap = 1440;                                /* max render height (adaptive)         */
static int g_quit, g_full, g_inmodal, g_started, g_down, g_tracking;
static volatile LONG g_silent;                         /* minimized: keep the device fed with silence */
static WINDOWPLACEMENT g_wp = { sizeof(WINDOWPLACEMENT) };
static CRITICAL_SECTION g_alock;
static LARGE_INTEGER g_freq, g_last;
static double g_ema; static int g_slow;
static const char *g_shot; static int g_shot_frames, g_frames;
typedef HRESULT (WINAPI *dwmflush_fn)(void);
static dwmflush_fn g_dwmflush; static int g_dwm_miss;   /* DwmFlush(): wait for the compositor's vblank (smooth pacing) */

/* ---------------- audio: waveOut + feeder thread ---------------- */
#define ABUFS 3
#define AFRAMES 1024
static HWAVEOUT g_wo; static WAVEHDR g_wh[ABUFS]; static i16 g_abuf[ABUFS][AFRAMES * 2];
static HANDLE g_aevent, g_athread; static volatile LONG g_arun;
static DWORD WINAPI audio_thread(LPVOID p) {
    (void)p;
    while (g_arun) {
        WaitForSingleObject(g_aevent, 50);
        for (int i = 0; i < ABUFS; i++) if (g_wh[i].dwFlags & WHDR_DONE) {
            if (g_silent) memset(g_abuf[i], 0, sizeof(g_abuf[i]));
            else { EnterCriticalSection(&g_alock); audio_mix(g_abuf[i], AFRAMES); LeaveCriticalSection(&g_alock); }
            g_wh[i].dwFlags &= ~WHDR_DONE;
            waveOutWrite(g_wo, &g_wh[i], sizeof(WAVEHDR));
        }
    }
    return 0;
}
static void audio_start(void) {
    WAVEFORMATEX wf; memset(&wf, 0, sizeof(wf));
    wf.wFormatTag = WAVE_FORMAT_PCM; wf.nChannels = 2; wf.nSamplesPerSec = 44100; wf.wBitsPerSample = 16; wf.nBlockAlign = 4; wf.nAvgBytesPerSec = 44100 * 4;
    g_aevent = CreateEventW(NULL, FALSE, FALSE, NULL);
    if (waveOutOpen(&g_wo, WAVE_MAPPER, &wf, (DWORD_PTR)g_aevent, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) { g_wo = NULL; return; }
    for (int i = 0; i < ABUFS; i++) {
        memset(&g_wh[i], 0, sizeof(WAVEHDR)); g_wh[i].lpData = (LPSTR)g_abuf[i]; g_wh[i].dwBufferLength = AFRAMES * 4;
        waveOutPrepareHeader(g_wo, &g_wh[i], sizeof(WAVEHDR)); waveOutWrite(g_wo, &g_wh[i], sizeof(WAVEHDR));
    }
    g_arun = 1; g_athread = CreateThread(NULL, 0, audio_thread, NULL, 0, NULL);
}
static void audio_stop(void) {
    if (!g_wo) return;
    g_arun = 0; SetEvent(g_aevent); WaitForSingleObject(g_athread, 500);
    waveOutReset(g_wo);
    for (int i = 0; i < ABUFS; i++) waveOutUnprepareHeader(g_wo, &g_wh[i], sizeof(WAVEHDR));
    waveOutClose(g_wo); g_wo = NULL;
}
void plat_audio_lock(void) { EnterCriticalSection(&g_alock); }
void plat_audio_unlock(void) { LeaveCriticalSection(&g_alock); }

/* ---------------- save file: %APPDATA%\MelNyam\save.dat ---------------- */
static int save_path(wchar_t *out, int make_dir) {
    wchar_t base[MAX_PATH]; DWORD n = GetEnvironmentVariableW(L"APPDATA", base, MAX_PATH);
    if (n == 0 || n >= MAX_PATH - 32) { n = GetModuleFileNameW(NULL, base, MAX_PATH - 32); while (n > 0 && base[n - 1] != L'\\') n--; if (n) base[n - 1] = 0; else lstrcpyW(base, L"."); }
    lstrcpyW(out, base); lstrcatW(out, L"\\MelNyam");
    if (make_dir) CreateDirectoryW(out, NULL);
    lstrcatW(out, L"\\save.dat");
    return 1;
}
void plat_save(const void *data, int size) {
    wchar_t path[MAX_PATH + 40]; save_path(path, 1);
    HANDLE f = CreateFileW(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f == INVALID_HANDLE_VALUE) return;
    DWORD w; WriteFile(f, data, (DWORD)size, &w, NULL); CloseHandle(f);
}
int plat_load(void *data, int maxsize) {
    wchar_t path[MAX_PATH + 40]; save_path(path, 0);
    HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f == INVALID_HANDLE_VALUE) return 0;
    DWORD r = 0; ReadFile(f, data, (DWORD)maxsize, &r, NULL); CloseHandle(f);
    return (int)r;
}
/* named blobs (own replays, own levels): %APPDATA%\MelNyam\<key>.dat */
static void blob_path(wchar_t *out, const char *key, int make_dir) {
    wchar_t wk[40]; int i = 0; save_path(out, make_dir);
    int n = lstrlenW(out); while (n > 0 && out[n - 1] != L'\\') n--; out[n] = 0;
    for (; key[i] && i < 30; i++) wk[i] = (wchar_t)(unsigned char)key[i]; wk[i] = 0;
    lstrcatW(out, wk); lstrcatW(out, L".dat");
}
void plat_store(const char *key, const void *data, int size) {
    wchar_t path[MAX_PATH + 80]; blob_path(path, key, 1);
    if (size <= 0) { DeleteFileW(path); return; }
    HANDLE f = CreateFileW(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f == INVALID_HANDLE_VALUE) return;
    DWORD w; WriteFile(f, data, (DWORD)size, &w, NULL); CloseHandle(f);
}
int plat_fetch(const char *key, void *data, int maxsize) {
    wchar_t path[MAX_PATH + 80]; blob_path(path, key, 0);
    HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f == INVALID_HANDLE_VALUE) return 0;
    DWORD r = 0; ReadFile(f, data, (DWORD)maxsize, &r, NULL); CloseHandle(f);
    return (int)r;
}
u32 plat_random(void) {
    LARGE_INTEGER c; QueryPerformanceCounter(&c); FILETIME ft; GetSystemTimeAsFileTime(&ft);
    u32 h = (u32)c.LowPart * 2654435761u ^ (u32)ft.dwLowDateTime ^ (u32)GetCurrentProcessId() * 40503u ^ (u32)GetTickCount() * 2246822519u;
    h ^= h >> 15; h *= 2246822519u; h ^= h >> 13; return h;
}
/* ---------------- network: WinINet on a worker thread, the answer is posted back to the window ---------------- */
#define WM_HTTP_DONE (WM_APP + 7)
typedef struct { int id, status, n, blen, https, port; char *url, *body, *data; char host[256]; const char *path; } HttpJob;
static DWORD WINAPI http_thread(LPVOID arg) {
    HttpJob *j = (HttpJob *)arg;
    HINTERNET net = InternetOpenA("MelNyam/0.2", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
    if (net) {
        DWORD to = 12000; InternetSetOptionA(net, INTERNET_OPTION_CONNECT_TIMEOUT, &to, sizeof(to)); InternetSetOptionA(net, INTERNET_OPTION_RECEIVE_TIMEOUT, &to, sizeof(to)); InternetSetOptionA(net, INTERNET_OPTION_SEND_TIMEOUT, &to, sizeof(to));
        HINTERNET con = InternetConnectA(net, j->host, (INTERNET_PORT)j->port, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
        if (con) {
            DWORD fl = INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE | INTERNET_FLAG_NO_UI | INTERNET_FLAG_NO_COOKIES | (j->https ? INTERNET_FLAG_SECURE : 0);
            HINTERNET rq = HttpOpenRequestA(con, j->body ? "POST" : "GET", j->path, NULL, NULL, NULL, fl, 0);
            if (rq) {
                static const char hdr[] = "Content-Type: text/plain;charset=utf-8\r\n";
                if (HttpSendRequestA(rq, j->body ? hdr : NULL, j->body ? (DWORD)(sizeof(hdr) - 1) : 0, j->body, j->body ? (DWORD)j->blen : 0)) {
                    DWORD code = 0, sz = sizeof(code), got = 0; size_t cap = 1 << 15;
                    HttpQueryInfoA(rq, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &code, &sz, NULL);
                    j->data = (char *)malloc(cap);
                    while (j->data && InternetReadFile(rq, j->data + j->n, (DWORD)(cap - (size_t)j->n - 1), &got) && got > 0) {
                        j->n += (int)got; if ((size_t)j->n + 1024 > cap) { cap *= 2; char *q = (char *)realloc(j->data, cap); if (!q) break; j->data = q; }
                        if (j->n > (4 << 20)) break;
                    }
                    if (j->data) { j->data[j->n] = 0; j->status = (int)code; }
                }
                InternetCloseHandle(rq);
            }
            InternetCloseHandle(con);
        }
        InternetCloseHandle(net);
    }
    if (!PostMessageW(g_hwnd, WM_HTTP_DONE, 0, (LPARAM)j)) { free(j->data); free(j->url); free(j->body); free(j); }
    return 0;
}
void plat_http(int id, const char *url, const char *body, int body_len) {
    HttpJob *j = (HttpJob *)calloc(1, sizeof(HttpJob)); if (!j) return;
    j->id = id; j->url = _strdup(url);
    if (body) { j->body = (char *)malloc((size_t)body_len + 1); memcpy(j->body, body, (size_t)body_len); j->body[body_len] = 0; j->blen = body_len; }
    const char *p = j->url; int ok = 0;
    if (!strncmp(p, "https://", 8)) { j->https = 1; p += 8; ok = 1; } else if (!strncmp(p, "http://", 7)) { p += 7; ok = 1; }
    if (ok) {
        int i = 0; while (*p && *p != '/' && *p != ':' && *p != '?' && i < 255) j->host[i++] = *p++; j->host[i] = 0;
        j->port = j->https ? 443 : 80; if (*p == ':') { j->port = atoi(p + 1); while (*p && *p != '/' && *p != '?') p++; }
        j->path = *p ? p : "/";
        HANDLE th = CreateThread(NULL, 0, http_thread, j, 0, NULL);
        if (th) { CloseHandle(th); return; }
    }
    if (!PostMessageW(g_hwnd, WM_HTTP_DONE, 0, (LPARAM)j)) { free(j->url); free(j->body); free(j); }
}
void plat_quit(void) { PostMessageW(g_hwnd, WM_CLOSE, 0, 0); }
int plat_caps(void) { return 7; }
void plat_log(const char *s) { OutputDebugStringA(s); OutputDebugStringA("\n"); }
void plat_fullscreen(void) {
    DWORD st = (DWORD)GetWindowLongPtrW(g_hwnd, GWL_STYLE);
    if (!g_full) {
        MONITORINFO mi; mi.cbSize = sizeof(mi);
        if (GetWindowPlacement(g_hwnd, &g_wp) && GetMonitorInfoW(MonitorFromWindow(g_hwnd, MONITOR_DEFAULTTOPRIMARY), &mi)) {
            SetWindowLongPtrW(g_hwnd, GWL_STYLE, (st & ~(DWORD)WS_OVERLAPPEDWINDOW) | WS_POPUP);
            SetWindowPos(g_hwnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top, SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
            g_full = 1;
        }
    } else {
        SetWindowLongPtrW(g_hwnd, GWL_STYLE, (st & ~(DWORD)WS_POPUP) | WS_OVERLAPPEDWINDOW);
        SetWindowPlacement(g_hwnd, &g_wp);
        SetWindowPos(g_hwnd, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
        g_full = 0;
    }
}

/* ---------------- framebuffer ---------------- */
static void layout(void) {
    RECT rc; GetClientRect(g_hwnd, &rc); g_cw = rc.right; g_ch = rc.bottom;
    if (g_cw < 16 || g_ch < 9) return;
    int w = g_cw, h = (int)(g_cw * 9.0 / 16.0 + 0.5);
    if (h > g_ch) { h = g_ch; w = (int)(g_ch * 16.0 / 9.0 + 0.5); }
    g_dw = w; g_dh = h; g_dx = (g_cw - w) / 2; g_dy = (g_ch - h) / 2;
    /* Render 1:1 when it fits the budget; otherwise render every k-th line and let GDI stretch by an
       integer factor (pixel doubling stays crisp, a fractional nearest-neighbour stretch would not). */
    int k = 1; while (h / k > g_cap) k++;
    int fw = (w + k / 2) / k, fh = (h + k / 2) / k;
    if (fw < 64) fw = 64; if (fh < 36) fh = 36;
    if (fw != g_fbw || fh != g_fbh || !g_fb) {
        free(g_fb); g_fb = (u32 *)calloc((size_t)fw * fh + 16, 4); g_fbw = fw; g_fbh = fh;
        app_resize(g_fb, fw, fh);
    }
}
static void present(HDC dc) {
    if (!g_fb) return;
    BITMAPINFO bi; memset(&bi, 0, sizeof(bi));
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER); bi.bmiHeader.biWidth = g_fbw; bi.bmiHeader.biHeight = -g_fbh;
    bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
    if (g_dw == g_fbw && g_dh == g_fbh) SetDIBitsToDevice(dc, g_dx, g_dy, g_fbw, g_fbh, 0, 0, 0, g_fbh, g_fb, &bi, DIB_RGB_COLORS);
    else { SetStretchBltMode(dc, COLORONCOLOR); StretchDIBits(dc, g_dx, g_dy, g_dw, g_dh, 0, 0, g_fbw, g_fbh, g_fb, &bi, DIB_RGB_COLORS, SRCCOPY); }
}
static void paint_bars(HDC dc) {
    HBRUSH b = (HBRUSH)GetStockObject(BLACK_BRUSH); RECT r;
    if (g_dx > 0) { SetRect(&r, 0, 0, g_dx, g_ch); FillRect(dc, &r, b); SetRect(&r, g_dx + g_dw, 0, g_cw, g_ch); FillRect(dc, &r, b); }
    if (g_dy > 0) { SetRect(&r, 0, 0, g_cw, g_dy); FillRect(dc, &r, b); SetRect(&r, 0, g_dy + g_dh, g_cw, g_ch); FillRect(dc, &r, b); }
}
static void save_bmp(const char *path) {
    FILE *f = fopen(path, "wb"); if (!f) return;
    BITMAPFILEHEADER fh; BITMAPINFOHEADER ih; memset(&fh, 0, sizeof(fh)); memset(&ih, 0, sizeof(ih));
    fh.bfType = 0x4D42; fh.bfOffBits = sizeof(fh) + sizeof(ih); fh.bfSize = fh.bfOffBits + (DWORD)(g_fbw * g_fbh * 4);
    ih.biSize = sizeof(ih); ih.biWidth = g_fbw; ih.biHeight = -g_fbh; ih.biPlanes = 1; ih.biBitCount = 32; ih.biCompression = BI_RGB;
    fwrite(&fh, 1, sizeof(fh), f); fwrite(&ih, 1, sizeof(ih), f); fwrite(g_fb, 4, (size_t)g_fbw * g_fbh, f); fclose(f);
}

/* one frame: simulate + render + blit */
static void tick(void) {
    if (!g_started || !g_fb) return;
    LARGE_INTEGER now; QueryPerformanceCounter(&now);
    double dt = (double)(now.QuadPart - g_last.QuadPart) / (double)g_freq.QuadPart; g_last = now;
    if (dt > 0.1) dt = 0.1; if (dt < 0) dt = 0;
    if (g_shot) dt = 1.0 / 60.0;
    app_frame((float)dt);
    HDC dc = GetDC(g_hwnd); present(dc); ReleaseDC(g_hwnd, dc);
    LARGE_INTEGER end; QueryPerformanceCounter(&end);
    double cost = (double)(end.QuadPart - now.QuadPart) / (double)g_freq.QuadPart;
    /* adaptive render resolution: software rendering must stay well inside the frame budget */
    g_ema = g_ema * 0.95 + cost * 0.05;
    if (g_ema > 0.0125 && g_fbh > 720) { if (++g_slow > 45) { g_slow = 0; g_ema = 0.006; g_cap = g_fbh - 1; layout(); InvalidateRect(g_hwnd, NULL, FALSE); } }
    else g_slow = 0;
    g_frames++;
    if (g_shot && g_frames >= g_shot_frames) { save_bmp(g_shot); g_quit = 1; }
}

static void pointer(int type, LPARAM lp) {
    if (g_dw <= 0) return;
    float x = ((float)(short)LOWORD(lp) - (float)g_dx) * DESIGN_W / (float)g_dw, y = ((float)(short)HIWORD(lp) - (float)g_dy) * DESIGN_H / (float)g_dh;
    app_pointer(type, x, y);
}
static LRESULT CALLBACK wndproc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    switch (m) {
    case WM_SIZE: if (wp != SIZE_MINIMIZED && g_started) { layout(); InvalidateRect(h, NULL, FALSE); } return 0;
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: { PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); paint_bars(dc); present(dc); EndPaint(h, &ps); } return 0;
    case WM_ENTERSIZEMOVE: g_inmodal = 1; SetTimer(h, 1, 15, NULL); return 0;
    case WM_EXITSIZEMOVE: g_inmodal = 0; KillTimer(h, 1); return 0;
    case WM_TIMER: if (g_inmodal) tick(); return 0;
    case WM_GETMINMAXINFO: { MINMAXINFO *mi = (MINMAXINFO *)lp; mi->ptMinTrackSize.x = 480; mi->ptMinTrackSize.y = 300; } return 0;
    case WM_LBUTTONDOWN: g_down = 1; SetCapture(h); pointer(1, lp); return 0;
    case WM_MOUSEMOVE:
        if (!g_tracking) { TRACKMOUSEEVENT t; t.cbSize = sizeof(t); t.dwFlags = TME_LEAVE; t.hwndTrack = h; t.dwHoverTime = 0; if (TrackMouseEvent(&t)) g_tracking = 1; }
        pointer(0, lp); return 0;
    case WM_MOUSELEAVE: g_tracking = 0; if (!g_down) app_pointer(0, -1000.0f, -1000.0f); return 0;
    case WM_LBUTTONUP: if (g_down) { g_down = 0; pointer(2, lp); } ReleaseCapture(); return 0;
    case WM_CAPTURECHANGED: if (g_down) { g_down = 0; app_pointer(2, -1000.0f, -1000.0f); } return 0;   /* e.g. Alt+Tab while dragging */
    case WM_SYSKEYDOWN: if (wp == VK_RETURN && (lp & (1 << 29))) { plat_fullscreen(); return 0; } break;
    case WM_KEYDOWN: case WM_KEYUP: {
        int k = 0, down = (m == WM_KEYDOWN);
        switch (wp) {
        case VK_ESCAPE: k = KEY_ESC; break; case VK_RETURN: k = KEY_ENTER; break; case VK_SPACE: k = KEY_SPACE; break;
        case 'R': k = KEY_R; break; case 'M': k = KEY_M; break; case 'F': case VK_F11: k = KEY_F; break;
        case VK_LEFT: k = KEY_LEFT; break; case VK_RIGHT: k = KEY_RIGHT; break;
        case VK_BACK: k = KEY_BACKSPACE; break; case VK_UP: k = KEY_UP; break; case VK_DOWN: k = KEY_DOWN; break; case VK_DELETE: k = KEY_DELETE; break;
        }
        if (down && (lp & (1 << 30)) && k != KEY_BACKSPACE && k != KEY_LEFT && k != KEY_RIGHT) return 0;      /* ignore auto-repeat (except while editing text) */
        if (k) app_key(k, down);
    } return 0;
    case WM_CHAR: {                                      /* typed text: nick, level name */
        static u32 hi; u32 c = (u32)wp;
        if (c >= 0xD800 && c < 0xDC00) { hi = c; return 0; }
        if (c >= 0xDC00 && c < 0xE000) { c = hi ? 0x10000u + ((hi - 0xD800u) << 10) + (c - 0xDC00u) : 0; hi = 0; }
        if (c >= 32 && c != 127) app_char(c);
    } return 0;
    case WM_HTTP_DONE: {
        HttpJob *j = (HttpJob *)lp;
        app_http(j->id, j->status, j->data ? j->data : "", j->n);
        free(j->data); free(j->url); free(j->body); free(j);
    } return 0;
    case WM_CLOSE: DestroyWindow(h); return 0;
    case WM_DESTROY: g_quit = 1; PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h, m, wp, lp);
}

int WINAPI WinMain(HINSTANCE inst, HINSTANCE prev, LPSTR cmd, int show) {
    (void)prev;
    /* hidden test switch:  MelNyam.exe --shot out.bmp 120  (render N frames, dump one, exit) */
    static char shotpath[MAX_PATH];
    if (cmd && strncmp(cmd, "--shot ", 7) == 0) { int n = 90; if (sscanf(cmd + 7, "%259s %d", shotpath, &n) >= 1) { g_shot = shotpath; g_shot_frames = n; } }

    HMODULE u32dll = GetModuleHandleW(L"user32.dll");
    if (u32dll) { typedef BOOL (WINAPI *dpi_fn)(void); dpi_fn f = (dpi_fn)(void *)GetProcAddress(u32dll, "SetProcessDPIAware"); if (f) f(); }
    InitializeCriticalSection(&g_alock);

    HRSRC rs = FindResourceW(inst, MAKEINTRESOURCEW(ID_PACK), (LPCWSTR)RT_RCDATA);
    HGLOBAL rh = rs ? LoadResource(inst, rs) : NULL;
    const u8 *pack = rh ? (const u8 *)LockResource(rh) : NULL; DWORD packsize = rs ? SizeofResource(inst, rs) : 0;
    if (!pack || packsize < 16) { MessageBoxW(NULL, L"Не найдены ресурсы игры (pack).", L"Мел-Ням", MB_ICONERROR); return 1; }

    WNDCLASSEXW wc; memset(&wc, 0, sizeof(wc));
    wc.cbSize = sizeof(wc); wc.style = CS_OWNDC; wc.lpfnWndProc = wndproc; wc.hInstance = inst;
    wc.hCursor = LoadCursorW(NULL, (LPCWSTR)IDC_ARROW); wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(1)); wc.hIconSm = wc.hIcon;
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH); wc.lpszClassName = L"MelNyamWindow";
    RegisterClassExW(&wc);

    RECT wa; SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
    int aw = wa.right - wa.left, ah = wa.bottom - wa.top, cw = 1280, ch = 720;
    static const int sizes[5][2] = { { 1920, 1080 }, { 1600, 900 }, { 1280, 720 }, { 1024, 576 }, { 800, 450 } };
    for (int i = 0; i < 5; i++) { cw = sizes[i][0]; ch = sizes[i][1]; if (cw <= aw * 0.92 && ch <= ah * 0.88) break; }
    if (g_shot) { cw = 1280; ch = 720; }
    DWORD style = WS_OVERLAPPEDWINDOW; RECT r = { 0, 0, cw, ch }; AdjustWindowRectEx(&r, style, FALSE, 0);
    int ww = r.right - r.left, wh = r.bottom - r.top;
    g_hwnd = CreateWindowExW(0, wc.lpszClassName, L"\x041C\x0435\x043B-\x041D\x044F\x043C", style, wa.left + (aw - ww) / 2, wa.top + (ah - wh) / 2 > 0 ? wa.top + (ah - wh) / 2 : 0, ww, wh, NULL, NULL, inst, NULL);
    if (!g_hwnd) return 1;

    app_init(pack, (int)packsize, 44100);
    g_started = 1; layout();
    if (cmd && strncmp(cmd, "--demotest ", 11) == 0) {      /* hidden self-test: replay the stored solution of every level */
        FILE *f = fopen(cmd + 11, "w"); int bad = 0, count = app_debug(28, 0);
        for (int lv = 0; lv < count; lv++) {
            app_debug(2, lv); int res = 0, stars = 0, need = app_debug(25, lv);
            for (int i = 0; i < 60 * 40; i++) { app_frame(1.0f / 60.0f); int st = app_debug(4, 0); if (st & 15) { res = st & 15; stars = (st >> 4) & 15; break; } }
            if (f) fprintf(f, "level %2d: result=%d stars=%d/%d\n", lv + 1, res, stars, need);
            if (res != 1 || stars != need) bad++;
        }
        if (f) { fprintf(f, "demotest: %d levels, %d bad\n", count, bad); fclose(f); }
        return bad;
    }
    if (cmd && strncmp(cmd, "--simhash ", 10) == 0) {       /* hidden self-test: the physics must give the same numbers as every other build */
        FILE *f = fopen(cmd + 10, "w"); int count = app_debug(28, 0);
        if (f) { fprintf(f, "sim %d\n", app_debug(31, 0)); for (int lv = 0; lv < count; lv++) fprintf(f, "%d %d\n", lv, app_debug(30, lv)); fclose(f); }
        return 0;
    }
    if (cmd && strncmp(cmd, "--http ", 7) == 0) {           /* hidden self-test of the network layer:  --http OUTFILE URL [FILE WITH THE POST BODY]  */
        static char out[MAX_PATH], url[2048], bfile[MAX_PATH], body[16384]; body[0] = 0;
        int na = sscanf(cmd + 7, "%259s %2047s %259s", out, url, bfile);
        if (na >= 3) { FILE *bf = fopen(bfile, "rb"); size_t n = bf ? fread(body, 1, sizeof(body) - 1, bf) : 0; body[n] = 0; if (bf) fclose(bf); }
        if (na >= 2) {
            app_debug(90, 1);                               /* the game writes the next answer into its debug buffer */
            plat_http(9000, url, na >= 3 ? body : NULL, (int)strlen(body));
            DWORD t0 = GetTickCount(); MSG msg;
            while (!app_debug(91, 0) && GetTickCount() - t0 < 20000) { while (PeekMessageW(&msg, NULL, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); } Sleep(10); }
            FILE *f = fopen(out, "wb");
            if (f) { int n = app_debug(92, 0); fprintf(f, "status %d size %d\n", app_debug(91, 0) - 1, n); for (int i = 0; i < n; i++) fputc(app_debug(93, i), f); fclose(f); }
        }
        return 0;
    }
    { static char api[1024]; DWORD n = GetEnvironmentVariableA("MELNYAM_API", api, sizeof(api)); if (n > 0 && n < sizeof(api)) app_text(1, api); }     /* tests: another address of the online table */
    if (cmd && strncmp(cmd, "--selftest ", 11) == 0) {       /* hidden self-test: two real runs, their recordings, the save files and the records table */
        FILE *f = fopen(cmd + 11, "w"); MSG msg;
        app_text(2, "Тест_exe");
        for (int lv = 0; lv < 2; lv++) { app_debug(34, lv); for (int i = 0; i < 60 * 9; i++) { app_frame(1.0f / 60.0f); while (PeekMessageW(&msg, NULL, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); } } }
        for (int i = 0; i < 400; i++) { app_frame(1.0f / 60.0f); while (PeekMessageW(&msg, NULL, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); } Sleep(10); if (app_debug(99, 1) >= 2) break; }
        app_debug(105, 0);
        for (int i = 0; i < 400; i++) { app_frame(1.0f / 60.0f); while (PeekMessageW(&msg, NULL, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); } Sleep(10); if (((app_debug(95, 0) >> 8) & 15) >= 2) break; }
        if (f) { int r = app_debug(95, 0); fprintf(f, "net %d sent %d rows %d mine %d replay0 %d replay1 %d stars %d\n", app_debug(94, 0), app_debug(99, 1), r & 255, (r >> 12) - 1, app_debug(111, 0), app_debug(111, 1), app_debug(9, 0)); fclose(f); }
        return 0;
    }
    if (!g_shot) audio_start();
    ShowWindow(g_hwnd, show ? show : SW_SHOW); UpdateWindow(g_hwnd);

    DEVMODEW dm; memset(&dm, 0, sizeof(dm)); dm.dmSize = sizeof(dm);
    double hz = 60.0; if (EnumDisplaySettingsW(NULL, ENUM_CURRENT_SETTINGS, &dm) && dm.dmDisplayFrequency >= 50 && dm.dmDisplayFrequency <= 240) hz = (double)dm.dmDisplayFrequency;
    if (hz > 144.0) hz = 144.0;
    double target = 1.0 / hz;
    HMODULE dwm = LoadLibraryW(L"dwmapi.dll");
    if (dwm) g_dwmflush = (dwmflush_fn)(void *)GetProcAddress(dwm, "DwmFlush");
    timeBeginPeriod(1);
    QueryPerformanceFrequency(&g_freq); QueryPerformanceCounter(&g_last);
    LARGE_INTEGER next = g_last;
    while (!g_quit) {
        MSG msg;
        while (PeekMessageW(&msg, NULL, 0, 0, PM_REMOVE)) { if (msg.message == WM_QUIT) g_quit = 1; TranslateMessage(&msg); DispatchMessageW(&msg); }
        if (g_quit) break;
        if (IsIconic(g_hwnd)) { g_silent = 1; Sleep(40); QueryPerformanceCounter(&g_last); next = g_last; continue; }
        g_silent = 0;
        LARGE_INTEGER fstart; QueryPerformanceCounter(&fstart);
        tick();
        if (g_shot) continue;
        /* Frame pacing. Preferred: block in DwmFlush() until the desktop compositor has shown the frame, which
           locks the loop to the real refresh rate. If that call is missing or returns at once (no compositor,
           Wine), fall back to a timer: sleep until the next 1/refresh slot. */
        LARGE_INTEGER now;
        if (g_dwmflush) {
            LARGE_INTEGER a; QueryPerformanceCounter(&a);
            HRESULT hr = g_dwmflush();
            QueryPerformanceCounter(&now);
            double waited = (double)(now.QuadPart - a.QuadPart) / (double)g_freq.QuadPart;
            if (SUCCEEDED(hr) && waited >= 0.001 && waited < 0.25) {
                /* very fast displays (240 Hz and up): no need to redraw more than ~165 times a second */
                for (int i = 0; i < 3 && (double)(now.QuadPart - fstart.QuadPart) / (double)g_freq.QuadPart < 0.0059; i++) { g_dwmflush(); QueryPerformanceCounter(&now); }
                g_dwm_miss = 0; next = now; continue;
            }
            if (FAILED(hr) || ++g_dwm_miss > 600) g_dwmflush = NULL;
        }
        next.QuadPart += (LONGLONG)(target * (double)g_freq.QuadPart);
        QueryPerformanceCounter(&now);
        if (now.QuadPart > next.QuadPart) next = now;
        else {
            double left = (double)(next.QuadPart - now.QuadPart) / (double)g_freq.QuadPart;
            if (left > 0.002) Sleep((DWORD)((left - 0.0015) * 1000.0));
            for (;;) { QueryPerformanceCounter(&now); if (now.QuadPart >= next.QuadPart) break; Sleep(0); }
        }
    }
    timeEndPeriod(1);
    audio_stop();
    return 0;
}
