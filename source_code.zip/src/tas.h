/* TAS search: looks for the fastest full-star run of a level.
   It works on the bare simulation (sim.c), so its answer is an ordinary recording that the game can replay.

   How it searches
     1. Every known full-star run (the stored solution, the player's own recording) is a starting point.
     2. "Wave" search: all states the bottle can be in are expanded tick by tick, every possible action at every tick.
        States that fall into the same small cell (position, speed, what is cut / collected / switched) are kept once,
        the earliest arrival wins. The cells get finer from pass to pass. With cells of size zero (exact mode) the
        wave visits every reachable state: if such a pass finishes, no faster run exists at all.
     3. Every run that the wave finds is polished tick by tick: each action is moved, removed, retargeted,
        new actions are inserted, pairs of actions are moved together - until nothing makes the run shorter.
     4. The rest of the budget goes into random "kicks" of the best run followed by the same polishing.

   The work is cut into small portions (tas_work), so the game can draw a progress bar between them. */
#ifndef MN_TAS_H
#define MN_TAS_H
#include "sim.h"

#define TAS_MAXA 1500                                 /* actions in one run (as many as a recording of the game can hold) */
typedef struct { int n, ticks; u32 a[TAS_MAXA]; } TasPlan;      /* a[i] = tick << 15 | action << 12 | argument (the replay format) */

typedef struct {
    long long units;          /* budget: simulation ticks to spend */
    int frontier;             /* states kept per tick of the wave */
    int closed_log2;          /* log2 of the cell table size */
    int nodes_log2;           /* log2 of the action tree size */
    int res_first, res_last;  /* wave passes: cell sizes from coarse (0) to fine (TAS_RES_N - 1) */
    int exact;                /* 1: try the exhaustive pass as well */
    int suffix;               /* bit f (1..7): one more group of passes that starts at f/8 of the best run */
    int ins_step;             /* polishing tries a new action at every ins_step-th tick (1 = at every tick) */
    int fmem;                 /* at most this many bytes for one tick of the wave (0: no limit) */
    int verbose;
} TasCfg;
#define TAS_RES_N 11

typedef struct Tas Tas;
void  tas_cfg_game(TasCfg *c);                        /* what the game uses for levels made by players */
Tas  *tas_new(const LObj *objs, const TasCfg *cfg);   /* NULL: out of memory */
void  tas_seed(Tas *t, const u32 *a, int n);          /* a known full-star run; call before the first tas_work */
int   tas_work(Tas *t, long long units);              /* spend about that many ticks; 0 when the search is over */
float tas_progress(const Tas *t);                     /* 0..1 */
long long tas_tried(const Tas *t);                    /* runs and states examined so far */
const TasPlan *tas_best(const Tas *t);                /* NULL: no full-star run is known */
int   tas_proved(const Tas *t);                       /* 1: the exhaustive pass has finished, nothing faster exists */
void  tas_stats(const Tas *t, char *out, int max);
void  tas_free(Tas *t);
int   tas_check(const LObj *objs, const u32 *a, int n);   /* the real simulation: ticks of a full-star win, 0 otherwise */
int   tas_selftest(const LObj *objs, int rounds);         /* tools only (TAS_TOOLS) */

#endif
